/* W11: inspectable component-built rivals, mirrored head-to-head club rounds,
 * finishing-order standings, funded awards and bounded progression.
 * Authored RRR sporting format, not claimed to be Gaiden's exact tournament rules. */
(function(root){'use strict';
const R=root.RRRRace||(typeof require==='function'?require('./race.js'):null);
const C=root.RRRCatalog||(typeof require==='function'?require('./catalog.js'):null);
const H=root.RRRHosts||(typeof require==='function'?require('./hosts.js'):null);
const B=root.RRRBench||(typeof require==='function'?require('./bench.js'):null);
const X=root.RRRCircuits||(typeof require==='function'?require('./circuits.js'):null);
const cp=B.copy, key=B.canonical, need=(c,m)=>{if(!c)throw Error(m);};
const DEFINITIONS=[
 {id:'seam',owner:'Ivo Pell',name:'SEAMSTRESS',body:'needleback',number:'14',colour:'ivory',approach:'clean',leverage:1,
  products:['redline','sticktoe','gyropods'],genes:[[0,1],[0,1],[0,1]],
  purpose:'Clean release and fast correction. The legs must disengage fast enough to use the drive.',target:{kind:'stick',trait:'release',op:'max',threshold:.045},route:'stick'},
 {id:'hopper',owner:'Jess Rill',name:'THIRD NOTICE',body:'lowline',number:'03',colour:'ochre',approach:'hopper',leverage:.9,
  products:['hoppers','redline','fatbody','keel'],genes:[[0,1],[1,1],[0,1]],
  purpose:'Matched takeoff and controlled recovery. Supply, launch tissue and rebound tissue are distinct.',target:{kind:'hopper',trait:'phase',op:'max',threshold:.07},route:'verge'},
 {id:'load',owner:'Cinderhouse club team',name:'BOLT MUNCHER',body:'broadback',number:'28',colour:'ochre',approach:'clean',leverage:.75,
  products:['torque','lowstep','cleats','boxbrace'],genes:[[0,1],[0,1],[1,1]],
  purpose:'Usable thrust and loose-ground feet under a supported heavy body. More leverage is not always faster.',target:{kind:'mole',trait:'roughGrip',op:'min',threshold:1.4},route:'mole'},
 {id:'ram',owner:'Mara Venn',name:'HORN TAX',body:'lowline',number:'09',colour:'vermilion',approach:'charge',leverage:.85,
  products:['torque','bullhorn','sticktoe'],genes:[[0,1],[0,1],[1,1]],
  purpose:'Forceful aligned charges. Horn geometry only works when the roach reaches contact.',target:{kind:'horn',trait:'impact',op:'min',threshold:1},route:'horn'},
 {id:'claw',owner:'Saltglass club team',name:'COUNTEROFFER',body:'lowline',number:'21',colour:'ivory',approach:'counter',leverage:1,
  products:['redline','catchclaws','sticktoe'],genes:[[0,1],[1,1],[0,1]],
  purpose:'Fast closure at working reach. Interception is an action with timing, not passive armor.',target:{kind:'mantis',trait:'closure',op:'max',threshold:.125},route:'mantis'},
 {id:'flash',owner:'Tinwater independent',name:'FLASHLEG',body:'needleback',number:'07',colour:'ochre',approach:'charge',leverage:.9,
  products:['redline','bullhorn','gyropods'],genes:[[0,1],[0,1],[0,1]],
  purpose:'A narrow passing body with a forward attack. The same drive supplies racing and contact.',target:{kind:'cicada',trait:'cadence',op:'min',threshold:10.5},route:'kiln'}
];
const EVENTS=[
 {id:'first',name:'First Current',tag:'LOCAL · OPEN QUALIFIER',equipment:'open',roster:['seam','ram','hopper'],straight:14,laps:2,surface:'smooth',fee:6,purse:[60,24,12,0],grant:'local_open',requires:null,editionLimit:3,
  purpose:'The first official Open circuit title. Win the meet to earn an invitation to the Regional trial.'},
 {id:'glass',name:'Glassline Dash',tag:'LOCAL · SPEEDSTERS',equipment:'speedsters',roster:['seam','hopper','load'],straight:20,laps:2,surface:'smooth',fee:6,purse:[48,20,8,0],grant:'local_speedsters',requires:null,editionLimit:3,
  purpose:'Weapon-free builds, real contact and legal Hoppers. Raw pace, release and reserve matter.'},
 {id:'sparks',name:'Sparks at Sundown',tag:'LOCAL · FIREWORKS',equipment:'fireworks',roster:['ram','claw','flash'],straight:12,laps:2,surface:'rough',fee:6,purse:[54,22,10,0],grant:null,requires:null,editionLimit:3,
  purpose:'Working offense and light carapace. Win by finishing races, not by attack count.'},
 {id:'regional',name:'Ballast Regional Trial',tag:'REGIONAL · OPEN',equipment:'open',roster:['seam','load','claw'],straight:16,laps:3,surface:'dust',fee:8,purse:[76,30,14,0],grant:'regional_open',requires:'local_open',editionLimit:3,
  purpose:'A longer loose-surface circuit. A win records Regional completion; Factional racing is not implemented.'},
 {id:'home',name:'Your Circuit Invitational',tag:'EXHIBITION · YOUR LAID COURSE',equipment:'open',roster:['seam','ram','hopper'],fee:6,purse:[36,16,8,0],grant:null,requires:null,editionLimit:2,
  purpose:'Host real races on the frozen version of your owned layout. Custom geometry never grants a championship qualifier.'}
];
const PAIRINGS=[[[0,1],[2,3]],[[0,2],[3,1]],[[0,3],[1,2]]];
function makeSpec(id,kind,genes,owner,plan){return{id,kind,genes:cp(genes),sex:'A',owner,bodyPlan:plan||'lowline',stage:'adult',origin:'W11 declared club stock / '+owner,parents:[],alive:true,measured:true,protected:true,anatomy:true,regions:Object.fromEntries(C.regions(kind).map(r=>[r,'intact'])),schedule:[],condition:'intact',appearance:C.FORMS[kind].sign,born:0,brood:null};}
function makeRival(d){
 const owner='npc_'+d.id,host=makeSpec('W11.NPC.'+d.id+'.HOST','roach',[[0,1],[0,1],[0,1]],owner,d.body),profile=H.profile(host),donors=[],parts=[];
 for(let i=0;i<d.products.length;i++){
  const product=d.products[i],kind=Object.keys(C.FORMS).find(k=>C.FORMS[k].products.includes(product));
  const s=makeSpec(`W11.NPC.${d.id}.DONOR.${i}`,kind,d.genes,owner);s.stage=C.PRODUCTS[product].stages[0];
  const p={id:`W11.NPC.${d.id}.PART.${i}`,product,donor:s.id,kind:C.PRODUCTS[product].kind,owner,created:0};
  for(const a of C.PRODUCTS[product].regions)s.regions[a]=p.id;
  if(C.PRODUCTS[product].vital)s.alive=false;
  p.snapshot=C.descriptor(s,p,B.BASE);donors.push(s);parts.push(p);
 }
 // The same catalogue and fitting/compiler are used by the player. No private stat multipliers.
 B.setExtras(parts.map(p=>p.snapshot));
 const bench=B.initialHost(profile,d.name);bench.draft.number=d.number;bench.draft.livery=d.colour;bench.draft.approach=d.approach;bench.draft.tuning.leverage=d.leverage;bench.draft.tuning.preload=.45;
 for(const p of parts)bench.draft.placements.push({id:p.id,...cp(p.snapshot.default)});
 const errors=B.fitting(bench.draft,profile);need(!errors.length,d.name+': '+errors.map(x=>x.message).join('; '));
 const fitted=B.commit(bench),build=B.compile(fitted.fitted,fitted.revision,profile);
 return{...cp(d),ownerAccount:owner,host,donors,parts,bench:fitted,build,policy:B.policy(fitted.fitted)};
}
function init(w){if(w.club)return;const roster=DEFINITIONS.map(makeRival);w.club={schema:'W11.CLUB.1',roster,active:null,history:[],editions:Object.fromEntries(EVENTS.map(e=>[e.id,0])),badges:[],trophies:[],tickets:[],next:1};
 // Finite operating grant; external counter-account keeps the inherited closed ledger invariant.
 w.accounts.club=1440;w.accounts.external-=1440;for(const r of roster)w.accounts[r.ownerAccount]=0;
 w.ledger.push({tick:w.tick,from:'external',to:'club',amount:1440,reason:'W11 finite club-meet operating grant; not player earnings',ref:'W11.CLUB.SEED'});
 // Two alternate, real donor pairs. Only one can be claimed for the first qualifying victory.
 for(const [kind,genes] of [['hopper',[[1,1],[0,1],[0,1]]],['stick',[[0,1],[1,1],[0,1]]]])for(const sex of ['A','B']){
  const s=makeSpec(`W11.AWARD.${kind}.${sex}`,kind,genes,'club');s.sex=sex;s.origin='Foundry award nursery / finite declared stock';w.specimens.push(s);
 }
}
function extras(w){return (w.club?.roster||[]).flatMap(r=>r.parts.map(p=>p.snapshot));}
function eventBy(id){const e=EVENTS.find(e=>e.id===id);need(e,'Unknown meet');return e;}
function rosterBy(w,id){const n=w.club.roster.find(n=>n.id===id);need(n,'Unknown club racer');return n;}
function courseFor(w,e){
 if(e.id==='home'){const s=X.active(w.trackworks);return{origin:'player',version:s.id,name:s.name,fingerprint:s.fingerprint,course:cp(s.course)};}
 const c=R.foundryCourse(e.straight,e.laps).data();c.id=`W11.COURSE.${e.id}.1`;
 if(e.surface==='dust')for(const p of c.pieces){p.surface='loose';p.grip=1.3;p.resistance=.18;}
 if(e.surface==='rough')for(const [i,p]of c.pieces.entries())if(!p.curvature&&i%2===0)p.bump=1;
 new R.Course(c);return{origin:'club',version:c.id,name:e.name+' / advertised course',fingerprint:key(c),course:c};
}
function snapshot(w){const b=w.bench;need(key(b.draft)===key(b.fitted),'Fit or discard the draft before registering an entry');return B.compile(b.fitted,b.revision,b.host_profile);}
function status(w,e){const a=[];if(w.club.active)a.push('Finish or withdraw from the current meet');if(e.requires&&!w.club.badges.some(b=>b.code===e.requires))a.push('Win First Current to earn the Local Open invitation');if(w.club.editions[e.id]>=e.editionLimit)a.push('Finite sponsored editions exhausted; practice remains available');if(e.id==='home'&&!w.trackworks.active)a.push('Lay a valid owned circuit first');if(w.accounts.club<e.purse.reduce((a,b)=>a+b,0))a.push('Club purse not funded');return a;}
function register(w,cmd,o){const e=eventBy(cmd.event),blocked=status(w,e);need(!blocked.length,blocked[0]);need(w.club.history.length<40,'Local meet archive is full');const build=snapshot(w);need(!o.parentBusy(w,build.host_id),'This racer is occupied by reproduction');need(R.legal(build,e.equipment),'Fitted anatomy does not meet this equipment policy');need(o.spendable(w)>=e.fee+6+o.forecast(w,6).cashCost,'Reserve registration, three service rounds and six turns of care');
 const id=`W11.MEET.${w.club.next++}`,purse=e.purse.reduce((a,b)=>a+b,0);o.transfer(w,'player','services',e.fee,'Club registration',id);o.transfer(w,'club','escrow',purse,'Reserve complete advertised purse',id);
 const frozen=courseFor(w,e),entrants=[{id:build.host_id,name:build.name,account:'player',rival:null,build:cp(build),policy:B.policy(w.bench.fitted)},...e.roster.map(rid=>{const r=rosterBy(w,rid);return{id:r.host.id,name:r.name,account:r.ownerAccount,rival:rid,build:cp(r.build),policy:cp(r.policy)};})];
 w.club.editions[e.id]++;w.club.active={id,eventId:e.id,edition:w.club.editions[e.id],registeredAt:w.tick,hostId:build.host_id,course:frozen,equipment:e.equipment,purse:cp(e.purse),escrow:purse,entrants,rounds:[],round:0,pending:null,state:'entered'};return id;}
function requestsFor(w,m){const build=snapshot(w);need(build.host_id===m.hostId,'Select the registered host before the next round');need(R.legal(build,m.equipment),'Revised fit does not meet this meet policy');const entrants=cp(m.entrants);entrants[0].build=build;entrants[0].name=build.name;entrants[0].policy=B.policy(w.bench.fitted);
 return PAIRINGS[m.round].flatMap((pair,pairIndex)=>[0,1].map(leg=>{const es=pair.map((i,j)=>({build:cp(entrants[i].build),policy:cp(entrants[i].policy),d:(j===0?-.34:.34)*(leg===0?1:-1)}));if(leg===1)es.reverse();return{course:cp(m.course.course),entrants:es,equipment:m.equipment,dt:.01,metadata:{meet_id:m.id,round:m.round,leg,pair:cp(pair),pairIndex,build_revision:w.bench.revision,host_id:m.hostId,design:cp(w.bench.fitted),course_label:m.course.name,course_version:m.course.version,practice:false,world_clock_integrated:true,attendance_turns:2}};}));}
function start(w,o){const m=w.club.active;need(m&&!m.pending&&m.round<3,'No round ready');need(!o.parentBusy(w,m.hostId),'The entered host is busy');need(o.spendable(w)>=2+o.forecast(w,2).cashCost,'Need round service and care');const requests=requestsFor(w,m),id=m.id+'.ROUND.'+m.round;m.pending={id,requests,startedAt:w.tick};return cp(m.pending);}
function validRows(q,run){need(run&&Array.isArray(run.results)&&run.results.length===2,'Expected two actual result rows');need(key(run.course)===key(new R.Course(q.course).data())&&run.equipment===q.equipment,'Result uses another course or class');
 for(const e of q.entrants){const rows=run.results.filter(r=>r.host_id===e.build.host_id);need(rows.length===1&&key(rows[0].build)===key(e.build),'Result does not match frozen build');const r=rows[0],g=new R.Course(q.course).gates.length;need(r.required_gates===g&&Number.isInteger(r.gates)&&r.gates>=0&&r.gates<=g,'Invalid gate count');need(r.finish_time===null||(Number.isFinite(r.finish_time)&&r.finish_time>=0&&r.finish_time<=181&&r.gates===g),'No valid course completion');}
}
function scoreRows(rows){const finished=rows.filter(r=>r.finish_time!==null);if(finished.length===0)return Object.fromEntries(rows.map(r=>[r.host_id,0]));if(finished.length===1)return Object.fromEntries(rows.map(r=>[r.host_id,r.finish_time!==null?3:0]));const tied=Math.abs(rows[0].finish_time-rows[1].finish_time)<=1e-7;return Object.fromEntries(rows.map(r=>[r.host_id,tied?1:r.finish_time===Math.min(...finished.map(x=>x.finish_time))?3:0]));}
function standings(m){const rows=m.entrants.map(e=>({id:e.id,name:e.name,account:e.account,points:0,wins:0,finishes:0,heats:0,rank:null}));for(const round of m.rounds)for(const heat of round.heats){const scores=scoreRows(heat.results);for(const result of heat.results){const row=rows.find(r=>r.id===result.host_id);row.heats++;row.points+=scores[row.id];row.wins+=scores[row.id]===3?1:0;row.finishes+=result.finish_time!==null?1:0;}}
 rows.sort((a,b)=>b.points-a.points||b.finishes-a.finishes||a.id.localeCompare(b.id));let prior=null;rows.forEach((r,i)=>{r.rank=r.finishes?(prior&&prior.points===r.points&&prior.finishes===r.finishes?prior.rank:i+1):null;prior=r;});return rows;}
function closeMeet(w,m,o){const e=eventBy(m.eventId),table=standings(m),payments=[];for(const rank of [...new Set(table.filter(r=>r.rank!==null).map(r=>r.rank))]){const group=table.filter(r=>r.rank===rank),slots=m.purse.slice(rank-1,rank-1+group.length),amount=Math.floor(slots.reduce((a,b)=>a+b,0)/group.length);for(const r of group){if(amount){o.transfer(w,'escrow',r.account,amount,'Club finish-order award',m.id);m.escrow-=amount;}payments.push({hostId:r.id,rank,amount});}}
 if(m.escrow){o.transfer(w,'escrow','club',m.escrow,'Unawarded purse returned',m.id);m.escrow=0;}
 const me=table.find(r=>r.id===m.hostId),champion=me.rank===1&&me.wins>=3;
 if(champion){w.club.trophies.push({id:m.id+'.TROPHY',event:e.name,meetId:m.id,hostId:m.hostId,hostName:m.entrants[0].name,courseVersion:m.course.version,turn:w.tick,joint:table.filter(r=>r.rank===1).length>1});
 if(e.grant&&!w.club.badges.some(b=>b.code===e.grant)){w.club.badges.push({code:e.grant,meetId:m.id,hostId:m.hostId,turn:w.tick});if(e.grant==='local_open')w.club.tickets.push({id:m.id+'.STOCK',meetId:m.id,state:'ready',choices:['hopper','stick'],claimed:null});}}
 m.state='complete';m.completedAt=w.tick;m.table=table;m.payments=payments;m.champion=champion;w.club.history.push(cp(m));w.club.active=null;o.settleCare(w);return{meetId:m.id,table:cp(table),payments,champion,qualification:champion?e.grant:null};}
function finish(w,cmd,o){const m=w.club.active;need(m&&m.pending&&m.pending.id===cmd.id,'No matching pending round');need(Array.isArray(cmd.runs)&&cmd.runs.length===4,'Four mirrored pair results required');for(let i=0;i<4;i++)validRows(m.pending.requests[i],cmd.runs[i]);
 o.pay(w,2,'Club round service / declared reserve preparation',cmd.id);o.step(w,2);const heats=cmd.runs.map((run,i)=>({id:cmd.id+'.HEAT.'+i,request:cp(m.pending.requests[i]),results:cp(run.results),events:cp(run.events.filter(e=>['overtake','horn_contact','grasp','takeoff','landing','finish','course_out'].includes(e.kind)).slice(-60))}));
 m.entrants[0].build=cp(m.pending.requests[0].entrants[0].build);m.entrants[0].name=m.entrants[0].build.name;m.rounds.push({id:cmd.id,at:w.tick,heats});m.pending=null;m.round++;m.state=m.round===3?'settling':'between_rounds';if(m.round===3)return closeMeet(w,m,o);return{meetId:m.id,round:m.round,table:standings(m)};}
function withdraw(w,o){const m=w.club.active;need(m&&!m.pending,'Finish or cancel computation before withdrawal');if(m.escrow)o.transfer(w,'escrow','club',m.escrow,'Withdrawn meet / remaining purse released',m.id);m.escrow=0;m.state='withdrawn';m.table=standings(m);m.completedAt=w.tick;w.club.history.push(cp(m));w.club.active=null;return m.id;}
function claim(w,cmd,o){const t=w.club.tickets.find(t=>t.id===cmd.id);need(t&&t.state==='ready'&&t.choices.includes(cmd.kind),'No such unclaimed stock award');need(o.occupied(w)+2<=w.capacity.holding,'Make two actual holding places before claiming; the award remains reserved');const ids=['A','B'].map(s=>`W11.AWARD.${cmd.kind}.${s}`);for(const id of ids)need(w.specimens.some(s=>s.id===id&&s.owner==='club'&&s.alive),'Award stock unavailable');for(const id of ids){const s=w.specimens.find(s=>s.id===id);s.owner='player';s.protected=true;}t.state='claimed';t.claimed=ids;t.claimedAt=w.tick;return cp(ids);}
function dispatch(w,cmd,o){init(w);switch(cmd.type){case'clubEnter':return register(w,cmd,o);case'clubStart':return start(w,o);case'clubFinish':return finish(w,cmd,o);case'clubCancel':need(w.club.active?.pending,'No calculation to cancel');w.club.active.pending=null;return null;case'clubWithdraw':return withdraw(w,o);case'clubClaim':return claim(w,cmd,o);default:throw Error('Unknown club command');}}
function validate(w){const c=w.club;need(c&&c.schema==='W11.CLUB.1','Missing club state');need(c.roster.length===DEFINITIONS.length&&c.history.length<=40,'Invalid club archive');need(Object.keys(c.editions).length===EVENTS.length,'Bad edition registry');for(const e of EVENTS)need(Number.isSafeInteger(c.editions[e.id])&&c.editions[e.id]>=0&&c.editions[e.id]<=e.editionLimit,'Invalid edition count');
 const seenRoster=new Set();for(const r of c.roster){
 need(!seenRoster.has(r.id),'Duplicate rival identity');seenRoster.add(r.id);
 const d=DEFINITIONS.find(x=>x.id===r.id);need(d&&r.ownerAccount==='npc_'+r.id&&r.host.id===`W11.NPC.${r.id}.HOST`,'Invalid rival owner');
 need(key(r.host.genes)===key([[0,1],[0,1],[0,1]])&&r.host.bodyPlan===d.body,'Altered native rival profile');
 need(r.parts.length===d.products.length&&r.donors.length===r.parts.length,'Invalid rival stock');
 for(const [i,p]of r.parts.entries()){const donor=r.donors[i];need(p.product===d.products[i]&&p.donor===donor.id&&p.owner===r.ownerAccount,'Rival product identity drift');need(key(donor.genes)===key(d.genes),'Rival genetics drift');need(key(C.descriptor(donor,p,B.BASE))===key(p.snapshot),'Rival measurements differ from anatomy');}
 need(key(B.compile(r.bench.fitted,r.bench.revision,r.bench.host_profile))===key(r.build),'Rival is not compiled from its components');
 need(key(B.policy(r.bench.fitted))===key(r.policy),'Rival policy mismatch');
 }
 const ids=new Set();for(const m of [...c.history,...(c.active?[c.active]:[])]){need(!ids.has(m.id),'Duplicate meet');ids.add(m.id);const e=eventBy(m.eventId);need(m.entrants.length===4&&new Set(m.entrants.map(x=>x.id)).size===4,'Duplicate meet host');new R.Course(m.course.course);need(m.equipment===e.equipment&&key(m.purse)===key(e.purse),'Altered meet policy');need(Number.isSafeInteger(m.escrow)&&m.escrow>=0&&m.escrow<=e.purse.reduce((a,b)=>a+b,0),'Invalid meet purse');need(m.rounds.length===m.round&&m.round<=3,'Invalid round count');for(const [roundIndex,round]of m.rounds.entries()){
 need(round.heats.length===4,'Missing paired heat');for(const [i,h]of round.heats.entries()){
  need(key(h.request.course)===key(m.course.course)&&h.request.equipment===m.equipment,'Heat course drift');
  const order=PAIRINGS[roundIndex][Math.floor(i/2)].map(k=>m.entrants[k].id);if(i%2)order.reverse();
  need(key(h.request.entrants.map(e=>e.build.host_id))===key(order),'Pairing drift');
  validRows(h.request,{course:new R.Course(h.request.course).data(),equipment:h.request.equipment,results:h.results});
 }}
 if(m.state==='complete'){const standingsNow=standings(m),me=standingsNow.find(r=>r.id===m.hostId);need(m.round===3&&m.escrow===0&&key(m.table)===key(standingsNow),'Altered standings');need(m.champion===(me.rank===1&&me.wins>=3),'Invented championship result');}
}
 if(c.active)need(w.hosts[c.active.hostId]&&w.specimens.some(s=>s.id===c.active.hostId&&s.owner==='player'),'Missing entered host');
 need(new Set(c.badges.map(b=>b.code)).size===c.badges.length,'Duplicate qualification');
 for(const badge of c.badges)need(c.history.some(m=>m.id===badge.meetId&&m.state==='complete'&&m.champion&&eventBy(m.eventId).grant===badge.code),'Qualification without winning result');
 for(const t of c.tickets){need(['ready','claimed'].includes(t.state)&&c.history.some(m=>m.id===t.meetId&&m.champion&&eventBy(m.eventId).grant==='local_open'),'Award without qualifying result');if(t.state==='claimed')need(Array.isArray(t.claimed)&&t.claimed.length===2&&new Set(t.claimed).size===2&&t.claimed.every(id=>w.specimens.some(s=>s.id===id)),'Invalid claimed pair');}
 for(const t of c.trophies)need(c.history.some(m=>m.id===t.meetId&&m.champion&&m.hostId===t.hostId),'Trophy without finish result');
 return true;}
const api={EVENTS,DEFINITIONS,PAIRINGS,init,extras,dispatch,validate,standings,scoreRows,courseFor,status,rosterBy,requestsFor,snapshot};root.RRRClub=api;if(typeof module!=='undefined')module.exports=api;
})(typeof globalThis!=='undefined'?globalThis:this);
