# RRR — Wave v0.5 development TODO

Status: completed work is only complete at its declared scope. Human gameplay acceptance remains open.

## W05.T01 — Audit the continuation and preserve all prior records
**Dependencies:** none. **Role:** supporting.
**Specification:** developed. **Runtime/evidence:** reviewed; baseline byte and content preservation checked.

## W05.T02 — Port the same race operators into the local browser
**Dependencies:** W05.T01. **Role:** experimental.
**Specification:** developed. **Runtime/evidence:** implemented and six-case Python/JS parity checked.

## W05.T03 — Implement unique-stock draft and fitting operations
**Dependencies:** W05.T01. **Role:** novel_integration.
**Specification:** developed. **Runtime/evidence:** implemented and adversarial model-tested within a retained-native fixture.

## W05.T04 — Render the editable anatomical workbench
**Dependencies:** W05.T03. **Role:** novel_execution.
**Specification:** developed. **Runtime/evidence:** implemented; pointer/keyboard/drag interactions and screenshots reviewed.

## W05.T05 — Race the committed build and compare exact snapshots
**Dependencies:** W05.T02, W05.T03, W05.T04. **Role:** novel_integration.
**Specification:** developed. **Runtime/evidence:** implemented for three ground course settings and three rival profiles.

## W05.T06 — Preserve recipes, session design and exportable records
**Dependencies:** W05.T03, W05.T04. **Role:** supporting.
**Specification:** developed. **Runtime/evidence:** portable round-trip and input rejection tested; native file-storage persistence unverified.

## W05.T07 — Connect build recipes to breeding and fitting livelihoods
**Dependencies:** W05.T03, W05.T05. **Role:** design.
**Specification:** developed. **Runtime/evidence:** foundation rules and service records developed; market execution not added.

## W05.T08 — Adversarial checks, visual polish and MIVIM handoff
**Dependencies:** W05.T01, W05.T02, W05.T03, W05.T04, W05.T05, W05.T06, W05.T07. **Role:** supporting.
**Specification:** developed. **Runtime/evidence:** scoped evidence and next-wave queue supplied.

## Carried implementation work

### W06.T01 — Shared intake, brood, bench and world clock
Priority P0. Refines W04.T02, W04.T04.
Replace fixed endowments with one persistent stock service. A captured or matured individual can be inspected, retained, prepared, fitted or sold without duplicated bodies. Race attendance advances the same obligations; replay does not. Keep the playable bench intact.

### W06.T02 — Repeated livelihood and recovery calibration
Priority P0. Refines W04.T02.
Several uncertain broods, funded demand renewal, living costs, retained parents and delayed/failed orders. Compare kit buyers, catchers and breeders without a forced profession. Supply actionable reserve and intake views, not only a positive one-cohort ledger.

### W06.T03 — One complete stage-specific donor and viable storage branch
Priority P1. Refines W04.T03.
Clockleaf or pond donor with actual stage transitions, reproductive replacement, preparation window, transport and viable storage/removal. Do not promote the W05 reusable-cradle fixture into universal painless graft removal.

### W06.T04 — Motion and fitting fidelity without loss of clarity
Priority P1. Refines W04.T01.RUNTIME.
Visible loaded limbs and recovery, richer fit envelopes, source-traceable public measurements and multi-drive capability only after its actual supporting anatomy is modeled. Human tests assess novice assembly and recognition of build changes.
