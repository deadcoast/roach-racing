{
  "manifest": {
    "id": "W05",
    "version": "0.5.0",
    "title": "RRR — The Living Workbench",
    "date": "2026-09-09",
    "status": "revisable_foundation_with_editable_browser_slice",
    "extends": "RRR_World_Context_v0.4.json",
    "base_sha256": "2013cd88f76cb92e9d09ea8b01f59afdddd1f8132fe66494515d94a1b695a41c",
    "serialization": "Strict JSON .spec continuing the RRR exchange format; not an asserted canonical private MIVIM grammar."
  },
  "Reference": {
    "baseline_files": [
      "RRR_Wave_04.spec",
      "RRR_World_Context_v0.4.json"
    ],
    "sources": [
      {
        "id": "W05.S01",
        "title": "Tamiya Mini 4WD Setup Guide",
        "url": "https://www.tamiya.com/english/mini4wd/setupguide/setupguide.htm",
        "scope": "Personal assembly, distinct motor and gear choices, contact, placement and compatible parts.",
        "limits": "No direct transfer of fixed-wheel cornering physics; does not validate RRR anatomy.",
        "checked_on": "2026-09-09"
      },
      {
        "id": "W05.S02",
        "title": "Tamiya FM-A Balanced Starter Pack, 18710",
        "url": "https://www.tamiya.com/english/products/18710/index.html",
        "scope": "Assembly kit bundled with selected upgrade parts as an approachable starting project.",
        "limits": "RRR fixed-stock demonstration is not a real Tamiya product or a breeding mechanic.",
        "checked_on": "2026-09-09"
      },
      {
        "id": "W05.S03",
        "title": "MDN: Window.localStorage",
        "url": "https://developer.mozilla.org/en-US/docs/Web/API/Window/localStorage",
        "scope": "Browser persistence, possible SecurityError, and unspecified file-URL behavior.",
        "limits": "Native file persistence not validated in this host; portable recipe export remains available.",
        "checked_on": "2026-09-09"
      },
      {
        "id": "W05.S04",
        "title": "MDN: Using Web Workers",
        "url": "https://developer.mozilla.org/en-US/docs/Web/API/Web_Workers_API/Using_web_workers",
        "scope": "Off-main-thread computation and message-based worker execution.",
        "limits": "W05 also has a cooperative fallback; worker availability is not assumed universally.",
        "checked_on": "2026-09-09"
      }
    ],
    "findings": [
      {
        "id": "W05.GAP.01",
        "finding": "Replay could show fitted stock, but the user could not place or change it.",
        "repair": "An editable draft, atomic fitting and live race entry share the same component identities."
      },
      {
        "id": "W05.GAP.02",
        "finding": "A fresh browser implementation risked becoming a second unrelated race formula.",
        "repair": "Port the unchanged W04 operations and compare six reference experiments numerically."
      },
      {
        "id": "W05.GAP.03",
        "finding": "Treating root position as decoration would disconnect the kit from racing.",
        "repair": "Support and root overlap gate fitting; alignment, reach and yaw map to stated behavior. Inert positioning changes are not falsely credited as performance."
      },
      {
        "id": "W05.GAP.04",
        "finding": "Returning a replacement could make native anatomy appear from nowhere.",
        "repair": "The fixture explicitly preserves native exchange units in a cradle. This is not regrowth or a global removal rule."
      },
      {
        "id": "W05.GAP.05",
        "finding": "A recipe could be mistaken for inventory or an authoritative save.",
        "repair": "Import only a bounded arrangement against existing local stock; do not import cash, genomes or race authority."
      },
      {
        "id": "W05.GAP.06",
        "finding": "The permanent record risked following mutable draft state.",
        "repair": "Freeze the entry payload and keep later edits separate from recorded result and visualization."
      },
      {
        "id": "W05.GAP.07",
        "finding": "Expanding expert controls initially stretched the bench into a large blank surface.",
        "repair": "Bound desktop panels with internal scrolling; keep the creature and commit controls in view."
      },
      {
        "id": "W05.GAP.08",
        "finding": "Rebuilding the source card during drag-start detached the native drag target.",
        "repair": "Keep the source node intact during a tray drag; test the real DataTransfer path, not only Fit buttons."
      }
    ],
    "preserved": [
      "speed and winning",
      "personally assembled kits",
      "collection and showing off",
      "anyone can catch and breed",
      "whole-insect Wrangloid trade",
      "genuine superior stock",
      "optional professions and expert depth",
      "Open equipment freedom",
      "Flyers with Flyers",
      "no new global racer permadeath",
      "Locals-Regionals-Factionals-New World City"
    ]
  },
  "Plan": {
    "tasks": [
      {
        "id": "W05.T01",
        "title": "Audit the continuation and preserve all prior records",
        "priority": "P0",
        "depends_on": [],
        "contribution_role": "supporting",
        "spec_status": "developed",
        "runtime_status": "reviewed; baseline byte and content preservation checked"
      },
      {
        "id": "W05.T02",
        "title": "Port the same race operators into the local browser",
        "priority": "P0",
        "depends_on": [
          "W05.T01"
        ],
        "contribution_role": "experimental",
        "spec_status": "developed",
        "runtime_status": "implemented and six-case Python/JS parity checked"
      },
      {
        "id": "W05.T03",
        "title": "Implement unique-stock draft and fitting operations",
        "priority": "P0",
        "depends_on": [
          "W05.T01"
        ],
        "contribution_role": "novel_integration",
        "spec_status": "developed",
        "runtime_status": "implemented and adversarial model-tested within a retained-native fixture"
      },
      {
        "id": "W05.T04",
        "title": "Render the editable anatomical workbench",
        "priority": "P0",
        "depends_on": [
          "W05.T03"
        ],
        "contribution_role": "novel_execution",
        "spec_status": "developed",
        "runtime_status": "implemented; pointer/keyboard/drag interactions and screenshots reviewed"
      },
      {
        "id": "W05.T05",
        "title": "Race the committed build and compare exact snapshots",
        "priority": "P0",
        "depends_on": [
          "W05.T02",
          "W05.T03",
          "W05.T04"
        ],
        "contribution_role": "novel_integration",
        "spec_status": "developed",
        "runtime_status": "implemented for three ground course settings and three rival profiles"
      },
      {
        "id": "W05.T06",
        "title": "Preserve recipes, session design and exportable records",
        "priority": "P1",
        "depends_on": [
          "W05.T03",
          "W05.T04"
        ],
        "contribution_role": "supporting",
        "spec_status": "developed",
        "runtime_status": "portable round-trip and input rejection tested; native file-storage persistence unverified"
      },
      {
        "id": "W05.T07",
        "title": "Connect build recipes to breeding and fitting livelihoods",
        "priority": "P1",
        "depends_on": [
          "W05.T03",
          "W05.T05"
        ],
        "contribution_role": "design",
        "spec_status": "developed",
        "runtime_status": "foundation rules and service records developed; market execution not added"
      },
      {
        "id": "W05.T08",
        "title": "Adversarial checks, visual polish and MIVIM handoff",
        "priority": "P0",
        "depends_on": [
          "W05.T01",
          "W05.T02",
          "W05.T03",
          "W05.T04",
          "W05.T05",
          "W05.T06",
          "W05.T07"
        ],
        "contribution_role": "supporting",
        "spec_status": "developed",
        "runtime_status": "scoped evidence and next-wave queue supplied"
      }
    ],
    "continued_task": "W04.T01.RUNTIME",
    "next_tasks": [
      {
        "id": "W06.T01",
        "priority": "P0",
        "title": "Shared intake, brood, bench and world clock",
        "continuation": [
          "W04.T02",
          "W04.T04"
        ],
        "acceptance": "Replace fixed endowments with one persistent stock service. A captured or matured individual can be inspected, retained, prepared, fitted or sold without duplicated bodies. Race attendance advances the same obligations; replay does not. Keep the playable bench intact."
      },
      {
        "id": "W06.T02",
        "priority": "P0",
        "title": "Repeated livelihood and recovery calibration",
        "continuation": [
          "W04.T02"
        ],
        "acceptance": "Several uncertain broods, funded demand renewal, living costs, retained parents and delayed/failed orders. Compare kit buyers, catchers and breeders without a forced profession. Supply actionable reserve and intake views, not only a positive one-cohort ledger."
      },
      {
        "id": "W06.T03",
        "priority": "P1",
        "title": "One complete stage-specific donor and viable storage branch",
        "continuation": [
          "W04.T03"
        ],
        "acceptance": "Clockleaf or pond donor with actual stage transitions, reproductive replacement, preparation window, transport and viable storage/removal. Do not promote the W05 reusable-cradle fixture into universal painless graft removal."
      },
      {
        "id": "W06.T04",
        "priority": "P1",
        "title": "Motion and fitting fidelity without loss of clarity",
        "continuation": [
          "W04.T01.RUNTIME"
        ],
        "acceptance": "Visible loaded limbs and recovery, richer fit envelopes, source-traceable public measurements and multi-drive capability only after its actual supporting anatomy is modeled. Human tests assess novice assembly and recognition of build changes."
      }
    ]
  },
  "Workflow": {
    "order": [
      "Read actual baseline and queued acceptance",
      "Preserve reference and source inventory",
      "Build shared model and assembly operations",
      "Connect editable UI to fresh computation",
      "Exercise adversarial interactions and visual review",
      "Generate scope-correct specification, evidence and next queue"
    ],
    "closeout_rule": "Specified is not implemented; port parity is not physical validity; no human playtest means no player-experience acceptance."
  },
  "Adherence": {
    "hard_constraints": [
      "Speed, winning, personally assembled kits and collecting remain central.",
      "Wrangloid trade, wild selection, breeding and careers remain nonexclusive.",
      "No class/rank gene gates, universal sidegrade requirement, arbitrary brow ban, or global point cap.",
      "Do not silently turn free fixture editing into universal painless removal.",
      "Appearance is desirable in its own right; no hidden livery buff.",
      "New rules are proposals and prior world records are preserved."
    ]
  },
  "MIVIM": {
    "criteria_source": "W04 MIVIM profile carried forward; no new expansion, numeric weights or grade bands",
    "eligibility": "quality_at_declared_scope AND novel_development_adherence_at_declared_scope",
    "numeric_score": null,
    "numeric_score_reason": "No authorized numerical grading formula.",
    "novel_objective": "A personally arranged biological kit, with known donor history, directly authors a fresh observable race and reusable building knowledge.",
    "comparator": "Equipment selection with cosmetic placement, unrelated race scores, canned replays and recipes that duplicate stock.",
    "contribution_scope": "Editable eight-sect browser workshop plus bounded path-model races, foundation integration and separately credited supporting validation.",
    "findings": {
      "quality": "Implemented and visually reviewed at slice scope; native-platform behavior, human usability and finished-game quality remain open.",
      "novel_development_adherence": "Concrete project-specific integration of anatomical placement, component provenance, builder setup and racing; no worldwide novelty claim.",
      "effectiveness": "Direct editing, custody, entry snapshots and selected outcomes tested; livelihood effects remain specified rather than simulated.",
      "creativity": "Original procedural anatomical presentation and integrated kit interaction delivered; player-perceived distinctiveness unmeasured.",
      "scaling_potential": "Shared pure model, typed stock/profile boundary and versioned snapshots provide an extension path. Fixed inventory and path-space geometry do not establish world-scale capability."
    },
    "supporting_work": "Port parity, schemas, manifests, input validation and test counts protect the intended feature but are not themselves an achieved gameplay innovation."
  },
  "systems": [
    {
      "id": "W05.SYSTEM.BENCH",
      "title": "Draft, fitted host and physical custody",
      "origin": "source_hobby_translation",
      "refines": [
        "W04.BENCH.04",
        "W04.BIND.01"
      ],
      "rules": [
        {
          "id": "W05.BENCH.01",
          "statement": "A draft changes a proposed arrangement, not the host or current component custody.",
          "decision": "Try a new build before committing.",
          "consequence": "The currently fitted racer remains available and unchanged."
        },
        {
          "id": "W05.BENCH.02",
          "statement": "A fitting commit validates the whole draft, then swaps the intended components together.",
          "decision": "Fit an accepted layout.",
          "consequence": "A failure does not remove half a build or install a duplicate."
        },
        {
          "id": "W05.BENCH.03",
          "statement": "The same prepared sect identity may be loose, packaged or installed in the broader system, but never in two places at once.",
          "decision": "Choose its present use.",
          "consequence": "A saved recipe is not an additional component."
        },
        {
          "id": "W05.BENCH.04",
          "statement": "Repeated fitting of an unchanged arrangement is a no-op.",
          "decision": "Confirm or retry safely.",
          "consequence": "No second revision, duplicate anatomy or charge is created."
        },
        {
          "id": "W05.BENCH.05",
          "statement": "Replacement native units are explicitly retained in the W05 bench cradle.",
          "decision": "Return an installed replacement.",
          "consequence": "The retained native unit is reinstalled; tissue is not regenerated."
        },
        {
          "id": "W05.BENCH.06",
          "statement": "This reusable preparation profile applies only to the declared bench experiment.",
          "decision": "Select the branch explicitly.",
          "consequence": "W04 removal, injury and preservation decisions remain open elsewhere."
        },
        {
          "id": "W05.BENCH.07",
          "statement": "Returning a component in the draft does not yet make the fitted item loose.",
          "decision": "Review removals before commitment.",
          "consequence": "Draft and installed readouts use different labels."
        },
        {
          "id": "W05.BENCH.08",
          "statement": "A whole multi-role Hopper assembly contributes mass and inventory once.",
          "decision": "Use the paired unit rather than duplicated role slots.",
          "consequence": "Jump and landing capabilities do not create extra limbs."
        },
        {
          "id": "W05.BENCH.09",
          "statement": "A host retains its nameable identity across fitted versions.",
          "decision": "Rebuild the same racer.",
          "consequence": "A new configuration is not a newly bred animal."
        },
        {
          "id": "W05.BENCH.10",
          "statement": "Any future payment or care commitment must attach to the actual fitting transaction.",
          "decision": "Extend the fixture into the operating world.",
          "consequence": "Free session editing is not claimed as calibrated workshop economics."
        }
      ]
    },
    {
      "id": "W05.SYSTEM.FIT",
      "title": "Meaningful placement and bounded physical fitting",
      "origin": "source_hobby_translation_and_rrr_extension",
      "refines": [
        "W04.BENCH.05",
        "W04.BIND.04"
      ],
      "rules": [
        {
          "id": "W05.FIT.01",
          "statement": "Prepared-root ranges describe the supported geometry of the current components, not a universal species permission.",
          "decision": "Move a root within its usable preparation.",
          "consequence": "Unsupported fit identifies the component and needed correction."
        },
        {
          "id": "W05.FIT.02",
          "statement": "Root collision is checked using oriented rectangles on named attachment layers.",
          "decision": "Rotate or reposition a conflicting component.",
          "consequence": "Intersecting same-layer roots block commitment; different layers can coexist."
        },
        {
          "id": "W05.FIT.03",
          "statement": "The prepared starter host has one primary-drive interface in this fixture.",
          "decision": "Choose Redline, Torque or retained native drive.",
          "consequence": "The local interface limitation does not ban multi-drive roaches from RRR."
        },
        {
          "id": "W05.FIT.04",
          "statement": "A central horn and split brow vanes can coexist if their actual roots do not intersect.",
          "decision": "Compose rather than obey an arbitrary brow-slot ban.",
          "consequence": "The accepted arrangement is visible and can enter Open."
        },
        {
          "id": "W05.FIT.05",
          "statement": "Hopper rotation and off-center fitting contribute mounting error separately from inherited phase.",
          "decision": "Align the prepared pair.",
          "consequence": "Remounting can change useful launch transfer without rewriting ancestry."
        },
        {
          "id": "W05.FIT.06",
          "statement": "Horn forward position and yaw change projected reach; lateral offset changes its modeled contact line.",
          "decision": "Adjust the contact geometry.",
          "consequence": "The displayed fit has a named mechanical consequence."
        },
        {
          "id": "W05.FIT.07",
          "statement": "Claw placement changes modeled reach and angle can change closure delay.",
          "decision": "Set the intended interception envelope.",
          "consequence": "No passive armor or remote control effect is added."
        },
        {
          "id": "W05.FIT.08",
          "statement": "Not every permitted cosmetic or spatial adjustment must improve lap time.",
          "decision": "Fit for clearance, appearance or performance as appropriate.",
          "consequence": "The UI does not manufacture a bonus for every drag."
        }
      ]
    },
    {
      "id": "W05.SYSTEM.TUNE",
      "title": "Inherited traits, setup and source function",
      "origin": "source_hobby_translation",
      "refines": [
        "W04.BIND.03",
        "W03.PERFORMANCE.01"
      ],
      "rules": [
        {
          "id": "W05.TUNE.01",
          "statement": "Drive cadence and useful force remain separate from hip leverage.",
          "decision": "Select a drive then tune its delivery.",
          "consequence": "A gear-equivalent does not create a second motor."
        },
        {
          "id": "W05.TUNE.02",
          "statement": "Preload spends the available launch supply and is bounded by the local assembly profile.",
          "decision": "Select an active-jump setup.",
          "consequence": "A dormant or absent Hopper does not confer an unexplained speed multiplier."
        },
        {
          "id": "W05.TUNE.03",
          "statement": "Reserve fill changes starting energy and entry mass; storage capacity and delivery remain component properties.",
          "decision": "Prepare a short run or a longer run.",
          "consequence": "Feeding does not mutate inherited reserve quality."
        },
        {
          "id": "W05.TUNE.04",
          "statement": "Running stance changes the modeled body envelope and passing clearance.",
          "decision": "Choose a wider or narrower configuration.",
          "consequence": "Visual stance and collision width come from the same setting."
        },
        {
          "id": "W05.TUNE.05",
          "statement": "The current pad model changes traction; full peel-release gait is not claimed.",
          "decision": "Compare the defined contact contribution.",
          "consequence": "Untested foot dynamics remain explicit missing fidelity."
        },
        {
          "id": "W05.TUNE.06",
          "statement": "The split-vane fixture adds a speed-dependent hold-down term rather than powered flight.",
          "decision": "Fit aero to a ground racer.",
          "consequence": "It can affect traction and corner control without granting Flyer eligibility."
        },
        {
          "id": "W05.TUNE.07",
          "statement": "Livery, name and number have no mechanical multiplier.",
          "decision": "Make the racer recognizable.",
          "consequence": "Appearance and collection value do not require fabricated race superiority."
        },
        {
          "id": "W05.TUNE.08",
          "statement": "Available measurements in this stock profile are declared fixture observations.",
          "decision": "Inspect the known stock.",
          "consequence": "No full genotype oracle or unperformed assay is presented as earned knowledge."
        }
      ]
    },
    {
      "id": "W05.SYSTEM.RACE",
      "title": "Actual entry, frozen records and comparisons",
      "origin": "source_hobby_translation_and_rrr_extension",
      "refines": [
        "W04.RACE.01",
        "W04.BIND.06",
        "W04.PRESENT.06"
      ],
      "rules": [
        {
          "id": "W05.RACE.01",
          "statement": "Race entry requires a committed design; an unresolved draft is neither silently discarded nor silently installed.",
          "decision": "Commit or revert deliberately.",
          "consequence": "The entered build is unambiguous."
        },
        {
          "id": "W05.RACE.02",
          "statement": "A race is newly computed from its entry snapshot rather than chosen from a result table.",
          "decision": "Test a new assembly or setting.",
          "consequence": "Changed parts can cause changed motion and finish times."
        },
        {
          "id": "W05.RACE.03",
          "statement": "Class checks inspect actual offensive capability, not the selected approach or product label.",
          "decision": "Enter Speedsters, Fireworks or Open.",
          "consequence": "A peaceful policy does not legalize a fitted weapon in Speedsters."
        },
        {
          "id": "W05.RACE.04",
          "statement": "Current editable events are ground-only.",
          "decision": "Use supported practice settings.",
          "consequence": "Full sustained-flight simulation remains open rather than approximated by a ground race."
        },
        {
          "id": "W05.RACE.05",
          "statement": "Rivals use independently identified declared stock and published fixture behavior.",
          "decision": "Choose a useful practice opponent.",
          "consequence": "The rival does not read hidden player genetics to manufacture a counterbuild."
        },
        {
          "id": "W05.RACE.06",
          "statement": "Frozen results preserve the build, positions, appearance, settings, course and policy used at entry.",
          "decision": "Watch, export or inspect an old run.",
          "consequence": "Later bench edits do not alter a previous finish."
        },
        {
          "id": "W05.RACE.07",
          "statement": "A matched comparison requires the same course, laps, class, rival and starting grid.",
          "decision": "Pin a useful reference.",
          "consequence": "A changed course is flagged rather than attributed solely to the component."
        },
        {
          "id": "W05.RACE.08",
          "statement": "Practice, replay and exported result records do not mint prize money or advance the world clock in this slice.",
          "decision": "Experiment without fictional payouts.",
          "consequence": "The separate coupled-clock and funded-event tasks remain open."
        },
        {
          "id": "W05.RACE.09",
          "statement": "An unfinished run reports no finish instead of a synthetic low score or fabricated time.",
          "decision": "Inspect the loss or revise the build.",
          "consequence": "First valid finish remains the racing objective."
        }
      ]
    },
    {
      "id": "W05.SYSTEM.RECIPE",
      "title": "Personal recipes and commercial kit specifications",
      "origin": "source_hobby_translation",
      "refines": [
        "W04.BENCH.06",
        "W04.DEMAND.03"
      ],
      "rules": [
        {
          "id": "W05.RECIPE.01",
          "statement": "A personal build sheet references component instances and settings; it does not grant ownership.",
          "decision": "Keep or share an arrangement.",
          "consequence": "Import cannot create a donor, genome, wallet or trophy."
        },
        {
          "id": "W05.RECIPE.02",
          "statement": "A commercial recipe references acceptable component families, measured ranges and preparation tolerances.",
          "decision": "Produce coordinated kits from nonidentical individuals.",
          "consequence": "Usable consistency does not require genetic clones."
        },
        {
          "id": "W05.RECIPE.03",
          "statement": "Personal instance sheets and commercial product specifications remain distinct document types.",
          "decision": "Reproduce a personal build or produce a repeatable product.",
          "consequence": "The current exact-stock importer is not advertised as a general market solver."
        },
        {
          "id": "W05.RECIPE.04",
          "statement": "A commercial bill of materials identifies retained native anatomy and all transferred components.",
          "decision": "Package an honest kit.",
          "consequence": "Several functional roles cannot conceal missing or duplicated tissue."
        },
        {
          "id": "W05.RECIPE.05",
          "statement": "Substitution needs adequate function, physical fit and disclosed evidence.",
          "decision": "Offer an alternative donor or preparation.",
          "consequence": "A higher rarity label alone cannot certify an equivalent kit."
        },
        {
          "id": "W05.RECIPE.06",
          "statement": "Build finishing can be commissioned independently of race tuning.",
          "decision": "Pay for or provide an attractive finish.",
          "consequence": "Aesthetic labor has a legitimate customer purpose without a stat aura."
        },
        {
          "id": "W05.RECIPE.07",
          "statement": "A saved recipe may outlive the particular component it originally used.",
          "decision": "Preserve a design after selling its stock.",
          "consequence": "The later general importer must show missing parts, never restore ownership from history."
        }
      ]
    },
    {
      "id": "W05.SYSTEM.LIVELIHOOD",
      "title": "Breeding stock and workbench expertise create different products",
      "origin": "rrr_native_world_integration",
      "refines": [
        "W04.DEMAND.02",
        "W04.STOCK.02",
        "W04.BENCH.06"
      ],
      "rules": [
        {
          "id": "W05.LIVELIHOOD.01",
          "statement": "Breeders select for the traits a component or customer needs; fitters control preparation and arrangement.",
          "decision": "Breed, buy, commission or personally build.",
          "consequence": "A fitting improvement does not falsely certify improved inheritance."
        },
        {
          "id": "W05.LIVELIHOOD.02",
          "statement": "A component can be strong but awkward to fit to a particular host.",
          "decision": "Reserve it for a custom commission, adjust the preparation or choose another buyer.",
          "consequence": "Poor fit for one kit is not universal low quality."
        },
        {
          "id": "W05.LIVELIHOOD.03",
          "statement": "Production selection can include repeatable anatomical proportions where the donor genetics model supports them.",
          "decision": "Raise the fraction of stock fitting an ordinary kit specification.",
          "consequence": "The statistical/genetic model is an expansion task, not invented by this fixed catalogue."
        },
        {
          "id": "W05.LIVELIHOOD.04",
          "statement": "A fitting commission names requested function, supplied stock, handling authority, labor, evidence, fee and acceptance.",
          "decision": "Earn through building expertise.",
          "consequence": "Compensation is attached to performed work rather than a promise of winning every race."
        },
        {
          "id": "W05.LIVELIHOOD.05",
          "statement": "An inspection or bench trial can support a narrow claim about configuration.",
          "decision": "Sell measurable adjustment work.",
          "consequence": "One result does not imply an entire donor line is genetically certified."
        },
        {
          "id": "W05.LIVELIHOOD.06",
          "statement": "Routine compatible stock, useful intermediates and unusual custom stock can serve different funded customers.",
          "decision": "Allocate a cohort among production, selection, personal builds and sales.",
          "consequence": "Progress does not wait for a perfect organism."
        },
        {
          "id": "W05.LIVELIHOOD.07",
          "statement": "The editable prototype grants no new market funds, breeding output or service income.",
          "decision": "Use it to establish the builder contribution.",
          "consequence": "Economy behavior remains attached to the queued shared inventory and clock implementation."
        }
      ]
    },
    {
      "id": "W05.SYSTEM.POLISH",
      "title": "Creature-first interaction and accessible control",
      "origin": "rrr_native_execution",
      "refines": [
        "W04.PRESENT.02",
        "W03.POLISH.06"
      ],
      "rules": [
        {
          "id": "W05.POLISH.01",
          "statement": "Tray parts display their own visual forms, identity and custody state.",
          "decision": "Recognize a selected sect before opening numbers.",
          "consequence": "Different donors are not anonymous stat cards."
        },
        {
          "id": "W05.POLISH.02",
          "statement": "Direct root dragging, arrow-key nudging and explicit fit controls act on the same draft.",
          "decision": "Choose mouse, keyboard or tap-friendly controls.",
          "consequence": "Precise pointer skill is not required to assemble the kit."
        },
        {
          "id": "W05.POLISH.03",
          "statement": "Anatomical illustration is generated from the actual placement and finish record.",
          "decision": "Fit, move or recolor a part.",
          "consequence": "The bench, saved sheet and recorded racer remain visibly connected."
        },
        {
          "id": "W05.POLISH.04",
          "statement": "Under-shell inspection reveals internal modules without equipping a different build.",
          "decision": "Inspect the fitted drive or reserve.",
          "consequence": "A view toggle does not change performance."
        },
        {
          "id": "W05.POLISH.05",
          "statement": "Expert controls expand inside a bounded desktop panel; mobile uses natural vertical flow.",
          "decision": "Explore depth without losing the host or commit boundary.",
          "consequence": "Optional controls do not generate a large empty canvas or hide the commit bar."
        },
        {
          "id": "W05.POLISH.06",
          "statement": "Bulk or gesture-level edits keep reversible draft history.",
          "decision": "Undo an exploratory drag or a tuning gesture.",
          "consequence": "Undo does not reverse a paid world transaction or alter a finished race."
        },
        {
          "id": "W05.POLISH.07",
          "statement": "During native tray dragging the dragged DOM node stays intact.",
          "decision": "Drag a component into the prepared root area.",
          "consequence": "Rendering cannot detach and cancel the source action."
        },
        {
          "id": "W05.POLISH.08",
          "statement": "Race order, action messages and a recorded-roach detail accompany the small track view.",
          "decision": "Follow the race and recognize the fitted creature.",
          "consequence": "Information is not available solely through tiny moving markers."
        },
        {
          "id": "W05.POLISH.09",
          "statement": "Reduced-motion preferences suppress automatic replay start.",
          "decision": "Choose when to watch movement.",
          "consequence": "The whole simulation remains available without forced autoplay."
        },
        {
          "id": "W05.POLISH.10",
          "statement": "Focus, labels, fit warnings and textual state supplement color.",
          "decision": "Navigate and diagnose without relying on hue alone.",
          "consequence": "A selected item and its inspector remain synchronized."
        }
      ]
    },
    {
      "id": "W05.SYSTEM.EVIDENCE",
      "title": "Persistence, source parity and evidence boundaries",
      "origin": "supporting",
      "refines": [
        "W04.BIND.07",
        "W03.REVISION.03"
      ],
      "rules": [
        {
          "id": "W05.EVIDENCE.01",
          "statement": "The browser port is compared with unchanged W04 Python sources before new profile extensions are credited.",
          "decision": "Continue the same mechanical reference.",
          "consequence": "Porting does not silently replace the underlying race model."
        },
        {
          "id": "W05.EVIDENCE.02",
          "statement": "Local file storage may be unavailable; keep portable recipe export and reject invalid imported fields.",
          "decision": "Retain work through an allowed path.",
          "consequence": "No claim of universal browser persistence is made."
        },
        {
          "id": "W05.EVIDENCE.03",
          "statement": "The model and worker fallback consume the same compiled entry payload.",
          "decision": "Run without freezing the interface.",
          "consequence": "A worker restriction does not select a canned result."
        },
        {
          "id": "W05.EVIDENCE.04",
          "statement": "New fixture branches retain their input values and model versions.",
          "decision": "Calibrate later without rewriting history.",
          "consequence": "Body mass, root bounds and aero coefficients remain proposals."
        },
        {
          "id": "W05.EVIDENCE.05",
          "statement": "Quality and novel-development adherence are non-compensable gates; unknown evidence remains open.",
          "decision": "Assess the actual contribution at its scope.",
          "consequence": "Test counts and documentation volume do not become an innovation grade."
        },
        {
          "id": "W05.EVIDENCE.06",
          "statement": "The cumulative context appends W05 while preserving old records and waves.",
          "decision": "Continue development without resetting the world.",
          "consequence": "Earlier specimens, sources, decisions and historical demonstrations remain intact."
        }
      ]
    }
  ],
  "operational_threads": [
    {
      "id": "W05.THREAD.FIT_COMMISSION",
      "origin": "PCR expert tuning / RRR living assembly",
      "actor_ref": "VENUE_FOUNDRY",
      "input": "Customer-owned host and grafts, requested behavior, authorized handling, measured baseline.",
      "operation": "Prepare a fitting proposal, agree fee and acceptance, commit physical work, compare the same conditions.",
      "output": "Performed-service receipt, actual arrangement, restricted performance claim.",
      "reward": "Labor/service margin once the shared economy is implemented.",
      "limit": "No live fee or autonomous client implemented in W05."
    },
    {
      "id": "W05.THREAD.KIT_SUPPLY",
      "origin": "PCR coordinated kit / RRR selected biological stock",
      "actor_ref": "SHOP_TWO_NETS",
      "input": "Measured stock from multiple donor lines, fit ranges, actual host and parts, recipe revision.",
      "operation": "Select appropriate components; package without duplicating anatomy; supply a build guide.",
      "output": "A physical kit and separately versioned product recipe.",
      "reward": "Coordination and preparation margin; ordinary brood stock can be useful.",
      "limit": "W05 exact-instance build sheets are not yet generic kit production contracts."
    },
    {
      "id": "W05.THREAD.BREED_FOR_FIT",
      "origin": "RRR breeding specialization serving kit customization",
      "actor_ref": "ORG_CINDER",
      "input": "Breeding project and observed batch outcomes including dimensions and desired function.",
      "operation": "Select heritable contributions separately from developmental damage and adjustable mounting error.",
      "output": "More suitably measured donor stock, not magically pre-aligned offspring.",
      "reward": "Higher accepted-kit yield only if the inherited/development model and customer demand support it.",
      "limit": "Anatomical-proportion genetics and longitudinal batch statistics are not implemented."
    },
    {
      "id": "W05.THREAD.PUBLIC_BUILD",
      "origin": "PCR build display and finished kit culture",
      "actor_ref": "MEDIA_BENCHLINE",
      "input": "Owner-permitted entry snapshot, result and visible component identities.",
      "operation": "Publish or share the build without hidden genetic data or invented winner guarantees.",
      "output": "Public assembly interest and possible later specific inquiries.",
      "reward": "Recognition, possible commissions or collector attention; no immediate money generated.",
      "limit": "Local exported records are not cryptographically authoritative competition results."
    }
  ],
  "assets": [
    {
      "id": "UPGRADE-DRIVE",
      "name": "Cicada Redline",
      "short": "Redline",
      "kind": "drive",
      "origin": "Purchased from the Wave 3 brood margin",
      "donor": "DRIVE-DONOR",
      "form": "W02.DONOR.CICADA",
      "source": "Cooling-kiln / rooted pipe galleries",
      "purpose": "Loaded cadence and useful force; compare at the same hip leverage.",
      "signature": "Ribbed copper-red muscle lobes",
      "mass": 0.12,
      "replaces": 0.12,
      "stats": {
        "cadence": 12,
        "force": 2.5
      },
      "grade": "MEASURED DRIVE",
      "colour": "#b85d48",
      "default": {
        "x": 0,
        "y": -0.12,
        "angle": 0
      },
      "bounds": [
        -0.12,
        0.12,
        -0.25,
        0.05
      ],
      "layer": "internal",
      "roots": [
        [
          0,
          0,
          0.22,
          0.24
        ]
      ],
      "roles": [
        "drive"
      ],
      "measure": "12 cadence · 2.5 force",
      "next": "Cadence under load is the selection target. Loudness is not a test."
    },
    {
      "id": "W05.TORQUE",
      "name": "Scarab Torque Bundle",
      "short": "Torque",
      "kind": "drive",
      "origin": "Explicit W05 starter-stock endowment",
      "donor": "W05.SCARAB.D01",
      "form": "W02.DONOR.SCARAB",
      "source": "Cooling-kiln / protected furnace beds",
      "purpose": "More driving force at lower cadence. A replaceable primary drive cassette in this bench profile.",
      "signature": "Ivory muscle columns and dark seams",
      "mass": 0.2,
      "replaces": 0.12,
      "stats": {
        "cadence": 9,
        "force": 4.1
      },
      "grade": "LOAD SPECIALIST",
      "colour": "#b5a28a",
      "default": {
        "x": 0,
        "y": -0.12,
        "angle": 0
      },
      "bounds": [
        -0.12,
        0.12,
        -0.25,
        0.05
      ],
      "layer": "internal",
      "roots": [
        [
          0,
          0,
          0.24,
          0.27
        ]
      ],
      "roles": [
        "drive"
      ],
      "measure": "9 cadence · 4.1 force",
      "next": "Select force per muscle mass; grow-out supports the useful adult thorax."
    },
    {
      "id": "H-6",
      "name": "Grasshopper Hoppers",
      "short": "Hoppers",
      "kind": "hopper",
      "origin": "B1 brood / inherited F1 pair from Wave 3",
      "donor": "B1-6",
      "form": "W02.DONOR.HOPPER",
      "source": "Switchyard line / P-R × P-S",
      "purpose": "One paired assembly supplies running limbs, stored launch and landing recovery.",
      "signature": "Folded amber femurs with joint bands",
      "mass": 0.26,
      "replaces": 0.18,
      "stats": {
        "hopper": [
          0.625,
          0.07,
          0.06
        ],
        "max_preload": 6
      },
      "grade": "SELECTED INTERMEDIATE",
      "colour": "#c3944e",
      "default": {
        "x": 0,
        "y": 0.3,
        "angle": 0
      },
      "bounds": [
        -0.15,
        0.15,
        0.1,
        0.55
      ],
      "layer": "shell",
      "roots": [
        [
          -0.27,
          0,
          0.13,
          0.18
        ],
        [
          0.27,
          0,
          0.13,
          0.18
        ]
      ],
      "roles": [
        "hind_limbs",
        "jump",
        "landing"
      ],
      "measure": "62.5% return · .07 phase · .06 settle",
      "next": "Keep synchronized stock that complements a high-return line; this pair is useful F1 output, not a guaranteed champion."
    },
    {
      "id": "W05.CROP",
      "name": "Nectar Crop",
      "short": "Nectar crop",
      "kind": "reserve",
      "origin": "Explicit W05 starter-stock endowment",
      "donor": "W05.BEE.D01",
      "form": "W02.DONOR.BEE",
      "source": "Protected flowering plots / productive colony",
      "purpose": "High delivery feeds drive and active actions from the same reservoir.",
      "signature": "Translucent amber storage lobes",
      "mass": 0.12,
      "replaces": 0.1,
      "stats": {
        "delivery": 12,
        "reserve": 150
      },
      "grade": "HIGH DELIVERY",
      "colour": "#bf9c57",
      "default": {
        "x": 0,
        "y": 0.39,
        "angle": 0
      },
      "bounds": [
        -0.12,
        0.12,
        0.2,
        0.6
      ],
      "layer": "internal",
      "roots": [
        [
          0,
          0,
          0.25,
          0.29
        ]
      ],
      "roles": [
        "reserve"
      ],
      "measure": "12 delivery · 150 capacity",
      "next": "A full crop is temporary state. Reproductive colony stock supplies recurring donor workers."
    },
    {
      "id": "W05.PADS",
      "name": "Sticktoe Contact Set",
      "short": "Sticktoe",
      "kind": "pads",
      "origin": "Explicit W05 starter-stock endowment",
      "donor": "W05.STICK.D01",
      "form": "W02.DONOR.STICK",
      "source": "Glasshouse / shaded glazed overgrowth",
      "purpose": "Front and middle contact surfaces affect available traction in the simplified running model.",
      "signature": "Four broad, pale contact pads",
      "mass": 0.05,
      "replaces": 0.035,
      "stats": {
        "grip": 1.23
      },
      "grade": "CONTACT SET",
      "colour": "#b1b3a1",
      "default": {
        "x": 0,
        "y": -0.04,
        "angle": 0
      },
      "bounds": [
        -0.08,
        0.08,
        -0.15,
        0.06
      ],
      "layer": "feet",
      "roots": [
        [
          -0.4,
          -0.16,
          0.11,
          0.1
        ],
        [
          0.4,
          -0.16,
          0.11,
          0.1
        ],
        [
          -0.4,
          0.13,
          0.11,
          0.1
        ],
        [
          0.4,
          0.13,
          0.11,
          0.1
        ]
      ],
      "roles": [
        "front_contact",
        "middle_contact"
      ],
      "measure": "1.23 contact multiplier",
      "next": "Breed purchase and peel release separately. Full pad-release gait is not simulated by this multiplier."
    },
    {
      "id": "W05.HORN",
      "name": "Bullhorn Ram",
      "short": "Bullhorn",
      "kind": "horn",
      "origin": "Explicit W05 starter-stock endowment",
      "donor": "W05.HORN.D01",
      "form": "W02.DONOR.HORN",
      "source": "Cooling-kiln / debris-covered compost",
      "purpose": "An aligned charge can disrupt a rival. Forward placement changes the modeled reach.",
      "signature": "Curved bone horn on a ribbed root",
      "mass": 0.14,
      "replaces": 0,
      "stats": {},
      "grade": "OFFENSIVE ASSEMBLY",
      "colour": "#dfc69b",
      "default": {
        "x": 0,
        "y": -0.66,
        "angle": 0
      },
      "bounds": [
        -0.16,
        0.16,
        -0.82,
        -0.42
      ],
      "layer": "shell",
      "roots": [
        [
          0,
          0,
          0.13,
          0.22
        ]
      ],
      "roles": [
        "ram"
      ],
      "measure": "Reach responds to placement",
      "next": "Select root strength and useful curvature; the longest horn is not automatically the strongest."
    },
    {
      "id": "W05.CLAWS",
      "name": "Mantis Catchclaws",
      "short": "Catchclaws",
      "kind": "claws",
      "origin": "Explicit W05 starter-stock endowment",
      "donor": "W05.MANTIS.D01",
      "form": "W02.DONOR.MANTIS",
      "source": "Saltglass / vertical scrub and perches",
      "purpose": "A timed counter-grasp can intercept a ram; it does not grant passive armor.",
      "signature": "Folded serrated forearms",
      "mass": 0.2,
      "replaces": 0,
      "stats": {},
      "grade": "COUNTER / CONTROL",
      "colour": "#bcb38a",
      "default": {
        "x": 0,
        "y": -0.35,
        "angle": 0
      },
      "bounds": [
        -0.12,
        0.12,
        -0.6,
        -0.15
      ],
      "layer": "shell",
      "roots": [
        [
          -0.26,
          0,
          0.14,
          0.2
        ],
        [
          0.26,
          0,
          0.14,
          0.2
        ]
      ],
      "roles": [
        "grasp"
      ],
      "measure": "Closure and reach reflect fit",
      "next": "Long reach matters when the arm still closes in time. Rearing requires protected individual compartments."
    },
    {
      "id": "W05.VANES",
      "name": "Ashveil Split-Vanes",
      "short": "Split-vanes",
      "kind": "vanes",
      "origin": "Explicit W05 starter-stock endowment",
      "donor": "W05.MOTH.D01",
      "form": "W02.DONOR.MOTH",
      "source": "Sheltered textile ruins / intact adult margins",
      "purpose": "A small speed-dependent hold-down term increases contact load. This is stylized aero, not powered flight.",
      "signature": "Paired veined shell blades",
      "mass": 0.04,
      "replaces": 0,
      "stats": {
        "downforce": 0.035
      },
      "grade": "BROW AERO",
      "colour": "#948b75",
      "default": {
        "x": 0,
        "y": -0.56,
        "angle": 0
      },
      "bounds": [
        -0.12,
        0.12,
        -0.72,
        -0.25
      ],
      "layer": "shell",
      "roots": [
        [
          -0.23,
          0,
          0.13,
          0.12
        ],
        [
          0.23,
          0,
          0.13,
          0.12
        ]
      ],
      "roles": [
        "aero"
      ],
      "measure": "Speed-dependent hold-down",
      "next": "Select stiff light surfaces. Split mounting can coexist with a central horn; there is no one-brow-slot ban."
    }
  ],
  "entity_extensions": [
    {
      "id": "W05.ENTITY.DESIGN",
      "fields": [
        "host_id",
        "instance_placements",
        "tuning",
        "approach",
        "name",
        "number",
        "livery"
      ],
      "purpose": "Mutable draft; no ownership authority."
    },
    {
      "id": "W05.ENTITY.FIT",
      "fields": [
        "host_id",
        "revision",
        "fitted_design",
        "native_exchange_custody",
        "prepared_custody"
      ],
      "purpose": "Committed atomic assembly; actual fitted stock."
    },
    {
      "id": "W05.ENTITY.PREP_PROFILE",
      "fields": [
        "root_bounds",
        "root_footprints",
        "layer",
        "mass",
        "native_replacement_mass",
        "supported_action_projection"
      ],
      "purpose": "Declared geometry and preparation of this component, not a species permission list."
    },
    {
      "id": "W05.ENTITY.BUILD_SHEET",
      "fields": [
        "schema",
        "stock_profile",
        "host_id",
        "design",
        "note"
      ],
      "purpose": "Portable exact-instance recipe; import grants no goods."
    },
    {
      "id": "W05.ENTITY.RUN",
      "fields": [
        "run_id",
        "model",
        "input_snapshot",
        "metadata",
        "course",
        "results",
        "events",
        "frames"
      ],
      "purpose": "Immutable local practice record; no prize or authentication implied."
    }
  ],
  "model_contract": {
    "base": "W04.RACE.PATH2P5.v1",
    "runtime": "W05.PATH2P5.browser.v1",
    "units": "Normalized L/M/T/E; no absolute insect scale set.",
    "unchanged_ops": "Path integration, shared energy, anticipatory turn controller, overtaking commitment, jump load/recovery and gate completion.",
    "additions": "Default-zero aero contact load; default-compatible fitted horn/claw reach and closure; cross-entrant component uniqueness.",
    "assembly": "Oriented root rectangles plus preparation bounds, layer separation, retained-native swaps. This is not full swept anatomical collision.",
    "worker": "Same engine source inside a local Blob worker; cooperative bounded chunks if Worker unavailable."
  },
  "fixture_summary": {
    "initial_stock_note": "H-6 and UPGRADE-DRIVE reconstruct previous demonstrated identities. Six other catalogue parts, four retained-native exchange units and facilities are disclosed test endowments. No wallet created in this slice.",
    "host_profile": "HOST base mass 1.60; initial fitted H-6 mass 1.68. This is a normalized W05 profile, not a mutation of a prior physical-scale claim.",
    "drive_only_comparison": {
      "scope": "Only installed drive changes. Same host, hopper, course, rival, grid and settings.",
      "ordinary": {
        "time": 70.04552728926302,
        "remaining_energy": 62.61558467246009,
        "build": {
          "id": "W05.PLAYER.B1",
          "host_id": "HOST",
          "name": "SECOND HELPING",
          "component_ids": [
            "H-6"
          ],
          "drive_source": "HOST.native_drive",
          "hopper_source": "H-6",
          "mass": 1.6800000000000002,
          "cadence": 10,
          "force": 2,
          "stride": 0.25,
          "leverage": 1,
          "grip": 1,
          "delivery": 3,
          "efficiency": 0.75,
          "reserve": 120,
          "width": 0.38,
          "length": 0.62,
          "height": 0.26,
          "hopper": [
            0.625,
            0.07,
            0.06
          ],
          "preload": 5,
          "alignment_error": 0,
          "horn": false,
          "claws": false,
          "armor": "light",
          "provenance": [
            "B1-6"
          ],
          "finish": {
            "number": "06",
            "livery": "vermilion"
          },
          "placements": [
            {
              "id": "H-6",
              "x": 0,
              "y": 0.3,
              "angle": 0
            }
          ],
          "bench_profile": "W05.BENCH.STOCK.1",
          "design_snapshot": {
            "name": "SECOND HELPING",
            "number": "06",
            "livery": "vermilion",
            "placements": [
              {
                "id": "H-6",
                "x": 0,
                "y": 0.3,
                "angle": 0
              }
            ],
            "tuning": {
              "leverage": 1,
              "preload": 5,
              "stance": 0.38,
              "reserve_fraction": 1
            },
            "approach": "clean"
          }
        }
      },
      "improved": {
        "time": 58.99982336099028,
        "remaining_energy": 34.65117296562564,
        "build": {
          "id": "W05.PLAYER.B2",
          "host_id": "HOST",
          "name": "SECOND HELPING",
          "component_ids": [
            "H-6",
            "UPGRADE-DRIVE"
          ],
          "drive_source": "UPGRADE-DRIVE",
          "hopper_source": "H-6",
          "mass": 1.6800000000000002,
          "cadence": 12,
          "force": 2.5,
          "stride": 0.25,
          "leverage": 1,
          "grip": 1,
          "delivery": 3,
          "efficiency": 0.75,
          "reserve": 120,
          "width": 0.38,
          "length": 0.62,
          "height": 0.26,
          "hopper": [
            0.625,
            0.07,
            0.06
          ],
          "preload": 5,
          "alignment_error": 0,
          "horn": false,
          "claws": false,
          "armor": "light",
          "provenance": [
            "B1-6",
            "DRIVE-DONOR"
          ],
          "finish": {
            "number": "06",
            "livery": "vermilion"
          },
          "placements": [
            {
              "id": "H-6",
              "x": 0,
              "y": 0.3,
              "angle": 0
            },
            {
              "id": "UPGRADE-DRIVE",
              "x": 0,
              "y": -0.12,
              "angle": 0
            }
          ],
          "bench_profile": "W05.BENCH.STOCK.1",
          "design_snapshot": {
            "name": "SECOND HELPING",
            "number": "06",
            "livery": "vermilion",
            "placements": [
              {
                "id": "H-6",
                "x": 0,
                "y": 0.3,
                "angle": 0
              },
              {
                "id": "UPGRADE-DRIVE",
                "x": 0,
                "y": -0.12,
                "angle": 0
              }
            ],
            "tuning": {
              "leverage": 1,
              "preload": 5,
              "stance": 0.38,
              "reserve_fraction": 1
            },
            "approach": "clean"
          }
        }
      }
    },
    "port_cases": [
      {
        "name": "before",
        "passed": true
      },
      {
        "name": "after",
        "passed": true
      },
      {
        "name": "pass",
        "passed": true
      },
      {
        "name": "horn",
        "passed": true
      },
      {
        "name": "claw",
        "passed": true
      },
      {
        "name": "hop",
        "passed": true
      }
    ]
  },
  "validation_artifacts": [
    "evidence/model_report.json",
    "evidence/parity_report.json",
    "evidence/browser_report.json",
    "evidence/browser_edge_report.json",
    "evidence/wave04_regression.txt",
    "evidence/wave03_regression.txt",
    "evidence/visual_review.md",
    "evidence/validation_report.json"
  ],
  "implementation_boundaries": [
    "Fixed declared stock, not live capture or breeding gameplay.",
    "General catalogue, colony genetics, full life stages and recurring economies remain open.",
    "Reusable bench-collar and retained-native fixture; full damage, failure, tissue regrowth, storage decay and removal not implemented.",
    "One prepared primary-drive interface in this starter fixture; not a canonical universal cap.",
    "Root geometry is not full articulated-limb or collision-volume simulation.",
    "Fuel consumption does not dynamically reduce in-race mass in the inherited solver; fill affects entry mass.",
    "Path-space two-racer ground events only; no sustained flight or free 3D racing.",
    "Ground approach policy, not direct steering.",
    "No coupled race/world-clock obligations; practice pays no money.",
    "Local session and recipes only; records are not secure authoritative multiplayer saves.",
    "Native file navigation blocked in the test host; exact HTML executed via set_content. File URL autosave is best-effort.",
    "No Windows/macOS runtime or human playtest performed."
  ]
}
