"""Explicit, versioned experiment setups. No fixture is a canonical race history."""
from __future__ import annotations
from dataclasses import replace
from collections import Counter
from copy import deepcopy
from race import *
from hobby import *


def comparative_runs(dt=.01):
    w=resume_workshop()
    before=compile_workshop(w,'W04.EXP.PRE')
    w.install('W04.fit.purchased.drive','UPGRADE-DRIVE','player','HOST')
    after=compile_workshop(w,'W04.EXP.POST')
    course=foundry_course()
    runs={label:Race(course,[Runner(build)],equipment='speedsters',dt=dt).run()
          for label,build in [('before',before),('after',after)]}
    return w,runs


def encounter(mode:str,dt=.01,mass=1.7,preload=5.):
    """Same starting field and engine data per action comparison; not guaranteed victories.

    Host geometry, opponent and high-throughput reserve are in-kind experimental profiles.
    The challenger consumes the actual inherited H-6 F1 phenotype and purchased drive.
    """
    require(mode in {'pass','horn','claw','hop'},'unknown encounter')
    w=resume_workshop();w.install('W04.fit.purchased.drive','UPGRADE-DRIVE','player','HOST')
    challenger=compile_workshop(w,'W04.ENTRY.WORKSHOP')
    # Leverage is builder-selected; delivery is a disclosed stock reserve fixture.
    challenger=replace(challenger,name='Workshop racer',leverage=.85,delivery=12.,mass=mass,preload=preload,horn=mode in {'horn','claw'})
    if challenger.horn:
        # Explicit in-kind donor and prepared sect, then installation; not a free label bonus.
        w.stocks['W04.HORN.DONOR']=Stock('W04.HORN.DONOR','W02.DONOR.HORN','player','adult',None,{'horn_root','body'})
        w.prepare('W04.prepare.horn','player','W04.HORN.DONOR',[{'id':'W04.HORN','product':'W02.PROD.HORN.1','tissues':['horn_root']}])
        w.install('W04.fit.horn','W04.HORN','player','HOST')
        challenger=replace(challenger,component_ids=challenger.component_ids+('W04.HORN',),provenance=challenger.provenance+('W04.HORN.DONOR',))
    opponent=Build('W04.ENTRY.CLUB','W04.HOST.CLUB','Club demonstrator',('W04.NPC.STOCK',),'W04.NPC.STOCK',None,
                   cadence=9,force=4,claws=mode=='claw',provenance=('declared_in_kind_opponent',))
    policies=[Policy(passing=False,counter=mode=='claw'),Policy(passing=mode!='hop',jumping=mode=='hop',attacking=mode in {'horn','claw'})]
    entrants=[Runner(opponent,policies[0],d=.3),Runner(challenger,policies[1],d=-.3)]
    result=Race(foundry_course(straight=20),entrants,equipment='open',dt=dt).run()
    result['experiment']=mode
    result['setup_notes']=['NPC stock, mass/geometry and high-delivery reserve are declared fixture inputs.',
        'W03 H-6 inherited traits and UPGRADE-DRIVE identity are retained.',
        'Preload and leverage are setup choices, not inherited mutations.',
        'Different experiment runs are independent branches, not cloned stock coexisting in one world.',
        'Path-space race: no free steering, full body/limb collision, destructive damage, flyways or branching routes.']
    result['event_counts']=dict(Counter(e['kind'] for e in result['events']))
    return w,result


def integrated_meeting():
    w,result=encounter('hop')
    # Explicit initial endowments, not recurring creation of money.
    w.cash.update({'club':0,'sponsor':90,'club_lanista':0,'trial_customer':70})
    initial=w.total_money()
    record=register_result(result,'W04.MEETING.DEMONSTRATION')
    owners={'W04.ENTRY.WORKSHOP':'player','W04.ENTRY.CLUB':'club_lanista'}
    receipt=settle_meeting(w,record['event_id'],record,owners,'sponsor','club')
    trial=funded_trial(w,record['event_id'],'trial_customer')
    require(initial==w.total_money(),'post-race money not conserved')
    return {'scope':'One funded demonstration and authored customer decision, not an autonomous economy.',
        'race_result':record,'meeting_receipt':receipt,'trial_order':trial,'closing_cash':w.cash,
        'all_accounts_and_escrow':w.total_money(),'opening_accounts_and_escrow':initial,
        'public_cards':[public_build_card(row,True) for row in result['results']],
        'derived_project':{'donor':'W02.DONOR.HOPPER','candidate_basis':'measured synchrony contribution',
            'requested_output':'ordinary prepared assemblies; acceptance remains a bench test',
            'limits':'A published race is not evidence of genotype or a guaranteed offspring result.'},
        'limitations':['No repeat-cohort economy, mortality forecast, retention or purchase-conversion rate is claimed.',
            'Race time is not yet integrated with the broader world scheduler.',
            'Prize is paid once; replay scrubbing never produces a second transaction.']}


def write_outputs(directory):
    import json
    from pathlib import Path
    out=Path(directory);out.mkdir(parents=True,exist_ok=True)
    w,comparisons=comparative_runs()
    summary={'protocol':'W04 normalized path-race experiment','comparisons':{},'encounters':{}}
    for k,r in comparisons.items():
        summary['comparisons'][k]={'finish_time':r['results'][0]['finish_time'],'energy_used':120-r['results'][0]['remaining_energy'],
            'build':r['results'][0]['build'],'gates':r['results'][0]['gates']}
    for mode in ('pass','horn','claw','hop'):
        _,r=encounter(mode)
        (out/f'race_{mode}.json').write_text(json.dumps(r,indent=2,allow_nan=False),encoding='utf8')
        summary['encounters'][mode]={'classification':[{k:row[k] for k in ('id','name','finish_time','place')} for row in r['results']],
                                    'event_counts':r['event_counts']}
    summary['meeting']=integrated_meeting()
    (out/'fixture_outputs.json').write_text(json.dumps(summary,indent=2,allow_nan=False),encoding='utf8')
    return summary

if __name__=='__main__':
    import sys,json
    print(json.dumps(write_outputs(sys.argv[1] if len(sys.argv)>1 else '../evidence'),indent=2))
