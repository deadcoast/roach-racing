# RAD ROACH RACING — One Living Inventory / v0.6

An editable local browser slice connecting targeted collection, one working breeding profile, prepared anatomy, the existing workbench and newly calculated ground races. No account, installation or external assets are required to use the HTML.

## Open and use

Open `RRR_Living_World_v0.6.html` in a browser. Start on **Live stock** to see the protected complementary founders, two collection routes, the dry-bank nursery, funded sales, care commitments and whole-world backup. The previous bench, circuit and build sheets remain available.

A useful first sequence is to start a brood, visit the Switchyard Verge, inspect a catch, and advance to maturity. Retain animals for a project or sell suitable surplus. Preparing a donor creates an identified sect in the existing tray. Return the currently drafted same-role component, fit the new sect, commit the arrangement, and race it. Draft changes are free; fitting, attendance, collecting, preparation and care have disclosed costs. Do not consume the sole protected founders without deliberately releasing their protection.

Hopper offspring can themselves become breeders. **Ordinary surplus** is an opt-in production policy, not automatic genetic optimization: it retains identified replacement stock and sells unprotected ordinary output within the buyer's budget and quantity. **Repeat** attempts the next brood only when space and care reserves allow. **Pause new starts** does not halt the care of living animals. A rack expands actual capacity but does not generate demand. Funded club work supplies a lower-capital recovery action.

## Clock, money and save behavior

Only world actions advance turns. Offline time is paused. One newly computed race attendance advances two turns and charges three credits plus care; playback, pause and scrubbing do not. Care costs advance for both owned living stock and active broods. Temporary emergency-care debt is recorded rather than silently granting free care or imposing a new global death rule.

The World backup in **Live stock** exports and restores inventory, broods, money, clock and bench. Header **Export sheet / Import** remains a recipe operation, not ownership. Race frame playback stays in the active browser session; attendance summaries remain in world backups. Whole backups are editable local user files, not secure competition saves.

Browser local storage is best-effort and its status is displayed. File and HTTP navigation were blocked by the evaluation host. Actual controls and file backup round trips were tested by executing the exact HTML with Playwright `set_content`; native-file persistence and Windows/macOS behavior are unverified. Export a whole-world backup before replacing versions or clearing browser storage. A previous same-origin W05 bench may be migrated as a design against disclosed W06 starting assets, not imported as a nonexistent historical economy.

## What is implemented

Two targeted, menu-driven field routes (Hoppers and cicadas); bounded source populations; capture preservation choices; individual observations; three-locus Hopper breeding with eggs/nymphs/adults; future capacity; protected founders and replacement policy; ordinary live and prepared-part sales; optional repeat production; buyer quotas and explicitly external-funded renewal; care and working funds; live donor-to-part custody; dynamic bench components; attendance clock; local backup; desktop and narrow interfaces.

The starting host, eight existing sects, two founders, facilities and 142 player credits are in-kind experimental assets. Whole-specimen buying, staged contracts and a general commercial kit shop are the next primary task. No complete player-driven or autonomous economy is claimed.

## Scope boundaries

Fictional normalized model, not real insect biology. Only Hoppers reproduce in this release. The two-route field screen is not a traversable wilderness. Three independent diploid loci do not implement linkage, mutation or a general genetics system. Capture damage changes anatomy usefulness; it does not reroll genetics. Supported Hopper bodies remain cared for after hind-pair extraction; drive extraction is vital for the cicada. The W05 reusable collar/native cradle profile remains limited to this workshop, not all graft removal.

Race engine and procedural anatomy drawing remain unchanged from W05. It is a two-racer ground path-space model, not full articulated physics or sustained flight. Cicada efficiency is recorded for later integration; current race efficiency remains fixed, while cadence and force are bound. A single active-world descriptor registry supports this local app; concurrent server worlds are not implemented. Repeated income probes use a stated off-screen budget boundary, explicit starting assets and one fixed seed; they do not establish balanced or guaranteed profit.

## Source and build

`src/world.js` owns world state and operations. `src/bench.js` extends the prior bench with dynamic component descriptions. `src/race.js` and `src/anatomy.js` are byte-identical prior sources. `src/app.js` and `src/template.html` contain the integrated UI. `src/style.css` contains styling.

Rebuild the self-contained HTML:

```sh
python tools/build_app.py
```

The strict-JSON `RRR_Wave_06.spec` and cumulative `world_context_v0.6.json` retain source relationships, proposals, task status, evidence limits and next work. The `.spec` is RRR's exchange format, not a claimed canonical private MIVIM grammar. `tools/build_spec.py` derives the current documents from its authored records and executed model report. Run the model tests before regenerating these documents.

## Validation

Requires Python, Node.js and `jsonschema`. The tested environment used Python 3.11+ compatible syntax and Node.js with CommonJS. Optional browser tests require Playwright and Chromium; the supplied harness uses `/usr/bin/chromium` on Linux.

```sh
node tests/world_tests.cjs
node tests/bench_regression.cjs
node tests/parity.cjs
python validate_wave06.py
python validate_wave06.py --browser
```

The validator checks baseline preservation, schema, references, exact HTML/source consistency, new behavior, original bench behavior, six preserved Python/JS examples and earlier Python suites extracted from the actual reference archive. Without `--browser`, its browser findings refer to the supplied hash-bound report rather than a fresh browser run. Schema validation is structural only; behavioral tests are separate. No human usability, retention, full economy calibration or independent creative-quality certification is claimed.

## Read order for the next agent

Read `RRR_Wave_06_Foundations.md`, `TODO_Wave_v0.6.md`, the `.spec`, then `MIVIM_Review_v0.6.md`. Reproduce `evidence/validation_report.json`. Preserve the actual bench and world rather than replacing them with a new disconnected demonstration. The next primary task is Two Nets' two-way live shop and specimen-aware funded orders.
