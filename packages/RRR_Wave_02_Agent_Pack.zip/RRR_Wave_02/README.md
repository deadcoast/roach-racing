# RRR Wave 02 — Agent packet

Start with `RRR_Wave_02_Foundations.md`. Load `world_context_v0.2.json` for the existing reference context plus the new rules, or `wave02.json` for only this wave.

The new data is proposed foundation material. It does not promote generated ideas to user canon. Previous seed records remain unchanged; new fields use the `W02` namespace.

## Validation

Run `python validate_wave02.py` from any working directory. Python 3.10+ is sufficient for the standard-library fixtures. The optional `jsonschema` package enables the complete field-shape check. No network calls are made by the validator.

`validation_report.json` states exactly what was tested. No full race, ecology, economy or retention simulation is included.

## Extending the wave

Select a named record and revise it with a new version and explicit dependencies. Keep measurement, genotype truth, observed evidence, fitted configuration and temporary condition separate. Do not reinterpret null timing or capacity parameters as zero.

Preserve the prior handbook as a component/world baseline. Do not turn these records into prose scenes unless a later task asks for story material.
