# RRR Wave v0.3 — agent handoff

Start with `RRR_Wave_03_Foundations.md`. Read `TODO_Wave_v0.3.md` for completed specification work and the next queued task. `MIVIM_Review_v0.3.md` distinguishes novel contributions, experimental witnesses, interaction design and supporting work.

## Formats

`RRR_Wave_03.spec` is strict JSON using Reference, Plan, Workflow, Adherence and MIVIM sections plus typed development content. Its serialization is an RRR exchange format, not a claim about an unavailable canonical MIVIM grammar.

`world_context_v0.3.json` appends this wave to the previous context. Prior collections and Wave 02 are unchanged. `reference/world_context_v0.2.json` is a byte-preserved baseline used for regression checks. New rules refine old IDs; they do not retroactively rewrite history.

## Run local checks

From the unpacked folder:

```sh
python validate_wave03.py
```

The behavior model and tests use the standard library and Python 3.10+ syntax. JSON Schema validation runs when `jsonschema` is installed; otherwise the report explicitly records that optional check as not run. No network is used by validation. Structural checks and behavior tests still run without that dependency.

`evidence/test_log.txt` contains individual test results. `evidence/fixture_outputs.json` contains the actual normalized bench and integration outputs. `evidence/wave02_regression_report.json` records the separately rerun baseline validator; its code remains in the original Wave 02 pack.

## Load for agent work

Use the cumulative context for identifiers and earlier proposals. Retrieve only relevant records for an operation. For intake, load the active project and its `intake_requirements`, not its final-product target. For commercial acceptance, load the actual order protocol and requirements. For genetics, distinguish internal truth from player-observed evidence.

**Next primary task: W04.T01 — shared-trait assembled-racer and modular-course race integration.** Keep real race wins, personal kit assembly, ambitious appearance and the wider hobby central.

## Evidence boundary

This is specification development with bounded executable witnesses. It is not a game build, rendered interface, realistic biological model, complete economy or retention experiment. Units and eight-tick life timings are fixture parameters, not calibrated world laws. Money is fictional game currency; the worked margin is not a guarantee. Open biological and permanent-loss branches remain open.
