# RRR — Wave 14 Authoring TODO

**Current phase:** compendium and world-bible architecture. Completed rows refer to reference content, not software features or game balance.

## Completed in this reference volume

### [x] W14.T01 — Separate universe foundations from prototype-specific bounds
**Role:** editorial_architecture. **Status:** authored_and_cross_referenced.
Author premises retain authority; historical prototype dimensions, rates and solver limits remain experimental records.

### [x] W14.T02 — Define anatomy and all major component-role distinctions
**Role:** world_and_system_design. **Status:** authored_and_cross_referenced.
The host, support, supply, drive, gait, contact, correction, landing and protection are not conflated.

### [x] W14.T03 — Develop sect monographs linking source, selection, fitting, race behavior and trade
**Role:** creative_translation. **Status:** authored_and_cross_referenced.
Each of thirty entries has physical anatomy, a source, purposeful selection, construction, observed consequence and commercial role.

### [x] W14.T04 — Define action phases and qualitative morphological branches
**Role:** mechanical_and_biological_conception. **Status:** authored_not_simulated.
Actions have actual anatomical prerequisites and visible consequences; six morphology proposals change structure or appearance without a universal rarity bonus.

### [x] W14.T05 — Define common graft exchange, part states and breeding-production boundaries
**Role:** world_practice_design. **Status:** working_proposals_authored.
Innate assimilation remains unrestricted by commercial permission; prepared swaps, vital extraction, condition, retained anatomy and regrowth are distinguished.

### [x] W14.T06 — Interconnect sets, institutions, sport and physical hobby objects
**Role:** integrated_worldbuilding. **Status:** authored_and_cross_referenced.
Eight construction families, nine institutional/occupation entries, eight prop briefs and six integrated chains create concrete uses and relationships.

### [x] W14.T07 — Publish the reference volume, reading map and editorial amendments
**Role:** editorial_handoff. **Status:** editorially_checked.
Working proposals are marked; links and identifiers resolve; the cumulative baseline is preserved; next work is compendium authoring rather than runtime work.

## Next compendium work

### [ ] P0 / W15.C01 — Donor monographs: inheritance, life history and selection depth
**Purpose:** Expand the existing source forms into full species and population monographs rather than more one-line bonuses.
**Required reference:** For each selected form: life stages, reproductive eligibility, heritable variation, morphology, developmental confounders, useful-stage anatomy, founder selection, population differences, preservation and distinct customers.
**Boundary:** Do not copy one three-locus reproductive formula into every species or fabricate universal probabilities.

### [ ] P0 / W15.C02 — The living material lifecycle: preparation, recovery and preservation
**Purpose:** Develop the qualitative branches that determine swappable parts and the value of keeping living stock.
**Required reference:** Product-specific raw preparation, exchange, supported-body handling, storage states, material loss, transport and repair definitions, with a clearly proposed injury/aging philosophy.
**Boundary:** No surprise global permadeath or free infinite regeneration; numbers follow the selected meanings.

### [ ] P0 / W15.C03 — Biosphere, scale and chronology
**Purpose:** Resolve core environmental context before geography and production imply contradictory survival histories.
**Required reference:** A consistent proposed post-winter recovery account, creature scale reference, resource ecology and explicit separation of apocalypse time from the sport’s thirty-year history.
**Boundary:** Any adopted origin explanation requires explicit working-proposal status; earlier vault suggestions are not author canon.

### [ ] P1 / W15.C04 — Factional sport and regional supply atlas
**Purpose:** Define institutional differences rather than palette-swapped opponents.
**Required reference:** Named factions and regions with livelihoods, ecological sources, trade, club culture, representation process, championship role and everyday participants.
**Boundary:** No faction-exclusive gene permission or artificial geographic tiering of every ordinary insect.

### [ ] P1 / W15.C05 — Flyer division and complete aerial kit handbook
**Purpose:** Expand previously declared flight anatomy, rearing and course culture into a dedicated reference chapter.
**Required reference:** Wing/drive/linkage/sensing combinations, aerial track grammar, preparation, viable landing and race distinctions; supply businesses and kit forms included.
**Boundary:** No engine work required to author the chapter; no suggestion that raised ground racing constitutes flight.

### [ ] P1 / W15.C06 — Catalog editions, appearance inheritance and hobby history
**Purpose:** Make collecting, display and restoration as concrete as racing preparation.
**Required reference:** Natural variants versus finishes, supported inheritance proposals, breeder/product histories, historic originals versus revivals, collector claims and usable artifact briefs.
**Boundary:** Do not use cosmetics as unannounced speed bonuses or claim provenance automatically from a product name.

## Downstream implementation work stays separate

The previous active-limb simulation, numerical progression calibration, rendering, transport operators and runtime-scale tasks remain in their historical handoffs. They are not marked complete and they are not the next coding instruction for this compendium-authoring phase. Software work should consume the defined meanings rather than deciding them accidentally through a convenient implementation.
