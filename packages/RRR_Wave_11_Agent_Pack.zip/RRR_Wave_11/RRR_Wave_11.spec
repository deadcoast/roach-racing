{
  "manifest": {
    "id": "W11",
    "version": "0.11.0",
    "date": "2026-09-11",
    "title": "RRR \u2014 Club Circuit",
    "status": "revisable_foundations_and_interactive_local_prototype",
    "runtime_base": "Wave09",
    "written_handoff": "Wave10 specification retained as unresolved runtime handoff",
    "base_sha256": "7f915b265b60492b587400d00f29587200ab2e6d8c1da30d4a2a575de572d335",
    "serialization": "Strict JSON RRR exchange format; not a claimed canonical private MIVIM grammar"
  },
  "Reference": {
    "sources": [
      {
        "id": "W11.S01",
        "title": "SEGA \u2014 Gaiden Adventure / Pocket Circuit",
        "url": "https://ryu-ga-gotoku.com/gaiden/asia_en/adventure/",
        "checked_on": "2026-09-11",
        "supports": "CourStar venue, body/part acquisition, Time Attack and local Rival modes.",
        "limits": "Coliseum tournament text elsewhere on this page is NOT Pocket Circuit evidence. No RRR table, payout or genetic rule supplied."
      },
      {
        "id": "W11.S02",
        "title": "Tamiya \u2014 Official Mini 4WD Race Regulations",
        "url": "https://www.tamiya.com/english/mini4wd/regulation.htm",
        "checked_on": "2026-09-11",
        "supports": "Inspection before start; no changes after inspection; race completion, classification, qualifying and final results.",
        "limits": "No brand-only, body-dimension, damage or homemade-part restriction imported into RRR Open. RRR mirrored format and points are authored."
      },
      {
        "id": "W11.S03",
        "title": "Tamiya \u2014 Mini 4WD Setup Guide",
        "url": "https://www.tamiya.com/english/mini4wd/setupguide/setupguide.htm",
        "checked_on": "2026-09-11",
        "supports": "Motor speed/torque, gearing, contact, braking, landing and assembly have distinct purposes.",
        "limits": "Walking anatomy and every normalized RRR coefficient are fictional. No unknown source-game per-item formula invented."
      },
      {
        "id": "W11.S04",
        "title": "Tamiya \u2014 Independent race organizers",
        "url": "https://www.tamiya.com/japan/mini4wd/localevents",
        "checked_on": "2026-09-11",
        "supports": "Circuit lending, published layouts, operating guidance and event support.",
        "limits": "Does not validate RRR costs, economy, sponsor funding or player qualification rules."
      }
    ],
    "next_task_source": "W10.T02 from Wave09 TODO and repeated Wave10 written handoff",
    "runtime_gap": "Runtime is based on the recovered Wave09 executable. Wave10 maker source and final archive were not recovered. Its written specification remains an explicit pending handoff."
  },
  "Plan": {
    "tasks": [
      {
        "id": "W11.T01",
        "title": "Recover handoff, check primary references and preserve actual baseline",
        "role": "supporting",
        "status": "reviewed",
        "depends_on": []
      },
      {
        "id": "W11.T02",
        "title": "Compile inspectable component-built rivals and connect useful trait projects",
        "role": "novel_integration",
        "status": "implemented",
        "depends_on": [
          "W11.T01"
        ]
      },
      {
        "id": "W11.T03",
        "title": "Implement mirrored club rounds, finishing classification and legal re-entry",
        "role": "novel_integration",
        "status": "implemented",
        "depends_on": [
          "W11.T02"
        ]
      },
      {
        "id": "W11.T04",
        "title": "Settle finite prizes, actual donor rewards and bounded qualification",
        "role": "novel_integration",
        "status": "implemented",
        "depends_on": [
          "W11.T03"
        ]
      },
      {
        "id": "W11.T05",
        "title": "Run exhibitions on owned published layouts with frozen geometry",
        "role": "novel_integration",
        "status": "implemented",
        "depends_on": [
          "W11.T04"
        ]
      },
      {
        "id": "W11.T06",
        "title": "Render race cards, actual racers, round programme and living prizes",
        "role": "visual_execution",
        "status": "rendered_and_browser_checked",
        "depends_on": [
          "W11.T05"
        ]
      },
      {
        "id": "W11.T07",
        "title": "Verify operational failure, migration, unchanged race operators and package",
        "role": "supporting",
        "status": "tested_at_declared_scope",
        "depends_on": [
          "W11.T06"
        ]
      }
    ],
    "next": [
      {
        "id": "W12.T01",
        "priority": "P0",
        "title": "Recover or explicitly rebuild the missing Wave10 maker runtime against this shared world",
        "acceptance": "Actual alternate-stock full kit production, safe packing/counter sales, and evidence-backed living breeder orders; preserve current competitions and all identities. Do not claim reconstruction preserves unrecovered implementation."
      },
      {
        "id": "W12.T02",
        "priority": "P0",
        "title": "Improve rival movement and competition depth through measured mechanisms",
        "acceptance": "Hopper timing, safe overtakes and contact are visibly useful across representative builds; multi-entrant simulation evaluated before calling four-entry rosters simultaneous races. No fake action bonus or per-rank stat multiplier."
      },
      {
        "id": "W12.T03",
        "priority": "P1",
        "title": "Connect repeat sporting demand and material suppliers",
        "acceptance": "Funded market requests derive from actual permitted build/result information and accepted products; no news-to-cash aura or guaranteed genetic claim."
      },
      {
        "id": "W12.T04",
        "priority": "P1",
        "title": "Advance Factional and Flyer competition only with required systems",
        "acceptance": "Actual qualification consequences, suitable course and locomotion implementation, finite rewards and disclosed rules. Do not rename a ground event as aerial racing."
      }
    ]
  },
  "Workflow": "reference \u2192 recovered baseline \u2192 actual-stock rival definitions \u2192 meet operators \u2192 existing race UI \u2192 failure cases \u2192 review \u2192 archive verification",
  "Adherence": {
    "authority": "Original user premises govern; all new mechanisms revisable.",
    "preserved": [
      "speed and winning",
      "personally assembled kits",
      "whole-insect Wrangloid commerce",
      "anyone may catch and breed",
      "genuine improvements",
      "optional careers",
      "Open equipment freedom",
      "Flyers with Flyers",
      "Locals \u2192 Regionals \u2192 Factionals \u2192 New World City"
    ],
    "MIVIM": {
      "objective": "Turn the same living-part constructions into public rivals, meaningful club competition, actual prizes and purposeful next donor projects.",
      "comparator": "A race-power ranking with cosmetic opponents, unbacked rewards and disconnected breeding hints.",
      "quality": "Reviewed at bounded local application scope; complete game and human usability gates remain open.",
      "novel_development_adherence": "Concrete project-specific integration of shared anatomy, public constructions, reciprocal contests, earned stock and project-led collection. No worldwide novelty claim.",
      "effectiveness": "Actual modeled rounds, UI operations, payments, classification, migration and portable backup checked.",
      "creativity": "Authored race-programme and anatomical inspection connect sporting identity to actionable biological projects; experiential originality unmeasured.",
      "scaling_potential": "Reusable event and rival definitions; finite local scenario, no autonomous national simulation or performance benchmark.",
      "grading": "No authorized numerical weights or score bands; quality AND novel-development adherence are hard conditions."
    }
  },
  "rules": [
    {
      "id": "W11.REFERENCE.01",
      "origin": "source_hobby_translation",
      "statement": "Use the Gaiden local venue, parts and rivals as the competitive-hobby reference.",
      "purpose": "The same useful part links the shop, build and opponent."
    },
    {
      "id": "W11.REFERENCE.02",
      "origin": "source_hobby_translation",
      "statement": "Keep physical Mini 4WD procedures separate from Gaiden videogame rules.",
      "purpose": "No invented 1:1 claim for the points table or tournament format."
    },
    {
      "id": "W11.REFERENCE.03",
      "origin": "source_hobby_translation",
      "statement": "Do not turn the Coliseum tournament on the SEGA page into Pocket Circuit evidence.",
      "purpose": "Source location matters as much as source domain."
    },
    {
      "id": "W11.REFERENCE.04",
      "origin": "source_hobby_translation",
      "statement": "The existing race engine compiles actual native anatomy and installed observations.",
      "purpose": "No difficulty multiplier overwrites component causes."
    },
    {
      "id": "W11.REFERENCE.05",
      "origin": "source_hobby_translation",
      "statement": "Retain Open build freedom, Speedsters weapons policy, Fireworks offense/light protection and Flyers with Flyers.",
      "purpose": "Ground scope is disclosed; no fake aerial event."
    },
    {
      "id": "W11.REFERENCE.06",
      "origin": "source_hobby_translation",
      "statement": "Wave 10 executable source was not recovered; runtime extends Wave09.",
      "purpose": "Its written maker requirements stay pending instead of being silently called integrated."
    },
    {
      "id": "W11.ROSTER.01",
      "origin": "rrr_native_integration",
      "statement": "Each rival has a particular host, particular donors and particular prepared components.",
      "purpose": "The runner can be inspected as a real construction."
    },
    {
      "id": "W11.ROSTER.02",
      "origin": "rrr_native_integration",
      "statement": "Compile NPCs with the player catalogue, fitting validation and compiler.",
      "purpose": "Equivalent assembly uses equivalent mechanisms."
    },
    {
      "id": "W11.ROSTER.03",
      "origin": "rrr_native_integration",
      "statement": "Publish the useful part measurements in the rival inspector.",
      "purpose": "The player sees which observed property to investigate."
    },
    {
      "id": "W11.ROSTER.04",
      "origin": "rrr_native_integration",
      "statement": "Rivals do not read unmeasured player genomes or conjure counterbuilds.",
      "purpose": "Changing hidden player state cannot alter their current stock."
    },
    {
      "id": "W11.ROSTER.05",
      "origin": "rrr_native_integration",
      "statement": "Role-specific mechanical advantages are not universal superiority.",
      "purpose": "Leverage, load, reach and surface remain purposeful decisions."
    },
    {
      "id": "W11.ROSTER.06",
      "origin": "rrr_native_integration",
      "statement": "NPC specimens are declared club-owned/competitor-owned fixture assets, not simulated prior breeding successes.",
      "purpose": "No invented provenance or player ownership is granted."
    },
    {
      "id": "W11.ROSTER.07",
      "origin": "rrr_native_integration",
      "statement": "A rival suggestion can become an existing selection target and field route.",
      "purpose": "The suggestion preserves trait ID and changes neither genes nor inventory."
    },
    {
      "id": "W11.ENTRY.01",
      "origin": "source_hobby_translation_and_rrr_execution",
      "statement": "A meet announces equipment policy, course version, laps, opponents, format, purse, fees and qualification before entry.",
      "purpose": "No hidden extra sporting requirement appears at settlement."
    },
    {
      "id": "W11.ENTRY.02",
      "origin": "source_hobby_translation_and_rrr_execution",
      "statement": "Entry uses an owned registered host with a committed valid build.",
      "purpose": "An unresolved draft is not silently equipped or discarded."
    },
    {
      "id": "W11.ENTRY.03",
      "origin": "source_hobby_translation_and_rrr_execution",
      "statement": "Reserve the complete advertised purse before registration succeeds.",
      "purpose": "Unfunded competition is unavailable rather than promising fictitious receipts."
    },
    {
      "id": "W11.ENTRY.04",
      "origin": "source_hobby_translation_and_rrr_execution",
      "statement": "One active meet is supported in the local implementation.",
      "purpose": "A second registration cannot double-book the same world operation."
    },
    {
      "id": "W11.ENTRY.05",
      "origin": "source_hobby_translation_and_rrr_execution",
      "statement": "One host represents the player throughout that meet.",
      "purpose": "Other stable projects remain available; changing the entrant requires withdrawal."
    },
    {
      "id": "W11.ENTRY.06",
      "origin": "source_hobby_translation_and_rrr_execution",
      "statement": "Between rounds the same host can be refitted and re-inspected.",
      "purpose": "Already completed heats preserve their earlier snapshots."
    },
    {
      "id": "W11.ENTRY.07",
      "origin": "source_hobby_translation_and_rrr_execution",
      "statement": "The entered host cannot begin reproduction before its meet ends or is withdrawn.",
      "purpose": "Competition and breeding share the same animal."
    },
    {
      "id": "W11.ENTRY.08",
      "origin": "source_hobby_translation_and_rrr_execution",
      "statement": "A pending calculation freezes requests and blocks conflicting world commands.",
      "purpose": "No partly calculated round consumes a moving build or changing account."
    },
    {
      "id": "W11.FORMAT.01",
      "origin": "rrr_authored_sport",
      "statement": "Four entrants contest three round-robin rounds using the current two-racer engine.",
      "purpose": "A roster of four is not falsely displayed as simultaneous four-roach physics."
    },
    {
      "id": "W11.FORMAT.02",
      "origin": "rrr_authored_sport",
      "statement": "Every pairing has two standing-start heats with swapped sides.",
      "purpose": "Neither entrant permanently receives one favorable starting position."
    },
    {
      "id": "W11.FORMAT.03",
      "origin": "rrr_authored_sport",
      "statement": "Also reverse solver evaluation order in the second heat.",
      "purpose": "The probe reduces order bias without claiming perfect physical symmetry."
    },
    {
      "id": "W11.FORMAT.04",
      "origin": "rrr_authored_sport",
      "statement": "Use 3 points for a valid heat win, 1 each for a valid tied finish and 0 for a loss or no finish.",
      "purpose": "Contact and damage do not score championship points."
    },
    {
      "id": "W11.FORMAT.05",
      "origin": "rrr_authored_sport",
      "statement": "All-retired heats award no win and no tie point.",
      "purpose": "Last-roach-standing does not replace completing the race."
    },
    {
      "id": "W11.FORMAT.06",
      "origin": "rrr_authored_sport",
      "statement": "Rank by points, then number of valid finishes; otherwise share rank.",
      "purpose": "Arbitrary IDs or summed times across different rival encounters do not break the tie."
    },
    {
      "id": "W11.FORMAT.07",
      "origin": "rrr_authored_sport",
      "statement": "A qualifying crown requires first rank and at least three actual heat wins.",
      "purpose": "An all-tied low-evidence table cannot automatically grant a championship invitation."
    },
    {
      "id": "W11.FORMAT.08",
      "origin": "rrr_authored_sport",
      "statement": "Results use identical frozen course and build inputs and required gate completion.",
      "purpose": "Client place labels cannot override finishing times."
    },
    {
      "id": "W11.FORMAT.09",
      "origin": "rrr_authored_sport",
      "statement": "Four actual computed heats settle one round.",
      "purpose": "NPC-versus-NPC results are simulated rather than inferred from labels."
    },
    {
      "id": "W11.REWARD.01",
      "origin": "rrr_native_progression",
      "statement": "First Current awards Local Open qualification; Ballast requires that record.",
      "purpose": "Participation permission follows a real sporting result, not money or breeding rank."
    },
    {
      "id": "W11.REWARD.02",
      "origin": "rrr_native_progression",
      "statement": "A Regional win records Regional completion only.",
      "purpose": "Factionals and World City remain explicitly not playable."
    },
    {
      "id": "W11.REWARD.03",
      "origin": "rrr_native_progression",
      "statement": "The custom-course invitational pays its declared purse but grants no championship qualification.",
      "purpose": "A player-authored easy layout cannot manufacture official advancement."
    },
    {
      "id": "W11.REWARD.04",
      "origin": "rrr_native_progression",
      "statement": "Trophies preserve the entered host identity, name, meet and course version.",
      "purpose": "Later renaming cannot rewrite the winner remembered by the record."
    },
    {
      "id": "W11.REWARD.05",
      "origin": "rrr_native_progression",
      "statement": "The first Local Open crown offers one actual donor pair from a finite nursery.",
      "purpose": "The reward is useful stock, not a species or gene unlock."
    },
    {
      "id": "W11.REWARD.06",
      "origin": "rrr_native_progression",
      "statement": "The player chooses return-focused Hoppers or release-focused Glassfoot stock.",
      "purpose": "Both connect to existing breeding and alternative-preparation projects."
    },
    {
      "id": "W11.REWARD.07",
      "origin": "rrr_native_progression",
      "statement": "Claiming requires two real holding places and protects the transferred stock.",
      "purpose": "Full capacity does not delete the award or spawn overflow inventory."
    },
    {
      "id": "W11.REWARD.08",
      "origin": "rrr_native_progression",
      "statement": "Unchosen award stock remains with the club; a claimed ticket cannot pay again.",
      "purpose": "No doubled offspring or second reward appears on retry."
    },
    {
      "id": "W11.MONEY.01",
      "origin": "rrr_native_economy",
      "statement": "The club receives a finite declared 1440-credit opening operating grant against the external account.",
      "purpose": "Player cash and old account balances are preserved."
    },
    {
      "id": "W11.MONEY.02",
      "origin": "rrr_native_economy",
      "statement": "Registration fee goes to operating services; advertised prize funds are separately reserved.",
      "purpose": "A registration receipt is not a prize receipt."
    },
    {
      "id": "W11.MONEY.03",
      "origin": "rrr_native_economy",
      "statement": "A completed round costs two credits plus actual care and advances two world turns.",
      "purpose": "Broods, care, orders and competition share one clock."
    },
    {
      "id": "W11.MONEY.04",
      "origin": "rrr_native_economy",
      "statement": "The six-heat player schedule covers three rounds and six world turns.",
      "purpose": "Mirror-leg playback is not another attendance charge."
    },
    {
      "id": "W11.MONEY.05",
      "origin": "rrr_native_economy",
      "statement": "Tied entrants split the prize slots they occupy; indivisible remainder returns to the club.",
      "purpose": "Conservation holds without silently creating fractions or extra money."
    },
    {
      "id": "W11.MONEY.06",
      "origin": "rrr_native_economy",
      "statement": "NPC prize shares enter their actual accounts.",
      "purpose": "The player cannot take every advertised placing reward."
    },
    {
      "id": "W11.MONEY.07",
      "origin": "rrr_native_economy",
      "statement": "Cancellation of a failed calculation pays no round fee; withdrawal retains incurred costs and refunds the unawarded purse to the club.",
      "purpose": "Technical failure and voluntary withdrawal have distinct consequences."
    },
    {
      "id": "W11.MONEY.08",
      "origin": "rrr_native_economy",
      "statement": "The event roster has finite sponsored editions: three per official card and two custom exhibitions.",
      "purpose": "There is no unfunded infinite prize renewal; practice and existing livelihoods remain."
    },
    {
      "id": "W11.MONEY.09",
      "origin": "rrr_native_economy",
      "statement": "Replay, scrubbing, historical inspection and donor-project inspection cost no world time.",
      "purpose": "Learning and replay do not mint prizes or repeat care charges."
    },
    {
      "id": "W11.COURSE.01",
      "origin": "source_hobby_translation_and_rrr_execution",
      "statement": "Official meetings use their published normalized club geometry.",
      "purpose": "The same course version is used by all entrants in that meeting."
    },
    {
      "id": "W11.COURSE.02",
      "origin": "source_hobby_translation_and_rrr_execution",
      "statement": "An invitational freezes the currently laid owned circuit.",
      "purpose": "Drafts, saved plans and privately missing pieces cannot stand in for a physical course."
    },
    {
      "id": "W11.COURSE.03",
      "origin": "source_hobby_translation_and_rrr_execution",
      "statement": "A player course cannot be republished while its invitational is active.",
      "purpose": "The floor does not change under a pending meeting."
    },
    {
      "id": "W11.COURSE.04",
      "origin": "source_hobby_translation_and_rrr_execution",
      "statement": "A setup on smooth short circuits may differ from a longer loose-surface Regional.",
      "purpose": "Traits and fitting, not a regional stat aura, explain changed results."
    },
    {
      "id": "W11.PRESENT.01",
      "origin": "rrr_original_execution",
      "statement": "Event cards expose their useful rules and geometry before charging.",
      "purpose": "The player knows the goal, current entrants and costs."
    },
    {
      "id": "W11.PRESENT.02",
      "origin": "rrr_original_execution",
      "statement": "A current-round board keeps points, valid finishes, next opponent and fitted identity together.",
      "purpose": "The event remains readable beside the actual roach."
    },
    {
      "id": "W11.PRESENT.03",
      "origin": "rrr_original_execution",
      "statement": "Rival portraits draw their committed component layouts using the existing anatomical renderer.",
      "purpose": "Inspection is not a generic rival icon beside invented stats."
    },
    {
      "id": "W11.PRESENT.04",
      "origin": "rrr_original_execution",
      "statement": "The result comes before diagnosis and supply suggestions.",
      "purpose": "Winning the race remains the central achievement."
    },
    {
      "id": "W11.PRESENT.05",
      "origin": "rrr_original_execution",
      "statement": "Race replays use real current calculations and frozen appearance.",
      "purpose": "No preselected win animation stands in for simulation."
    },
    {
      "id": "W11.PRESENT.06",
      "origin": "rrr_original_execution",
      "statement": "Portable backups preserve tables, requests, qualification and reward custody, but not session replay frames.",
      "purpose": "Restored history never claims that missing playback data exists."
    },
    {
      "id": "W11.PRESENT.07",
      "origin": "rrr_original_execution",
      "statement": "Source-derived guidance is optional.",
      "purpose": "Buying a coordinated kit and simply racing remains a complete participation path."
    },
    {
      "id": "W11.VALIDATION.01",
      "origin": "supporting",
      "statement": "Use current behavior checks, original-release regression, rendered review and human testing as distinct evidence categories.",
      "purpose": "Tests cannot become a claim of enjoyment or originality."
    },
    {
      "id": "W11.VALIDATION.02",
      "origin": "supporting",
      "statement": "Preserve old cumulative records and original source references in the release.",
      "purpose": "Missing Wave10 runtime is recorded, not covered with a fabricated preservation claim."
    },
    {
      "id": "W11.VALIDATION.03",
      "origin": "supporting",
      "statement": "No final numeric MIVIM grade or acronym expansion is invented.",
      "purpose": "Quality and novel-development adherence remain non-compensable gates."
    },
    {
      "id": "W11.VALIDATION.04",
      "origin": "supporting",
      "statement": "Treat local backups as user-editable consistency-checked data, not server-authoritative competition records.",
      "purpose": "Synthetic settlement tests do not establish anti-cheat."
    },
    {
      "id": "W11.VALIDATION.05",
      "origin": "supporting",
      "statement": "Carry unverified Hopper timing and multi-racer-motion fidelity as explicit future tests.",
      "purpose": "No extra jump-win bonus masks a weak actual interaction."
    }
  ],
  "event_definitions": [
    {
      "id": "first",
      "name": "First Current",
      "tag": "LOCAL \u00b7 OPEN QUALIFIER",
      "equipment": "open",
      "roster": [
        "seam",
        "ram",
        "hopper"
      ],
      "straight": 14,
      "laps": 2,
      "surface": "smooth",
      "fee": 6,
      "purse": [
        60,
        24,
        12,
        0
      ],
      "grant": "local_open",
      "requires": null,
      "editionLimit": 3,
      "purpose": "The first official Open circuit title. Win the meet to earn an invitation to the Regional trial."
    },
    {
      "id": "glass",
      "name": "Glassline Dash",
      "tag": "LOCAL \u00b7 SPEEDSTERS",
      "equipment": "speedsters",
      "roster": [
        "seam",
        "hopper",
        "load"
      ],
      "straight": 20,
      "laps": 2,
      "surface": "smooth",
      "fee": 6,
      "purse": [
        48,
        20,
        8,
        0
      ],
      "grant": "local_speedsters",
      "requires": null,
      "editionLimit": 3,
      "purpose": "Weapon-free builds, real contact and legal Hoppers. Raw pace, release and reserve matter."
    },
    {
      "id": "sparks",
      "name": "Sparks at Sundown",
      "tag": "LOCAL \u00b7 FIREWORKS",
      "equipment": "fireworks",
      "roster": [
        "ram",
        "claw",
        "flash"
      ],
      "straight": 12,
      "laps": 2,
      "surface": "rough",
      "fee": 6,
      "purse": [
        54,
        22,
        10,
        0
      ],
      "grant": null,
      "requires": null,
      "editionLimit": 3,
      "purpose": "Working offense and light carapace. Win by finishing races, not by attack count."
    },
    {
      "id": "regional",
      "name": "Ballast Regional Trial",
      "tag": "REGIONAL \u00b7 OPEN",
      "equipment": "open",
      "roster": [
        "seam",
        "load",
        "claw"
      ],
      "straight": 16,
      "laps": 3,
      "surface": "dust",
      "fee": 8,
      "purse": [
        76,
        30,
        14,
        0
      ],
      "grant": "regional_open",
      "requires": "local_open",
      "editionLimit": 3,
      "purpose": "A longer loose-surface circuit. A win records Regional completion; Factional racing is not implemented."
    },
    {
      "id": "home",
      "name": "Your Circuit Invitational",
      "tag": "EXHIBITION \u00b7 YOUR LAID COURSE",
      "equipment": "open",
      "roster": [
        "seam",
        "ram",
        "hopper"
      ],
      "fee": 6,
      "purse": [
        36,
        16,
        8,
        0
      ],
      "grant": null,
      "requires": null,
      "editionLimit": 2,
      "purpose": "Host real races on the frozen version of your owned layout. Custom geometry never grants a championship qualifier."
    }
  ],
  "rival_definitions": [
    {
      "id": "seam",
      "owner": "Ivo Pell",
      "name": "SEAMSTRESS",
      "body": "needleback",
      "number": "14",
      "colour": "ivory",
      "approach": "clean",
      "leverage": 1,
      "products": [
        "redline",
        "sticktoe",
        "gyropods"
      ],
      "genes": [
        [
          0,
          1
        ],
        [
          0,
          1
        ],
        [
          0,
          1
        ]
      ],
      "purpose": "Clean release and fast correction. The legs must disengage fast enough to use the drive.",
      "target": {
        "kind": "stick",
        "trait": "release",
        "op": "max",
        "threshold": 0.045
      },
      "route": "stick"
    },
    {
      "id": "hopper",
      "owner": "Jess Rill",
      "name": "THIRD NOTICE",
      "body": "lowline",
      "number": "03",
      "colour": "ochre",
      "approach": "hopper",
      "leverage": 0.9,
      "products": [
        "hoppers",
        "redline",
        "fatbody",
        "keel"
      ],
      "genes": [
        [
          0,
          1
        ],
        [
          1,
          1
        ],
        [
          0,
          1
        ]
      ],
      "purpose": "Matched takeoff and controlled recovery. Supply, launch tissue and rebound tissue are distinct.",
      "target": {
        "kind": "hopper",
        "trait": "phase",
        "op": "max",
        "threshold": 0.07
      },
      "route": "verge"
    },
    {
      "id": "load",
      "owner": "Cinderhouse club team",
      "name": "BOLT MUNCHER",
      "body": "broadback",
      "number": "28",
      "colour": "ochre",
      "approach": "clean",
      "leverage": 0.75,
      "products": [
        "torque",
        "lowstep",
        "cleats",
        "boxbrace"
      ],
      "genes": [
        [
          0,
          1
        ],
        [
          0,
          1
        ],
        [
          1,
          1
        ]
      ],
      "purpose": "Usable thrust and loose-ground feet under a supported heavy body. More leverage is not always faster.",
      "target": {
        "kind": "mole",
        "trait": "roughGrip",
        "op": "min",
        "threshold": 1.4
      },
      "route": "mole"
    },
    {
      "id": "ram",
      "owner": "Mara Venn",
      "name": "HORN TAX",
      "body": "lowline",
      "number": "09",
      "colour": "vermilion",
      "approach": "charge",
      "leverage": 0.85,
      "products": [
        "torque",
        "bullhorn",
        "sticktoe"
      ],
      "genes": [
        [
          0,
          1
        ],
        [
          0,
          1
        ],
        [
          1,
          1
        ]
      ],
      "purpose": "Forceful aligned charges. Horn geometry only works when the roach reaches contact.",
      "target": {
        "kind": "horn",
        "trait": "impact",
        "op": "min",
        "threshold": 1
      },
      "route": "horn"
    },
    {
      "id": "claw",
      "owner": "Saltglass club team",
      "name": "COUNTEROFFER",
      "body": "lowline",
      "number": "21",
      "colour": "ivory",
      "approach": "counter",
      "leverage": 1,
      "products": [
        "redline",
        "catchclaws",
        "sticktoe"
      ],
      "genes": [
        [
          0,
          1
        ],
        [
          1,
          1
        ],
        [
          0,
          1
        ]
      ],
      "purpose": "Fast closure at working reach. Interception is an action with timing, not passive armor.",
      "target": {
        "kind": "mantis",
        "trait": "closure",
        "op": "max",
        "threshold": 0.125
      },
      "route": "mantis"
    },
    {
      "id": "flash",
      "owner": "Tinwater independent",
      "name": "FLASHLEG",
      "body": "needleback",
      "number": "07",
      "colour": "ochre",
      "approach": "charge",
      "leverage": 0.9,
      "products": [
        "redline",
        "bullhorn",
        "gyropods"
      ],
      "genes": [
        [
          0,
          1
        ],
        [
          0,
          1
        ],
        [
          0,
          1
        ]
      ],
      "purpose": "A narrow passing body with a forward attack. The same drive supplies racing and contact.",
      "target": {
        "kind": "cicada",
        "trait": "cadence",
        "op": "min",
        "threshold": 10.5
      },
      "route": "kiln"
    }
  ],
  "round_pairings": [
    [
      [
        0,
        1
      ],
      [
        2,
        3
      ]
    ],
    [
      [
        0,
        2
      ],
      [
        3,
        1
      ]
    ],
    [
      [
        0,
        3
      ],
      [
        1,
        2
      ]
    ]
  ],
  "result_policy": {
    "win_points": 3,
    "valid_tie_points": 1,
    "DNF_points": 0,
    "ordering": [
      "points descending",
      "valid finishes descending",
      "shared rank"
    ],
    "qualifying_crown": "rank==1 && heat_wins>=3",
    "purse_tie_policy": "sum occupied purse slots; equal integer shares; remainder returned"
  },
  "world_threads": [
    {
      "id": "W11.THREAD.RIVAL",
      "path": [
        "public racer construction",
        "named trait",
        "existing selection project",
        "donor habitat",
        "assay/breed/prepare/buy",
        "same workbench",
        "new round outcome"
      ]
    },
    {
      "id": "W11.THREAD.PRIZE",
      "path": [
        "valid local meet crown",
        "actual available award pair",
        "protected player living stock",
        "breeding or alternate preparation",
        "existing sales or fitting"
      ]
    },
    {
      "id": "W11.THREAD.HOST",
      "path": [
        "owned sections",
        "laid version",
        "frozen invitational",
        "computed heats",
        "funded placing",
        "same sections retained"
      ]
    },
    {
      "id": "W11.THREAD.CAMPAIGN",
      "path": [
        "local qualifier",
        "Regional event permission",
        "longer loose surface",
        "changed part priorities",
        "Regional completion only"
      ]
    }
  ],
  "limits": [
    "Runtime is based on the recovered Wave09 executable. Wave10 maker source and final archive were not recovered. Its written specification remains an explicit pending handoff.",
    "One local world; four-entry meets are sequences of two-roach races, not simultaneous four-roach physics.",
    "All tournament structure, costs, rates, thresholds, native profiles and inheritance values are authored normalized experiments, not exact PCR game data.",
    "Six fixed component-built NPCs; their prior breeding, purchases, training and supplier replenishment are not simulated.",
    "Two useful qualification stages only. Factional and World City events and powered flight remain unimplemented.",
    "Standing-start mirrored heats reduce one bias; path-space body contact, loading, airborne tactics and timing need further testing. No perfectly fair or calibrated tournament claim.",
    "Finite disclosed sponsorship and award nursery; club-owned care is bundled into supplied operating resources rather than a complete simulated institution.",
    "No globally imposed death, tissue-regrowth or storage policy. Earlier reusable-collar branch remains restricted.",
    "Snapshots and local backups are consistency-checked, not anti-cheat. Replay frames are session-only.",
    "Browser tested through exact HTML set_content when native file navigation was blocked. No native Windows/macOS, physical touch or human usability session.",
    "No measured enjoyment, retention, national economy balance or world-scale performance."
  ]
}