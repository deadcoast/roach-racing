# RRR — The Living Workbench / Wave v0.5

An editable, local browser slice of **Rad Roach Racing: Wastelander Lanista**. Build with identified prepared sects, fit an arrangement, and compute a new ground race using those components.

## Open

Open `RRR_Living_Workbench_v0.5.html` in a modern desktop browser. The file embeds its JavaScript, styling and procedural drawings; it has no network dependencies, installation step, account or telemetry.

Choose a sect in the tray and use **Fit to draft**, or drag it onto the roach. Move a fitted root with pointer dragging, arrow keys, or the nudge buttons. **Fit this build** commits the arrangement. **Take the line** opens race setup; **Race this build** computes a new run. The starting host is already functional; leaving native components in place is a valid build.

The inspector distinguishes donor origin, component purpose and adjustments. **Under the shell** reveals fitted internal parts. Tuning covers hip leverage, Hopper preload, stance, reserve fill and race approach. Shell finish, number and name are editable and do not grant hidden performance bonuses.

A central horn and split brow vanes can coexist. Out-of-support or overlapping roots produce a fitting warning; physical fit and event legality are separate. The starter profile supports one prepared primary drive, not a universal RRR prohibition on more complex power arrangements.

## Keep work

Local browser storage is attempted and its status is displayed. File-URL storage behavior varies by browser and can be blocked. **Export sheet** downloads a portable arrangement; **Import** loads it as a draft against stock already owned by this slice. It cannot create parts, money or genomes. Build sheets retain at most eight saved arrangements. Session race recordings can be exported separately; reload is not a multiplayer/authoritative save system.

## What exists

- Eight identified prepared sects and explicitly retained native exchange units.
- Draft/committed build separation, geometric root checking, undo/redo, fit/unfit, finish and saved arrangements.
- Three ground course settings, three rival profiles, equipment checks, fresh simulation, playback and matched comparisons.
- The original `H-6` / donor `B1-6` Hopper and purchased `UPGRADE-DRIVE` identities are retained from prior operator demonstrations.
- Sixty-five foundation statements and four operational world threads connect fitting, kits, breeder selection and public builds.

## Scope

This is not a completed game. Six additional sects, native exchange units, the bench and practice resources are declared test endowments. There is no capture gameplay, live brood management, world-clock integration, paid event, sustained flight, full limb dynamics or completed economy in this slice. The preparation profile makes reusable fitting possible with retained anatomy; it does not establish a universal no-cost, painless removal/regrowth rule. All quantities use normalized model units. Current fuel use does not dynamically reduce race mass.

The race is a path-space two-racer ground model. The player builds and chooses an approach; it is not direct steering. Physical roots are checked using oriented rectangles, attachment layers and bounded prepared-root regions, not full articulated collision geometry. A raw imported file is untrusted arrangement data, not evidence of a sanctioned race result.

## Agent entry points

1. `RRR_Wave_05.spec`: Reference → Plan → Workflow → Adherence → MIVIM → rules, stock and evidence boundaries. Strict JSON, continuing the RRR exchange format, not claiming a private canonical MIVIM grammar.
2. `RRR_Wave_05_Foundations.md`: readable expansion generated from that specification.
3. `TODO_Wave_v0.5.md`: work completed at explicit scopes and ordered remaining work.
4. `world_context_v0.5.json`: full cumulative dataset. Old records and waves are preserved unchanged.
5. `MIVIM_Review_v0.5.md` and `evidence/`: mechanism, presentation and verification findings; no invented numeric innovation grade.

## Source layout

`src/bench.js` owns identities, fitting, custody, compilation and import validation. `src/race.js` is the browser race engine. `src/anatomy.js` draws actual component arrangements. `src/app.js`, `src/style.css` and `src/template.html` provide the interface. `tools/build_app.py` makes the standalone HTML. No bundler or third-party frontend runtime is required.

Unmodified prior Python operators and tests live under `reference/`. `tools/export_reference.py` recreates the six old experiment outputs from those sources; it does not invent a prior world-save file.

## Reproduce checks

The application itself needs only a browser. Developer verification uses Python 3.10+, Node.js and Python `jsonschema`. Browser interaction tests additionally require Playwright and Chromium; set `RRR_CHROMIUM` to a local executable if it is not `/usr/bin/chromium`.

```sh
python tools/build_app.py
python validate_wave05.py
python validate_wave05.py --browser
```

The validator exits nonzero on a failed check. Without `--browser`, it explicitly reports browser interaction as not rerun while checking freshness of any packaged HTML evidence. Browser tests exercise the delivered artifact; they do not mark Windows, macOS, Safari or human usability as tested. In the production test host, native file navigation was blocked and the exact file content was executed through Playwright `set_content` instead. Native file persistence therefore remains unverified.

## Development direction

Next: join intake, brood, workbench and race attendance to one persistent stock/world-clock system. Preserve the working bench rather than replacing it with another disconnected demonstration. Repeated livelihood calibration and a complete stage-specific lifecycle remain open.
