from pathlib import Path
root=Path(__file__).resolve().parents[1]
s=(root/'src/template.html').read_text()
for key,name in [('CSS','style.css'),('ENGINE','race.js'),('CATALOG','catalog.js'),('BENCH','bench.js'),('ART','anatomy.js'),('WORLD','world.js'),('APP','app.js')]:
 t=(root/'src'/name).read_text();assert '</script' not in t.lower();s=s.replace('__'+key+'__',t)
assert '__SHOP_FUNCTIONS__' not in s
(root/'RRR_Living_Parts_v0.7.html').write_text(s)
print(len(s.encode()),'bytes')
