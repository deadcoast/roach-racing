"""RRR Wave 03: executable specification witnesses, NOT a game simulation.

Python 3.10+, standard library only. All biological values/time units are invented
fixtures. Hidden genetics, public evidence, custody, capacity and cash are separate.
"""
from __future__ import annotations

from collections import defaultdict
from copy import deepcopy
from dataclasses import dataclass, field
from fractions import Fraction
from hashlib import sha256
from itertools import product
import json
import math
import random
from typing import Any, Callable


class RuleViolation(ValueError):
    """An operation failed without permission to mutate its inputs."""


def require(test: bool, reason: str) -> None:
    if not test:
        raise RuleViolation(reason)


def canonical(value: Any) -> str:
    return json.dumps(value, sort_keys=True, separators=(",", ":"), allow_nan=False)


def finite(value: float, name: str, minimum: float = 0.0) -> None:
    require(isinstance(value, (int, float)) and not isinstance(value, bool)
            and math.isfinite(value) and value >= minimum, f"invalid {name}")


# ----------------- Independent-locus fixture genetics -----------------
# Genotype consists of one 0/1 allele pair per locus; no real biology asserted.
Genome = tuple[tuple[int, int], ...]


def check_genome(genome: Genome) -> None:
    require(bool(genome), "empty genome")
    require(all(len(pair) == 2 and all(type(a) is int and a in (0, 1) for a in pair)
                for pair in genome), "invalid allele pair")


def gametes(genome: Genome) -> dict[tuple[int, ...], Fraction]:
    check_genome(genome)
    result: dict[tuple[int, ...], Fraction] = defaultdict(Fraction)
    for choices in product((0, 1), repeat=len(genome)):
        hap = tuple(genome[i][j] for i, j in enumerate(choices))
        result[hap] += Fraction(1, 2 ** len(genome))
    return dict(result)


def cross(a: Genome, b: Genome) -> dict[Genome, Fraction]:
    check_genome(a)
    check_genome(b)
    require(len(a) == len(b), "locus mismatch")
    result: dict[Genome, Fraction] = defaultdict(Fraction)
    for ha, pa in gametes(a).items():
        for hb, pb in gametes(b).items():
            child = tuple(tuple(sorted((x, y))) for x, y in zip(ha, hb))
            result[child] += pa * pb
    return dict(result)


def target_probability(a: Genome, b: Genome, target: Genome) -> Fraction:
    return cross(a, b).get(target, Fraction(0))


def brood(world_seed: str, batch_id: str, a: Genome, b: Genome,
          viable_count: int) -> list[Genome]:
    """Event-local deterministic fixture; fertility/viability are NOT sampled here."""
    check_genome(a)
    check_genome(b)
    require(len(a) == len(b), "locus mismatch")
    require(type(viable_count) is int and viable_count >= 0, "invalid count")
    seed = int.from_bytes(sha256(f"{world_seed}|{batch_id}".encode()).digest(), "big")
    rng = random.Random(seed)
    return [tuple(tuple(sorted((x[rng.randrange(2)], y[rng.randrange(2)])))
                  for x, y in zip(a, b)) for _ in range(viable_count)]


def hopper_phenotype(genome: Genome) -> dict[str, float]:
    """Three-locus additive FIXTURE: R return, S synchrony, D settling."""
    check_genome(genome)
    require(len(genome) == 3, "hopper fixture requires R/S/D")
    r, s, d = (sum(pair) for pair in genome)
    return {
        "spring_return": round(0.55 + 0.075 * r, 8),
        "phase_error": round(0.12 - 0.05 * s, 8),
        "settle_time": round(0.18 - 0.06 * d, 8),
    }


# ----------------- Player-visible information, not a genotype oracle -----------------
PUBLIC_KEYS = ("id", "name", "donor", "stage", "appearance", "observations", "protections")


def public_view(specimen: dict[str, Any]) -> dict[str, Any]:
    return {k: deepcopy(specimen[k]) for k in PUBLIC_KEYS if k in specimen}


def evidence_match(observations: dict[str, Any], requirements: dict[str, Any],
                   protocol: str) -> str:
    """pass=all measured bounds pass; possible=unknown/straddling; fail=excluded.

    Bounds are declared assay bounds, not inferred confidence intervals.
    """
    possible = False
    for trait, req in requirements.items():
        obs = observations.get(trait)
        if not obs or obs.get("protocol") != protocol:
            possible = True
            continue
        lo, hi = obs.get("low"), obs.get("high")
        finite(lo, "observation low")
        finite(hi, "observation high")
        require(lo <= hi, "reversed observation bounds")
        threshold = req["value"]
        finite(threshold, "threshold")
        if req["direction"] == "at_least":
            if hi < threshold:
                return "fail"
            possible |= lo < threshold
        elif req["direction"] == "at_most":
            if lo > threshold:
                return "fail"
            possible |= hi > threshold
        else:
            raise RuleViolation("unknown direction")
    return "possible" if possible else "pass"


def intake_project(profile: dict[str, Any]) -> dict[str, Any]:
    """Adapter deliberately uses candidate criteria, NOT finished-product criteria."""
    require(profile.get("intake_predicate_basis") in {"missing_complement_not_final_product", "complete_product"},
            "project must declare candidate-selection basis")
    return {"id": profile["id"], "donor": profile["donor_id"], "protocol": profile["protocol"],
            "requirements": deepcopy(profile["intake_requirements"])}


def disposition(specimen: dict[str, Any], projects: list[dict[str, Any]]) -> dict[str, Any]:
    """Recommendations use ONLY the same information available to the player."""
    p = public_view(specimen)
    if p.get("protections"):
        return {"id": p["id"], "action": "keep", "reason": "explicit_protection"}
    reasons = []
    for project in projects:
        if p.get("donor") != project["donor"]:
            continue
        match = evidence_match(p.get("observations", {}), project["requirements"],
                               project["protocol"])
        if match != "fail":
            reasons.append({"project": project["id"], "evidence": match})
    if reasons:
        return {"id": p["id"], "action": "review", "reason": "project_relevance", "matches": reasons}
    return {"id": p["id"], "action": "sale_candidate", "reason": "no_current_keep_match"}


# ----------------- Half-open future capacity reservations -----------------
@dataclass(frozen=True)
class Reservation:
    job: str
    resource: str
    start: int
    end: int
    quantity: int


@dataclass
class Calendar:
    capacity: dict[str, int]
    reservations: list[Reservation] = field(default_factory=list)
    running: set[str] = field(default_factory=set)
    paused: set[str] = field(default_factory=set)

    def _validate(self, reservations: list[Reservation]) -> None:
        for r in reservations:
            require(r.resource in self.capacity, "unknown capacity resource")
            require(all(type(v) is int for v in (r.start, r.end, r.quantity)), "non-integer reservation")
            require(0 <= r.start < r.end and r.quantity > 0, "invalid reservation")
        for resource, cap in self.capacity.items():
            require(type(cap) is int and cap >= 0, "invalid capacity")
            changes: dict[int, int] = defaultdict(int)
            for r in reservations:
                if r.resource == resource:
                    changes[r.start] += r.quantity
                    changes[r.end] -= r.quantity
            used = 0
            for tick in sorted(changes):
                used += changes[tick]
                require(0 <= used <= cap, f"capacity exceeded: {resource}@{tick}")

    def reserve(self, bundle: list[Reservation]) -> None:
        require(bool(bundle), "empty bundle")
        job = bundle[0].job
        require(all(r.job == job for r in bundle), "mixed job bundle")
        require(not any(r.job == job for r in self.reservations), "job already reserved")
        proposed = self.reservations + bundle
        self._validate(proposed)
        self.reservations = proposed

    def occupancy(self, resource: str, tick: int) -> int:
        return sum(r.quantity for r in self.reservations
                   if r.resource == resource and r.start <= tick < r.end)

    def delay(self, job: str, resource: str, new_end: int, now: int) -> list[str]:
        """Protect a running cohort; release conflicting UNSTARTED bundles for replanning.

        A conflict with another running cohort is not silently resolved. That path
        needs physical overflow handling; the caller receives a no-mutation error.
        """
        require(job in self.running, "delay requires a running job")
        candidates = [r for r in self.reservations if r.job == job and r.resource == resource
                      and r.start <= now < r.end]
        require(len(candidates) == 1, "active reservation not unique")
        old = candidates[0]
        require(type(new_end) is int and new_end >= old.end, "invalid delay end")
        extension = Reservation(job, resource, old.start, new_end, old.quantity)
        proposed = [extension if r is old else r for r in self.reservations]
        paused: set[str] = set()
        # Pause later unstarted overlapping jobs only if necessary, stable by start/id.
        later = sorted({r.job for r in proposed if r.job != job and r.job not in self.running
                        and r.resource == resource and r.start < new_end and old.start < r.end},
                       key=lambda j: (min(r.start for r in proposed if r.job == j), j))
        while True:
            try:
                self._validate(proposed)
                break
            except RuleViolation:
                require(bool(later), "delay needs declared overflow; existing cohorts remain obligations")
                victim = later.pop(0)
                proposed = [r for r in proposed if r.job != victim]
                paused.add(victim)
        self.reservations = proposed
        self.paused.update(paused)
        return sorted(paused)


# ----------------- Atomic inventory, reservation and finite-money operations -----------------
@dataclass
class Stock:
    id: str
    donor: str
    owner: str
    stage: str
    genotype: Genome | None
    anatomy: set[str]
    observations: dict[str, Any] = field(default_factory=dict)
    protections: set[str] = field(default_factory=set)
    alive: bool = True


@dataclass
class Sect:
    id: str
    donor_id: str
    product: str
    owner: str
    tissues: set[str]
    measurements: dict[str, Any]
    custody: str = "inventory"
    holder: str | None = None


@dataclass
class Order:
    id: str
    buyer: str
    product: str
    quantity: int
    unit_price: int
    deadline: int
    protocol: str
    requirements: dict[str, Any]
    delivered: list[str] = field(default_factory=list)
    escrow: int = 0
    open: bool = True


@dataclass
class Workshop:
    cash: dict[str, int]
    stocks: dict[str, Stock] = field(default_factory=dict)
    sects: dict[str, Sect] = field(default_factory=dict)
    orders: dict[str, Order] = field(default_factory=dict)
    kits: dict[str, dict[str, Any]] = field(default_factory=dict)
    events: dict[str, dict[str, Any]] = field(default_factory=dict)
    ledger: list[dict[str, Any]] = field(default_factory=list)

    def transact(self, event_id: str, payload: dict[str, Any],
                 operation: Callable[[], Any]) -> Any:
        fingerprint = sha256(canonical(payload).encode()).hexdigest()
        if event_id in self.events:
            prior = self.events[event_id]
            require(prior["fingerprint"] == fingerprint, "idempotency key reused with different operation")
            return deepcopy(prior["result"])
        before = deepcopy(self.__dict__)
        try:
            result = operation()
            self.check()
            self.events[event_id] = {"fingerprint": fingerprint, "result": deepcopy(result)}
            return result
        except Exception:
            self.__dict__.clear()
            self.__dict__.update(before)
            raise

    def check(self) -> None:
        require(all(type(v) is int and v >= 0 for v in self.cash.values()), "negative or noninteger cash")
        occupied: set[tuple[str, str]] = set()
        for sect in self.sects.values():
            require(sect.donor_id in self.stocks, "missing source specimen")
            for tissue in sect.tissues:
                token = (sect.donor_id, tissue)
                require(token not in occupied, "duplicated anatomy")
                require(tissue not in self.stocks[sect.donor_id].anatomy, "anatomy still on donor")
                occupied.add(token)
        for order in self.orders.values():
            require(0 <= len(order.delivered) <= order.quantity, "order overfill")
            require(order.escrow >= 0, "negative escrow")
        for kit_id, kit in self.kits.items():
            for sid in kit["components"]:
                require(self.sects[sid].custody == "kit" and self.sects[sid].holder == kit_id,
                        "broken kit custody")

    def total_money(self) -> int:
        return sum(self.cash.values()) + sum(o.escrow for o in self.orders.values())

    def transfer(self, event_id: str, payer: str, payee: str, amount: int, reason: str) -> dict[str, Any]:
        def op() -> dict[str, Any]:
            require(type(amount) is int and amount >= 0, "invalid amount")
            require(payer != payee and payer in self.cash and payee in self.cash, "invalid counterparties")
            require(self.cash[payer] >= amount, "insufficient funds")
            self.cash[payer] -= amount
            self.cash[payee] += amount
            entry = {"event": event_id, "payer": payer, "payee": payee, "amount": amount, "reason": reason}
            self.ledger.append(entry)
            return entry
        return self.transact(event_id, {"op": "transfer", "payer": payer, "payee": payee,
                                       "amount": amount, "reason": reason}, op)

    def fund(self, event_id: str, order: Order) -> dict[str, Any]:
        def op() -> dict[str, Any]:
            require(order.id not in self.orders, "order exists")
            require(type(order.quantity) is int and order.quantity > 0, "invalid order quantity")
            require(type(order.unit_price) is int and order.unit_price >= 0, "invalid price")
            require(type(order.deadline) is int and order.deadline >= 0, "invalid deadline")
            require(order.buyer in self.cash, "unknown buyer")
            require(order.escrow == 0 and not order.delivered and order.open, "order must be new")
            cost = order.quantity * order.unit_price
            require(self.cash[order.buyer] >= cost, "buyer cannot fund order")
            self.cash[order.buyer] -= cost
            saved = deepcopy(order)
            saved.escrow = cost
            self.orders[order.id] = saved
            return {"order": order.id, "reserved_cash": cost, "seller_income": 0}
        return self.transact(event_id, {"op": "fund", "order": order.id,
             "buyer": order.buyer, "quantity": order.quantity, "unit_price": order.unit_price,
             "product": order.product, "deadline": order.deadline, "requirements": order.requirements,
             "protocol": order.protocol}, op)

    def prepare(self, event_id: str, owner: str, donor_id: str,
                products: list[dict[str, Any]], vital_tissues: set[str] | None = None) -> list[str]:
        def op() -> list[str]:
            require(donor_id in self.stocks, "missing donor")
            donor = self.stocks[donor_id]
            require(donor.owner == owner and not donor.protections, "donor not disposable")
            require(bool(products), "empty preparation")
            used: set[str] = set()
            ids: set[str] = set()
            for p in products:
                tissues = set(p["tissues"])
                require(bool(tissues), "empty source anatomy")
                require(p["id"] not in self.sects and p["id"] not in ids, "duplicate sect id")
                require(not used.intersection(tissues), "overlapping products")
                require(tissues <= donor.anatomy, "missing source anatomy")
                used.update(tissues)
                ids.add(p["id"])
            for p in products:
                self.sects[p["id"]] = Sect(p["id"], donor_id, p["product"], owner,
                    set(p["tissues"]), deepcopy(donor.observations))
            donor.anatomy.difference_update(used)
            if used.intersection(vital_tissues or set()):
                donor.alive = False
            return sorted(ids)
        return self.transact(event_id, {"op": "prepare", "owner": owner, "donor": donor_id,
            "products": products, "vital": sorted(vital_tissues or set())}, op)

    def pack(self, event_id: str, kit_id: str, owner: str,
             roles: dict[str, str], native_roles: list[str]) -> dict[str, Any]:
        def op() -> dict[str, Any]:
            require(kit_id not in self.kits and bool(roles), "invalid kit")
            require(not set(roles).intersection(native_roles), "role both supplied and native")
            components = sorted(set(roles.values()))  # multi-role sect is ONE physical asset
            for sid in components:
                require(sid in self.sects, "missing kit component")
                s = self.sects[sid]
                require(s.owner == owner and s.custody == "inventory", "component unavailable")
            self.kits[kit_id] = {"owner": owner, "roles": deepcopy(roles),
                                "native_roles": list(native_roles), "components": components}
            for sid in components:
                self.sects[sid].custody = "kit"
                self.sects[sid].holder = kit_id
            return deepcopy(self.kits[kit_id])
        return self.transact(event_id, {"op": "pack", "kit": kit_id, "owner": owner,
                                       "roles": roles, "native": native_roles}, op)

    def install(self, event_id: str, sid: str, owner: str, host_id: str) -> dict[str, Any]:
        def op() -> dict[str, Any]:
            require(sid in self.sects and host_id in self.stocks, "missing component or host")
            s, h = self.sects[sid], self.stocks[host_id]
            require(s.owner == owner == h.owner and s.custody == "inventory" and h.alive,
                    "component/host unavailable")
            s.custody, s.holder = "installed", host_id
            return {"sect": sid, "host": host_id, "host_genome_unchanged": True}
        return self.transact(event_id, {"op": "install", "sect": sid, "owner": owner, "host": host_id}, op)

    def deliver(self, event_id: str, order_id: str, seller: str,
                sect_ids: list[str], now: int) -> dict[str, Any]:
        def op() -> dict[str, Any]:
            require(order_id in self.orders and seller in self.cash, "unknown order/seller")
            o = self.orders[order_id]
            require(o.open and now <= o.deadline, "order closed or late")
            require(o.buyer != seller, "self-sale")
            require(bool(sect_ids) and len(set(sect_ids)) == len(sect_ids), "empty or duplicate delivery")
            require(len(o.delivered) + len(sect_ids) <= o.quantity, "overdelivery")
            for sid in sect_ids:
                require(sid in self.sects, "missing sect")
                s = self.sects[sid]
                require(s.owner == seller and s.custody == "inventory", "sect unavailable for sale")
                require(s.product == o.product, "wrong product")
                require(evidence_match(s.measurements, o.requirements, o.protocol) == "pass",
                        "acceptance evidence insufficient")
            payment = len(sect_ids) * o.unit_price
            require(o.escrow >= payment, "order funds unavailable")
            o.escrow -= payment
            self.cash[seller] += payment
            for sid in sect_ids:
                self.sects[sid].owner = o.buyer
                o.delivered.append(sid)
            if len(o.delivered) == o.quantity:
                o.open = False
            receipt = {"event": event_id, "order": order_id, "assets": list(sect_ids), "payment": payment}
            self.ledger.append(receipt)
            return receipt
        return self.transact(event_id, {"op": "deliver", "order": order_id, "seller": seller,
                                       "sects": sect_ids, "now": now}, op)

    def close_order(self, event_id: str, order_id: str) -> dict[str, Any]:
        def op() -> dict[str, Any]:
            require(order_id in self.orders, "unknown order")
            o = self.orders[order_id]
            refund = o.escrow
            self.cash[o.buyer] += refund
            o.escrow, o.open = 0, False
            return {"order": order_id, "refunded": refund}
        return self.transact(event_id, {"op": "close", "order": order_id}, op)


# ----------------- Controlled component benches (invented, normalized units) -----------------
def allocate_delivery(demands: dict[str, float], capacity: float) -> dict[str, float]:
    finite(capacity, "delivery capacity")
    for value in demands.values():
        finite(value, "demand")
    total = sum(demands.values())
    fraction = min(1.0, capacity / total) if total else 0.0
    return {key: value * fraction for key, value in demands.items()}


def hopper_bench(genome: Genome, preload: float = 4.0, mass: float = 1.0,
                 angle: float = math.pi / 4, alignment_error: float = 0.0) -> dict[str, float]:
    finite(preload, "preload")
    finite(mass, "mass")
    require(mass > 0, "mass must be positive")
    finite(alignment_error, "alignment error")
    require(0 < angle < math.pi / 2, "invalid launch angle")
    p = hopper_phenotype(genome)
    useful = preload * p["spring_return"] * max(0.0, 1.0 - p["phase_error"] - alignment_error)
    v = math.sqrt(2 * useful / mass)
    air_time = 2 * v * math.sin(angle)  # fixture gravitational acceleration = 1 L/T^2
    return {"spent_energy": preload, "useful_launch_energy": useful,
            "range": v * math.cos(angle) * air_time,
            "air_time": air_time, "settle_time": p["settle_time"]}


def straight_bench(cadence: float, stall_force: float, leverage: float = 1.0,
                   mass: float = 1.0, length: float = 12.0, stride: float = 0.25,
                   delivery: float = 3.0, efficiency: float = 0.75,
                   dt: float = 0.002, max_time: float = 120.0) -> dict[str, float | str]:
    """1D loaded-drive witness, not complete racing/foot physics.

    Units: L, M, T, energy=M L^2/T^2. Drag=0.15 force units.
    F(v)=Fstall*leverage*(1-v/(cadence*stride/leverage)), power-capped.
    Midpoint-limited drive ensures work at the discrete step does not exceed supply.
    Inventory mass, grip ceiling and all other inputs are held constant.
    """
    for name, value in locals().copy().items():
        finite(value, name)
    require(all(v > 0 for v in (cadence, stall_force, leverage, mass, length, stride, dt, max_time)),
            "positive bench parameters required")
    require(0 < efficiency <= 1, "invalid efficiency")
    v = x = time = spent = 0.0
    vfree = cadence * stride / leverage
    while x < length and time < max_time:
        demanded = stall_force * leverage * max(0.0, 1 - v / vfree)
        # F*(v + F*dt/(2m)) <= efficiency*delivery, conservative without drag.
        power_force = (math.sqrt(v*v + 2*dt*efficiency*delivery/mass) - v) * mass/dt
        drive = min(demanded, power_force, 4.0)  # fixture traction ceiling
        v1 = max(0.0, min(vfree, v + (drive - 0.15) * dt / mass))
        dx = (v + v1) * 0.5 * dt
        fraction = min(1.0, (length - x) / dx) if dx > 0 else 1.0
        work = drive * dx * fraction
        spent += work / efficiency
        time += dt * fraction
        x += dx * fraction
        v = v + (v1 - v) * fraction
    return {"status": "completed" if x >= length - 1e-9 else "stalled",
            "time": time, "energy": spent, "exit_speed": v}


# ----------------- Integrated predetermined outcome fixture -----------------
HOPPER = "W02.DONOR.HOPPER"
HOPPER_PRODUCT = "W02.PROD.HOPPER.1"
PROTOCOL = "W03.ASSAY.HOP.1"
REQUIREMENTS = {"spring_return": {"direction": "at_least", "value": 0.60},
                "phase_error": {"direction": "at_most", "value": 0.08}}


def measured(genome: Genome) -> dict[str, Any]:
    # Synthetic noise-free acceptance observations, explicitly not ordinary UI omniscience.
    return {k: {"low": value, "high": value, "protocol": PROTOCOL,
                "evidence_kind": "synthetic_exact_fixture"}
            for k, value in hopper_phenotype(genome).items()}


def integrated_fixture(advance_points: tuple[int, ...] = (8,)) -> dict[str, Any]:
    """Known 8-survivor F1 cohort; DOES NOT estimate survival or contract risk."""
    require(bool(advance_points) and advance_points[-1] == 8, "fixture must end at tick 8")
    require(all(type(t) is int and 0 <= t <= 8 for t in advance_points), "invalid tick")
    require(list(advance_points) == sorted(advance_points), "time reversal")
    a: Genome = ((1, 1), (0, 0), (1, 1))
    b: Genome = ((0, 0), (1, 1), (1, 1))
    w = Workshop({"player": 120, "buyer": 100, "suppliers": 0})
    w.stocks["P-R"] = Stock("P-R", HOPPER, "player", "adult", a, {"hind_pair", "body"}, protections={"founder"})
    w.stocks["P-S"] = Stock("P-S", HOPPER, "player", "adult", b, {"hind_pair", "body"}, protections={"founder"})
    w.stocks["HOST"] = Stock("HOST", "W02.DONOR.HOST", "player", "adult", a, {"native_body"}, protections={"named_racer"})
    w.stocks["DRIVE-DONOR"] = Stock("DRIVE-DONOR", "W02.DONOR.CICADA", "suppliers", "adult", None, {"thoracic_drive"})
    w.prepare("opening-prepared-drive", "suppliers", "DRIVE-DONOR",
              [{"id": "UPGRADE-DRIVE", "product": "W02.PROD.CICADA.1", "tissues": ["thoracic_drive"]}], {"thoracic_drive"})
    opening_money = w.total_money()
    w.fund("order-fund", Order("O-HOP", "buyer", HOPPER_PRODUCT, 4, 20, 8, PROTOCOL, REQUIREMENTS))
    c = Calendar({"pair:P-R": 1, "pair:P-S": 1, "incubator": 8, "growout": 8, "holding": 8})
    c.reserve([Reservation("B1", "pair:P-R", 0, 1, 1), Reservation("B1", "pair:P-S", 0, 1, 1),
               Reservation("B1", "incubator", 1, 3, 8), Reservation("B1", "growout", 3, 7, 8),
               Reservation("B1", "holding", 7, 9, 8)])
    c.running.add("B1")
    scheduled = [(0, "start", 6), (2, "care-2", 6), (4, "care-4", 6), (6, "care-6", 6),
                 (7, "mature", 0), (8, "prepare-deliver", 0)]
    processed: set[str] = set()
    for until in advance_points:
        for tick, eid, cost in scheduled:
            if tick > until or eid in processed:
                continue
            if cost:
                w.transfer(eid, "player", "suppliers", cost, "brood operations")
            elif eid == "mature":
                offspring = brood("W03-seed-1", "B1", a, b, 8)
                for i, genome in enumerate(offspring):
                    sid = f"B1-{i}"
                    w.stocks[sid] = Stock(sid, HOPPER, "player", "adult", genome,
                        {"hind_pair", "body"}, measured(genome), {"replacement"} if i < 2 else set())
            elif eid == "prepare-deliver":
                for i in range(2, 7):
                    w.transfer(f"prep-cost-{i}", "player", "suppliers", 2, "preparation")
                    w.prepare(f"prep-{i}", "player", f"B1-{i}",
                        [{"id": f"H-{i}", "product": HOPPER_PRODUCT, "tissues": ["hind_pair"]}])
                w.deliver("deliver", "O-HOP", "player", [f"H-{i}" for i in range(2, 6)], tick)
                w.install("fit-personal", "H-6", "player", "HOST")
                w.fund("upgrade-fund", Order("O-DRIVE", "player", "W02.PROD.CICADA.1", 1, 24, 8, "ordinary-offer", {}))
                w.deliver("upgrade-purchase", "O-DRIVE", "suppliers", ["UPGRADE-DRIVE"], tick)
            processed.add(eid)
    w.check()
    require(w.total_money() == opening_money, "cash conservation violated")
    return {
        "scope": "Deterministic operator integration fixture; not survival, revenue forecast or race outcome.",
        "opening_cash": 120, "buyer_opening_budget": 100,
        "initiated_and_surviving_fixture_count": 8,
        "cash_receipts": 80, "cash_operating_costs": 34, "operating_margin": 46,
        "paid_upgrade": 24, "acquired_upgrade_sect": "UPGRADE-DRIVE",
        "acquired_upgrade_owner": w.sects["UPGRADE-DRIVE"].owner,
        "acquired_upgrade_custody": w.sects["UPGRADE-DRIVE"].custody,
        "closing_player_cash": w.cash["player"],
        "escrow_remaining": w.orders["O-HOP"].escrow,
        "all_accounts_and_escrow": w.total_money(),
        "retained_replacements": [s.id for s in w.stocks.values() if "replacement" in s.protections],
        "delivered_sects": w.orders["O-HOP"].delivered,
        "installed_sect": "H-6", "unsold_intact_offspring": "B1-7",
        "anatomy_after_preparation": {f"B1-{i}": sorted(w.stocks[f"B1-{i}"].anatomy) for i in range(2, 7)},
        "offspring_phenotype": hopper_phenotype(w.stocks["B1-0"].genotype),
        "operating_clock_points": list(advance_points),
        "ledger": w.ledger,
        "limitations": ["Opening parents, host, equipment and supplier drive inventory are in-kind assets; no return-on-capital claim is made.",
                        "Viable count, maturity, measurements and funded buyer are supplied fixtures.",
                        "Order is for assemblies, not a complete kit; native host anatomy remains after installation.",
                        "The bought drive is transferred as actual inventory; it is not yet installed and no race result is awarded."]
    }
