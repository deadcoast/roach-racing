/* W12 — commercial recipes, physical kits, and evidence-backed breeder orders.
 * Reconstruction of written requirements, not recovered Wave10 code.
 * Functions operate on the transaction copy owned by world.js. They never run a
 * second race model, create components from recipes, or read unmeasured genes.
 */
(function (root) {
    'use strict';
    const B = root.RRRBench || require('./bench.js');
    const C = root.RRRCatalog || require('./catalog.js');
    const H = root.RRRHosts || require('./hosts.js');
    const E = root.RRREvidence || require('./evidence.js');
    const R = root.RRRRace || require('./race.js');
    const cp = B.copy, canon = B.canonical;
    const need = (ok, message) => { if (!ok) throw Error(message); };
    const integer = (v, lo, hi, label) => need(Number.isSafeInteger(v) && v >= lo && v <= hi, 'Invalid ' + label);
    const text = (v, label, max = 56) => { need(typeof v === 'string' && v.trim().length >= 2 && v.length <= max && !/[\x00-\x1f]/.test(v), label + ' needs 2–' + max + ' printable characters'); return v.trim(); };
    const lookup = (list, id, label) => { const value = list.find(x => x.id === id); need(value, 'Unknown ' + label); return value; };
    const spec = (w, id) => lookup(w.specimens, id, 'specimen');
    const part = (w, id) => lookup(w.parts, id, 'component');
    const recipe = (w, id) => lookup(w.maker.recipes, id, 'recipe');
    const order = (w, id) => lookup(w.maker.orders, id, 'maker order');
    const LEGACY = {'UPGRADE-DRIVE':'redline','W05.TORQUE':'torque','H-6':'hoppers','W05.CROP':'nectarcrop','W05.PADS':'sticktoe','W05.HORN':'bullhorn','W05.CLAWS':'catchclaws','W05.VANES':'splitvanes'};
    const MECHANISMS = {
        redline:['redline','torque'], torque:['redline','torque'],
        sticktoe:['sticktoe','cleats'], cleats:['sticktoe','cleats'],
        fatbody:['fatbody','nectarcrop'], nectarcrop:['fatbody','nectarcrop'],
        splitvanes:['splitvanes','browfoil'], browfoil:['splitvanes','browfoil'],
        gripstrip:['gripstrip','feltbrake'], feltbrake:['gripstrip','feltbrake']
    };
    // Direction is specific to the promise, not a universal rank for the animal.
    // Geometry is a bounded operating range; it is not assumed larger=better.
    const METRICS = {
        native:[['stride','min','Native stride'],['support','min','Native support']],
        drive:[['cadence','min','Cadence'],['force','min','Useful force'],['efficiency','min','Conversion efficiency']],
        pads:[['grip','min','Clean purchase'],['rough_grip','min','Loose purchase'],['release','max','Release delay']],
        hopper:[['hopper.0','min','Elastic return'],['hopper.1','max','Release mismatch'],['hopper.2','max','Settling']],
        frame:[['support','min','Lateral support']], gear:[['ratio','range','Mechanical advantage']],
        reserve:[['reserve','min','Capacity'],['delivery','min','Delivery']],
        suspension:[['settle','max','Settling'],['impact_absorb','min','Impact response']],
        damper:[['damping','min','Rebound damping']],
        stabilizer:[['latency','max','Signal delay'],['correction','min','Correction'],['support_width','range','Support extension']],
        horn:[['reach','range','Contact reach'],['impact','min','Transferred impact']],
        claws:[['reach','range','Working reach'],['closure','max','Closing delay']],
        vanes:[['downforce','range','Hold-down operating range'],['drag','max','Resistance']],
        brake:[['brake_mu','range','Brake friction'],['brake_travel','range','Compression travel'],['brake_rough','range','Dusty-contact friction']],
        railguide:[['rail_friction','max','Rail friction'],['rail_support','min','Guide support']]
    };
    const BRIEFS = [
        {id:'W12.ORDER.CLUB',type:'kit',name:'Foundry / club-entry tin',buyer:'shop',price:96,window:24,requiredKinds:['drive','pads'],equipment:'speedsters',minMass:0,maxMass:4,limit:2,
         purpose:'One complete host kit with a supplied drive and contact set; no dedicated weapons. The recipient assembles it.',bounds:{drive:{cadence:{min:9},force:{min:1.9}},pads:{release:{max:.07}}}},
        {id:'W12.ORDER.HOP',type:'kit',name:'Two Nets / hopping project',buyer:'shop',price:112,window:28,requiredKinds:['hopper','reserve'],equipment:'open',minMass:0,maxMass:4,limit:2,
         purpose:'One complete host, paired launch assembly and separately sourced supply. Useful intermediate Hoppers qualify.',bounds:{hopper:{'hopper.0':{min:.60},'hopper.1':{max:.08}},reserve:{delivery:{min:4}}}},
        {id:'W12.ORDER.BREED.HOP',type:'breeder',name:'Cinderhouse / synchronized founders',buyer:'shop',price:76,window:32,kind:'hopper',target:{kind:'hopper',trait:'phase',op:'max',threshold:.07},minTested:3,minMatches:2,minBroods:2,limit:1,
         purpose:'An intact measured A/B pair descended from the recorded line. Both delivered animals meet synchronization; evidence spans two measured broods.'},
        {id:'W12.ORDER.BREED.FEET',type:'breeder',name:'Glassline / quick-release founders',buyer:'shop',price:84,window:36,kind:'stick',target:{kind:'stick',trait:'release',op:'max',threshold:.045},minTested:3,minMatches:2,minBroods:2,limit:1,
         purpose:'An intact measured A/B pair from the line. Useful release can complement a higher-purchase breeding project.'}
    ];
    function init(w) {
        if (w.maker) return;
        w.maker={version:1,recipes:[],orders:BRIEFS.map(b=>({...cp(b),state:'offered',escrow:0,edition:1,deliveries:[]})),publications:[],shipments:[],next:1};
    }
    function benches(w){return [w.bench,...Object.values(w.stabled||{})];}
    function reservedBy(w,id){return benches(w).find(b=>[...b.fitted.placements,...b.draft.placements].some(p=>p.id===id))?.host_id || null;}
    function desc(w,id){
        const p=part(w,id), a=p.legacy?cp(B.BASE.find(x=>x.id===id)):cp(p.snapshot);
        // Effective historical inputs already used by the unchanged bench compiler.
        // This projection exposes declared defaults; it is not a new assay or mutation.
        if(p.legacy){
            const defaults={drive:{efficiency:.75},pads:{release:.035,rough_grip:a.stats.grip},horn:{reach:1.35,impact:1},claws:{reach:1.4,closure:.10},vanes:{drag:0}};
            a.stats={...(defaults[a.kind]||{}),...a.stats};a.contractEvidence='Historical bench profile, not a new biological measurement';
        }return a;
    }
    function productKey(w,id){const p=part(w,id);return p.product || LEGACY[id];}
    function metric(a,path){return path==='$mass'?a.mass:path.split('.').reduce((v,k)=>v?.[k],a.stats);}
    function measuredBounds(a,tolerance){
        const rows=[];
        for(const [path,op,label] of METRICS[a.kind]||[]) {
            const value=metric(a,path); if(!Number.isFinite(value))continue;
            const r={path,label,reference:value};
            if(op==='min'||op==='range')r.min=+(value*(1-tolerance)).toFixed(8);
            if(op==='max'||op==='range')r.max=+(value*(1+tolerance)).toFixed(8);
            rows.push(r);
        }
        rows.push({path:'$mass',label:'Component mass',reference:a.mass,max:+(a.mass*(1+tolerance)).toFixed(8)});
        return rows;
    }
    function recipeBounds(a,tolerance,overrides={}){
        need(overrides&&typeof overrides==='object'&&!Array.isArray(overrides),'Invalid acceptance overrides');
        const rows=measuredBounds(a,tolerance);
        need(Object.keys(overrides).every(path=>rows.some(r=>r.path===path)),'Unknown promised measurement');
        for(const row of rows){const patch=overrides[row.path];if(patch===undefined)continue;
            need(patch&&typeof patch==='object'&&!Array.isArray(patch)&&Object.keys(patch).length>0&&Object.keys(patch).every(k=>['min','max'].includes(k)),'Invalid measurement bound');
            for(const [op,value] of Object.entries(patch)){need(Number.isFinite(value)&&value>=0&&value<=10000,'Acceptance bound must be finite and nonnegative');row[op]=value;}
            need((row.min===undefined||row.reference>=row.min-1e-8)&&(row.max===undefined||row.reference<=row.max+1e-8),'The reference does not meet this advertised promise');
            need(row.min===undefined||row.max===undefined||row.min<=row.max,'Acceptance interval is reversed');
        } return rows;
    }
    function boundIssues(a,requirements){
        const issues=[];
        for(const r of requirements){const value=metric(a,r.path);
            if(!Number.isFinite(value))issues.push(r.label+': measurement missing');
            else if(r.min!==undefined&&value<r.min-1e-8)issues.push(r.label+': '+value+' below '+r.min);
            else if(r.max!==undefined&&value>r.max+1e-8)issues.push(r.label+': '+value+' above '+r.max);
        } return issues;
    }
    function publicResult(w,meetId,roundIndex=2){
        const m=w.club.history.find(x=>x.id===meetId&&x.state==='complete');need(m,'Publish a completed actual club meeting');
        integer(roundIndex,0,m.rounds.length-1,'source round');
        const heat=m.rounds[roundIndex].heats.find(h=>h.request.entrants.some(e=>e.build.host_id===m.hostId));
        need(heat,'Source entry is missing');
        const e=heat.request.entrants.find(e=>e.build.host_id===m.hostId), row=m.table.find(r=>r.id===m.hostId);
        const snapshot=e.build;need(snapshot.design_snapshot,'Entry lacks its fitted arrangement');
        return {meet:m.id,event:m.eventId,course:cp(m.course),round:roundIndex,hostId:m.hostId,name:row.name,rank:row.rank,wins:row.wins,champion:m.champion,build:cp(snapshot),publishedAt:w.tick};
    }
    function makeRecipe(w,cmd){
        need(w.maker.recipes.length<80,'Local product register full');
        const tolerance=cmd.tolerance ?? .15;need([0,.10,.15,.25].includes(tolerance),'Choose the declared 0/10/15/25 percent tolerance');
        let design,profile,source;
        if(cmd.meetId){source=publicResult(w,cmd.meetId,cmd.round??2);design=cp(source.build.design_snapshot);profile=cp(source.build.body_profile);need(profile,'Historical native profile missing');}
        else {need(canon(w.bench.draft)===canon(w.bench.fitted),'Fit or discard the draft before publishing');design=cp(w.bench.fitted);profile=cp(w.bench.host_profile);source={hostId:w.bench.host_id,revision:w.bench.revision,type:'workbench',build:cp(B.compile(design,w.bench.revision,profile))};}
        B.validateDesign(design);need(design.placements.length>0,'Publish a construction with at least one prepared sect');
        const overrides=cp(cmd.requirements||{});need(overrides&&typeof overrides==='object'&&!Array.isArray(overrides)&&Object.keys(overrides).every(key=>(key==='HOST'||(/^S[1-9][0-9]*$/.test(key)&&+key.slice(1)<=design.placements.length))),'Unknown recipe slot override');
        const id='W12.RECIPE.'+w.maker.next++, name=text(cmd.name||design.name,'Product name');
        const r={id,name,version:1,created:w.tick,tolerance,source,host:{plans:[profile.plan],requirements:recipeBounds({kind:'native',mass:profile.mass,stats:profile},tolerance,overrides.HOST)},guide:design,referenceProfile:profile,
            slots:design.placements.map((p,i)=>{const a=desc(w,p.id),product=productKey(w,p.id);need(product,'Preparation is not described');return {id:'S'+(i+1),name:a.name,kind:a.kind,sourceId:p.id,sourceProduct:product,allowed:cmd.signature?[product]:cp(MECHANISMS[product]||[product]),placement:cp(p),requirements:recipeBounds(a,tolerance,overrides['S'+(i+1)]),purpose:a.purpose,donorForm:Object.keys(C.FORMS).find(k=>C.FORMS[k].products.includes(product))||null};}),
            protocol:'W12.RECIPE.MEASURED.1',requirementOverrides:overrides,signature:!!cmd.signature,nativeRetained:'Native anatomy supplies every essential function not replaced by listed preparations.'};
        w.maker.recipes.push(r);
        if(cmd.meetId) w.maker.publications.push({id:'W12.PUBLIC.'+w.maker.next++,recipeId:id,...cp(source)});
        return id;
    }
    function stockIssues(w,p,slot){
        const reasons=[];
        if(p.owner!=='player')reasons.push('Not owned');
        if(p.kit)reasons.push('Still packed');
        if(p.condition==='unusable')reasons.push('Unusable condition');
        const host=reservedBy(w,p.id);if(host)reasons.push('Installed or draft-reserved on '+host);
        if(!slot.allowed.includes(productKey(w,p.id)))reasons.push('Different preparation mechanism');
        const a=desc(w,p.id);if(a.kind!==slot.kind)reasons.push('Different component function');
        reasons.push(...boundIssues(a,slot.requirements));
        return reasons;
    }
    function hostIssues(w,s,r,ctx){
        const reasons=[];
        if(s.kind!=='roach'||!s.alive||s.stage!=='adult'||s.owner!=='player'||s.kit||s.regions.body!=='intact')reasons.push('Needs an owned, mature, intact, unpacked roach');
        if(!r.host.plans.includes(s.bodyPlan))reasons.push('Recipe specifies '+r.host.plans.map(p=>H.PLANS[p].name).join(' / '));
        if(!s.measured)reasons.push('Native sizing not observed; assay or register first');else if(s.kind==='roach'){const p=H.profile(s);reasons.push(...boundIssues({kind:'native',mass:p.mass,stats:p},r.host.requirements).map(e=>'Host: '+e));}
        if(s.id===w.bench.host_id)reasons.push('Active workshop host: switch to another racer first');
        if(s.id==='HOST')reasons.push('Historical starter cradle is not transferable in this profile; use an alternate host');
        if(s.working||ctx.parentBusy(w,s.id))reasons.push('Host is working or pairing');
        if(w.club.active?.hostId===s.id)reasons.push('Host is entered in an unfinished meet');
        const b=w.stabled[s.id];
        if(b&&(b.fitted.placements.length||b.draft.placements.length))reasons.push('Unfit and release its draft before packing a build-it-yourself kit');
        return reasons;
    }
    function preview(w,cmd,ctx){
        const r=recipe(w,cmd.recipeId), s=w.specimens.find(s=>s.id===cmd.hostId),errors=[];
        if(!s)errors.push('Choose an actual host');else errors.push(...hostIssues(w,s,r,ctx));
        const chosen=cmd.bindings||{},used=new Set(),placements=[],rows=[];
        for(const slot of r.slots){
            const id=chosen[slot.id],p=w.parts.find(p=>p.id===id),reasons=p?stockIssues(w,p,slot):['Choose a component'];
            if(id&&used.has(id))reasons.push('One component cannot fill two physical slots');if(id)used.add(id);
            let placement={...cp(slot.placement),id};
            if(cmd.positions?.[slot.id])placement={id,...cp(cmd.positions[slot.id])};
            if(p)placements.push(placement);
            rows.push({slot:slot.id,id:id||null,name:slot.name,reasons,placement});
            errors.push(...reasons.map(x=>slot.name+': '+x));
        }
        let draft=null,compiled=null;
        if(s?.kind==='roach'&&placements.length===r.slots.length){
            draft={...cp(r.guide),placements};
            try {B.validateDesign(draft);const p=H.profile(s),fit=B.fitting(draft,p);errors.push(...fit.map(x=>'Fit: '+(typeof x==='string'?x:JSON.stringify(x))));if(!fit.length)compiled=B.compile(draft,1,p);}
            catch(e){errors.push('Fit: '+e.message);}
        }
        return {ok:!errors.length,errors:[...new Set(errors)],rows,design:draft,build:compiled,hostId:s?.id||null,recipeId:r.id};
    }
    function matchingStock(w,recipeId,ctx){
        const r=recipe(w,recipeId);
        return {hosts:w.specimens.filter(s=>s.kind==='roach'&&s.owner==='player').map(s=>({id:s.id,plan:s.bodyPlan,issues:hostIssues(w,s,r,ctx)})),
            slots:r.slots.map(slot=>({...cp(slot),candidates:w.parts.filter(p=>p.owner==='player'&&slot.allowed.includes(productKey(w,p.id))).map(p=>({id:p.id,name:desc(w,p.id).name,donor:p.donor,issues:stockIssues(w,p,slot)}))}))};
    }
    function pack(w,cmd,ctx){
        const check=preview(w,cmd,ctx);need(check.ok,check.errors.join(' · '));
        const s=spec(w,cmd.hostId),r=recipe(w,cmd.recipeId);
        // Protection is not inferred away by choosing a recipe or preview.
        need(!s.protected||cmd.releaseProtected===true,'Confirm release of this protected host into kit custody');
        need(w.kits.length<300,'Local kit archive full');
        need(ctx.spendable(w)>=4+ctx.forecast(w,1).cashCost,'Reserve packing supplies and current care');
        const ids=check.rows.map(row=>row.id),id='W12.KIT.'+w.maker.next++;
        const k={id,type:'maker_host',recipe:r.id,recipeRevision:r.version,hostId:s.id,owner:'player',status:'packed',items:ids,price:0,created:w.tick,guide:cp(check.design),entry:cp(check.build),profile:cp(H.profile(s)),preparedFor:r.name};
        // Lock material before advancing a turn: auto-sales cannot steal it mid-job.
        s.kit=id;s.protected=true;s.autoOrdinary=false;
        for(const id2 of ids)part(w,id2).kit=id;
        if(w.hosts[s.id]){k.priorRegistration=cp(w.hosts[s.id]);k.priorBench=cp(w.stabled[s.id]);delete w.hosts[s.id];delete w.stabled[s.id];}
        w.kits.push(k);ctx.pay(w,4,'Pack complete living kit',id);ctx.step(w,1);return id;
    }
    function open(w,id,ctx){
        const k=lookup(w.kits,id,'kit');need(k.type==='maker_host'&&k.status==='packed'&&k.owner==='player','No owned sealed maker kit');
        const s=spec(w,k.hostId);need(s.kit===id&&s.owner==='player','Host custody mismatch');
        for(const id2 of k.items){const p=part(w,id2);need(p.kit===id&&p.owner==='player','Kit contents changed');p.kit=null;}
        s.kit=null;k.status='unpacked';k.openedAt=w.tick;
        ctx.registerHost(w,s.id);
        if(k.priorBench)w.stabled[s.id]=cp(k.priorBench);
        return cp(k.items);
    }
    function guide(w,id){
        const k=lookup(w.kits,id,'kit');need(k.type==='maker_host'&&k.status==='unpacked'&&k.owner==='player','Open the owned maker kit');
        need(w.bench.host_id===k.hostId,'Bring the included host to the bench');need(canon(w.bench.draft)===canon(w.bench.fitted),'Fit or discard the current draft first');
        for(const id2 of k.items){const p=part(w,id2);need(p.owner==='player'&&!p.kit,'The historical kit guide is missing current stock');const holder=reservedBy(w,id2);need(!holder||holder===k.hostId,'Guide component belongs to another build');}
        need(!B.fitting(k.guide,w.bench.host_profile).length,'Guide no longer fits');w.bench.draft=cp(k.guide);return id;
    }
    function inspectKit(w,k,o){
        const errors=[];if(!k||k.type!=='maker_host'||k.owner!=='player'||k.status!=='packed')return ['Needs an owned sealed player-made complete kit'];
        const r=recipe(w,k.recipe),a=k.items.map(id=>desc(w,id)),kinds=a.map(x=>x.kind);
        if(o.recipeId&&r.id!==o.recipeId)errors.push('This inquiry requests a different published product');
        for(const kind of o.requiredKinds||[])if(!kinds.includes(kind))errors.push('Include prepared '+kind+' anatomy');
        if(o.equipment&&!R.legal(k.entry,o.equipment))errors.push('Construction does not meet '+o.equipment+' equipment policy');
        if(k.entry.mass>o.maxMass+1e-8)errors.push('Entry mass exceeds the declared customer limit');
        for(const [kind,bounds] of Object.entries(o.bounds||{})){const component=a.find(x=>x.kind===kind);if(component)errors.push(...boundIssues(component,Object.entries(bounds).map(([path,b])=>({path,label:kind+' '+path,...b}))));}
        return errors;
    }
    function retailQuote(w,k){
        need(k&&k.type==='maker_host'&&k.status==='packed','No sealed maker product');
        // Same counter must not buy back unchanged stock above its currently known retail quote.
        // Only public product facts enter this comparison; no hidden genomes or future results.
        const asOwned={...k,owner:'player'};
        const posted=w.maker.orders.filter(o=>o.type==='kit'&&!['cancelled','expired'].includes(o.state)&&!inspectKit(w,asOwned,o).length);
        return Math.max(k.price,...posted.map(o=>o.price+24));
    }
    function evidence(w,lineId,o){
        const line=w.lines.find(l=>l.id===lineId);
        if(!line||line.kind!==o.kind)return {ok:false,errors:['Choose a recorded '+C.FORMS[o.kind].name+' line'],tested:0,matching:0,broods:0,unmeasured:0,eligible:[],members:[]};
        const report=E.lineReport(w,{...line,target:cp(o.target)}),members=E.ancestry(w,line);
        const descendants=w.specimens.filter(s=>members.has(s.id)&&members.get(s.id)>0),tested=descendants.filter(s=>s.measured),matches=tested.filter(s=>targetPass(C.traits(s)[o.target.trait],o.target));
        const errors=[];
        if(tested.length<o.minTested)errors.push('Measure '+(o.minTested-tested.length)+' more distinct descendants');
        const broods=new Set(tested.map(s=>s.brood).filter(Boolean)).size;
        if(broods<o.minBroods)errors.push('Evidence needs '+o.minBroods+' distinct measured broods');
        if(matches.length<o.minMatches)errors.push('Only '+matches.length+' measured descendants meet the requested contribution');
        return {ok:!errors.length,errors,tested:tested.length,matching:matches.length,broods,unmeasured:descendants.length-tested.length,rows:report.rows,
            eligible:matches.filter(s=>s.owner==='player'&&s.alive&&s.stage==='adult'&&!s.kit&&!w.hosts[s.id]&&Object.values(s.regions).every(v=>v==='intact')).map(s=>({id:s.id,sex:s.sex,protected:s.protected,value:C.traits(s)[o.target.trait]})),
            members:[...members.keys()],claim:'Selected measured descendants, not unbiased future yield or a racing guarantee.'};
    }
    function contributionBound(q,value){
        if(q.min!==undefined&&q.max!==undefined){
            if(!Number.isFinite(value))return null;
            if(value>q.max)return{op:'max',threshold:q.max};
            if(value<q.min)return{op:'min',threshold:q.min};
            return null; // inside the desired range: no invented direction to optimize
        }
        return q.min!==undefined?{op:'min',threshold:q.min}:q.max!==undefined?{op:'max',threshold:q.max}:null;
    }
    function targetPass(v,t){return Number.isFinite(v)&&(t.op==='min'?v>=t.threshold-1e-8:v<=t.threshold+1e-8);}
    function acceptance(w,id){const o=order(w,id);return o.type==='kit'?w.kits.filter(k=>k.type==='maker_host'&&k.owner==='player'&&k.status==='packed').map(k=>({id:k.id,name:k.preparedFor,issues:inspectKit(w,k,o)})):w.lines.filter(l=>l.kind===o.kind).map(l=>({id:l.id,name:l.name,...evidence(w,l.id,o)}));}
    function accept(w,id,ctx){const o=order(w,id);need(o.state==='offered','Order is not offered');ctx.transfer(w,o.buyer,'escrow',o.price,'Fund maker commission',o.id);o.escrow=o.price;o.deadline=w.tick+o.window;o.state='active';return id;}
    function close(w,o,state,ctx){if(o.escrow)ctx.transfer(w,'escrow',o.buyer,o.escrow,'Return unearned maker funds',o.id);o.escrow=0;o.state=state;}
    function expire(w,ctx){for(const o of w.maker.orders)if(o.state==='active'&&w.tick>o.deadline)close(w,o,'expired',ctx);}
    function delivered(w,o,assets,claim,ctx){
        need(o.escrow===o.price,'Reserved payment missing');ctx.transfer(w,'escrow','player',o.price,'Accepted '+o.type+' commission',o.id);o.escrow=0;o.state='complete';
        const receipt={id:'W12.SALE.'+w.maker.next++,orderId:o.id,edition:o.edition,tick:w.tick,assets:cp(assets),paid:o.price,claim:claim?cp(claim):null};o.deliveries.push(receipt);w.maker.shipments.push(cp(receipt));ctx.settleCare(w);return cp(receipt);
    }
    function deliverKit(w,cmd,ctx){
        const o=order(w,cmd.id);need(o.type==='kit'&&o.state==='active'&&w.tick<=o.deadline,'Active kit order is required');
        const k=w.kits.find(k=>k.id===cmd.kitId),reasons=inspectKit(w,k,o);need(!reasons.length,reasons.join(' · '));
        const s=spec(w,k.hostId);need(s.owner==='player'&&s.kit===k.id,'Host ownership changed');
        for(const id of k.items){const p=part(w,id);need(p.owner==='player'&&p.kit===k.id,'Packed component changed owner');p.owner=o.buyer;}
        s.owner=o.buyer;k.owner=o.buyer;k.price=o.price+24;k.deliveredAt=w.tick;
        return delivered(w,o,[k.id,k.hostId,...k.items],{recipe:k.recipe,version:k.recipeRevision,assembly:k.guide},ctx);
    }
    function deliverBreeders(w,cmd,ctx){
        const o=order(w,cmd.id);need(o.type==='breeder'&&o.state==='active'&&w.tick<=o.deadline,'Active breeder order is required');
        const report=evidence(w,cmd.lineId,o);need(report.ok,report.errors.join(' · '));
        need(Array.isArray(cmd.ids)&&cmd.ids.length===2&&cmd.ids[0]!==cmd.ids[1],'Choose two distinct living breeders');
        const pair=cmd.ids.map(id=>spec(w,id));need(pair.every(s=>report.eligible.some(x=>x.id===s.id)),'Both animals must be observed qualifying descendants, intact owned adults outside a racer or kit');
        need(pair[0].sex!==pair[1].sex,'Customer needs complementary A/B reproductive roles');
        need(pair.every(s=>!s.working&&!ctx.parentBusy(w,s.id)),'Finish work or pairing before delivery');
        need(pair.every(s=>!s.protected)||cmd.releaseProtected===true,'Confirm release of the protected delivery animals');
        const claim={lineId:cmd.lineId,target:cp(o.target),tested:report.tested,matching:report.matching,broods:report.broods,unmeasured:report.unmeasured,rows:cp(report.rows),limit:report.claim};
        for(const s of pair){s.owner=o.buyer;s.protected=false;s.autoOrdinary=false;w.retail.liveOffers.push({id:s.id,price:Math.ceil(o.price/2)+16});}
        return delivered(w,o,cmd.ids,claim,ctx);
    }
    function requestRestock(w,id,ctx){
        const o=order(w,id);need(o.state==='complete'&&o.edition<o.limit,'No further customer edition available');
        need(w.accounts[o.buyer]>=o.price,'Customer has not funded another batch');
        o.edition++;o.state='offered';delete o.deadline;return o.id;
    }
    function inquiry(w,cmd){
        const r=recipe(w,cmd.recipeId),pub=w.maker.publications.find(p=>p.recipeId===r.id);need(pub&&pub.champion,'Publish a real champion round first');
        need(!w.maker.orders.some(o=>o.sourceMeet===pub.meet),'One showroom inquiry already exists for this meeting');
        const amount=Math.min(180,40+r.slots.reduce((s,x)=>s+(C.PRODUCTS[x.sourceProduct]?.price||24),0));
        const id='W12.INQUIRY.'+w.maker.next++;
        w.maker.orders.push({id,type:'kit',name:'Two Nets / '+r.name,buyer:'shop',price:amount,window:32,requiredKinds:[...new Set(r.slots.map(s=>s.kind))],equipment:'open',maxMass:5,limit:2,bounds:{},state:'offered',escrow:0,edition:1,deliveries:[],recipeId:r.id,sourceMeet:pub.meet,
            purpose:'Owner-approved winning round prompts a bounded product inquiry. Another host and qualifying parts are required; payment follows delivery.'});return id;
    }
    function dispatch(w,cmd,ctx){
        switch(cmd.type){
            case 'makerPublish':return makeRecipe(w,cmd);
            case 'makerPack':return pack(w,cmd,ctx);
            case 'makerOpen':return open(w,cmd.id,ctx);
            case 'makerGuide':return guide(w,cmd.id);
            case 'makerAccept':return accept(w,cmd.id,ctx);
            case 'makerDeliverKit':return deliverKit(w,cmd,ctx);
            case 'makerDeliverBreeders':return deliverBreeders(w,cmd,ctx);
            case 'makerCancel':{const o=order(w,cmd.id);need(o.state==='active','No active commission');close(w,o,'cancelled',ctx);return o.id;}
            case 'makerRestock':return requestRestock(w,cmd.id,ctx);
            case 'makerInquiry':return inquiry(w,cmd);
            default:throw Error('Unknown maker operation');
        }
    }
    function escrow(w){return (w.maker?.orders||[]).reduce((s,o)=>s+o.escrow,0);}
    function validate(w){
        const m=w.maker;need(m&&m.version===1,'Missing maker registry');integer(m.next,1,100000,'maker sequence');
        need(Array.isArray(m.recipes)&&m.recipes.length<=80&&Array.isArray(m.orders)&&m.orders.length<=100&&Array.isArray(m.publications)&&m.publications.length<=80&&Array.isArray(m.shipments)&&m.shipments.length<=300,'Maker archive bound');
        const unique=(a,label)=>need(new Set(a.map(x=>x.id)).size===a.length,'Duplicate '+label);unique(m.recipes,'recipe');unique(m.orders,'order');unique(m.publications,'publication');unique(m.shipments,'sale');unique(w.kits,'kit');
        for(const r of m.recipes){text(r.name,'Recipe');need(r.version===1&&r.protocol==='W12.RECIPE.MEASURED.1'&&[0,.10,.15,.25].includes(r.tolerance),'Recipe protocol changed');need(r.host.plans.length===1&&H.PLANS[r.host.plans[0]],'Recipe body plan missing');H.assertProfile(r.referenceProfile);B.validateDesign(r.guide);need(r.slots.length===r.guide.placements.length&&r.slots.length>0,'Recipe bill of materials incomplete');unique(r.slots,'recipe slot');need(canon(r.source.build.design_snapshot)===canon(r.guide)&&canon(r.source.build.body_profile)===canon(r.referenceProfile),'Recipe diverged from its published reference');need(r.host.plans[0]===r.referenceProfile.plan,'Recipe native plan changed');need(canon(r.host.requirements)===canon(recipeBounds({kind:'native',mass:r.referenceProfile.mass,stats:r.referenceProfile},r.tolerance,r.requirementOverrides?.HOST)),'Recipe native requirements changed');
            for(const slot of r.slots){const a=desc(w,slot.sourceId);need(slot.kind===a.kind&&slot.sourceProduct===productKey(w,slot.sourceId),'Recipe source changed');need(canon(slot.allowed)===canon(r.signature?[slot.sourceProduct]:(MECHANISMS[slot.sourceProduct]||[slot.sourceProduct])),'Recipe substitution semantics changed');need(canon(slot.requirements)===canon(recipeBounds(a,r.tolerance,r.requirementOverrides?.[slot.id])),'Altered acceptance measurements');need(canon(slot.placement)===canon(r.guide.placements.find(p=>p.id===slot.sourceId)),'Recipe placement missing');}
        }
        for(const pub of m.publications){const r=recipe(w,pub.recipeId),original=publicResult(w,pub.meet,pub.round);need(canon(pub.build)===canon(original.build)&&pub.rank===original.rank&&pub.champion===original.champion&&canon(r.source.build)===canon(pub.build),'Published claim differs from actual meeting');}
        for(const k of w.kits.filter(k=>k.type==='maker_host')){
            const r=recipe(w,k.recipe);need(k.recipeRevision===r.version&&k.items.length===r.slots.length&&['packed','unpacked'].includes(k.status),'Invalid maker kit');need(k.guide.placements.length===k.items.length&&canon(k.guide.placements.map(x=>x.id))===canon(k.items),'Kit guide does not match physical contents');H.assertProfile(k.profile);need(k.profile.id===k.hostId&&canon(k.profile)===canon(H.profile(spec(w,k.hostId))),'Kit native profile changed');need(r.host.plans.includes(k.profile.plan)&&!boundIssues({kind:'native',mass:k.profile.mass,stats:k.profile},r.host.requirements).length,'Kit host fails native promise');
            for(let i=0;i<r.slots.length;i++){const a=desc(w,k.items[i]);need(r.slots[i].allowed.includes(productKey(w,k.items[i]))&&!boundIssues(a,r.slots[i].requirements).length,'Kit contents fail published promise');}
            need(!B.fitting(k.guide,k.profile).length,'Packed guide is not buildable');need(canon(B.compile(k.guide,1,k.profile))===canon(k.entry),'Packed build fingerprint changed');
            if(k.status==='packed'){const s=spec(w,k.hostId);need(s.kit===k.id&&s.owner===k.owner&&!w.hosts[s.id]&&s.alive&&s.stage==='adult','Sealed host custody invalid');}
        }
        for(const o of m.orders){
            need(['kit','breeder'].includes(o.type)&&['offered','active','complete','cancelled','expired'].includes(o.state)&&o.buyer==='shop','Invalid maker order');integer(o.price,1,1000,'order price');integer(o.limit,1,2,'edition limit');integer(o.edition,1,o.limit,'edition');integer(o.escrow,0,1000,'maker escrow');
            need(o.escrow===(o.state==='active'?o.price:0),'Maker funding mismatch');need(o.deliveries.length<=o.edition,'Duplicated maker delivery');
            if(o.id.startsWith('W12.ORDER.')){const b=BRIEFS.find(b=>b.id===o.id);need(b&&Object.keys(b).every(key=>canon(o[key])===canon(b[key])),'Customer requirements changed');}
            else {const r=recipe(w,o.recipeId);need(m.publications.some(p=>p.recipeId===o.recipeId&&p.meet===o.sourceMeet&&p.champion),'Inquiry without owner-approved actual winner');const price=Math.min(180,40+r.slots.reduce((s,x)=>s+(C.PRODUCTS[x.sourceProduct]?.price||24),0));need(o.price===price&&o.window===32&&o.limit===2&&o.maxMass===5&&o.equipment==='open'&&canon(o.requiredKinds)===canon([...new Set(r.slots.map(s=>s.kind))])&&canon(o.bounds)==='{}','Inquiry requirements changed');}
            if(o.state==='active')integer(o.deadline,0,100100,'maker deadline');
            for(const sale of o.deliveries){integer(sale.edition,1,o.edition,'delivery edition');need(sale.orderId===o.id&&sale.paid===o.price&&m.shipments.some(s=>canon(s)===canon(sale)),'Missing sale record');}need(new Set(o.deliveries.map(d=>d.edition)).size===o.deliveries.length,'Two deliveries for one edition');if(o.state==='complete')need(o.deliveries.some(d=>d.edition===o.edition),'Completed order lacks accepted delivery');
        }
        for(const sale of m.shipments)need(m.orders.some(o=>o.deliveries.some(d=>canon(d)===canon(sale))),'Orphan sale receipt');
        return true;
    }
    const api={BRIEFS,METRICS,MECHANISMS,init,dispatch,preview,matchingStock,inspectKit,acceptance,retailQuote,evidence,expire,escrow,validate,recipe,productKey,desc,measuredBounds,recipeBounds,contributionBound,publicResult,stockIssues};
    root.RRRMaker=api;if(typeof module!=='undefined')module.exports=api;
})(typeof globalThis!=='undefined'?globalThis:this);
