'use strict';
const W=require('../src/world.js'),B=require('../src/bench.js'),K=require('../src/maker.js'),C=require('../src/catalog.js'),R=require('../src/race.js');
const a=(w,c)=>W.apply(w,c).world;
function funded(w=W.initial(),n=1500){w=B.copy(w);w.accounts.player+=n;w.accounts.external-=n;return w;} // synthetic operator fixture, never browser play
function upgraded(w=W.initial()){w.bench=B.place(B.place(w.bench,'UPGRADE-DRIVE'),'W05.PADS');return a(w,{type:'fit'});}
function complete(w=upgraded()){w=a(w,{type:'clubEnter',event:'first'});for(let i=0;i<3;i++){const p=W.apply(w,{type:'clubStart'});const runs=p.result.requests.map(q=>new R.Race(q.course,q.entrants,q.equipment,q.dt).run());w=a(p.world,{type:'clubFinish',id:p.result.id,runs});}return w;}
function publish(w,options={}){const r=W.apply(w,{type:'makerPublish',name:'Declared test kit',tolerance:.25,...options});return {w:r.world,rid:r.result};}
function brood(w){w=a(w,{type:'breed',parents:['P-R','P-S'],auto:false});w=a(w,{type:'wait',turns:5});return w;}
function f1(w){const before=new Set(w.specimens.map(s=>s.id));for(let i=0;i<5;i++){w=brood(w);const s=w.specimens.find(s=>!before.has(s.id)&&s.owner==='player'&&s.kind==='hopper'&&s.stage==='adult'&&s.alive);if(s){if(s.protected)w=a(w,{type:'protect',id:s.id});const out=W.apply(w,{type:'prepare',id:s.id,product:'hoppers'});return {w:out.world,pid:out.result,donor:s.id};}}throw Error('No actual F1 within declared attempt budget');}
function shopPart(w,product){const p=w.parts.find(p=>p.owner==='shop'&&!p.kit&&p.product===product);w=a(w,{type:'buyPart',id:p.id});return {w,pid:p.id};}
function preparedFeet(w){const id='W07.SHOP.LIVE.stick.B';w=a(w,{type:'buyLive',id});w=a(w,{type:'protect',id});const p=W.apply(w,{type:'prepare',id,product:'sticktoe'});return{w:p.world,pid:p.result};}
function kitFixture({champion=false,hostId='W08.SHOP.HOST.lowline.A'}={}){
 let w=champion?complete():upgraded(funded());let p=publish(w,champion?{meetId:w.club.history[0].id,requirements:{S3:{rough_grip:{min:.9}}}}:{requirements:{S3:{rough_grip:{min:.9}}}});w=p.w;let h=f1(w);w=h.w;let d=shopPart(w,'redline');w=d.w;let f=preparedFeet(w);w=f.w;w=a(w,{type:'buyLive',id:hostId});const req={recipeId:p.rid,hostId,bindings:{S1:h.pid,S2:d.pid,S3:f.pid},releaseProtected:true};return{w,rid:p.rid,req,donor:h.donor,components:[h.pid,d.pid,f.pid]};
}
function packedFixture(){const f=kitFixture();const p=W.apply(f.w,{type:'makerPack',...f.req});return {...f,w:p.world,kitId:p.result};}
function breederFixture(){let w=funded();w=a(w,{type:'selectionProject',kind:'hopper',trait:'phase',op:'max',threshold:.07});let r=W.apply(w,{type:'createLine',name:'Two-brood reference',parents:['P-R','P-S']});w=r.world;const lineId=r.result;for(let i=0;i<6;i++){w=brood(w);const adults=w.specimens.filter(s=>s.brood&&s.owner==='player'&&s.stage==='adult'&&s.alive);if(new Set(adults.map(s=>s.brood)).size>=2&&adults.some(s=>s.sex==='A')&&adults.some(s=>s.sex==='B'))break;}for(const s of w.specimens.filter(s=>s.brood&&s.owner==='player'&&s.stage==='adult'&&s.alive))if(!s.measured)w=a(w,{type:'assay',id:s.id});return{w,lineId};}
module.exports={W,B,K,C,R,a,funded,upgraded,complete,publish,brood,f1,shopPart,preparedFeet,kitFixture,packedFixture,breederFixture};
