# RAD ROACH RACING — Makers & Bloodlines / v0.12

Open `RRR_Makers_Bloodlines_v0.12.html` in a modern browser. Code, style and artwork are included; no installation or network assets are required for the playable HTML. Browser persistence can be unavailable. Use the separate whole-world backup for deliberate saves.

## What changed

**09 · Maker counter** publishes real committed or owner-selected recorded constructions, describes measured part/host promises, selects another actual host and anatomy, packs complete kits and delivers them to funded customers. The same sold kits appear at Two Nets and open into the existing workbench. Living breeder orders use observed descendants and an actual eligible reproductive pair. Club competition, donor preparation, the stable and Trackworks remain available.

This reconstructs missing Wave10 requirements on recovered Wave11 source. It does not recover that unavailable implementation.

## Use

1. Fit and commit a build with prepared anatomy, or complete a club meeting.
2. At Maker counter, choose the reference, name the product and inspect its measurements. Optional per-measurement promises must still contain the reference.
3. Select another measured adult host and loose components satisfying the recipe. Buy, catch or breed inputs through existing systems. The historical starter HOST cradle is not transferable in this fixture.
4. Resolve actual measurement/fit/reservation issues. Pack for four credits and one turn plus care, then deliver against a funded brief or keep/open the kit.
5. An owner-approved champion publication can prompt a bounded specific kit inquiry. It pays only for an accepted physical kit.

Breeding commissions require an existing line, enough distinct measured descendants and broods, and two eligible living A/B descendants meeting the requested contribution. Unknown siblings do not count as failures or successes. An evidence claim does not guarantee later offspring.

The two kit briefs support two editions; the breeder briefs one. Finite customer funds, care, ordinary sales and current source anatomy remain real constraints. The measured first manufacturing route loses cash despite receiving its advertised payment; final pricing and pacing are uncalibrated.

## Persistence

Whole-world backup includes stock, maker products, orders, receipts, stable, course and club history. Product-specification export is knowledge only and has no importer in this release. Personal build sheets remain different from whole-world backups. Saves are editable local data, not multiplayer authority. No automatic remote upload occurs.

## Developers

Runtime source is under `src/`. `maker.js` and `maker_ui.js` are the new feature modules. `world.js` integrates shared custody, money, persistence and clock. The existing `race.js`, `bench.js`, `anatomy.js`, `club.js`, and `circuits.js` are unchanged from the included W11 reference. Only one local world catalogue is active at a time.

Tested development tools: Python 3.13, Node 22, `jsonschema`, and Playwright with a Chromium executable. The playable HTML does not need these tools.

```sh
python tools/build_app.py
python validate_wave12.py
python validate_wave12.py --browser
python tools/verify_archive.py ../RRR_Wave_12_Agent_Pack.zip --run --report ../verified.json
```

`RRR_CHROMIUM` overrides the browser executable path. Default `/usr/bin/chromium` was used in Linux verification. Browser tests try file navigation, then use exact HTML with `set_content` where the host blocks it. The separate retail test restores the actual backup produced by the main browser test; it does not invent inventory.

## Agent entry points

`RRR_Wave_12.spec` is strict JSON in the project's exchange format, not a claimed secret MIVIM grammar. The foundation and TODO distinguish developed scope from open game systems. `world_context_v0.12.json` appends this wave without changing old non-manifest records. The baseline and missing Wave10 written handoff remain under `reference/`.

`evidence/validation_report.json` records current checks. Browser reports distinguish actual control paths from synthetic operator fixtures. Screenshots are reviewed UI evidence, not proof of human usability or final art quality. The exact archive verifier checks packaged inventory and hashes independently.
