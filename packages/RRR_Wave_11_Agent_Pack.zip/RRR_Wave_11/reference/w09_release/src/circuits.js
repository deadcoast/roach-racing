/* W09 Trackworks: owned physical sections, an editable chain, immutable course sheets.
 * Normalized tabletop fixture. Only one physical layout is assembled at a time.
 * A historical published sheet records geometry; it does not duplicate its sections. */
(function(root){'use strict';
 const R=root.RRRRace||(typeof require==='function'?require('./race.js'):null);
 const cp=x=>JSON.parse(JSON.stringify(x)),need=(x,m)=>{if(!x)throw Error(m);};
 const bounded=(x,a,b,m)=>need(Number.isFinite(x)&&x>=a&&x<=b,m);
 const TYPES={
  run:{name:'Gutter Run',length:6,curvature:0,width:2.4,price:8,colour:'#99a995',description:'Smooth straight. Extend a useful power run.'},
  half:{name:'Half Run',length:3,curvature:0,width:2.4,price:5,colour:'#929d89',description:'Half-length connector for smaller layouts.'},
  bend:{name:'Drum Bend',length:1.5*Math.PI,curvature:1/3,width:2.4,price:10,colour:'#bba780',description:'Reversible quarter turn. The rails carry contact, not invisible lane locks.'},
  rise:{name:'Brake Rise',length:6,curvature:0,width:2.4,price:12,colour:'#dc9b61',brakeHeight:.16,description:'Raised approach engages a low pad, then launches from a low lip. Follow it with a straight landing run.'},
  wash:{name:'Rivet Wash',length:6,curvature:0,width:2.4,price:10,colour:'#afad9b',bump:1,description:'Landing seams exercise joints and separately fitted rebound tissue.'},
  ash:{name:'Ash Gutter',length:6,curvature:0,width:2.4,price:10,colour:'#797d69',surface:'loose',description:'Same connectors; loose material changes the required foot purchase.'},
  rail:{name:'Ribbed Rail Bend',length:1.5*Math.PI,curvature:1/3,width:2.4,price:12,colour:'#d0bc8d',wallFriction:.75,description:'Quarter turn with a rough wall. Smooth guide tissue reduces contact loss.'}
 };
 const MAX=48;
 function text(s,n=40){need(typeof s==='string'&&s.trim()&&s.length<=n&&!/[\x00-\x1f]/.test(s),'Use a short printable course name');return s;}
 function hash(s){let h=2166136261;for(const c of s){h^=c.charCodeAt(0);h=Math.imul(h,16777619);}return (h>>>0).toString(16).padStart(8,'0');}
 function key(x){return JSON.stringify(x);}
 function initial(){
  const inventory=[],supply=[];let n=0;
  for(let i=0;i<8;i++)inventory.push({id:`W09.SECTION.START.${++n}`,type:'run',owner:'player'});
  for(let i=0;i<4;i++)inventory.push({id:`W09.SECTION.START.${++n}`,type:'bend',owner:'player'});
  for(const type of Object.keys(TYPES))for(let i=0;i<8;i++)supply.push({id:`W09.SECTION.SHOP.${type}.${i+1}`,type,owner:'shop'});
  const sequence=[];for(let side=0;side<4;side++)sequence.push({id:inventory[side*2].id,turn:1},{id:inventory[side*2+1].id,turn:1},{id:inventory[8+side].id,turn:1});
  return {schema:'W09.TRACKWORKS.1',inventory:[...inventory,...supply],draft:{name:'Foundry Home Loop',laps:2,sequence},published:[],active:null,next:1,history:[],commission:{id:'W09.FOUNDRY.LAYOUT.1',status:'offered',fee:24,name:'Foundry layout commission',requirements:'A closed 8–24 section loop with a Brake Rise, a Ribbed Rail Bend and two smooth Gutter Runs. Club pays once for setup work; your sections remain yours.'}};
 }
 function stock(t,id){const s=t.inventory.find(s=>s.id===id);need(s&&TYPES[s.type],'Unknown track section');return s;}
 function validateDraft(t,d){
  text(d.name);need(Number.isInteger(d.laps)&&d.laps>=1&&d.laps<=6,'Choose one to six laps');
  need(Array.isArray(d.sequence)&&d.sequence.length<=MAX,'Trackwork supports at most 48 sections');
  const ids=new Set();for(const a of d.sequence){need(a&&typeof a.id==='string'&&!ids.has(a.id),'A physical section cannot appear twice');ids.add(a.id);need(stock(t,a.id).owner==='player','Buy the section before placing it');need(a.turn===1||a.turn===-1,'Invalid curve orientation');}
 }
 function pointSeg(p,a,b){const dx=b[0]-a[0],dy=b[1]-a[1],den=dx*dx+dy*dy,f=den?R.clip(((p[0]-a[0])*dx+(p[1]-a[1])*dy)/den,0,1):0;return Math.hypot(p[0]-a[0]-f*dx,p[1]-a[1]-f*dy);}
 function cross(a,b,c){return (b[0]-a[0])*(c[1]-a[1])-(b[1]-a[1])*(c[0]-a[0]);}
 function segDist(a,b,c,d){const p=cross(a,b,c),q=cross(a,b,d),u=cross(c,d,a),v=cross(c,d,b);if(p*q<0&&u*v<0)return 0;return Math.min(pointSeg(a,c,d),pointSeg(b,c,d),pointSeg(c,a,b),pointSeg(d,a,b));}
 function samples(p,spacing=.3){const n=Math.ceil(p.length/spacing),v=[];for(let i=0;i<=n;i++)v.push(R.posePiece(p,p.length*i/n));return v;}
 function compile(t,d=t.draft){validateDraft(t,d);let x=0,y=0,h=0,starts=0;const pieces=d.sequence.map((a,i)=>{const s=stock(t,a.id),v=TYPES[s.type],p={id:s.id,type:s.type,name:v.name,length:v.length,curvature:v.curvature*a.turn,x,y,heading:h,width:v.width,grip:v.surface==='loose'?1.12:1.6,resistance:.15,ceiling:5,jumpable:!v.curvature,surface:v.surface||'smooth',track_profile:'W09.SURFACE.1',rail:true,wall_friction:v.wallFriction??.5,brake_height:v.brakeHeight??0,launch_angle:v.brakeHeight?.34:0,launch_height:v.brakeHeight?.12:0,brake_start:v.brakeHeight?v.length*.7:0,bump:v.bump??0,start_distance:starts};[x,y,h]=R.posePiece(p,p.length);starts+=p.length;return p;});
  const errors=[],warnings=[];const closure=Math.hypot(x,y),heading=Math.abs(((h+Math.PI)%(2*Math.PI)+2*Math.PI)%(2*Math.PI)-Math.PI);
  if(pieces.length<4)errors.push({code:'few_sections',message:'Lay at least four sections before publishing.'});
  if(closure>1e-6||heading>1e-6)errors.push({code:'open',message:`Open connector: ${closure.toFixed(2)} L from the release point; ${(heading*180/Math.PI).toFixed(0)}° heading mismatch.`});
  const points=pieces.map(p=>samples(p)),flat=points.flat();const bounds=flat.length?{minX:Math.min(...flat.map(p=>p[0]))-1.2,maxX:Math.max(...flat.map(p=>p[0]))+1.2,minY:Math.min(...flat.map(p=>p[1]))-1.2,maxY:Math.max(...flat.map(p=>p[1]))+1.2}:{minX:-2,maxX:2,minY:-2,maxY:2};
  if(bounds.maxX-bounds.minX>85||bounds.maxY-bounds.minY>85)errors.push({code:'footprint',message:'This workshop floor supports at most 85 × 85 normalized L.'});
  // Conservative sampled swept-channel separation. Adjacent join faces are exempt;
  // non-adjacent floor channels may not cross, overlap or touch. Bridges are not modeled.
  outer:for(let i=0;i<pieces.length;i++)for(let j=i+2;j<pieces.length;j++){
   if(i===0&&j===pieces.length-1&&closure<1e-6&&heading<1e-6)continue;
   const a=points[i],b=points[j],clearance=(pieces[i].width+pieces[j].width)/2-.015;
   for(let k=1;k<a.length;k++)for(let m=1;m<b.length;m++)if(segDist(a[k-1],a[k],b[m-1],b[m])<clearance){errors.push({code:'overlap',ids:[pieces[i].id,pieces[j].id],message:`Sections ${i+1} and ${j+1} overlap on the workshop floor; no implicit overpass.`});break outer;}
  }
  for(let i=0;i<pieces.length;i++)if(pieces[i].launch_angle){const n=pieces[(i+1)%pieces.length];if(n.curvature||n.launch_angle)errors.push({code:'landing',ids:[pieces[i].id],message:`Brake Rise ${i+1} needs a following flat straight for landing. Move the ramp earlier or add a landing section.`});}
  if(pieces.some(p=>p.brake_height)&&!pieces.some(p=>p.curvature))warnings.push('The Brake Rise has no following turn in the current draft. Braking is not free speed.');
  const course={id:'W09.DRAFT',laps:d.laps,pieces,length:starts,profile:'W09.TRACKWORKS.COURSE.1'};
  return {valid:errors.length===0,errors,warnings,course,closure,heading,end:{x,y,h},bounds,length:starts,total:starts*d.laps,counts:Object.fromEntries(Object.keys(TYPES).map(k=>[k,pieces.filter(p=>p.type===k).length]))};
 }
 function remember(t){t.history.push(cp(t.draft));if(t.history.length>40)t.history.shift();}
 function publish(t,tick){const r=compile(t);need(r.valid,r.errors[0]?.message);const previous=t.published.find(p=>p.id===t.active);
  if(previous&&key(previous.design)===key(t.draft))return {id:previous.id,unchanged:true};
  need(t.published.length<80,'Course-sheet archive full; local slice limit is 80 versions');
  const serial=t.next++,fingerprint=hash(key({design:t.draft,geometry:r.course.pieces})),id=`W09.COURSE.${serial}.${fingerprint}`;
  const sheet={id,version:serial,createdAt:tick,name:t.draft.name,design:cp(t.draft),fingerprint,course:{...r.course,id},commissioned:false};
  new R.Course(sheet.course);t.published.push(sheet);t.active=id;return {id,unchanged:false};
 }
 function materialize(t,sheet){need(sheet&&sheet.course,'Missing published sheet');const check=compile(t,sheet.design);need(check.valid,'Archived course no longer has valid geometry');need(key(check.course.pieces)===key(sheet.course.pieces)&&check.course.laps===sheet.course.laps,'Changed published course geometry');return new R.Course(sheet.course);}
 function active(t){const a=t.published.find(a=>a.id===t.active);need(a,'Publish a closed layout before racing your course');materialize(t,a);return a;}
 function exportPlan(t){validateDraft(t,t.draft);return {format:'RRR.TRACK.PLAN.1',name:t.draft.name,laps:t.draft.laps,sections:t.draft.sequence.map(a=>({type:stock(t,a.id).type,turn:a.turn})),note:'Construction plan only. Must be assembled from owned sections. No cash, parts or competition authority.'};}
 function importPlan(t,plan){need(plan&&plan.format==='RRR.TRACK.PLAN.1','Not a track construction plan');need(Object.keys(plan).every(k=>['format','name','laps','sections','note'].includes(k)),'Unknown plan field');text(plan.name);need(Array.isArray(plan.sections)&&plan.sections.length<=MAX,'Plan outside workshop bounds');const used=new Set();const sequence=plan.sections.map(a=>{need(a&&Object.keys(a).every(k=>['type','turn'].includes(k))&&TYPES[a.type]&&(a.turn===1||a.turn===-1),'Invalid plan section');const p=t.inventory.find(s=>s.type===a.type&&s.owner==='player'&&!used.has(s.id));need(p,`Missing owned ${TYPES[a.type].name}. A plan grants no inventory.`);used.add(p.id);return {id:p.id,turn:a.turn};});const d={name:plan.name,laps:plan.laps,sequence};validateDraft(t,d);remember(t);t.draft=d;}
 function validate(t){need(t&&t.schema==='W09.TRACKWORKS.1','Missing trackworks state');need(Array.isArray(t.inventory)&&t.inventory.length<=240,'Invalid section inventory');const seen=new Set();for(const s of t.inventory){need(typeof s.id==='string'&&/^W09[.]SECTION[.][A-Za-z0-9_.-]+$/.test(s.id)&&!seen.has(s.id),'Duplicate or malformed section identity');seen.add(s.id);need(TYPES[s.type]&&['shop','player'].includes(s.owner),'Unknown section type or owner');}
  validateDraft(t,t.draft);need(Array.isArray(t.history)&&t.history.length<=40,'Invalid track undo history');for(const d of t.history)validateDraft(t,d);
  need(Array.isArray(t.published)&&t.published.length<=80,'Invalid course archive');const pub=new Set();let max=0;for(const s of t.published){need(!pub.has(s.id),'Duplicate published course');pub.add(s.id);bounded(s.createdAt,0,100000,'Invalid publish time');need(Number.isInteger(s.version)&&s.version>0,'Invalid version');const v=compile(t,s.design);need(v.valid,'Invalid archived layout');need(s.fingerprint===hash(key({design:s.design,geometry:v.course.pieces}))&&s.id===`W09.COURSE.${s.version}.${s.fingerprint}`,'Changed course fingerprint');need(key(s.course)===key({...v.course,id:s.id}),'Changed published course');need(s.name===s.design.name,'Course title differs from snapshot');max=Math.max(max,s.version);}
  need(Number.isInteger(t.next)&&t.next>max,'Invalid next course version');need(t.active===null||pub.has(t.active),'Missing active sheet');need(t.commission?.id==='W09.FOUNDRY.LAYOUT.1'&&t.commission.fee===24&&['offered','paid'].includes(t.commission.status),'Invalid layout commission');if(t.commission.status==='paid')need(pub.has(t.commission.courseId),'Missing commissioned layout');return true;
 }
 function dispatch(w,cmd,ops){const t=w.trackworks;need(t,'Trackworks not initialized');const by=id=>stock(t,id);
  switch(cmd.type){
   case 'trackBuy':{const s=by(cmd.id);need(s.owner==='shop','This physical section has already been purchased');need(ops.spendable(w)>=TYPES[s.type].price,'Not enough spendable cash');ops.transfer(w,'player','shop',TYPES[s.type].price,'Buy track section',s.id);s.owner='player';return s.id;}
   case 'trackAppend':{const s=by(cmd.id);need(s.owner==='player'&&!t.draft.sequence.some(a=>a.id===s.id),'Section is not free in this draft');need(t.draft.sequence.length<MAX,'Maximum 48 sections');remember(t);t.draft.sequence.push({id:s.id,turn:cmd.turn??1});validateDraft(t,t.draft);return s.id;}
   case 'trackReplace':{const s=by(cmd.id);need(s.owner==='player'&&!t.draft.sequence.some(a=>a.id===s.id),'Section is not available');need(Number.isInteger(cmd.index)&&t.draft.sequence[cmd.index],'Select a section to replace');remember(t);t.draft.sequence[cmd.index]={id:s.id,turn:cmd.turn??t.draft.sequence[cmd.index].turn};return s.id;}
   case 'trackRemove':{need(Number.isInteger(cmd.index)&&t.draft.sequence[cmd.index],'Select a section');remember(t);return t.draft.sequence.splice(cmd.index,1)[0].id;}
   case 'trackMove':{need(Number.isInteger(cmd.index)&&t.draft.sequence[cmd.index]&&(cmd.offset===1||cmd.offset===-1),'Select a valid move');const j=cmd.index+cmd.offset;need(j>=0&&j<t.draft.sequence.length,'Already at the edge');remember(t);[t.draft.sequence[cmd.index],t.draft.sequence[j]]=[t.draft.sequence[j],t.draft.sequence[cmd.index]];return j;}
   case 'trackFlip':{need(Number.isInteger(cmd.index)&&t.draft.sequence[cmd.index],'Select a turn');const a=t.draft.sequence[cmd.index];need(TYPES[by(a.id).type].curvature,'Only a curved section has a turn direction');remember(t);a.turn*=-1;return cmd.index;}
   case 'trackName':{text(cmd.name);need(Number.isInteger(cmd.laps)&&cmd.laps>=1&&cmd.laps<=6,'Choose one to six laps');if(cmd.name===t.draft.name&&cmd.laps===t.draft.laps)return false;remember(t);t.draft.name=cmd.name;t.draft.laps=cmd.laps;return true;}
   case 'trackUndo':{need(t.history.length,'No track edit to undo');t.draft=t.history.pop();return true;}
   case 'trackClear':{remember(t);t.draft.sequence=[];return true;}
   case 'trackLoad':{const p=t.published.find(p=>p.id===cmd.id);need(p,'Unknown layout');remember(t);t.draft=cp(p.design);return p.id;}
   case 'trackImport':{need(typeof cmd.text==='string'&&cmd.text.length<=50000,'Track plan too large');importPlan(t,JSON.parse(cmd.text));return true;}
   case 'trackPublish':{const r=compile(t);need(r.valid,r.errors[0]?.message);const p=t.published.find(p=>p.id===t.active);if(p&&key(p.design)===key(t.draft))return {id:p.id,unchanged:true};need(ops.spendable(w)>=2+ops.forecast(w,1).cashCost,'Need layout setup cost and care');ops.pay(w,2,'Assemble and inspect circuit');ops.step(w,1);return publish(t,w.tick);}
   case 'trackCommission':{const c=t.commission;need(c.status==='offered','This club commission has already been paid');const p=active(t),r=compile(t,p.design);need(p.design.sequence.length>=8&&p.design.sequence.length<=24&&r.counts.rise>=1&&r.counts.rail>=1&&r.counts.run>=2,'Commission needs 8–24 sections including a Brake Rise, Ribbed Rail Bend and two smooth Gutter Runs');need(ops.spendable(w)>=ops.forecast(w,2).cashCost,'Reserve two turns of care for setup work');need(w.accounts.sponsor>=c.fee,'Club sponsor budget exhausted');ops.transfer(w,'sponsor','services',c.fee,'Fund club circuit setup',c.id);ops.step(w,2);ops.transfer(w,'services','player',c.fee,'Complete club circuit setup',c.id);ops.settleCare(w);c.status='paid';c.courseId=p.id;p.commissioned=true;return {fee:c.fee,courseId:p.id};}
   default:throw Error('Unknown track operation');
  }
 }
 const api={TYPES,MAX,initial,compile,validate,validateDraft,publish,active,materialize,exportPlan,importPlan,dispatch,hash,samples,segDist};root.RRRCircuits=api;if(typeof module!=='undefined')module.exports=api;
})(typeof globalThis!=='undefined'?globalThis:this);
