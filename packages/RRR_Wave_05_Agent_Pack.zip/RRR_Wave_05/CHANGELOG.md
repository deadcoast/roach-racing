# Changelog

## Wave v0.5 — The Living Workbench

### Developed

Editable anatomical kit bench over real fixture identities; atomic fit/return with retained-native custody; root overlap and support checks; native tray drag, pointer root positioning, keyboard and button equivalents; fit-linked horn/grasp reach; optional tuning and finishes; exact-instance sheets and bounded imports; same-model freshly calculated races; immutable entry rendering; portable record export; cooperative worker fallback.

### Review repairs

- Kept the dragged source DOM element intact during native tray drag.
- Synchronized keyboard-selected root and inspector.
- Bounded the desktop workspace when expert controls expand; mobile uses vertical flow.
- Normalized tiny drive tray illustrations and removed duplicated visible native hind legs under replacement Hoppers.
- Named and retained native exchange units instead of implying tissue reappears when a graft returns to the tray.
- Kept asynchronous computation state independent of whether a Worker is available.
- Matched source fixture identifiers and included the original Wave 03 specification required by its unchanged regression suite.
- Corrected a generated refinement reference before final specification validation.

### Evidence

Six Python/browser port comparisons; new pure-model and transaction tests; unchanged Wave 03/04 regressions; actual browser controls, drag/drop, file input/export, rejection behavior and fallback computation; manually inspected desktop and narrow layouts. Reports state their exact scope.

### Not closed

World-scale economy, breeding and capture runtime, joined world clock, full removal/storage biology, supported multi-drive anatomy, sustained flight, human playtest and native-platform assurance. Source reference data remain unchanged; new values and mechanics remain revisable proposals.
