{
  "manifest": {
    "id": "W04",
    "version": "0.4.0",
    "title": "RRR — Racing Makes the Hobby Move",
    "date": "2026-09-09",
    "status": "revisable_foundation_with_path_race_experiments",
    "extends": "RRR_World_Context_v0.3.json",
    "base_sha256": "e6701075f606fbc0eb8f85f258358c6d2ad0cd6119ed5d16a2ee7e60e8137243",
    "serialization": "Strict JSON .spec; preserves the prior RRR exchange structure, not a claim of canonical MIVIM syntax."
  },
  "Reference": {
    "baseline_files": [
      "RRR_Wave_03.spec",
      "RRR_World_Context_v0.3.json",
      "RRR_Wave_03_TODO.md"
    ],
    "sources": [
      {
        "id": "W04.S01",
        "title": "Tamiya Mini 4WD Setup Guide",
        "url": "https://www.tamiya.com/english/mini4wd/setupguide/setupguide.htm",
        "checked_on": "2026-09-09",
        "scope": "Distinct motor, ratio, contact, braking and landing tuning.",
        "limits": "Walking-animal and contact operators are fictional RRR design."
      },
      {
        "id": "W04.S02",
        "title": "Tamiya Official Mini 4WD Race Regulations",
        "url": "https://www.tamiya.com/english/mini4wd/regulation.htm",
        "checked_on": "2026-09-09",
        "scope": "Assembly, inspection, starts, finish ordering and course recognition.",
        "limits": "Brand, geometry and damage restrictions are not imported into Open."
      },
      {
        "id": "W04.S03",
        "title": "SEGA Gaiden — Pocket Circuit",
        "url": "https://ryu-ga-gotoku.com/gaiden/asia_en/adventure/",
        "checked_on": "2026-09-09",
        "scope": "A local social venue, parts acquisition, Time Attack and rivals.",
        "limits": "Does not establish breeding, ecology or the RRR market."
      },
      {
        "id": "W04.S04",
        "title": "Tamiya circuit extension set 69579",
        "url": "https://www.tamiya.com/english/products/69579/index.html",
        "checked_on": "2026-09-09",
        "scope": "Interchangeable lane-change, straight, wave and separate curve sections.",
        "limits": "RRR path geometry and continuous shared racing are authored extensions."
      },
      {
        "id": "W04.S05",
        "title": "Tamiya local event organizer support",
        "url": "https://www.tamiya.com/japan/mini4wd/localevents",
        "checked_on": "2026-09-09",
        "scope": "Circuit loans, organizer guidance, layout resources and event publicity.",
        "limits": "Does not prescribe RRR event costs or social rules."
      },
      {
        "id": "W04.S06",
        "title": "Tamiya Brake Sponge Set 15441",
        "url": "https://www.tamiya.com/english/products/15441/index.html",
        "checked_on": "2026-09-09",
        "scope": "Material variants affect jump approach braking.",
        "limits": "Does not validate fictional active-jump mechanics."
      }
    ],
    "findings": [
      {
        "id": "W04.GAP.01",
        "finding": "Component benches did not produce a course finish.",
        "repair": "An integrated path-space race consumes installed identities and inherited hopper properties."
      },
      {
        "id": "W04.GAP.02",
        "finding": "A completed race was not attached to a funded meeting or subsequent demand.",
        "repair": "Register snapshot, settle purse, publish limited card, then reserve a customer-funded trial."
      },
      {
        "id": "W04.GAP.03",
        "finding": "World roles were descriptions without sufficiently specific material exchanges.",
        "repair": "Six service contracts and eight donor-to-customer threads specify exchanges and decisions."
      },
      {
        "id": "W04.GAP.04",
        "finding": "Passing intent could oscillate or settle on a line no longer clearing the rival.",
        "repair": "Retain the target and side, update clearance, recenter only after completing the maneuver."
      },
      {
        "id": "W04.GAP.05",
        "finding": "Action energy could bypass the same delivery limit used for locomotion.",
        "repair": "Charge action stores from shared delivery before release; discard spent commitments on misses/cancellation."
      },
      {
        "id": "W04.GAP.06",
        "finding": "Registered build snapshots initially referenced mutable result objects.",
        "repair": "Copy the snapshot at registration and verify its content hash; this is integrity checking, not cryptographic authenticity."
      }
    ],
    "preserved": [
      "speed and winning",
      "personally assembled kits",
      "collection and showing off",
      "anyone can catch and breed",
      "whole-insect Wrangloid trade",
      "genuine superior stock",
      "optional professions and expert depth",
      "Open equipment freedom",
      "Flyers with Flyers",
      "no new global racer permadeath",
      "Locals-Regionals-Factionals-New World City"
    ]
  },
  "Plan": {
    "tasks": [
      {
        "id": "W04.T01",
        "title": "Assembled component identities on a modular-course race",
        "priority": "P0",
        "depends_on": [
          "W03.T07",
          "W03.T06"
        ],
        "spec_status": "developed",
        "runtime_status": "bounded_path_race_model_executed",
        "acceptance_state": "partial: no editable assembly or finished game physics",
        "artifacts": [
          "model/race.py",
          "model/fixtures.py",
          "Race_Observatory.html"
        ]
      },
      {
        "id": "W04.T02",
        "title": "Repeated production and livelihood affordability",
        "priority": "P0",
        "depends_on": [
          "W03.T04",
          "W03.T05"
        ],
        "spec_status": "extended through race demand and funded meetings",
        "runtime_status": "one event and trial-order settlement; not repeated economy",
        "acceptance_state": "open",
        "artifacts": [
          "model/hobby.py"
        ]
      },
      {
        "id": "W04.T03",
        "title": "Life-stage, removal and storage expansion",
        "priority": "P1",
        "depends_on": [
          "W03.T03",
          "W03.T06"
        ],
        "spec_status": "stage-specific market dependencies specified",
        "runtime_status": "not implemented in this wave",
        "acceptance_state": "open",
        "artifacts": []
      },
      {
        "id": "W04.T04",
        "title": "Render intake, brood and kit interactions",
        "priority": "P1",
        "depends_on": [
          "W03.T08"
        ],
        "spec_status": "race/replay presentation developed alongside earlier requirements",
        "runtime_status": "replay viewer only; intake/brood/editable bench remain open",
        "acceptance_state": "partial",
        "artifacts": [
          "Race_Observatory.html"
        ]
      },
      {
        "id": "W04.T05",
        "title": "Intertwine club, result, supply, field and breeder systems",
        "priority": "P0",
        "depends_on": [
          "W04.T01"
        ],
        "spec_status": "developed with eight operational demand threads and six services",
        "runtime_status": "bounded result-to-funded-trial witness; autonomous NPCs unimplemented",
        "acceptance_state": "specification delivered; broad runtime open",
        "artifacts": [
          "model/hobby.py"
        ]
      },
      {
        "id": "W04.T06",
        "title": "Adversarial checks, baseline preservation and MIVIM closeout",
        "priority": "P0",
        "depends_on": [
          "W04.T01",
          "W04.T05"
        ],
        "spec_status": "developed",
        "runtime_status": "tests and replay surface checks",
        "acceptance_state": "scoped review only",
        "artifacts": [
          "validate_wave04.py",
          "MIVIM_Review_v0.4.md"
        ]
      }
    ],
    "next_queue": [
      {
        "id": "W04.T01.RUNTIME",
        "priority": "P0",
        "task": "Editable kit-bench slice feeding these same race snapshots",
        "requires": "Physically fitted owned stock; visible donor signatures; novice and expert control; same inherited measurements; playtest finish/readability separately."
      },
      {
        "id": "W04.T02",
        "priority": "P0",
        "task": "Repeated customer/production seasons and common-stock livelihood affordability",
        "requires": "At least several uncertain cohorts, upkeep, household/workshop cost, real replenishment and competing customers; compare buying/catching/breeding routes."
      },
      {
        "id": "W04.T03",
        "priority": "P1",
        "task": "One complete Clockleaf or pond lifecycle plus viable removal/storage",
        "requires": "Target stage, replacement parents, transport, growth and decay; no surprise global host permadeath."
      },
      {
        "id": "W04.T04",
        "priority": "P1",
        "task": "Complete rendered intake and brood interactions on shared state",
        "requires": "Useful batch decisions, no hidden-truth leak, inspectable protections and care commitments, polished creature-centered presentation."
      }
    ]
  },
  "Workflow": {
    "executed": [
      "baseline read",
      "primary-source verification",
      "ordered race task continued",
      "modular motion and same-stock binding",
      "hobby exchange and demand-thread development",
      "regression and adversarial repair",
      "replay surface review",
      "scoped handoff"
    ],
    "decision_mode": "grouped work; no per-rule approval stops",
    "completion_semantics": [
      "specified != implemented",
      "path-model race != calibrated game physics",
      "replay viewer != editable game",
      "one funded event != sustainable economy"
    ]
  },
  "Adherence": {
    "hard_constraints": [
      "Quality and novel-development adherence are non-compensable guardrails.",
      "Every feature connects a user decision with physical stock, performance or a livelihood consequence.",
      "Supporting work is not credited as delivered innovation.",
      "No stories or generic exposition replace atomic foundations.",
      "No inherited Wave 02 null becomes global fact through a toy fixture."
    ],
    "authority_change": "No new author canon; generated proposals remain revisable. Prior context is preserved.",
    "exclusions": [
      "No universal Graft Point cap",
      "No weaponless-only starting requirement",
      "No retirement/permadeath policy inferred from the model",
      "No obligatory breeder profession",
      "No fastest-roach dismissal",
      "No decorative rarity-to-power conversion"
    ]
  },
  "MIVIM": {
    "criteria_source": "Recovered project definitions carried forward from Wave 03",
    "eligibility": "quality_at_declared_scope AND novel_development_adherence_at_declared_scope",
    "numeric_score": null,
    "numeric_score_reason": "No authorized numeric weights or grade bands.",
    "contribution_scope": "World-system integration and bounded executable race experiments, with a replay review surface.",
    "novel_objective": "One specimen history connects selection, fitted behavior, visible racing and credible commercial opportunities.",
    "comparator": "Disconnected rarity loot, automatic best-parent offspring, generic race power scores and coin-producing tanks.",
    "findings": {
      "quality": "reviewed at specification/experiment scope; finished game quality unestablished",
      "novel_development_adherence": "project-specific connected mechanisms developed; worldwide originality not claimed",
      "effectiveness": "specific race and funded-transaction behaviors tested, not retention",
      "creativity": "concrete integration and presentation candidate; player-perceived distinctiveness untested",
      "scaling_potential": "identity-preserving batching and serialized outcomes support extension; no large-world benchmark"
    },
    "supporting_work": "Validators and hashes protect the contribution; test counts do not grade innovation."
  },
  "systems": [
    {
      "id": "W04.SYSTEM.BIND",
      "title": "The same specimen becomes the racing part",
      "origin": "source_hobby_translation",
      "refines": [
        "W03.TRACE.02",
        "W03.PERFORMANCE.08"
      ],
      "rules": [
        {
          "id": "W04.BIND.01",
          "statement": "Compile a racer from one host, actual installed component identities, native anatomy, preparation and a saved setup.",
          "decision": "Fit parts, then enter that configuration.",
          "observable": "Purchase alone does not change racing performance.",
          "maturity": "spec_developed"
        },
        {
          "id": "W04.BIND.02",
          "statement": "An acquired part only changes a build after installation; acquisition history grants no hidden multiplier.",
          "decision": "Buy, catch or breed a useful donor.",
          "observable": "Equivalent finished anatomy performs equivalently under equal conditions.",
          "maturity": "spec_developed"
        },
        {
          "id": "W04.BIND.03",
          "statement": "A drive contributes cadence and useful force; leverage changes their delivery rather than adding a second motor.",
          "decision": "Choose drive stock and hip geometry separately.",
          "observable": "Acceleration and sustained pace change through the named variables.",
          "maturity": "spec_developed"
        },
        {
          "id": "W04.BIND.04",
          "statement": "A hopper contributes inherited return, phase and settling; preload and alignment remain builder choices.",
          "decision": "Breed a better pair or remount the existing pair.",
          "observable": "The comparison identifies which layer changed.",
          "maturity": "spec_developed"
        },
        {
          "id": "W04.BIND.05",
          "statement": "A multi-role graft contributes mass, tissue and capability once.",
          "decision": "Keep a whole package or separate its subcomponents.",
          "observable": "A hopper can serve jump and suspension roles without two free assemblies.",
          "maturity": "spec_developed"
        },
        {
          "id": "W04.BIND.06",
          "statement": "Race entry captures an immutable build snapshot and model/rules/course versions.",
          "decision": "Commit the intended setup before the start.",
          "observable": "Later edits do not alter an old win, trophy or provenance claim.",
          "maturity": "spec_developed"
        },
        {
          "id": "W04.BIND.07",
          "statement": "Normalized values remain local test profiles; absolute creature scale is not established by the solver.",
          "decision": "Calibrate scale separately.",
          "observable": "No normalized time is advertised as real seconds or a retail product guarantee.",
          "maturity": "spec_developed"
        }
      ]
    },
    {
      "id": "W04.SYSTEM.BENCH",
      "title": "Club benches, borrowing and personal assembly",
      "origin": "source_hobby_translation",
      "refines": [
        "W03.CUSTODY.07",
        "W03.POLISH.08"
      ],
      "rules": [
        {
          "id": "W04.BENCH.01",
          "statement": "A club bench supplies tools, fixtures, space and advice, not an exclusive right to modify a roach.",
          "decision": "Use home facilities, a club bay or a paid fitting service.",
          "observable": "Casual access and expert ownership coexist.",
          "maturity": "spec_developed"
        },
        {
          "id": "W04.BENCH.02",
          "statement": "A test loan changes custody of a particular component for an agreed session.",
          "decision": "Try a motor-equivalent before buying.",
          "observable": "One component cannot be on the shop display and two test racers simultaneously.",
          "maturity": "spec_developed"
        },
        {
          "id": "W04.BENCH.03",
          "statement": "A comparison ticket identifies fixed conditions, changed components and intended measurements.",
          "decision": "Compare a drive replacement or a preload change.",
          "observable": "An observed result is attributable to a stated experiment, not a universal best-build score.",
          "maturity": "spec_developed"
        },
        {
          "id": "W04.BENCH.04",
          "statement": "Guided kit assembly shows the actual parts, placement and incorporation; advanced adjustment remains on the same objects.",
          "decision": "Assemble the tin or modify its recipe.",
          "observable": "The beginner still builds their own racer.",
          "maturity": "spec_developed"
        },
        {
          "id": "W04.BENCH.05",
          "statement": "A failed fitting previews blocked motion, inadequate support or an event conflict separately.",
          "decision": "Move the graft, alter support or select an eligible event.",
          "observable": "No universal one-brow-slot rule returns.",
          "maturity": "spec_developed"
        },
        {
          "id": "W04.BENCH.06",
          "statement": "A fitting commission states desired outcome, supplied stock, labor, testing and revision terms.",
          "decision": "Earn money through assembly expertise.",
          "observable": "Professional work can improve execution without secretly improving donor genetics.",
          "maturity": "spec_developed"
        },
        {
          "id": "W04.BENCH.07",
          "statement": "A loan return or service completion records actual condition; new loss rules cannot be introduced retroactively.",
          "decision": "Accept known terms before handing over valued stock.",
          "observable": "Service income does not depend on surprise confiscation or mandatory permadeath.",
          "maturity": "spec_developed"
        }
      ]
    },
    {
      "id": "W04.SYSTEM.TRACK",
      "title": "Modular courses that support a modular hobby",
      "origin": "source_hobby_translation",
      "refines": [
        "W03.REVISION.05"
      ],
      "rules": [
        {
          "id": "W04.TRACK.01",
          "statement": "A section defines inlet and outlet pose, width, surface, usable paths, supports and active clearance.",
          "decision": "Assemble valid connected pieces.",
          "observable": "A track is both geometry and ordered travel, not a bag of section names.",
          "maturity": "spec_developed"
        },
        {
          "id": "W04.TRACK.02",
          "statement": "An installed course uses owned or borrowed section instances and a separate layout recipe.",
          "decision": "Pool, hire, buy or rearrange track pieces.",
          "observable": "A plan does not spawn the physical course.",
          "maturity": "spec_developed"
        },
        {
          "id": "W04.TRACK.03",
          "statement": "Passing space is authored as track geometry; guided and shared sections are both valid formats.",
          "decision": "Build a technical channel or a broad pack circuit.",
          "observable": "Contact opportunities follow the actual layout.",
          "maturity": "spec_developed"
        },
        {
          "id": "W04.TRACK.04",
          "statement": "Alternative routes declare their entry, exit, required gates and locomotion conditions.",
          "decision": "Choose a legitimate jump or climbing route.",
          "observable": "Route freedom does not silently skip mandatory course progress.",
          "maturity": "spec_developed"
        },
        {
          "id": "W04.TRACK.05",
          "statement": "Inside and outside paths have different physical distances when geometry makes them different.",
          "decision": "Take an inside line or a clear outside pass.",
          "observable": "Lateral position affects both distance and maneuvering; no artificial equal-distance assumption.",
          "maturity": "spec_developed"
        },
        {
          "id": "W04.TRACK.06",
          "statement": "A repeated qualifying format can rotate start assignments; a single experimental grid is not proof of competitive fairness.",
          "decision": "Choose published heat and seeding procedures.",
          "observable": "Grid advantage is assessed instead of hidden.",
          "maturity": "spec_developed"
        },
        {
          "id": "W04.TRACK.07",
          "statement": "Surface wear and cleaning change declared contact conditions only when that system is present.",
          "decision": "Maintain a venue or prepare suitable feet.",
          "observable": "The course does not receive arbitrary invisible difficulty multipliers.",
          "maturity": "spec_developed"
        },
        {
          "id": "W04.TRACK.08",
          "statement": "A layout revision creates a new record category while retaining historic times under their original layout.",
          "decision": "Modify a famous circuit and set new records.",
          "observable": "An old champion is not retroactively disqualified by a later rebuild.",
          "maturity": "spec_developed"
        }
      ]
    },
    {
      "id": "W04.SYSTEM.RACE",
      "title": "Pace, passing, contact and the finish",
      "origin": "source_hobby_translation_and_rrr_extension",
      "refines": [
        "W03.PERFORMANCE.01",
        "W03.PERFORMANCE.05",
        "W03.PERFORMANCE.08"
      ],
      "rules": [
        {
          "id": "W04.RACE.01",
          "statement": "Running output uses loaded drive, energy delivery, traction, body mass and leverage.",
          "decision": "Improve the desired mechanical contribution.",
          "observable": "Pace emerges from motion integration rather than a hidden race-power score.",
          "maturity": "spec_developed"
        },
        {
          "id": "W04.RACE.02",
          "statement": "A passing maneuver identifies available space, commits to a side and recenters after clearance.",
          "decision": "Attempt a pass rather than repeatedly steering toward and away from the same rival.",
          "observable": "The racer follows through on an observable overtaking attempt.",
          "maturity": "spec_developed"
        },
        {
          "id": "W04.RACE.03",
          "statement": "Hopper loading and locomotion share current reserve and delivery; released energy is not spent twice.",
          "decision": "Choose preload and timing.",
          "observable": "An active maneuver has a real resource cost before its benefit.",
          "maturity": "spec_developed"
        },
        {
          "id": "W04.RACE.04",
          "statement": "A jump uses inherited tissue and setup to determine useful energy, trajectory and recovery.",
          "decision": "Change the donor, preload, alignment or route.",
          "observable": "A better spring is not a guaranteed pass at every speed or clearance.",
          "maturity": "spec_developed"
        },
        {
          "id": "W04.RACE.05",
          "statement": "A horn attack requires reachable aligned contact after wind-up; a miss consumes the declared commitment.",
          "decision": "Build and use a useful ram geometry.",
          "observable": "No remote damage is awarded from an attack rating.",
          "maturity": "spec_developed"
        },
        {
          "id": "W04.RACE.06",
          "statement": "A grasping response has closure delay, reach, hold and recovery; holding can impede both racers.",
          "decision": "Intercept a committed rival or release to resume racing.",
          "observable": "Claws create a racing decision rather than a permanent disable.",
          "maturity": "spec_developed"
        },
        {
          "id": "W04.RACE.07",
          "statement": "Native contact and dedicated weapons are different capabilities; Speedsters permits the former and excludes the latter.",
          "decision": "Select the intended division.",
          "observable": "Weapon legality is not decided by cosmetic naming.",
          "maturity": "spec_developed"
        },
        {
          "id": "W04.RACE.08",
          "statement": "Recovery states preserve course location and elapsed time.",
          "decision": "Regain motion through existing anatomy or supported intervention.",
          "observable": "Falling behind is a racing consequence; the game does not silently reset position.",
          "maturity": "spec_developed"
        },
        {
          "id": "W04.RACE.09",
          "statement": "Finish classification requires the full ordered course; ties and nonfinishers have declared handling.",
          "decision": "Complete the race.",
          "observable": "Neither damage count nor a bench result grants victory.",
          "maturity": "spec_developed"
        },
        {
          "id": "W04.RACE.10",
          "statement": "The simulation reads inherited internal properties; public advice and commercial claims read only acquired evidence.",
          "decision": "Observe, test and disclose selectively.",
          "observable": "Mechanical correctness does not create an omniscient shopping interface.",
          "maturity": "spec_developed"
        }
      ]
    },
    {
      "id": "W04.SYSTEM.MEET",
      "title": "The event is a funded operation",
      "origin": "source_hobby_translation",
      "refines": [
        "W03.CASH.09",
        "W02.RACE.08"
      ],
      "rules": [
        {
          "id": "W04.MEET.01",
          "statement": "A meeting names venue, layout, locomotion, equipment policy, format, entry conditions and qualification consequences independently.",
          "decision": "Enter an appropriate local race or qualifier.",
          "observable": "Open is build freedom; local participation is not automatic World City admission.",
          "maturity": "spec_developed"
        },
        {
          "id": "W04.MEET.02",
          "statement": "A practice run can award a local record or rival acknowledgement without creating a cash prize.",
          "decision": "Practice freely or enter a funded event.",
          "observable": "Replay and practice do not print tournament money.",
          "maturity": "spec_developed"
        },
        {
          "id": "W04.MEET.03",
          "statement": "Prize commitments name entry receipts, sponsor funds, club funds or other declared backing.",
          "decision": "Host an event at a sustainable size.",
          "observable": "Prize money is transferred once from an identifiable budget.",
          "maturity": "spec_developed"
        },
        {
          "id": "W04.MEET.04",
          "statement": "Tied placements share the affected prize allocation under published terms.",
          "decision": "Resolve a dead heat.",
          "observable": "An identifier or iteration order does not select the richer winner.",
          "maturity": "spec_developed"
        },
        {
          "id": "W04.MEET.05",
          "statement": "Operational payments fund actual hosting activities separately from race prizes.",
          "decision": "Provide timing, track setup, staffing or facility services.",
          "observable": "Trackmakers and hosts can earn a keep without winning races.",
          "maturity": "spec_developed"
        },
        {
          "id": "W04.MEET.06",
          "statement": "A sanctioned result stores the named host, build snapshot, finish and course.",
          "decision": "Keep a trophy, publish a record or enter the next qualifier.",
          "observable": "A racer retains a career across equipment changes.",
          "maturity": "spec_developed"
        },
        {
          "id": "W04.MEET.07",
          "statement": "Replays, photographs and subsequent comparisons reference the original result without recommitting its transactions.",
          "decision": "Revisit a race or share its build.",
          "observable": "Watching a win twice does not pay twice.",
          "maturity": "spec_developed"
        },
        {
          "id": "W04.MEET.08",
          "statement": "A race winner is not automatically a genetically certified breeding line.",
          "decision": "Celebrate the win and offer an appropriately qualified claim.",
          "observable": "Prestige can generate attention without fabricating inherited guarantees.",
          "maturity": "spec_developed"
        }
      ]
    },
    {
      "id": "W04.SYSTEM.DEMAND",
      "title": "Race attention becomes specific hobby demand",
      "origin": "rrr_native_world_integration",
      "refines": [
        "W03.CASH.01",
        "W03.BREED.07"
      ],
      "rules": [
        {
          "id": "W04.DEMAND.01",
          "statement": "A viewer notices a visible performance or appearance; an inquiry precedes a purchase unless a standing agreement already exists.",
          "decision": "Demonstrate, advertise or decline to disclose.",
          "observable": "Publicity is an opportunity, not instant sale revenue.",
          "maturity": "spec_developed"
        },
        {
          "id": "W04.DEMAND.02",
          "statement": "A trial order states the useful component, observable acceptance criteria and funded quantity.",
          "decision": "Sell a small credible batch before promising a major run.",
          "observable": "The buyer purchases a specified assembly, not a promise that every child wins.",
          "maturity": "spec_developed"
        },
        {
          "id": "W04.DEMAND.03",
          "statement": "A buyer pays for performance, fit, consistency, availability, appearance or provenance according to its purpose.",
          "decision": "Choose the appropriate market for retained and surplus stock.",
          "observable": "Different customers can value the same cohort differently.",
          "maturity": "spec_developed"
        },
        {
          "id": "W04.DEMAND.04",
          "statement": "Funded inquiries compete for actual supply and production capacity; growing young remain future inventory.",
          "decision": "Allocate stock among personal builds, founders, ordinary sales and commissions.",
          "observable": "Commercial success creates meaningful allocation choices.",
          "maturity": "spec_developed"
        },
        {
          "id": "W04.DEMAND.05",
          "statement": "Consignment retains the consignor identity until a real sale; fees and custody are explicit.",
          "decision": "Use a shop to reach customers without selling outright.",
          "observable": "Shelf price and shop possession do not become realized seller income.",
          "maturity": "spec_developed"
        },
        {
          "id": "W04.DEMAND.06",
          "statement": "Recurring demand depends on customer activity and budgets outside the breeding tank.",
          "decision": "Serve kit buyers, collectors, racers, clubs and traders.",
          "observable": "No rule assumes that fresh animals are needed only because every race destroys them.",
          "maturity": "spec_developed"
        },
        {
          "id": "W04.DEMAND.07",
          "statement": "Ordinary paid services and common-stock buyers remain accessible recovery routes.",
          "decision": "Earn modest income after a failed ambitious project.",
          "observable": "A major race loss need not force a second career or wipe the workshop.",
          "maturity": "spec_developed"
        },
        {
          "id": "W04.DEMAND.08",
          "statement": "A broader economy may aggregate ordinary household spending, but its replenishment must be declared and bounded.",
          "decision": "Scale the world without simulating every citizen at full fidelity.",
          "observable": "Aggregate customers still have accountable expenditure rather than infinite wallets.",
          "maturity": "spec_developed"
        }
      ]
    },
    {
      "id": "W04.SYSTEM.FIELD",
      "title": "Performance questions lead back into the wildlands",
      "origin": "rrr_native_world_integration",
      "refines": [
        "W03.INTAKE.02",
        "W02.FIELD.14"
      ],
      "rules": [
        {
          "id": "W04.FIELD.01",
          "statement": "Race symptoms identify candidate explanations, not unique hidden genetic diagnoses.",
          "decision": "Check fuel, condition, setup and comparable assays before replacing a lineage.",
          "observable": "Late fading does not automatically mean poor inherited endurance.",
          "maturity": "spec_developed"
        },
        {
          "id": "W04.FIELD.02",
          "statement": "A targeted run links the missing contribution to a donor, stage, habitat and inspectable sign.",
          "decision": "Pursue loaded cadence, release timing, wing integrity or a particular appearance.",
          "observable": "The trip has a stated use without guaranteed rarity.",
          "maturity": "spec_developed"
        },
        {
          "id": "W04.FIELD.03",
          "statement": "A currently useful founder can be an ordinary performer that supplies the missing inherited complement.",
          "decision": "Retain synchronized hoppers for a high-return line.",
          "observable": "Field selection uses the current project, not only the finished-product cutoff.",
          "maturity": "spec_developed"
        },
        {
          "id": "W04.FIELD.04",
          "statement": "The same route can supply several disjoint customer needs and personal interests.",
          "decision": "Return with common pads, selected arms or attractive moths.",
          "observable": "Unwanted for one racer does not mean worthless to every customer.",
          "maturity": "spec_developed"
        },
        {
          "id": "W04.FIELD.05",
          "statement": "Published demand changes which traits a catcher seeks, not which genes already captured animals possess.",
          "decision": "Revisit known habitats for previously ignored characteristics.",
          "observable": "A new race trend cannot reroll existing specimens.",
          "maturity": "spec_developed"
        },
        {
          "id": "W04.FIELD.06",
          "statement": "Population recovery, stage changes and travel use world time; entering a screen is not a new cohort.",
          "decision": "Choose another route, breed, trade or wait under the declared clock.",
          "observable": "Rare searching remains an activity rather than a reload exploit.",
          "maturity": "spec_developed"
        }
      ]
    },
    {
      "id": "W04.SYSTEM.STOCK",
      "title": "Breeding, stage timing and race-season commitments",
      "origin": "rrr_native_world_integration",
      "refines": [
        "W03.CAPACITY.01",
        "W03.BREED.07"
      ],
      "rules": [
        {
          "id": "W04.STOCK.01",
          "statement": "A seasonal supply plan schedules brood, target stage, preparation, transport and receipt against an event or customer date.",
          "decision": "Choose which project can mature in time.",
          "observable": "A useful specimen arriving after the final is a different commercial proposition.",
          "maturity": "spec_developed"
        },
        {
          "id": "W04.STOCK.02",
          "statement": "Ordinary intermediary output and retained replacements can support a premium project simultaneously.",
          "decision": "Sell useful stock while continuing selective work.",
          "observable": "Selection need not wait for a perfect genotype before earning anything.",
          "maturity": "spec_developed"
        },
        {
          "id": "W04.STOCK.03",
          "statement": "Stage-specific products use an actual developmental window, not a generic adult rarity upgrade.",
          "decision": "Produce Clockleaf couplings at the useful stage while retaining reproductive adults.",
          "observable": "An adult-only enclosure cannot supply every stage on demand.",
          "maturity": "spec_developed"
        },
        {
          "id": "W04.STOCK.04",
          "statement": "Preparation and storage windows remain product-specific; frozen future output cannot be sold as ready stock.",
          "decision": "Prepare near delivery or pay for supported preservation.",
          "observable": "Storage services change scheduling, not inherited quality.",
          "maturity": "spec_developed"
        },
        {
          "id": "W04.STOCK.05",
          "statement": "A line claim includes tested offspring, brood identities, protocol and date.",
          "decision": "Sell reliability backed by observed batches.",
          "observable": "One famous installed pair does not certify every descendant.",
          "maturity": "spec_developed"
        },
        {
          "id": "W04.STOCK.06",
          "statement": "Race attendance advances the same broader world obligations when the clocks are integrated.",
          "decision": "Arrange care before a circuit trip.",
          "observable": "The later runtime must advance production and upkeep together; the present race witness does not yet do so.",
          "maturity": "spec_developed"
        }
      ]
    },
    {
      "id": "W04.SYSTEM.PEOPLE",
      "title": "Clubs, Wrangloids and rivals share the same world",
      "origin": "rrr_native_world_integration",
      "refines": [
        "W03.TRACE.06"
      ],
      "rules": [
        {
          "id": "W04.PEOPLE.01",
          "statement": "Wrangloids combine finding, breeding, trading and expertise in different proportions; their profession is not an exclusive permission.",
          "decision": "Become a supplier, customer, breeder or some combination.",
          "observable": "Every person can attempt the underlying hobby activities.",
          "maturity": "spec_developed"
        },
        {
          "id": "W04.PEOPLE.02",
          "statement": "An NPC racer has owned stock, available money, knowledge, preferred activities and an event schedule.",
          "decision": "Compete, trade, lend, teach or commission work.",
          "observable": "A rival does not conjure a perfect counterbuild from private player data.",
          "maturity": "spec_developed"
        },
        {
          "id": "W04.PEOPLE.03",
          "statement": "NPC changes follow their observations and available opportunities, including shop stock and public build cards.",
          "decision": "Demonstrate an idea or keep parts undisclosed.",
          "observable": "The competitive scene can adapt without omniscience.",
          "maturity": "spec_developed"
        },
        {
          "id": "W04.PEOPLE.04",
          "statement": "Club participation can provide shared tools, borrowed sections, introductions and practice partners.",
          "decision": "Join for material and social benefits rather than a hidden stat aura.",
          "observable": "A club matters even to a collector who does not campaign for the Derby.",
          "maturity": "spec_developed"
        },
        {
          "id": "W04.PEOPLE.05",
          "statement": "Faction support differs through facilities, funded programs, supply contacts and representative selection.",
          "decision": "Choose affiliations and opportunities.",
          "observable": "Faction identity is not reduced to a palette swap or a universally superior gene.",
          "maturity": "spec_developed"
        },
        {
          "id": "W04.PEOPLE.06",
          "statement": "Collectors, finishers, kit authors and track builders receive distinct credit.",
          "decision": "Show a beautiful animal, sell a signature tin or host a remarkable layout.",
          "observable": "Recognition is not exclusively awarded to the current fastest racer.",
          "maturity": "spec_developed"
        },
        {
          "id": "W04.PEOPLE.07",
          "statement": "Advice, sale reputation, competition standing and lineage evidence are independent records.",
          "decision": "Trust a reliable seller without assuming they are the best racer.",
          "observable": "One popularity scalar does not replace every relationship.",
          "maturity": "spec_developed"
        }
      ]
    },
    {
      "id": "W04.SYSTEM.PRESENT",
      "title": "Visible changes, useful records and optional depth",
      "origin": "rrr_native_execution",
      "refines": [
        "W03.POLISH.06",
        "W03.POLISH.07"
      ],
      "rules": [
        {
          "id": "W04.PRESENT.01",
          "statement": "Primary race presentation shows position, direction, major actions, remaining distance and the finish.",
          "decision": "Watch the race as a sporting event.",
          "observable": "Diagnostic detail does not displace excitement and readable competition.",
          "maturity": "spec_developed"
        },
        {
          "id": "W04.PRESENT.02",
          "statement": "A visible module signature accompanies its action: horn commitment, folding grasp, loaded hind limbs and landing compression.",
          "decision": "Recognize the graft personally fitted.",
          "observable": "The roach is not rendered as an identical marker with different stat text.",
          "maturity": "spec_developed"
        },
        {
          "id": "W04.PRESENT.03",
          "statement": "A result card shows placing and time first, followed by the actual build and optional component evidence.",
          "decision": "Celebrate, compare or publish.",
          "observable": "The victory is not reframed as merely solving a track.",
          "maturity": "spec_developed"
        },
        {
          "id": "W04.PRESENT.04",
          "statement": "Public build cards can disclose component identity without revealing hidden genes or unmeasured values.",
          "decision": "Show off or keep a preparation detail private.",
          "observable": "A photograph is not an omniscient assay.",
          "maturity": "spec_developed"
        },
        {
          "id": "W04.PRESENT.05",
          "statement": "A replay inspector links each major action to the fitted component and relevant preparation.",
          "decision": "Inspect a pass or failed jump after watching it.",
          "observable": "The evidence remains attached to the same asset rather than an unrelated tutorial page.",
          "maturity": "spec_developed"
        },
        {
          "id": "W04.PRESENT.06",
          "statement": "Replay controls do not mutate the underlying outcome, inventory, world clock or purse.",
          "decision": "Scrub, pause and switch experiments.",
          "observable": "Presentation does not rerun a payable event.",
          "maturity": "spec_developed"
        },
        {
          "id": "W04.PRESENT.07",
          "statement": "The delivered browser surface is an experimental replay viewer, not the editable kit bench or finished game.",
          "decision": "Review the visible mechanism at its actual scope.",
          "observable": "Unimplemented assembly and simulation controls are not represented by dead buttons.",
          "maturity": "spec_developed"
        }
      ]
    }
  ],
  "operational_threads": [
    {
      "id": "W04.THREAD.PACE",
      "name": "Cadence that survives a real load",
      "origin": "PCR motor selection",
      "trigger": "A build consistently accelerates more slowly under a matched load.",
      "next_evidence": "Compare fuel delivery, mass and leverage before interpreting the drive assay.",
      "donor_id": "W02.DONOR.CICADA",
      "where": "Cooling-kiln run; rooted pipe galleries.",
      "selection": "Loaded cadence and usable force, not loudness.",
      "breeding_objective": "Combine useful cadence with efficient output; retain productive founders.",
      "facility_id": "W02.FAC.FLIGHT",
      "output": "Cicada Redline",
      "customer": "Club racers and coordinated kit authors.",
      "world_consequence": "Component upgrade demand supports adult stock sales and complete nursery investments.",
      "limit": "Race-model drive identity is implemented; cicada genetics are not."
    },
    {
      "id": "W04.THREAD.HOP",
      "name": "A hopper line worth repeating",
      "origin": "PCR landing control plus RRR active jumping",
      "trigger": "A clean overtake succeeds, or landing recovery loses the gained position.",
      "next_evidence": "Separate launch preload, alignment and inherited phase/settling measurements.",
      "donor_id": "W02.DONOR.HOPPER",
      "where": "Switchyard embankments and sleeper edges.",
      "selection": "The missing synchronization or settling contribution, including ordinary-return candidates.",
      "breeding_objective": "Build a joint return/synchrony/settling target across generations.",
      "facility_id": "W02.FAC.DRY",
      "output": "Prepared paired Hoppers; alternatively disassembled joints.",
      "customer": "Ordinary kit shop plus selected-component customers.",
      "world_consequence": "Intermediary stock funds continued selection while actual installed examples advertise the line.",
      "limit": "One observed pass supports that build, not guaranteed offspring success."
    },
    {
      "id": "W04.THREAD.PAD",
      "name": "Grip that releases in time",
      "origin": "PCR tire/contact choice",
      "trigger": "Foot-slip or slow foot release appears in controlled running.",
      "next_evidence": "Compare the same surface, moisture, load and current cleanliness.",
      "donor_id": "W02.DONOR.STICK",
      "where": "Glasshouse overgrowth and sheltered stems.",
      "selection": "Purchase plus fast peel release; keep attractive forms independently.",
      "breeding_objective": "Combine complementary pad properties and select consistent usable pairs.",
      "facility_id": "W02.FAC.REED",
      "output": "Sticktoe foot sets or alternative brake strips.",
      "customer": "Technical racers, brake makers and collectors.",
      "world_consequence": "A single route supports different buyers; no duplicate harvest of the same pads.",
      "limit": "Full foot gait is not in the current race solver."
    },
    {
      "id": "W04.THREAD.HORN",
      "name": "The base transfers the charge",
      "origin": "RRR derby weapon, integrated with PCR frame support",
      "trigger": "A ram contacts but deflects or destabilizes its own support.",
      "next_evidence": "Inspect contact direction, root structure and support before blaming size.",
      "donor_id": "W02.DONOR.HORN",
      "where": "Debris-covered compost margins on the Cooling-kiln route.",
      "selection": "Root strength and useful curvature rather than longest tip.",
      "breeding_objective": "Combine a useful horn geometry with strong, consistent roots.",
      "facility_id": "W02.FAC.SOIL",
      "output": "Bullhorn Ram and disjoint support products.",
      "customer": "Open or Fireworks builders and horn-form collectors.",
      "world_consequence": "Creates demand for breeders, preparation and structural fitting commissions.",
      "limit": "Root fracture and destructible anatomy remain unimplemented."
    },
    {
      "id": "W04.THREAD.GRASP",
      "name": "Closure before the rival escapes",
      "origin": "RRR native offensive/control module",
      "trigger": "A grasp winds up but closes after the target has passed.",
      "next_evidence": "Compare actual reach, closure response and target alignment.",
      "donor_id": "W02.DONOR.MANTIS",
      "where": "Glasshouse vertical scrub and stable perches.",
      "selection": "Useful reach while retaining fast closure.",
      "breeding_objective": "Outcross reach and closure contributions without relying on body size.",
      "facility_id": "W02.FAC.PRED",
      "output": "Catchclaws; alternatively non-attacking counterbraces.",
      "customer": "Open and Fireworks racers; legal brace buyers.",
      "world_consequence": "Predator compartments and careful transport earn value through intact useful arms.",
      "limit": "Current claw operator is a contact-delay proxy, not articulated limb physics."
    },
    {
      "id": "W04.THREAD.STAGE",
      "name": "The useful juvenile is the product",
      "origin": "PCR synchronization plus RRR life stages",
      "trigger": "A repeat order requests matched couplings before a meeting.",
      "next_evidence": "Verify stage, current function and delivery window rather than buying the largest adults.",
      "donor_id": "W02.DONOR.CLOCK",
      "where": "Pond/reed route during the declared cohort window.",
      "selection": "Precision plus a practical usable-stage window.",
      "breeding_objective": "Retain adult founders and schedule juvenile output separately.",
      "facility_id": "W02.FAC.REED",
      "output": "Planthopper Lockstep",
      "customer": "Assembly workshops and timing specialists.",
      "world_consequence": "Creates stage-specific orders and preservation demand without forcing real-world login schedules.",
      "limit": "A complete numerical lifecycle and storage window remain queued."
    },
    {
      "id": "W04.THREAD.FLIGHT",
      "name": "An intact wing supply",
      "origin": "RRR Flyers with PCR power/handling functions",
      "trigger": "Flyer clients request efficient matched wing-root assemblies.",
      "next_evidence": "Distinguish damage, fit, drive supply and repeatable root response.",
      "donor_id": "W02.DONOR.DRAGON",
      "where": "Cooling ponds with clear emergence supports.",
      "selection": "Wing efficiency, root endurance and intact expansion.",
      "breeding_objective": "Track parents through aquatic young and emergence rather than adult-only cages.",
      "facility_id": "W02.FAC.POND",
      "output": "Dragonfly Quadwing",
      "customer": "Flyer teams and display collectors.",
      "world_consequence": "Pond breeders, protected carriers and fitting workshops all have paid roles.",
      "limit": "Sustained flight is not simulated in this wave."
    },
    {
      "id": "W04.THREAD.DISPLAY",
      "name": "Desirable without a race justification",
      "origin": "PCR finishing and collectible kit culture",
      "trigger": "A customer wants a distinctive visible form or finish.",
      "next_evidence": "Record appearance, provenance and condition; do not invent superior race traits.",
      "donor_id": "W02.DONOR.MOTH",
      "where": "Sheltered textile ruins and nearby vegetation.",
      "selection": "The requested markings or structure, not a generic rarity color.",
      "breeding_objective": "Select the appearance goal while preserving viable reproduction.",
      "facility_id": "W02.FAC.LARVA",
      "output": "Whole display stock, prepared vanes or signature presentation kit.",
      "customer": "Collectors, finishers and signature-kit authors.",
      "world_consequence": "Aesthetics produces collection value and optional livelihoods alongside racing.",
      "limit": "No formula for player aesthetic preference is claimed."
    }
  ],
  "service_contracts": [
    {
      "id": "W04.SERVICE.BENCH",
      "provider_ref": "VENUE_FOUNDRY",
      "service": "shared fitting and controlled testing",
      "inputs": "reserved bench time, actual customer stock, tools",
      "receipt": "performed service and observations",
      "purpose": "low-capital tuning access without compulsory breeding"
    },
    {
      "id": "W04.SERVICE.KIT",
      "provider_ref": "SHOP_TWO_NETS",
      "service": "selected-stock kit commission",
      "inputs": "host, prepared sects, recipe, labor",
      "receipt": "physical kit transferred; assembly still player-led",
      "purpose": "turn repeatable line quality into an approachable product"
    },
    {
      "id": "W04.SERVICE.TRIAL",
      "provider_ref": "SHOP_SALTGLASS",
      "service": "small funded component trial",
      "inputs": "declared buying budget and product acceptance",
      "receipt": "accepted arrival only",
      "purpose": "connect publicity to credible buying without a genetic guarantee"
    },
    {
      "id": "W04.SERVICE.CARRIER",
      "provider_ref": "ORG_CARRIERS",
      "service": "stage-aware live or sect delivery",
      "inputs": "cargo, route, enclosure/support, arrival window",
      "receipt": "delivered custody and condition",
      "purpose": "distant customers create logistics income"
    },
    {
      "id": "W04.SERVICE.LINE",
      "provider_ref": "ORG_CINDER",
      "service": "brood contract and reserve production",
      "inputs": "retained founders, facility capacity, care, acceptance target",
      "receipt": "accepted stock; unsold young remain obligations",
      "purpose": "earn through productive consistency, not only top race stats"
    },
    {
      "id": "W04.SERVICE.MEDIA",
      "provider_ref": "MEDIA_BENCHLINE",
      "service": "result reporting and optional build feature",
      "inputs": "verified event and permission to publish components",
      "receipt": "public record or advertised claim",
      "purpose": "fame spreads through information, not hidden global bonuses"
    }
  ],
  "entity_extensions": [
    {
      "id": "W04.ENTITY.BUILD_SNAPSHOT",
      "fields": [
        "host_id",
        "build_version",
        "component_ids",
        "donor_ids",
        "native_anatomy",
        "setup",
        "condition",
        "model_version",
        "immutable_hash"
      ],
      "purpose": "Keep the actual racer and old results traceable."
    },
    {
      "id": "W04.ENTITY.COURSE_INSTANCE",
      "fields": [
        "layout_version",
        "owned_piece_ids",
        "port_poses",
        "surfaces",
        "widths",
        "clearance",
        "supports",
        "required_gate_sequence"
      ],
      "purpose": "Connect trackmaker inventory to valid race routes."
    },
    {
      "id": "W04.ENTITY.RACE_RESULT",
      "fields": [
        "event_id",
        "layout_id",
        "rules_version",
        "model_version",
        "build_snapshots",
        "finish_times",
        "gates",
        "incidents",
        "classification",
        "unit_system"
      ],
      "purpose": "Preserve a competition without retroactive setup changes."
    },
    {
      "id": "W04.ENTITY.MEETING",
      "fields": [
        "host_organization",
        "venue",
        "entries",
        "format",
        "purse_sources",
        "service_costs",
        "qualification",
        "result"
      ],
      "purpose": "Make event participation and hosting meaningful economic actions."
    },
    {
      "id": "W04.ENTITY.INQUIRY",
      "fields": [
        "customer",
        "observed_claim",
        "requested_product",
        "acceptance",
        "quantity",
        "budget",
        "knowledge_scope",
        "state"
      ],
      "purpose": "Separate public attention from willingness, funding and completed sale."
    },
    {
      "id": "W04.ENTITY.PUBLIC_BUILD_CARD",
      "fields": [
        "name",
        "host_id",
        "build_id",
        "placing",
        "time",
        "consented_component_ids"
      ],
      "purpose": "Support hobby prestige without hidden-genotype exposure."
    }
  ],
  "model_contract": {
    "unit_system": "normalized L/M/T; gravitational acceleration 1",
    "drive": "same Wave 03 force-speed form with shared power cap, drag and traction",
    "course": "piecewise line/arc centerline, lateral offsets and offset-distance correction; connected closed loop",
    "movement": "time-integrated longitudinal/lateral/height state; planned line changes; anticipatory turn braking",
    "jump": "shared charged preload; return and phase reduce transferred energy; split useful energy into horizontal and vertical components; straight-tube/ceiling checks",
    "contact": "path-space body envelopes; dissipative horn disruption; timed grasp/hold response",
    "classification": "ordered section gates and interpolated finish times",
    "limitations": [
      "Track section stock is declared per experiment; pooled track ownership and purchasing are not implemented",
      "No full rigid-body or limb dynamics",
      "Airborne motion follows a straight course tube; no free steering or branching flight",
      "No graded damage, genetic horn morphology, full foot gait or ecology",
      "No fully integrated race/world production clock",
      "Path corner controller is not a physical spin/course-out solver",
      "Experimental fixture mass, high-delivery reserve and NPC stock are disclosed in-kind inputs",
      "Entry-order invariance and one timestep-halving comparison do not establish multiplayer fairness"
    ]
  },
  "fixture_summary": {
    "before_time": 50.05675647022996,
    "after_time": 46.09635224760291,
    "encounters": {
      "pass": {
        "classification": [
          {
            "id": "W04.ENTRY.WORKSHOP",
            "name": "Workshop racer",
            "finish_time": 56.95068435195619,
            "place": 1
          },
          {
            "id": "W04.ENTRY.CLUB",
            "name": "Club demonstrator",
            "finish_time": 66.32264810989616,
            "place": 2
          }
        ],
        "event_counts": {
          "overtake": 1,
          "finish": 2
        }
      },
      "horn": {
        "classification": [
          {
            "id": "W04.ENTRY.WORKSHOP",
            "name": "Workshop racer",
            "finish_time": 57.14362408168801,
            "place": 1
          },
          {
            "id": "W04.ENTRY.CLUB",
            "name": "Club demonstrator",
            "finish_time": 66.41190666960915,
            "place": 2
          }
        ],
        "event_counts": {
          "ram_windup": 1,
          "body_contact": 2,
          "ram_contact": 1,
          "overtake": 1,
          "finish": 2
        }
      },
      "claw": {
        "classification": [
          {
            "id": "W04.ENTRY.WORKSHOP",
            "name": "Workshop racer",
            "finish_time": 57.55579552964329,
            "place": 1
          },
          {
            "id": "W04.ENTRY.CLUB",
            "name": "Club demonstrator",
            "finish_time": 66.7104022212163,
            "place": 2
          }
        ],
        "event_counts": {
          "ram_windup": 1,
          "claw_windup": 1,
          "body_contact": 2,
          "ram_contact": 1,
          "claw_contact": 1,
          "recovered": 2,
          "overtake": 1,
          "finish": 2
        }
      },
      "hop": {
        "classification": [
          {
            "id": "W04.ENTRY.WORKSHOP",
            "name": "Workshop racer",
            "finish_time": 57.14349962510802,
            "place": 1
          },
          {
            "id": "W04.ENTRY.CLUB",
            "name": "Club demonstrator",
            "finish_time": 66.38264705376893,
            "place": 2
          }
        ],
        "event_counts": {
          "body_contact": 3,
          "jump_load": 1,
          "takeoff": 1,
          "overtake": 1,
          "landing": 1,
          "recovered": 1,
          "finish": 2
        }
      }
    },
    "meeting": {
      "scope": "One funded demonstration and authored customer decision, not an autonomous economy.",
      "race_result": {
        "event_id": "W04.MEETING.DEMONSTRATION",
        "course_id": "W04.COURSE.FOUNDRY_LOOP.ca0749100639.v1",
        "model": "W04.RACE.PATH2P5.v1",
        "classification": [
          {
            "place": 1,
            "id": "W04.ENTRY.WORKSHOP",
            "host_id": "HOST",
            "finish_time": 57.14349962510802,
            "gates": 20,
            "required_gates": 20
          },
          {
            "place": 2,
            "id": "W04.ENTRY.CLUB",
            "host_id": "W04.HOST.CLUB",
            "finish_time": 66.38264705376893,
            "gates": 20,
            "required_gates": 20
          }
        ],
        "build_snapshots": {
          "W04.ENTRY.WORKSHOP": {
            "id": "W04.ENTRY.WORKSHOP",
            "host_id": "HOST",
            "name": "Workshop racer",
            "component_ids": [
              "UPGRADE-DRIVE",
              "H-6"
            ],
            "drive_source": "UPGRADE-DRIVE",
            "hopper_source": "H-6",
            "mass": 1.7,
            "cadence": 12,
            "force": 2.5,
            "stride": 0.25,
            "leverage": 0.85,
            "grip": 1.0,
            "delivery": 12.0,
            "efficiency": 0.75,
            "reserve": 120.0,
            "width": 0.38,
            "length": 0.62,
            "height": 0.26,
            "hopper": [
              0.625,
              0.07,
              0.06
            ],
            "preload": 5.0,
            "alignment_error": 0.0,
            "horn": false,
            "claws": false,
            "armor": "light",
            "provenance": [
              "DRIVE-DONOR",
              "B1-6",
              "W03.fixture.replayed"
            ]
          },
          "W04.ENTRY.CLUB": {
            "id": "W04.ENTRY.CLUB",
            "host_id": "W04.HOST.CLUB",
            "name": "Club demonstrator",
            "component_ids": [
              "W04.NPC.STOCK"
            ],
            "drive_source": "W04.NPC.STOCK",
            "hopper_source": null,
            "mass": 1.0,
            "cadence": 9,
            "force": 4,
            "stride": 0.25,
            "leverage": 1.0,
            "grip": 1.0,
            "delivery": 3.0,
            "efficiency": 0.75,
            "reserve": 120.0,
            "width": 0.38,
            "length": 0.62,
            "height": 0.26,
            "hopper": null,
            "preload": 0.7,
            "alignment_error": 0.0,
            "horn": false,
            "claws": false,
            "armor": "light",
            "provenance": [
              "declared_in_kind_opponent"
            ]
          }
        },
        "hash": "5fe6808af1d108abf4fcb6c599c86c03d20f8290103e705ac00c41bfae77aa3a"
      },
      "meeting_receipt": {
        "event": "W04.MEETING.DEMONSTRATION",
        "record_hash": "5fe6808af1d108abf4fcb6c599c86c03d20f8290103e705ac00c41bfae77aa3a",
        "prizes": {
          "player": 30,
          "club_lanista": 12
        },
        "operations_payment": 18,
        "unspent_nominal_prizes": 0,
        "claim_kind": "observed_result_not_genetic_certification"
      },
      "trial_order": {
        "id": "trial:W04.MEETING.DEMONSTRATION",
        "escrow": 40,
        "quantity": 2,
        "seller_revenue": 0,
        "acceptance": "ordinary measured assembly, no champion-gene guarantee"
      },
      "closing_cash": {
        "player": 172,
        "buyer": 20,
        "suppliers": 58,
        "club": 18,
        "sponsor": 30,
        "club_lanista": 12,
        "trial_customer": 30
      },
      "all_accounts_and_escrow": 380,
      "opening_accounts_and_escrow": 380,
      "public_cards": [
        {
          "name": "Workshop racer",
          "build_id": "W04.ENTRY.WORKSHOP",
          "host_id": "HOST",
          "finish_time": 57.14349962510802,
          "place": 1,
          "component_ids": [
            "UPGRADE-DRIVE",
            "H-6"
          ]
        },
        {
          "name": "Club demonstrator",
          "build_id": "W04.ENTRY.CLUB",
          "host_id": "W04.HOST.CLUB",
          "finish_time": 66.38264705376893,
          "place": 2,
          "component_ids": [
            "W04.NPC.STOCK"
          ]
        }
      ],
      "derived_project": {
        "donor": "W02.DONOR.HOPPER",
        "candidate_basis": "measured synchrony contribution",
        "requested_output": "ordinary prepared assemblies; acceptance remains a bench test",
        "limits": "A published race is not evidence of genotype or a guaranteed offspring result."
      },
      "limitations": [
        "No repeat-cohort economy, mortality forecast, retention or purchase-conversion rate is claimed.",
        "Race time is not yet integrated with the broader world scheduler.",
        "Prize is paid once; replay scrubbing never produces a second transaction."
      ]
    }
  },
  "validation_artifacts": {
    "runner": "validate_wave04.py",
    "tests": "tests/test_wave04.py",
    "regression": "reference/test_wave03.py",
    "evidence": "evidence/validation_report.json",
    "probe": "evidence/hop_setup_probe.json",
    "initial_failures": "evidence/initial_failures.txt"
  },
  "implementation_boundaries": [
    "Eight demand threads and six service contracts are specified; only result settlement and one authored funded inquiry execute.",
    "W04.T01 is partly realized as a headless path-race model and replay, not closed as a finished game.",
    "Repeated economy, staged reproduction and editable bench tasks remain in the existing queue."
  ]
}