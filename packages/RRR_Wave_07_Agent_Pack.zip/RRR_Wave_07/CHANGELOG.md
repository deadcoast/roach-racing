# Wave 07 changes

## Added
- Ten purposeful donor forms, thirty selectable properties, sixteen preparations, six stage facilities.
- Interchangeable frame, gear, sensory/support stabilizer, independent landing joints and rebound organ.
- Two Nets: real live stock, prepared stock, three conversion tins and three finite measured orders.
- Alternative anatomy preparation and limited disjoint post-vital processing.
- Species-specific staged pair breeding and a working waxmoth useful-larva / retained-adult loop.
- Four forward course presets, including Rivet Wash seams.
- Component-derived inspection and stage-specific stock silhouettes.

## Changed
- Race energy consumes actual donor drive efficiency.
- Running uses finite foot release and surface-specific purchase.
- Cornering can be constrained by structural support; corrections and landing recovery consume corresponding installed properties.
- Native contact has an explicit finite release baseline so an ordinary native foot is not an undocumented maximum-tier part.
- Main component titles emphasize names, with stable specimen ids in metadata.
- Narrow shop cards preserve readable measurements.

## Preserved
- Named host, historical H-6 and purchased drive; dynamic specimen and component ids.
- Draft / fitted / frozen-entry boundaries, shared clock, care, funded ordinary sales and portable world backup.
- Prior source context and reference archive.
- Legacy raw race profiles remain checked against the six earlier numerical experiments.

## Not claimed
- Exact PCR coefficients, complete source item coverage, whole-host kit shopping, biological realism, full damage/motion, calibrated economy, sustained flight or human playtest.
