# v0.4.0

Added: installed-asset race compilation, connected modular line/arc course, integrated pace and gates, passing, charged hoppers, contact proxies, replay records, immutable result registration, funded meeting and trial-order witness.
Added: eight operational donor/demand threads; six service relationships; world rules for practice, public build cards, club access, purposeful field return, stage-specific output and NPC knowledge.
Fixed during this wave: passing oscillation and stale clearance; action power bypass; mutable result snapshot aliasing; stale trial-escrow reporting.
Preserved: W03 model, cumulative v0.3 baseline, seed characters/places and historical illustrative results.
Not closed: editable game bench, full physics, repeated affordability, life-stage/removal/storage and intake/brood interfaces.
