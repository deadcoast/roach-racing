"""Validate Wave 02's data and isolated examples, not game balance.

Run: python validate_wave02.py
Optional complete JSON Schema check: install jsonschema, then run again.
No external services, downloads, or paid APIs are used.
"""
from __future__ import annotations
import copy
import itertools
import json
from collections import Counter
from fractions import Fraction
from pathlib import Path
import unittest

ROOT = Path(__file__).resolve().parent
PACK = json.loads((ROOT / 'wave02.json').read_text(encoding='utf-8'))
WORLD = json.loads((ROOT / 'world_context_v0.2.json').read_text(encoding='utf-8'))

def all_id_records(value: object):
    if isinstance(value, dict):
        if isinstance(value.get('id'), str):
            yield value
        for item in value.values():
            yield from all_id_records(item)
    elif isinstance(value, list):
        for item in value:
            yield from all_id_records(item)

def gametes(genotype: str) -> Counter:
    """Exact two-locus independent assortment. RRss -> {'Rs': 1}."""
    if len(genotype) != 4 or any(a.upper() != 'R' for a in genotype[:2]) or any(a.upper() != 'S' for a in genotype[2:]):
        raise ValueError('Expected a two-locus genotype such as RrSs or RRss.')
    result: Counter = Counter()
    for a, b in itertools.product(genotype[:2], genotype[2:]):
        result[a + b] += Fraction(1, 4)
    return result

def cross(left: str, right: str) -> Counter:
    result: Counter = Counter()
    for ga, pa in gametes(left).items():
        for gb, pb in gametes(right).items():
            genotype = ''.join(sorted((ga[0], gb[0]))) + ''.join(sorted((ga[1], gb[1])))
            result[genotype] += pa * pb
    return result

def probability_at_least_one(p: Fraction, n: int) -> Fraction:
    if n < 0 or not 0 <= p <= 1:
        raise ValueError('n must be nonnegative and p within [0, 1].')
    return 1 - (1 - p) ** n

class InventoryFixture:
    """Minimal transition fixture, deliberately not a full economy engine."""
    def __init__(self):
        self.specimen = {'owner': 'player', 'anatomy': {'left_hind', 'right_hind', 'forelimbs'}, 'reserved_parent': True}
        self.grafts: dict[str, dict] = {}
        self.receipts = 0

    def harvest(self, parts: set[str], graft_id: str) -> None:
        if not parts or not parts <= self.specimen['anatomy'] or graft_id in self.grafts:
            raise ValueError('Anatomy missing, empty plan, or duplicate graft identity.')
        self.specimen['anatomy'] -= parts
        self.grafts[graft_id] = {'owner': 'player', 'anatomy': set(parts), 'state': 'inventory'}

    def auto_sell_parent(self) -> bool:
        return not self.specimen['reserved_parent']

    def sell_graft(self, graft_id: str, price: int) -> None:
        g = self.grafts[graft_id]
        if price < 0 or g['owner'] != 'player' or g['state'] != 'inventory':
            raise ValueError('Unavailable stock or invalid price.')
        g['owner'], g['state'] = 'customer', 'sold'
        self.receipts += price

class WaveTests(unittest.TestCase):
    def test_unique_wave_ids(self):
        ids = [r['id'] for r in all_id_records(PACK)]
        self.assertEqual(len(ids), len(set(ids)))

    def test_references(self):
        base = copy.deepcopy(WORLD)
        base.pop('development_waves', None)
        ids = {r['id'] for r in all_id_records(base)} | {r['id'] for r in all_id_records(PACK)}
        singular = {'source_id','owner_donor_id','donor_id','extends_seed_id','extends_line_seed_id','selection_profile_id','toy_fixture_id','economy_fixture_id','baseline_decision_id'}
        plural = {'trait_ids','facility_ids','target_donor_ids'}
        def walk(value):
            if isinstance(value, dict):
                for key, child in value.items():
                    if key in singular and child is not None:
                        self.assertIn(child, ids, (key, child))
                    if key in plural:
                        for ref in child: self.assertIn(ref, ids, (key, ref))
                    if key == 'supply' and child != 'native': self.assertIn(child, ids)
                    walk(child)
            elif isinstance(value, list):
                for child in value: walk(child)
        walk(PACK)

    def test_donor_complete_chain(self):
        for donor in PACK['donors']:
            for key in ('racing_role','habitat','search_window','field_signs','capture_priority','breeding_goal','useful_stage','facility_ids','products','ordinary_stock_outlets','misleading_selection'):
                self.assertTrue(donor[key], (donor['id'], key))
            self.assertGreaterEqual(len(donor['trait_ids']), 3)

    def test_no_source_rank_locks(self):
        self.assertTrue(all(not run['rank_gate'] for run in PACK['field_runs']))

    def test_f1_exact(self):
        self.assertEqual(cross('RRss', 'rrSS'), {'RrSs': Fraction(1)})

    def test_f2_target(self):
        distribution = cross('RrSs','RrSs')
        self.assertEqual(distribution['RRSS'], Fraction(1,16))
        self.assertEqual(sum(distribution.values()), 1)

    def test_target_fixed_loci(self):
        self.assertEqual(cross('RRSS','RRSS'), {'RRSS': Fraction(1)})
        # Fixing these two loci is NOT a claim about fertility, other traits or race results.

    def test_brood_probability(self):
        self.assertAlmostEqual(float(probability_at_least_one(Fraction(1,16),16)), 0.6439258695482072)
        self.assertEqual(probability_at_least_one(Fraction(1,16),0), 0)

    def test_ledger_conserves_offspring(self):
        ledger = next(x for x in PACK['economy_examples'] if x['id'].endswith('LEDGER'))
        self.assertEqual(sum(x['count'] for x in ledger['dispositions']), ledger['mature_offspring'])
        retained = next(x for x in ledger['dispositions'] if x['kind']=='retained_replacement_breeder')
        self.assertEqual(retained['cash_revenue'], 0)

    def test_ledger_cash(self):
        l = next(x for x in PACK['economy_examples'] if x['id'].endswith('LEDGER'))
        revenue = sum(x['cash_revenue'] for x in l['dispositions'])
        costs = sum(l['cash_costs'].values())
        self.assertEqual((revenue,costs,revenue-costs,revenue-costs-8),(144,64,80,72))

    def test_unsold_not_income(self):
        self.assertEqual(144-60-64,20)
        stock = InventoryFixture()
        stock.harvest({'left_hind','right_hind'},'pair')
        self.assertEqual(stock.receipts,0)

    def test_anatomy_cannot_be_harvested_twice(self):
        stock = InventoryFixture()
        stock.harvest({'left_hind','right_hind'},'pair')
        with self.assertRaises(ValueError): stock.harvest({'left_hind'},'duplicate')

    def test_reserved_parent_protected(self):
        self.assertFalse(InventoryFixture().auto_sell_parent())

    def test_unique_sale(self):
        stock = InventoryFixture()
        stock.harvest({'left_hind','right_hind'},'pair')
        stock.sell_graft('pair',30)
        with self.assertRaises(ValueError): stock.sell_graft('pair',30)
        self.assertEqual(stock.receipts,30)

    def test_effect_contracts(self):
        required = {'cause','target','operation','magnitude_or_formula','trigger','duration','resource_draw','stacking_family','inherited','event_legality'}
        for effect in PACK['effects']: self.assertTrue(required <= effect.keys())

    def test_base_records_preserved(self):
        self.assertEqual(len(WORLD['seed_records']),41)
        self.assertEqual(WORLD['development_waves'][0],PACK)
        self.assertTrue(all(r['status']!='author_canon' for r in PACK['donors']))


def main() -> int:
    schema_result = 'not run: jsonschema package unavailable'
    try:
        import jsonschema
    except ImportError:
        pass
    else:
        schema = json.loads((ROOT/'wave02.schema.json').read_text(encoding='utf-8'))
        jsonschema.Draft202012Validator.check_schema(schema)
        jsonschema.validate(PACK,schema)
        schema_result = 'passed'
    suite = unittest.defaultTestLoader.loadTestsFromTestCase(WaveTests)
    result = unittest.TextTestRunner(verbosity=2).run(suite)
    report = {
        'scope':'Isolated data, inheritance-arithmetic and inventory/accounting fixtures; NOT game, economic or engagement validation.',
        'schema':schema_result, 'unit_tests_run':result.testsRun,
        'failures':len(result.failures),'errors':len(result.errors),
        'passed':result.wasSuccessful(),
        'counts':{k:len(PACK[k]) for k in ('donors','traits','facilities','field_runs','effects','assembly_recipes','market_channels')},
        'rule_count':sum(len(g['rules']) for g in PACK['rule_groups']),
        'toy_breeding':{'single_viable_offspring_target_probability':float(Fraction(1,16)),
            'at_least_one_target':{str(n):float(probability_at_least_one(Fraction(1,16),n)) for n in (8,16,24)}},
        'not_tested':['race outcomes','complete fertility or genetics model','full tank scheduling','ecological encounter distributions','sustainable market demand','realistic anatomy','player retention','gameplay balance']}
    (ROOT/'validation_report.json').write_text(json.dumps(report,indent=2)+'\n',encoding='utf-8')
    print(json.dumps(report,indent=2))
    return 0 if result.wasSuccessful() else 1

if __name__ == '__main__':
    raise SystemExit(main())
