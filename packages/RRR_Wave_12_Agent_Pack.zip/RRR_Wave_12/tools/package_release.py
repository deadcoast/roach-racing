"""Create a reproducible-name ZIP plus exact file inventory. No old generated ZIPs included."""
from pathlib import Path
import hashlib,json,zipfile
ROOT=Path(__file__).resolve().parents[1]
for directory in ROOT.rglob('__pycache__'):
    import shutil
    shutil.rmtree(directory)
excluded={'package-manifest.json'}
files=sorted(p for p in ROOT.rglob('*') if p.is_file() and p.name not in excluded and not p.name.endswith(('.zip','.pyc')))
manifest={'release':'RRR Wave v0.12','version':'0.12.0','file_count':len(files),'files':{str(p.relative_to(ROOT)):hashlib.sha256(p.read_bytes()).hexdigest() for p in files},'scope':'Exact delivered files; validation scope is recorded in evidence/validation_report.json.'}
(ROOT/'package-manifest.json').write_text(json.dumps(manifest,indent=2)+'\n')
out=ROOT.parent/'RRR_Wave_12_Agent_Pack.zip'
with zipfile.ZipFile(out,'w',zipfile.ZIP_DEFLATED,compresslevel=9) as z:
    for p in files+[ROOT/'package-manifest.json']:z.write(p,ROOT.name+'/'+str(p.relative_to(ROOT)))
print(out, out.stat().st_size, 'bytes',len(files),'hashed files')
