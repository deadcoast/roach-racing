"""Validate the Wave 03 package locally; no network or game runtime is used."""
from pathlib import Path
import hashlib
import importlib
import io
import json
import sys
import unittest
from fractions import Fraction
from w03_model import *

ROOT = Path(__file__).resolve().parent


def load(name):
    return json.loads((ROOT / name).read_text(encoding='utf-8'))


def collect_ids(x):
    out = []
    if isinstance(x, dict):
        if isinstance(x.get('id'), str): out.append(x['id'])
        for v in x.values(): out.extend(collect_ids(v))
    elif isinstance(x, list):
        for v in x: out.extend(collect_ids(v))
    return out


def check_references(x, available, path='$'):
    direct = {'donor_id','product_id','field_run_id','baseline_ref','task_id','protocol','extends'}
    many = {'refines','depends_on','trait_ids','facility_ids'}
    if isinstance(x, dict):
        for k,v in x.items():
            if k in direct and isinstance(v,str) and v.startswith(('W02.','W03.','W04.')):
                if v not in available: raise AssertionError(f'{path}.{k}: unknown reference {v}')
            if k in many:
                for ref in v:
                    if ref not in available: raise AssertionError(f'{path}.{k}: unknown reference {ref}')
            check_references(v,available,path+'.'+k)
    elif isinstance(x,list):
        for i,v in enumerate(x): check_references(v,available,f'{path}[{i}]')


def structural():
    spec=load('RRR_Wave_03.spec')
    base=load('reference/world_context_v0.2.json')
    world=load('world_context_v0.3.json')
    needed={'Reference','Plan','Workflow','Adherence','MIVIM','systems','assay_profiles'}
    assert needed <= spec.keys(), 'missing requested top-level sections'
    for k,v in base.items():
        if k not in {'manifest','development_waves'}:
            assert world[k] == v, f'base collection changed: {k}'
    assert world['development_waves'][:-1] == base['development_waves'], 'prior wave changed'
    assert world['development_waves'][-1] == spec, 'new wave differs from exchange spec'
    allowed={'version','relationship_to_handbook','validation_scope'}
    assert {k for k in base['manifest'] if world['manifest'].get(k)!=base['manifest'][k]} <= allowed
    baseline_hash=hashlib.sha256((ROOT/'reference/world_context_v0.2.json').read_bytes()).hexdigest()
    assert baseline_hash==spec['manifest']['base_sha256'], 'baseline digest mismatch'
    ids=collect_ids(spec)
    assert len(ids)==len(set(ids)), 'duplicate Wave 03 definition IDs'
    available=set(collect_ids(base)) | set(ids)
    check_references(spec,available)
    assert spec['MIVIM']['numeric_score'] is None, 'unsupported numeric score'
    assert len(spec['Plan']['next_queue']) > 0, 'no next work'
    # Dependency order is explicit and acyclic for this wave.
    seen=set()
    for t in spec['Plan']['tasks']:
        assert set(t['depends_on']) <= seen, 'task ordering/cycle failure'
        seen.add(t['id'])
    schema_status='not_run_missing_optional_jsonschema'
    try:
        from jsonschema import Draft202012Validator
    except ImportError:
        pass
    else:
        schema=load('wave03.schema.json')
        Draft202012Validator.check_schema(schema)
        Draft202012Validator(schema).validate(spec)
        schema_status='passed'
    return {'base_content_preserved':True,'baseline_sha256':baseline_hash,
            'unique_definition_ids':len(ids),'references':'passed','task_dependencies':'passed',
            'schema':schema_status,'rules':sum(len(g['rules']) for g in spec['systems']),
            'tasks':len(spec['Plan']['tasks']),'next_tasks':len(spec['Plan']['next_queue'])}


def fixtures():
    low=((0,0),(0,0),(0,0)); het=((0,1),(0,1),(0,1)); top=((1,1),(1,1),(1,1))
    a=((1,1),(0,0),(1,1)); b=((0,0),(1,1),(1,1)); f1=((0,1),(0,1),(1,1))
    p2=target_probability(het[:2],het[:2],top[:2]);p3=target_probability(het,het,top)
    return {'status':'uncalibrated_normalized_fixtures',
            'genetics':{'first_generation':str(cross(a,b)),
                        'two_locus_target_probability':str(p2),
                        'three_locus_target_probability':str(p3),
                        'conditional_at_least_one_three_locus_target_in_16':float(1-(1-p3)**16),
                        'limit':'Conditional on viable offspring, independent loci, disclosed engine genotype and no mutation; not a real fertility forecast.'},
            'hopper_bench':{'ordinary':hopper_bench(low),'first_generation':hopper_bench(f1),'selected':hopper_bench(top)},
            'drive_bench':{'ordinary':straight_bench(10,2),'improved':straight_bench(12,2.5),
                           'higher_leverage':straight_bench(10,2,leverage=1.5)},
            'integration':integrated_fixture(),
            'not_demonstrated':['actual races or wins','world economy equilibrium','retention','full fertility or colony genetics','rendered visual/UI quality']}


def main():
    root=ROOT/'evidence';root.mkdir(exist_ok=True)
    stream=io.StringIO()
    suite=unittest.defaultTestLoader.loadTestsFromName('test_wave03')
    result=unittest.TextTestRunner(stream=stream,verbosity=2).run(suite)
    (root/'test_log.txt').write_text(stream.getvalue(),encoding='utf-8')
    report={'scope':'Specification, independent-locus and operator witnesses; not game validation.',
            'behavioral_tests_run':result.testsRun,'failures':len(result.failures),'errors':len(result.errors),
            'skipped':len(result.skipped),'tests_passed':result.wasSuccessful()}
    try:
        report['structural_checks']=structural()
        (root/'fixture_outputs.json').write_text(json.dumps(fixtures(),indent=2,allow_nan=False)+'\n')
        report['structural_passed']=True
    except Exception as exc:
        report['structural_passed']=False
        report['structural_error']=f'{type(exc).__name__}: {exc}'
    report['passed']=report['tests_passed'] and report['structural_passed']
    report['limitations']=['No actual game build or rendered interface.','No simulated fertility, complete lifecycle or self-renewing market.',
                          'Fixtures do not establish biological accuracy, balanced profits, meaningful novelty to players or retention.',
                          'Quality and novel-development guardrails require contribution-scoped review; tests are supporting evidence.']
    (root/'validation_report.json').write_text(json.dumps(report,indent=2)+'\n')
    print(json.dumps(report,indent=2))
    return 0 if report['passed'] else 1


if __name__=='__main__':
    raise SystemExit(main())
