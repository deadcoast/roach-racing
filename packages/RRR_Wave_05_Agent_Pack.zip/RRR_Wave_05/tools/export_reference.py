"""Rebuild disclosed W04 scenarios from unchanged Python sources; no prior save invented."""
from pathlib import Path
import sys,json
from dataclasses import asdict
root=Path(__file__).resolve().parents[1]
sys.path.insert(0,str(root/'reference/wave04_model'))
from race import resume_workshop, compile_workshop, foundry_course, Runner, Race
from fixtures import encounter, comparative_runs
cases={}
_,cs=comparative_runs()
for label,r in cs.items():
 cases[label]={'input':{'course':r['course'],'entrants':[{'build':r['results'][0]['build'],'policy':{},'d':0}], 'equipment':r['equipment'],'dt':r['dt']},'expected':r}
for mode in ('pass','horn','claw','hop'):
 _,r=encounter(mode)
 bs={row['id']:row['build'] for row in r['results']}
 entrants=[{'build':bs['W04.ENTRY.CLUB'],'policy':{'passing':False,'counter':mode=='claw'},'d':.3},{'build':bs['W04.ENTRY.WORKSHOP'],'policy':{'passing':mode!='hop','jumping':mode=='hop','attacking':mode in {'horn','claw'}},'d':-.3}]
 cases[mode]={'input':{'course':r['course'],'entrants':entrants,'equipment':'open','dt':.01},'expected':r}
(root/'evidence/python_reference.json').write_text(json.dumps(cases,separators=(',',':'),allow_nan=False))
w=resume_workshop()
def safe(v):
 if isinstance(v,set):return sorted(v)
 raise TypeError(type(v))
records={'note':'W03 transactions reconstructed by unchanged W04 resume_workshop; not a world save.', 'cash':w.cash, 'host':asdict(w.stocks['HOST']), 'hopper_donor':asdict(w.stocks['B1-6']), 'hopper':asdict(w.sects['H-6']), 'drive':asdict(w.sects['UPGRADE-DRIVE']), 'drive_donor':asdict(w.stocks['DRIVE-DONOR'])}
(root/'reference/workshop_origin.json').write_text(json.dumps(records,indent=2,default=safe))
print('Exported',len(cases),'reference experiments')
