{
  "manifest": {
    "id": "W03",
    "version": "0.3.0",
    "title": "RRR — Selected Stock, Scheduled Broods and Funded Upgrades",
    "status": "proposed_foundation_with_executable_witnesses",
    "date": "2026-09-09",
    "extends": "RRR_World_Context_v0.2.json",
    "base_sha256": "ac9705da5dab4b2a009c3ac000e7f084bab0a4c4be2efe6c6201b9d13210162f",
    "serialization": "strict JSON in .spec; this is an RRR exchange format, not an asserted canonical MIVIM grammar",
    "scope": "Specification development and bounded executable witnesses; not a game implementation",
    "authority": "Author premises govern; new mechanics are revisable proposals"
  },
  "Reference": {
    "baseline_files": [
      "RRR_Wave_02_Foundations.md",
      "RRR_World_Context_v0.2.json",
      "RAD_ROACH_RACING_Handbook_v0.2.md"
    ],
    "sources": [
      {
        "id": "W03.S01",
        "title": "Tamiya Mini 4WD Setup Guide",
        "url": "https://www.tamiya.com/english/mini4wd/setupguide/setupguide.htm",
        "checked_on": "2026-09-09",
        "scope": "Distinct motors, ratios, contacts, maintenance, dampers and assembly decisions.",
        "limits": "Physical Mini 4WD; not a biological simulation or proof of RRR gameplay."
      },
      {
        "id": "W03.S02",
        "title": "Tamiya Basic Tune-Up Parts Set for MA Chassis, 15476",
        "url": "https://www.tamiya.com/english/products/15476/index.html",
        "checked_on": "2026-09-09",
        "scope": "Complementary components supplied as a coordinated upgrade pack.",
        "limits": "Does not specify living stock, breeding, inventory accounting or RRR geometry."
      },
      {
        "id": "W03.S03",
        "title": "Mewgenics developer-authored Steam description",
        "url": "https://store.steampowered.com/app/686060/Mewgenics/",
        "checked_on": "2026-09-09",
        "scope": "Resource expeditions, multigenerational breeding, inherited skills/mutations and house-upgrade choices.",
        "limits": "No exact inheritance coefficients, universal success claim or cause of retention is inferred."
      }
    ],
    "findings": [
      {
        "id": "W03.GAP.01",
        "finding": "Selection rules name what to keep, but a practical intake has no evidence-bound project decision record.",
        "baseline_ref": "W02.SORT.02",
        "task_id": "W03.T02",
        "repair": "A weak overall donor with a useful complementary trait is reviewed rather than silently bulk-sold."
      },
      {
        "id": "W03.GAP.02",
        "finding": "The breeding witness covers a two-locus probability, not a trait-to-product computation.",
        "baseline_ref": "W02.GENE.03",
        "task_id": "W03.T03",
        "repair": "An explicit scoped hopper model links inherited return, synchrony and settling to component measurements."
      },
      {
        "id": "W03.GAP.03",
        "finding": "Future capacity is named but not executable; mating availability can hide a grow-out shortage.",
        "baseline_ref": "W02.TANK.06",
        "task_id": "W03.T04",
        "repair": "Atomic multi-stage reservations reject impossible future occupancy."
      },
      {
        "id": "W03.GAP.04",
        "finding": "Developmental delay can invalidate later commitments; retaining live obligations needs a defined replan.",
        "baseline_ref": "W02.TANK.10",
        "task_id": "W03.T04",
        "repair": "A delayed live cohort keeps its space; conflicting unstarted batches pause for replanning."
      },
      {
        "id": "W03.GAP.05",
        "finding": "The previous income fixture begins with already-matured stock; operating time and buyer funds are not connected.",
        "baseline_ref": "W02.EXAMPLE.LEDGER",
        "task_id": "W03.T05",
        "repair": "A scheduled example pays care, prepares existing output, settles finite escrow and buys an upgrade."
      },
      {
        "id": "W03.GAP.06",
        "finding": "Whole assemblies span roles, but role expansion could duplicate tissues or make packaged stock separately saleable.",
        "baseline_ref": "W02.PART.02",
        "task_id": "W03.T06",
        "repair": "One physical source supports several roles once; custody prevents double use."
      },
      {
        "id": "W03.GAP.07",
        "finding": "Directional traits lack a measurable matched comparison.",
        "baseline_ref": "W02.PART.12",
        "task_id": "W03.T07",
        "repair": "Loaded-drive and hopper fixtures produce inspectable outputs under declared assumptions."
      },
      {
        "id": "W03.GAP.08",
        "finding": "Useful depth risks becoming recurring clerical work or an omniscient auto-optimizer.",
        "baseline_ref": "W02.TANK.15",
        "task_id": "W03.T08",
        "repair": "Intake, brood board and cash views disclose decisions at beginner and expert depth using the same evidence."
      },
      {
        "id": "W03.GAP.09",
        "finding": "No ordered Wave 03 backlog or contribution-scoped MIVIM assessment is present.",
        "baseline_ref": "W02.CONTRACT.04",
        "task_id": "W03.T01",
        "repair": "Priority, scope, dependencies, evidence, limitations and next work are explicit."
      },
      {
        "id": "W03.GAP.10",
        "finding": "A world-sized sandbox can be implied from a few passing data tests.",
        "baseline_ref": "W02.ACCEPT.QUALITY",
        "task_id": "W03.T09",
        "repair": "Model checks, originality review, runtime scale and play experience remain distinct findings."
      }
    ],
    "preserved": [
      "speed and winning",
      "personally assembled kits",
      "collection and showing off",
      "anyone can catch and breed",
      "whole-insect Wrangloid trade",
      "genuine superior stock",
      "optional professions and expert depth",
      "Open equipment freedom",
      "Flyers with Flyers",
      "no new global racer permadeath",
      "Locals-Regionals-Factionals-New World City"
    ]
  },
  "Plan": {
    "tasks": [
      {
        "id": "W03.T01",
        "title": "Review, reference trace and ordered wave plan",
        "priority": "P0",
        "depends_on": [],
        "contribution_role": "supporting",
        "spec_status": "developed_this_wave",
        "witness_status": "reviewed",
        "acceptance": "Preserve prior records; record concrete gaps and scope-correct criteria."
      },
      {
        "id": "W03.T02",
        "title": "Project-led intake and complementary-stock decisions",
        "priority": "P0",
        "depends_on": [
          "W03.T01"
        ],
        "contribution_role": "novel_integration",
        "spec_status": "developed_this_wave",
        "witness_status": "public-evidence routing checked; visual UI not rendered",
        "acceptance": "Same public evidence gives same advice; poor present output can still matter to a named project."
      },
      {
        "id": "W03.T03",
        "title": "Hopper inheritance-to-product specification",
        "priority": "P0",
        "depends_on": [
          "W03.T02"
        ],
        "contribution_role": "novel_integration",
        "spec_status": "developed_this_wave",
        "witness_status": "three-locus hopper fixture checked; general genetics and fertility not implemented",
        "acceptance": "Exact independent-locus outcomes and measured component consequences; no automatic max-parent inheritance."
      },
      {
        "id": "W03.T04",
        "title": "Future-cohort capacity and commitment-preserving replanning",
        "priority": "P0",
        "depends_on": [
          "W03.T03"
        ],
        "contribution_role": "novel_integration",
        "spec_status": "developed_this_wave",
        "witness_status": "interval capacity and delay witnesses checked; live-overflow relocation remains open",
        "acceptance": "Reserve parents and future stages atomically; delay pauses only unstarted conflicts."
      },
      {
        "id": "W03.T05",
        "title": "Funded brood orders and honest operating cash",
        "priority": "P0",
        "depends_on": [
          "W03.T04"
        ],
        "contribution_role": "novel_integration",
        "spec_status": "developed_this_wave",
        "witness_status": "finite-money operators and eight-tick integration checked; repeated economy calibration open",
        "acceptance": "Care costs advance; delivered accepted assets earn money; escrow/unsold inventory do not."
      },
      {
        "id": "W03.T06",
        "title": "Anatomy-safe prepared packs and assembly custody",
        "priority": "P1",
        "depends_on": [
          "W03.T02"
        ],
        "contribution_role": "novel_integration",
        "spec_status": "developed_this_wave",
        "witness_status": "harvest, pack and simple installation checked; geometric bench/kit unpack runtime open",
        "acceptance": "No overlapping harvest or duplicate component; native functions and actual kit assembly remain."
      },
      {
        "id": "W03.T07",
        "title": "Controlled performance witnesses and same-trait race binding",
        "priority": "P1",
        "depends_on": [
          "W03.T03",
          "W03.T06"
        ],
        "contribution_role": "experimental",
        "spec_status": "developed_this_wave",
        "witness_status": "normalized one-dimensional drive and launch benches checked; actual race binding queued",
        "acceptance": "A declared donor/drive improvement changes a measured result through a stated mechanism."
      },
      {
        "id": "W03.T08",
        "title": "Intake, brood and earnings interaction polish",
        "priority": "P1",
        "depends_on": [
          "W03.T02",
          "W03.T04",
          "W03.T05"
        ],
        "contribution_role": "design",
        "spec_status": "developed_this_wave",
        "witness_status": "interaction and presentation contracts authored; no rendered UI/usability test",
        "acceptance": "Few actionable views preserve expert detail, identities and uncertainty without compulsory busywork."
      },
      {
        "id": "W03.T09",
        "title": "Regression, MIVIM review and next-wave handoff",
        "priority": "P0",
        "depends_on": [
          "W03.T01",
          "W03.T02",
          "W03.T03",
          "W03.T04",
          "W03.T05",
          "W03.T06",
          "W03.T07",
          "W03.T08"
        ],
        "contribution_role": "supporting",
        "spec_status": "developed_this_wave",
        "witness_status": "automated report and qualitative review supplied",
        "acceptance": "Base preservation and exact evidence scope; no test-count credit for innovation."
      }
    ],
    "next_queue": [
      {
        "id": "W04.T01",
        "priority": "P0",
        "title": "Bind component traits to a real assembled racer and modular-course race slice",
        "depends_on": [
          "W03.T07",
          "W03.T06"
        ],
        "acceptance": [
          "Same stock and build identities feed the race model.",
          "Compare actual finish times and overtakes; no result awarded from a bench score.",
          "Kit assembly, horn/claw/hopper choices and course connectivity remain visible.",
          "Inspect fun, legibility, identity and finish presentation separately from solver tests."
        ]
      },
      {
        "id": "W04.T02",
        "priority": "P0",
        "title": "Calibrate repeated production, uncertainty and livelihood affordability",
        "depends_on": [
          "W03.T04",
          "W03.T05"
        ],
        "acceptance": [
          "Multiple cohorts and buyer budgets; care and household/workshop costs included.",
          "Matched scenarios compare casual buying, collecting and breeding without forced profession choice.",
          "Common-catch recovery routes and delayed/failed contracts are stress-tested."
        ]
      },
      {
        "id": "W04.T03",
        "priority": "P1",
        "title": "Extend life-stage, removal and storage branches",
        "depends_on": [
          "W03.T03",
          "W03.T06"
        ],
        "acceptance": [
          "One staged non-hopper profile including colony or aquatic lifecycle.",
          "Actual removal/viability behavior and overflow support rather than silent assumptions.",
          "No surprise host permadeath rule."
        ]
      },
      {
        "id": "W04.T04",
        "priority": "P1",
        "title": "Render and evaluate intake, brood and kit interactions",
        "depends_on": [
          "W03.T08"
        ],
        "acceptance": [
          "Bespoke coherent biological hobby presentation, not generic admin panels.",
          "Casual and expert paths tested on the same underlying state.",
          "No hidden-truth leak or compulsory repetitive care clicks."
        ]
      }
    ]
  },
  "Workflow": {
    "executed": [
      "Inspect full prior archive metadata and relevant foundation sections.",
      "Check for an existing ordered TODO; none found in Wave 02 foundation/README.",
      "Recover MIVIM constraints; do not invent missing score weights.",
      "Author integrated Wave 03 spec and scoped model witnesses.",
      "Run adversarial behavior and base-preservation checks.",
      "Record review, remaining gaps and next primary task."
    ],
    "decision_mode": "Continue substantive grouped work; no per-rule approval stops.",
    "completion_semantics": "spec developed != runtime built != playtested"
  },
  "Adherence": {
    "hard_constraints": [
      "Quality and novel-development adherence are non-compensable guardrails.",
      "Every feature connects a user decision with physical stock, performance or a livelihood consequence.",
      "Supporting work is not credited as delivered innovation.",
      "No stories or generic exposition replace atomic foundations.",
      "No inherited Wave 02 null becomes global fact through a toy fixture."
    ],
    "authority_change": "No prior author_canon or seed_records altered.",
    "reviewed_exclusions": [
      "no forced track-puzzle framing",
      "no universal sidegrade rule",
      "no manufactured Graft Point cap",
      "no obligatory breeder career",
      "no player-rank gene gates",
      "no monetary claims from unsold stock"
    ]
  },
  "MIVIM": {
    "criteria_source": "Recovered user project constraints from prior discussion; complete numeric rubric/grade bands unavailable.",
    "acronym_expansion": null,
    "numeric_score": null,
    "numeric_score_reason": "No authorized weights or grade bands recovered; do not fabricate.",
    "eligibility": "quality_at_declared_scope AND novel_development_adherence_at_declared_scope; unknown remains pending",
    "contribution_scope": "Novel integration specification with supporting executable witnesses; not demonstrated player experience.",
    "innovation_objectives": [
      "One trait identity connects field selection, reproductive project, product acceptance, kit and measured behavior.",
      "Future production commitments preserve the same living stock and financial obligations during delays.",
      "Accessible batch actions preserve expert knowledge and animal identity instead of replacing selection with a global score."
    ],
    "findings": [
      {
        "criterion": "quality",
        "assessment": "Reviewed at specification/operator-witness scope; gameplay-quality gate open",
        "evidence": [
          "atomic rules",
          "adversarial tests",
          "migration checks"
        ],
        "limits": [
          "No finished visual interface",
          "No full game or playtest"
        ]
      },
      {
        "criterion": "novel-development adherence",
        "assessment": "Supported for this project-specific integration; not a claim of worldwide novelty",
        "evidence": [
          "linked field-to-brood-to-build mechanism",
          "explicit rejected conventional substitutes"
        ],
        "limits": [
          "Player-perceived distinctiveness untested"
        ]
      },
      {
        "criterion": "effectiveness",
        "assessment": "Demonstrated only for bounded operator and mechanism fixtures",
        "evidence": [
          "finite settlement",
          "future capacity",
          "matched performance outputs"
        ],
        "limits": [
          "No race win, survival forecast or sustainable economy proven"
        ]
      },
      {
        "criterion": "creativity",
        "assessment": "Concrete authored integration; experiential result unverified",
        "evidence": [
          "project-relative complementary stock",
          "line-aware prepared products",
          "commitment-preserving brood operations"
        ],
        "limits": [
          "No numerical creativity score"
        ]
      },
      {
        "criterion": "scaling_potential",
        "assessment": "Architectural path specified; runtime scale unmeasured",
        "evidence": [
          "batch views preserve individual IDs",
          "event-local outcomes",
          "resource calendars",
          "protocol references"
        ],
        "limits": [
          "No large-world benchmark or autonomous market test"
        ]
      }
    ],
    "role_separation": {
      "novel_integration": "T02-T06 advance selected-stock/breeding/build/livelihood integration",
      "experimental": "T07 explores a measurable shared trait mechanism",
      "design": "T08 defines unfinished interaction polish",
      "supporting": "T01/T09 protect scope and evidence; test count alone gives no innovation credit"
    }
  },
  "systems": [
    {
      "id": "W03.GROUP.TRACE",
      "title": "Reference and development scope",
      "rules": [
        {
          "id": "W03.TRACE.01",
          "statement": "Source-hobby function, RRR translation and new extension are separate fields.",
          "player_or_agent_decision": "Trace a mechanic before adding it.",
          "observable_consequence": "A tank is not falsely attributed to PCR; a muscle still has a motor-related purpose.",
          "origin_category": "RRR_native_integration",
          "refines": [
            "W02.CONTRACT.01",
            "W02.CONTRACT.04"
          ],
          "status": "proposed_foundation"
        },
        {
          "id": "W03.TRACE.02",
          "statement": "The same trait identifier must connect field observations, breeding goals, accepted products and controlled performance tests.",
          "player_or_agent_decision": "Change a trait once and inspect all dependents.",
          "observable_consequence": "A breeding improvement cannot secretly become an unrelated race bonus.",
          "origin_category": "RRR_native_integration",
          "refines": [
            "W02.CONTRACT.01",
            "W02.CONTRACT.04"
          ],
          "status": "proposed_foundation"
        },
        {
          "id": "W03.TRACE.03",
          "statement": "No fixed scoring weights, grade boundaries or acronym expansion are invented for MIVIM.",
          "player_or_agent_decision": "Use recovered guardrails and separate criterion findings.",
          "observable_consequence": "Unsupported numerical grades are absent.",
          "origin_category": "RRR_native_integration",
          "refines": [
            "W02.CONTRACT.01",
            "W02.CONTRACT.04"
          ],
          "status": "proposed_foundation"
        },
        {
          "id": "W03.TRACE.04",
          "statement": "Conventional validation work protects the novel contribution but cannot substitute for it.",
          "player_or_agent_decision": "Report contribution role and evidence at its own scope.",
          "observable_consequence": "A schema test is not claimed as delivered gameplay innovation.",
          "origin_category": "RRR_native_integration",
          "refines": [
            "W02.CONTRACT.01",
            "W02.CONTRACT.04"
          ],
          "status": "proposed_foundation"
        },
        {
          "id": "W03.TRACE.05",
          "statement": "All new numeric profiles are named revisioned fixtures; existing nulls remain unresolved outside that profile.",
          "player_or_agent_decision": "Choose a profile explicitly.",
          "observable_consequence": "A hopper test duration does not become every insect species lifecycle.",
          "origin_category": "RRR_native_integration",
          "refines": [
            "W02.CONTRACT.01",
            "W02.CONTRACT.04"
          ],
          "status": "proposed_foundation"
        },
        {
          "id": "W03.TRACE.06",
          "statement": "Original user premises outrank generated handbooks; new waves do not silently promote proposals into canon.",
          "player_or_agent_decision": "Resolve conflicts with authority and explicit amendments.",
          "observable_consequence": "Open remains open; any hobbyist may catch and breed.",
          "origin_category": "RRR_native_integration",
          "refines": [
            "W02.CONTRACT.01",
            "W02.CONTRACT.04"
          ],
          "status": "proposed_foundation"
        }
      ]
    },
    {
      "id": "W03.GROUP.INTAKE",
      "title": "Project-led intake and evidence",
      "rules": [
        {
          "id": "W03.INTAKE.01",
          "statement": "A project names a desired product or specimen use, target traits, current evidence, missing complement and spending or capacity limit.",
          "player_or_agent_decision": "Create a sprint, breeding, supply or collection project.",
          "observable_consequence": "The player can explain why an animal is useful before keeping it.",
          "origin_category": "RRR_native_integration",
          "refines": [
            "W02.SORT.01",
            "W02.VALUE.01",
            "W02.CONTRACT.07"
          ],
          "status": "proposed_foundation"
        },
        {
          "id": "W03.INTAKE.02",
          "statement": "A complementary breeder is judged against the current project, not solely its own aggregate race performance.",
          "player_or_agent_decision": "Retain a low-return high-synchrony hopper for a high-return line.",
          "observable_consequence": "An otherwise ordinary capture may advance a specific breeding objective.",
          "origin_category": "RRR_native_integration",
          "refines": [
            "W02.SORT.01",
            "W02.VALUE.01",
            "W02.CONTRACT.07"
          ],
          "status": "proposed_foundation"
        },
        {
          "id": "W03.INTAKE.03",
          "statement": "Intake recommendations read only the observations and knowledge visible to that decision maker.",
          "player_or_agent_decision": "Inspect, test or buy knowledge.",
          "observable_consequence": "Two unseen genotypes with the same visible evidence receive the same default recommendation.",
          "origin_category": "RRR_native_integration",
          "refines": [
            "W02.SORT.01",
            "W02.VALUE.01",
            "W02.CONTRACT.07"
          ],
          "status": "proposed_foundation"
        },
        {
          "id": "W03.INTAKE.04",
          "statement": "An observation records protocol, condition, load, stage, value bounds, time and method; bounds are not called confidence intervals without a model.",
          "player_or_agent_decision": "Compare compatible measurements.",
          "observable_consequence": "A field glimpse and controlled assay remain visibly different evidence.",
          "origin_category": "RRR_native_integration",
          "refines": [
            "W02.SORT.01",
            "W02.VALUE.01",
            "W02.CONTRACT.07"
          ],
          "status": "proposed_foundation"
        },
        {
          "id": "W03.INTAKE.05",
          "statement": "A demonstrated match, possible match and ruled-out target are distinct; unknown is not zero or automatic success.",
          "player_or_agent_decision": "Review uncertainty instead of accepting a fabricated exact answer.",
          "observable_consequence": "A possible useful donor is flagged, not certified.",
          "origin_category": "RRR_native_integration",
          "refines": [
            "W02.SORT.01",
            "W02.VALUE.01",
            "W02.CONTRACT.07"
          ],
          "status": "proposed_foundation"
        },
        {
          "id": "W03.INTAKE.06",
          "statement": "Explicit founder, replacement, collectible and order protections precede bulk sale recommendations.",
          "player_or_agent_decision": "Set or release a protection deliberately.",
          "observable_consequence": "Quick-sale previews exclude protected stock.",
          "origin_category": "RRR_native_integration",
          "refines": [
            "W02.SORT.01",
            "W02.VALUE.01",
            "W02.CONTRACT.07"
          ],
          "status": "proposed_foundation"
        },
        {
          "id": "W03.INTAKE.07",
          "statement": "Possible project matches request review without creating permanent unremovable locks.",
          "player_or_agent_decision": "Snooze a project, dismiss a match or override the current batch.",
          "observable_consequence": "A full holding case can be cleared without deleting the whole project.",
          "origin_category": "RRR_native_integration",
          "refines": [
            "W02.SORT.01",
            "W02.VALUE.01",
            "W02.CONTRACT.07"
          ],
          "status": "proposed_foundation"
        },
        {
          "id": "W03.INTAKE.08",
          "statement": "The quick route permits buying a coordinated kit and racing; assay and breeding are optional activities.",
          "player_or_agent_decision": "Choose the depth of participation.",
          "observable_consequence": "Basic participation does not require learning allele notation.",
          "origin_category": "RRR_native_integration",
          "refines": [
            "W02.SORT.01",
            "W02.VALUE.01",
            "W02.CONTRACT.07"
          ],
          "status": "proposed_foundation"
        },
        {
          "id": "W03.INTAKE.09",
          "statement": "Prices reflect buyer purpose and available evidence, not a hidden exact-genotype price oracle.",
          "player_or_agent_decision": "Choose a buyer or better evidence for a sale.",
          "observable_consequence": "Unidentified stock can be sold honestly as unidentified.",
          "origin_category": "RRR_native_integration",
          "refines": [
            "W02.SORT.01",
            "W02.VALUE.01",
            "W02.CONTRACT.07"
          ],
          "status": "proposed_foundation"
        },
        {
          "id": "W03.INTAKE.10",
          "statement": "Run planning stores target donor, stage, habitat, observable sign, capture method, space, ordinary-stock outlet and source of the claim.",
          "player_or_agent_decision": "Choose a purposeful route.",
          "observable_consequence": "A trip has a useful ordinary result as well as exceptional targets, without guaranteed profit.",
          "origin_category": "RRR_native_integration",
          "refines": [
            "W02.SORT.01",
            "W02.VALUE.01",
            "W02.CONTRACT.07"
          ],
          "status": "proposed_foundation"
        }
      ]
    },
    {
      "id": "W03.GROUP.BREED",
      "title": "Selection and phenotype production",
      "rules": [
        {
          "id": "W03.BREED.01",
          "statement": "The Wave 03 witness uses three independent diploid hopper loci for return, synchrony and settling; it does not generalize to colony donors.",
          "player_or_agent_decision": "Apply the named fixture only to its declared scope.",
          "observable_consequence": "Unavailable colony formulas stay unavailable.",
          "origin_category": "RRR_native_extension",
          "refines": [
            "W02.GENE.02",
            "W02.GENE.03",
            "W02.GENE.08",
            "W02.PROJECT.HOP"
          ],
          "status": "proposed_foundation"
        },
        {
          "id": "W03.BREED.02",
          "statement": "Offspring inherit one allele per parent per locus in this fixture; mutation, linkage and reproductive failure are separately configured, not implied.",
          "player_or_agent_decision": "Choose parents with complementary contributions.",
          "observable_consequence": "The support of possible offspring is enumerable and does not default to parental maxima.",
          "origin_category": "RRR_native_extension",
          "refines": [
            "W02.GENE.02",
            "W02.GENE.03",
            "W02.GENE.08",
            "W02.PROJECT.HOP"
          ],
          "status": "proposed_foundation"
        },
        {
          "id": "W03.BREED.03",
          "statement": "Genotype potential, developmental expression, current condition, preparation and mounting remain separate records.",
          "player_or_agent_decision": "Correct the relevant cause of a disappointing result.",
          "observable_consequence": "Remounting a part does not rewrite its pedigree.",
          "origin_category": "RRR_native_extension",
          "refines": [
            "W02.GENE.02",
            "W02.GENE.03",
            "W02.GENE.08",
            "W02.PROJECT.HOP"
          ],
          "status": "proposed_foundation"
        },
        {
          "id": "W03.BREED.04",
          "statement": "A founder contribution may matter across generations even when first-generation offspring do not meet the final target.",
          "player_or_agent_decision": "Choose immediate donor use versus intermediate breeding stock.",
          "observable_consequence": "A failed premium target can still produce useful ordinary assemblies.",
          "origin_category": "RRR_native_extension",
          "refines": [
            "W02.GENE.02",
            "W02.GENE.03",
            "W02.GENE.08",
            "W02.PROJECT.HOP"
          ],
          "status": "proposed_foundation"
        },
        {
          "id": "W03.BREED.05",
          "statement": "Breeding forecasts state what they are conditional on, including initiated count, survival, assay and delivery window.",
          "player_or_agent_decision": "Decide whether a forecast supports a promise.",
          "observable_consequence": "A conditional one-in-sixteen genotype chance is never shown as a guaranteed sale rate.",
          "origin_category": "RRR_native_extension",
          "refines": [
            "W02.GENE.02",
            "W02.GENE.03",
            "W02.GENE.08",
            "W02.PROJECT.HOP"
          ],
          "status": "proposed_foundation"
        },
        {
          "id": "W03.BREED.06",
          "statement": "Project forecasts use compatible observations or explicit tested genotype knowledge; engine-truth enumeration is a debug witness, not default UI.",
          "player_or_agent_decision": "Acquire relevant evidence rather than access omniscient suggestions.",
          "observable_consequence": "The breeder panel can state insufficient evidence.",
          "origin_category": "RRR_native_extension",
          "refines": [
            "W02.GENE.02",
            "W02.GENE.03",
            "W02.GENE.08",
            "W02.PROJECT.HOP"
          ],
          "status": "proposed_foundation"
        },
        {
          "id": "W03.BREED.07",
          "statement": "A demonstrated line claim names protocol, trait acceptance, tested count, brood identities and dates; one winning racer does not certify a line.",
          "player_or_agent_decision": "Publish a narrow reproducibility claim.",
          "observable_consequence": "Customers can distinguish a sample observation from a guarantee.",
          "origin_category": "RRR_native_extension",
          "refines": [
            "W02.GENE.02",
            "W02.GENE.03",
            "W02.GENE.08",
            "W02.PROJECT.HOP"
          ],
          "status": "proposed_foundation"
        },
        {
          "id": "W03.BREED.08",
          "statement": "Fertility, initiated young, surviving young, saleable young and retained replacements are counted separately.",
          "player_or_agent_decision": "Improve the bottleneck the business actually has.",
          "observable_consequence": "A larger clutch may not increase saleable output.",
          "origin_category": "RRR_native_extension",
          "refines": [
            "W02.GENE.02",
            "W02.GENE.03",
            "W02.GENE.08",
            "W02.PROJECT.HOP"
          ],
          "status": "proposed_foundation"
        },
        {
          "id": "W03.BREED.09",
          "statement": "A project may target production reliability or appearance instead of maximal race output.",
          "player_or_agent_decision": "Breed for wholesale, collection or a competitive build.",
          "observable_consequence": "Modest racing stock can be the preferred commercial parent.",
          "origin_category": "RRR_native_extension",
          "refines": [
            "W02.GENE.02",
            "W02.GENE.03",
            "W02.GENE.08",
            "W02.PROJECT.HOP"
          ],
          "status": "proposed_foundation"
        },
        {
          "id": "W03.BREED.10",
          "statement": "Each batch has a stable event-local outcome seed in the implementation witness; unrelated actions and view refreshes do not reroll it.",
          "player_or_agent_decision": "Replay or inspect without changing ancestry.",
          "observable_consequence": "Splitting a clock advance does not change the cohort.",
          "origin_category": "RRR_native_extension",
          "refines": [
            "W02.GENE.02",
            "W02.GENE.03",
            "W02.GENE.08",
            "W02.PROJECT.HOP"
          ],
          "status": "proposed_foundation"
        }
      ]
    },
    {
      "id": "W03.GROUP.CAPACITY",
      "title": "Future capacity and delayed cohorts",
      "rules": [
        {
          "id": "W03.CAPACITY.01",
          "statement": "A production commitment reserves identified parents, mating time, incubation, grow-out, transition space and planned output handling.",
          "player_or_agent_decision": "Inspect the full path before starting another brood.",
          "observable_consequence": "An empty mating compartment does not conceal full future grow-out.",
          "origin_category": "RRR_native_integration",
          "refines": [
            "W02.TANK.06",
            "W02.TANK.09",
            "W02.TANK.10"
          ],
          "status": "proposed_foundation"
        },
        {
          "id": "W03.CAPACITY.02",
          "statement": "Capacity claims use resource-specific physical or declared fixture units and half-open intervals [start,end).",
          "player_or_agent_decision": "Compare overlapping occupancy on the same resource.",
          "observable_consequence": "A departing cohort and arriving cohort can share a boundary without double occupancy.",
          "origin_category": "RRR_native_integration",
          "refines": [
            "W02.TANK.06",
            "W02.TANK.09",
            "W02.TANK.10"
          ],
          "status": "proposed_foundation"
        },
        {
          "id": "W03.CAPACITY.03",
          "statement": "The safe preset reserves the bounded initiated cohort count, not merely expected survivors; risk-taking overflow plans must name actual capacity or services.",
          "player_or_agent_decision": "Pay for capacity or accept a declared alternative.",
          "observable_consequence": "A probability forecast cannot manufacture physical space.",
          "origin_category": "RRR_native_integration",
          "refines": [
            "W02.TANK.06",
            "W02.TANK.09",
            "W02.TANK.10"
          ],
          "status": "proposed_foundation"
        },
        {
          "id": "W03.CAPACITY.04",
          "statement": "A multi-resource reservation commits atomically or not at all.",
          "player_or_agent_decision": "Attempt a new plan.",
          "observable_consequence": "Failure does not strand a parent reservation or consume half the supplies.",
          "origin_category": "RRR_native_integration",
          "refines": [
            "W02.TANK.06",
            "W02.TANK.09",
            "W02.TANK.10"
          ],
          "status": "proposed_foundation"
        },
        {
          "id": "W03.CAPACITY.05",
          "statement": "A delay to a living cohort preserves the actual animals and their occupancy.",
          "player_or_agent_decision": "Reschedule later production or acquire overflow.",
          "observable_consequence": "Living young are not deleted because a spreadsheet says their stage ended.",
          "origin_category": "RRR_native_integration",
          "refines": [
            "W02.TANK.06",
            "W02.TANK.09",
            "W02.TANK.10"
          ],
          "status": "proposed_foundation"
        },
        {
          "id": "W03.CAPACITY.06",
          "statement": "When a delay conflicts only with unstarted jobs, pause those whole jobs and release their unspent reservations for replanning.",
          "player_or_agent_decision": "Review which future contracts require revision.",
          "observable_consequence": "No unstarted job retains hidden partial resources.",
          "origin_category": "RRR_native_integration",
          "refines": [
            "W02.TANK.06",
            "W02.TANK.09",
            "W02.TANK.10"
          ],
          "status": "proposed_foundation"
        },
        {
          "id": "W03.CAPACITY.07",
          "statement": "A conflict between two existing living cohorts requires actual relocation or other declared handling; the witness refuses to pretend that pausing resolves it.",
          "player_or_agent_decision": "Arrange supported overflow or a stated consequence.",
          "observable_consequence": "The unimplemented relocation path is flagged, not silently credited as safe.",
          "origin_category": "RRR_native_integration",
          "refines": [
            "W02.TANK.06",
            "W02.TANK.09",
            "W02.TANK.10"
          ],
          "status": "proposed_foundation"
        },
        {
          "id": "W03.CAPACITY.08",
          "statement": "Starting costs, ongoing care, deadlines, maturation and actual settlement use the same world clock.",
          "player_or_agent_decision": "Race, travel or fast-forward while production operates.",
          "observable_consequence": "Waiting advances costs as well as opportunities.",
          "origin_category": "RRR_native_integration",
          "refines": [
            "W02.TANK.06",
            "W02.TANK.09",
            "W02.TANK.10"
          ],
          "status": "proposed_foundation"
        },
        {
          "id": "W03.CAPACITY.09",
          "statement": "Default offline behavior remains paused world time; no return schedule is imposed.",
          "player_or_agent_decision": "Leave the game without maintaining a real-world appointment.",
          "observable_consequence": "Real time alone does not kill or feed stock in the default branch.",
          "origin_category": "RRR_native_integration",
          "refines": [
            "W02.TANK.06",
            "W02.TANK.09",
            "W02.TANK.10"
          ],
          "status": "proposed_foundation"
        },
        {
          "id": "W03.CAPACITY.10",
          "statement": "Mature stock still needs holding; storage and replacement space remain obligations after grow-out.",
          "player_or_agent_decision": "Reserve output handling rather than ending the schedule at maturity.",
          "observable_consequence": "Production completion does not free space occupied by unsold animals.",
          "origin_category": "RRR_native_integration",
          "refines": [
            "W02.TANK.06",
            "W02.TANK.09",
            "W02.TANK.10"
          ],
          "status": "proposed_foundation"
        },
        {
          "id": "W03.CAPACITY.11",
          "statement": "Pausing new production does not pause care for existing stock.",
          "player_or_agent_decision": "Protect working capital or pay for help.",
          "observable_consequence": "A stopped business remains responsible for living inventory.",
          "origin_category": "RRR_native_integration",
          "refines": [
            "W02.TANK.06",
            "W02.TANK.09",
            "W02.TANK.10"
          ],
          "status": "proposed_foundation"
        }
      ]
    },
    {
      "id": "W03.GROUP.CUSTODY",
      "title": "Anatomy, components and kit assembly",
      "rules": [
        {
          "id": "W03.CUSTODY.01",
          "statement": "An anatomy token identifies a physical donor region; extraction transfers it from that individual to a prepared component.",
          "player_or_agent_decision": "Choose a harvest plan.",
          "observable_consequence": "The same hind joint cannot remain simultaneously on the live donor and in a kit.",
          "origin_category": "source_hobby_translation_plus_RRR_extension",
          "refines": [
            "W02.PART.01",
            "W02.PART.02",
            "W02.PART.07"
          ],
          "status": "proposed_foundation"
        },
        {
          "id": "W03.CUSTODY.02",
          "statement": "A complete multi-role assembly contributes its physical structures once, regardless of the number of functional roles it covers.",
          "player_or_agent_decision": "Use a whole Hopper set or a subassembly.",
          "observable_consequence": "Hind limbs, jump and landing roles do not multiply mass, price or stock count.",
          "origin_category": "source_hobby_translation_plus_RRR_extension",
          "refines": [
            "W02.PART.01",
            "W02.PART.02",
            "W02.PART.07"
          ],
          "status": "proposed_foundation"
        },
        {
          "id": "W03.CUSTODY.03",
          "statement": "Alternative harvest plans sharing anatomy are exclusive; disjoint plans can coexist.",
          "player_or_agent_decision": "Choose a complete hopper or separated joint product; allocate scarab tissues independently where possible.",
          "observable_consequence": "One donor can supply several honest products without duplicated loot.",
          "origin_category": "source_hobby_translation_plus_RRR_extension",
          "refines": [
            "W02.PART.01",
            "W02.PART.02",
            "W02.PART.07"
          ],
          "status": "proposed_foundation"
        },
        {
          "id": "W03.CUSTODY.04",
          "statement": "Protected parents require explicit release before irreversible preparation.",
          "player_or_agent_decision": "Trade future reproductive value for immediate use deliberately.",
          "observable_consequence": "Automation cannot casually consume the sole retained founder.",
          "origin_category": "source_hobby_translation_plus_RRR_extension",
          "refines": [
            "W02.PART.01",
            "W02.PART.02",
            "W02.PART.07"
          ],
          "status": "proposed_foundation"
        },
        {
          "id": "W03.CUSTODY.05",
          "statement": "Vital extraction changes the donor living state; nonvital extraction still changes anatomy and condition.",
          "player_or_agent_decision": "Select the preparation and retained stock.",
          "observable_consequence": "A body record surviving in the database is not proof its animal remains intact.",
          "origin_category": "source_hobby_translation_plus_RRR_extension",
          "refines": [
            "W02.PART.01",
            "W02.PART.02",
            "W02.PART.07"
          ],
          "status": "proposed_foundation"
        },
        {
          "id": "W03.CUSTODY.06",
          "statement": "A packaged kit owns custody of its components; loose-component sale or installation first requires a declared unpack operation.",
          "player_or_agent_decision": "Keep, sell, unpack or assemble the kit.",
          "observable_consequence": "A packaged part cannot be sold separately while the kit remains complete.",
          "origin_category": "source_hobby_translation_plus_RRR_extension",
          "refines": [
            "W02.PART.01",
            "W02.PART.02",
            "W02.PART.07"
          ],
          "status": "proposed_foundation"
        },
        {
          "id": "W03.CUSTODY.07",
          "statement": "Buying a kit transfers its real contents and recipe; assembly remains an actual sequence using those contents.",
          "player_or_agent_decision": "Place and fit the parts personally or use the supported guided process.",
          "observable_consequence": "A purchased tin is not an instant unearned assembled racer.",
          "origin_category": "source_hobby_translation_plus_RRR_extension",
          "refines": [
            "W02.PART.01",
            "W02.PART.02",
            "W02.PART.07"
          ],
          "status": "proposed_foundation"
        },
        {
          "id": "W03.CUSTODY.08",
          "statement": "Installation changes component custody and the named host configuration, not its germline.",
          "player_or_agent_decision": "Fit a new graft.",
          "observable_consequence": "The host retains identity and its inherited genome.",
          "origin_category": "source_hobby_translation_plus_RRR_extension",
          "refines": [
            "W02.PART.01",
            "W02.PART.02",
            "W02.PART.07"
          ],
          "status": "proposed_foundation"
        },
        {
          "id": "W03.CUSTODY.09",
          "statement": "Geometry feasibility and event legality are separate, capability-based results.",
          "player_or_agent_decision": "Solve interference or choose another legal event.",
          "observable_consequence": "Horn-and-foil combinations are not banned by a returning one-brow-slot rule.",
          "origin_category": "source_hobby_translation_plus_RRR_extension",
          "refines": [
            "W02.PART.01",
            "W02.PART.02",
            "W02.PART.07"
          ],
          "status": "proposed_foundation"
        },
        {
          "id": "W03.CUSTODY.10",
          "statement": "A failed multi-asset commit leaves ownership, money and custody unchanged.",
          "player_or_agent_decision": "Correct the missing item and retry.",
          "observable_consequence": "No partial kit or sale is silently committed.",
          "origin_category": "source_hobby_translation_plus_RRR_extension",
          "refines": [
            "W02.PART.01",
            "W02.PART.02",
            "W02.PART.07"
          ],
          "status": "proposed_foundation"
        }
      ]
    },
    {
      "id": "W03.GROUP.CASH",
      "title": "Funded orders and earned operating margin",
      "rules": [
        {
          "id": "W03.CASH.01",
          "statement": "A firm standing order reserves actual buyer funds for its remaining accepted quantity.",
          "player_or_agent_decision": "Accept a funded commitment rather than an unfunded asking price.",
          "observable_consequence": "A visible order has a finite budget; escrow is not seller revenue.",
          "origin_category": "RRR_native_integration",
          "refines": [
            "W02.MONEY.03",
            "W02.MONEY.04",
            "W02.MONEY.05",
            "W02.MONEY.14"
          ],
          "status": "proposed_foundation"
        },
        {
          "id": "W03.CASH.02",
          "statement": "A casual spot sale can settle immediately; the standing-order path does not add compulsory waiting to every transaction.",
          "player_or_agent_decision": "Choose immediate sale or production contracting.",
          "observable_consequence": "The ordinary return-and-sell loop remains accessible.",
          "origin_category": "RRR_native_integration",
          "refines": [
            "W02.MONEY.03",
            "W02.MONEY.04",
            "W02.MONEY.05",
            "W02.MONEY.14"
          ],
          "status": "proposed_foundation"
        },
        {
          "id": "W03.CASH.03",
          "statement": "Order acceptance uses product identity, declared evidence and condition policy; engine-hidden genotype is not an undeclared acceptance requirement.",
          "player_or_agent_decision": "Test, substitute by agreement or sell in another channel.",
          "observable_consequence": "A known ordinary product can be accepted without pedigree certification.",
          "origin_category": "RRR_native_integration",
          "refines": [
            "W02.MONEY.03",
            "W02.MONEY.04",
            "W02.MONEY.05",
            "W02.MONEY.14"
          ],
          "status": "proposed_foundation"
        },
        {
          "id": "W03.CASH.04",
          "statement": "Delivery transfers accepted assets and payment together; repeated event IDs replay the original receipt without a second payment.",
          "player_or_agent_decision": "Commit or retry a delivery.",
          "observable_consequence": "Reloading or double-clicking cannot generate extra income.",
          "origin_category": "RRR_native_integration",
          "refines": [
            "W02.MONEY.03",
            "W02.MONEY.04",
            "W02.MONEY.05",
            "W02.MONEY.14"
          ],
          "status": "proposed_foundation"
        },
        {
          "id": "W03.CASH.05",
          "statement": "A repeated transaction key with a different payload is rejected.",
          "player_or_agent_decision": "Submit a genuinely new action with a new identity.",
          "observable_consequence": "Retries cannot be repurposed into unlogged changes.",
          "origin_category": "RRR_native_integration",
          "refines": [
            "W02.MONEY.03",
            "W02.MONEY.04",
            "W02.MONEY.05",
            "W02.MONEY.14"
          ],
          "status": "proposed_foundation"
        },
        {
          "id": "W03.CASH.06",
          "statement": "Remaining escrow returns to the buyer when the order closes under its cancellation terms.",
          "player_or_agent_decision": "Cancel or settle the outstanding obligation.",
          "observable_consequence": "Unspent funds do not become a cancellation profit.",
          "origin_category": "RRR_native_integration",
          "refines": [
            "W02.MONEY.03",
            "W02.MONEY.04",
            "W02.MONEY.05",
            "W02.MONEY.14"
          ],
          "status": "proposed_foundation"
        },
        {
          "id": "W03.CASH.07",
          "statement": "Delivery at the stated final tick is valid before end-of-tick expiry; transport arrival is not assumed at dispatch.",
          "player_or_agent_decision": "Plan arrival rather than merely shipment.",
          "observable_consequence": "Deadline boundaries have one reproducible interpretation.",
          "origin_category": "RRR_native_integration",
          "refines": [
            "W02.MONEY.03",
            "W02.MONEY.04",
            "W02.MONEY.05",
            "W02.MONEY.14"
          ],
          "status": "proposed_foundation"
        },
        {
          "id": "W03.CASH.08",
          "statement": "Cash received, operating payments, unsold stock, retained productive stock, earmarks and capital purchases are distinct quantities.",
          "player_or_agent_decision": "Choose reinvestment while preserving care money.",
          "observable_consequence": "A brood summary cannot count a retained breeder as both sale and inventory.",
          "origin_category": "RRR_native_integration",
          "refines": [
            "W02.MONEY.03",
            "W02.MONEY.04",
            "W02.MONEY.05",
            "W02.MONEY.14"
          ],
          "status": "proposed_foundation"
        },
        {
          "id": "W03.CASH.09",
          "statement": "A product sale uses a funded customer; market replenishment requires a declared demand and budget source outside the closed fixture.",
          "player_or_agent_decision": "Find recurring customers or new markets.",
          "observable_consequence": "Advancing time alone does not replenish every buyer wallet infinitely.",
          "origin_category": "RRR_native_integration",
          "refines": [
            "W02.MONEY.03",
            "W02.MONEY.04",
            "W02.MONEY.05",
            "W02.MONEY.14"
          ],
          "status": "proposed_foundation"
        },
        {
          "id": "W03.CASH.10",
          "statement": "Cash planning includes incurred and future care; inability to start a new brood does not erase current obligations.",
          "player_or_agent_decision": "Hold a working reserve, reduce new starts or buy services.",
          "observable_consequence": "An advertised margin does not imply affordable growth.",
          "origin_category": "RRR_native_integration",
          "refines": [
            "W02.MONEY.03",
            "W02.MONEY.04",
            "W02.MONEY.05",
            "W02.MONEY.14"
          ],
          "status": "proposed_foundation"
        },
        {
          "id": "W03.CASH.11",
          "statement": "Low quality relative to one project can still have ordinary kit, service or collector demand; no universal profitable outlet is guaranteed.",
          "player_or_agent_decision": "Choose the relevant buyer or retain stock.",
          "observable_consequence": "Selling surplus is useful without turning every animal into fixed cash.",
          "origin_category": "RRR_native_integration",
          "refines": [
            "W02.MONEY.03",
            "W02.MONEY.04",
            "W02.MONEY.05",
            "W02.MONEY.14"
          ],
          "status": "proposed_foundation"
        },
        {
          "id": "W03.CASH.12",
          "statement": "Every monetary figure in the supplied integration is a fixture with initial assets and omitted costs disclosed.",
          "player_or_agent_decision": "Use it to check consistency, not predict final profits.",
          "observable_consequence": "A positive single cohort is not declared a sustainable economy.",
          "origin_category": "RRR_native_integration",
          "refines": [
            "W02.MONEY.03",
            "W02.MONEY.04",
            "W02.MONEY.05",
            "W02.MONEY.14"
          ],
          "status": "proposed_foundation"
        }
      ]
    },
    {
      "id": "W03.GROUP.PERFORMANCE",
      "title": "Trait-to-part and part-to-run contracts",
      "rules": [
        {
          "id": "W03.PERFORMANCE.01",
          "statement": "The reference-hobby distinction between drive output, leverage, contact and handling remains explicit.",
          "player_or_agent_decision": "Choose components affecting the intended mechanical variable.",
          "observable_consequence": "A horn is not renamed as a motor; foot grip does not invent energy.",
          "origin_category": "source_hobby_translation_plus_RRR_extension",
          "refines": [
            "W02.PART.12",
            "W02.BUFF.06",
            "W02.RACE.07"
          ],
          "status": "proposed_foundation"
        },
        {
          "id": "W03.PERFORMANCE.02",
          "statement": "Each controlled comparison fixes host mass, reserve, surface, configuration and protocol except the stated changed input.",
          "player_or_agent_decision": "Compare a donor change or tuning action.",
          "observable_consequence": "Measured changes are attributed to a declared cause.",
          "origin_category": "source_hobby_translation_plus_RRR_extension",
          "refines": [
            "W02.PART.12",
            "W02.BUFF.06",
            "W02.RACE.07"
          ],
          "status": "proposed_foundation"
        },
        {
          "id": "W03.PERFORMANCE.03",
          "statement": "The hopper fixture maps return to useful launch energy, timing error to transfer loss and settling tissue to recovery time.",
          "player_or_agent_decision": "Breed and fit the desired combination.",
          "observable_consequence": "A selected assembly can improve several results at the same input energy.",
          "origin_category": "source_hobby_translation_plus_RRR_extension",
          "refines": [
            "W02.PART.12",
            "W02.BUFF.06",
            "W02.RACE.07"
          ],
          "status": "proposed_foundation"
        },
        {
          "id": "W03.PERFORMANCE.04",
          "statement": "Mounting error is a setup term separate from inherited timing.",
          "player_or_agent_decision": "Align a useful donor correctly.",
          "observable_consequence": "A remount changes the result without improving its genes.",
          "origin_category": "source_hobby_translation_plus_RRR_extension",
          "refines": [
            "W02.PART.12",
            "W02.BUFF.06",
            "W02.RACE.07"
          ],
          "status": "proposed_foundation"
        },
        {
          "id": "W03.PERFORMANCE.05",
          "statement": "Drive cadence and stall force feed a loaded one-dimensional bench; leverage changes force and free stride speed in opposite directions.",
          "player_or_agent_decision": "Try a faster motor or different hip geometry.",
          "observable_consequence": "A new drive can demonstrably run the same bench faster.",
          "origin_category": "source_hobby_translation_plus_RRR_extension",
          "refines": [
            "W02.PART.12",
            "W02.BUFF.06",
            "W02.RACE.07"
          ],
          "status": "proposed_foundation"
        },
        {
          "id": "W03.PERFORMANCE.06",
          "statement": "Shared delivery is allocated across simultaneous demands; no organ receives the whole supply independently.",
          "player_or_agent_decision": "Configure priorities or supply capacity in the eventual runtime.",
          "observable_consequence": "Requested outputs cannot exceed declared delivery together.",
          "origin_category": "source_hobby_translation_plus_RRR_extension",
          "refines": [
            "W02.PART.12",
            "W02.BUFF.06",
            "W02.RACE.07"
          ],
          "status": "proposed_foundation"
        },
        {
          "id": "W03.PERFORMANCE.07",
          "statement": "Normalized fixtures have explicit units, input bounds and protocol versions; they are not claims about real insect scale.",
          "player_or_agent_decision": "Replace coefficients through calibration without rewriting history.",
          "observable_consequence": "No physical speed or jump height is falsely asserted.",
          "origin_category": "source_hobby_translation_plus_RRR_extension",
          "refines": [
            "W02.PART.12",
            "W02.BUFF.06",
            "W02.RACE.07"
          ],
          "status": "proposed_foundation"
        },
        {
          "id": "W03.PERFORMANCE.08",
          "statement": "A component test is not a race result; the eventual course simulation must consume the same accepted trait contract.",
          "player_or_agent_decision": "Validate actual racing separately.",
          "observable_consequence": "No fixture automatically grants a win, qualification or trophy.",
          "origin_category": "source_hobby_translation_plus_RRR_extension",
          "refines": [
            "W02.PART.12",
            "W02.BUFF.06",
            "W02.RACE.07"
          ],
          "status": "proposed_foundation"
        },
        {
          "id": "W03.PERFORMANCE.09",
          "statement": "Genuine improvements remain permitted without obligatory drawbacks.",
          "player_or_agent_decision": "Keep an exceptionally useful find.",
          "observable_consequence": "Equal-mass, equal-input improvement is not arbitrarily weakened to force a tradeoff.",
          "origin_category": "source_hobby_translation_plus_RRR_extension",
          "refines": [
            "W02.PART.12",
            "W02.BUFF.06",
            "W02.RACE.07"
          ],
          "status": "proposed_foundation"
        },
        {
          "id": "W03.PERFORMANCE.10",
          "statement": "The ordinary purchase route can obtain the same functional quality as breeding; different acquisition routes change history and cost, not hidden performance multipliers.",
          "player_or_agent_decision": "Buy, find or breed a good component.",
          "observable_consequence": "A shop customer is not made intrinsically inferior to a breeder.",
          "origin_category": "source_hobby_translation_plus_RRR_extension",
          "refines": [
            "W02.PART.12",
            "W02.BUFF.06",
            "W02.RACE.07"
          ],
          "status": "proposed_foundation"
        }
      ]
    },
    {
      "id": "W03.GROUP.POLISH",
      "title": "Interaction and presentation contracts",
      "rules": [
        {
          "id": "W03.POLISH.01",
          "statement": "The intake primary view has Keep, Review and Sale-candidate groups with a short reason for each assignment.",
          "player_or_agent_decision": "Handle a mixed case quickly.",
          "observable_consequence": "Useful decisions are visible before advanced numbers.",
          "origin_category": "RRR_native_integration",
          "refines": [
            "W02.TANK.15",
            "W02.SORT.04",
            "W02.RISK.08"
          ],
          "status": "proposed_foundation"
        },
        {
          "id": "W03.POLISH.02",
          "statement": "Expert inspection expands observations, parentage evidence, anatomy, stage and project match without navigating to a disconnected application.",
          "player_or_agent_decision": "Investigate a promising specimen.",
          "observable_consequence": "Depth is optional but immediately related to the same animal.",
          "origin_category": "RRR_native_integration",
          "refines": [
            "W02.TANK.15",
            "W02.SORT.04",
            "W02.RISK.08"
          ],
          "status": "proposed_foundation"
        },
        {
          "id": "W03.POLISH.03",
          "statement": "A brood card states current stage, next transition, live occupancy, future occupancy, reserved replacements and the first blocking condition.",
          "player_or_agent_decision": "Fix the actual constraint.",
          "observable_consequence": "Full grow-out is not mislabeled as no breeding slot.",
          "origin_category": "RRR_native_integration",
          "refines": [
            "W02.TANK.15",
            "W02.SORT.04",
            "W02.RISK.08"
          ],
          "status": "proposed_foundation"
        },
        {
          "id": "W03.POLISH.04",
          "statement": "An earnings card shows received, spent, outstanding, retained and available-after-planned-care separately.",
          "player_or_agent_decision": "Choose reinvestment or a safer reserve.",
          "observable_consequence": "Expected income is never styled as already spendable cash.",
          "origin_category": "RRR_native_integration",
          "refines": [
            "W02.TANK.15",
            "W02.SORT.04",
            "W02.RISK.08"
          ],
          "status": "proposed_foundation"
        },
        {
          "id": "W03.POLISH.05",
          "statement": "Batch actions preview affected identities and protections; routine care operates through chosen presets or services.",
          "player_or_agent_decision": "Approve a useful batch rather than repeat individual feeding clicks.",
          "observable_consequence": "Large operations add strategic planning rather than proportional click burden.",
          "origin_category": "RRR_native_integration",
          "refines": [
            "W02.TANK.15",
            "W02.SORT.04",
            "W02.RISK.08"
          ],
          "status": "proposed_foundation"
        },
        {
          "id": "W03.POLISH.06",
          "statement": "Breeder marks, donor lineage, prepared anatomy and build identity remain visible in product cards and finished racers.",
          "player_or_agent_decision": "Recognize and show the part that was earned.",
          "observable_consequence": "The biological hobby identity survives optimization and batch processing.",
          "origin_category": "RRR_native_integration",
          "refines": [
            "W02.TANK.15",
            "W02.SORT.04",
            "W02.RISK.08"
          ],
          "status": "proposed_foundation"
        },
        {
          "id": "W03.POLISH.07",
          "statement": "A beautiful unusual specimen can be kept by preference without a racing justification; presentation and provenance have first-class fields.",
          "player_or_agent_decision": "Collect or finish a distinctive build.",
          "observable_consequence": "The world is not reduced to one numeric optimizer.",
          "origin_category": "RRR_native_integration",
          "refines": [
            "W02.TANK.15",
            "W02.SORT.04",
            "W02.RISK.08"
          ],
          "status": "proposed_foundation"
        },
        {
          "id": "W03.POLISH.08",
          "statement": "No visual/usability polish is credited as rendered or playtested in this wave.",
          "player_or_agent_decision": "Carry the interaction specification to the next implementation.",
          "observable_consequence": "Design ambition remains open rather than a text-only mockup being called finished UI.",
          "origin_category": "RRR_native_integration",
          "refines": [
            "W02.TANK.15",
            "W02.SORT.04",
            "W02.RISK.08"
          ],
          "status": "proposed_foundation"
        }
      ]
    },
    {
      "id": "W03.GROUP.REVISION",
      "title": "Versioning, testing and handoff",
      "rules": [
        {
          "id": "W03.REVISION.01",
          "statement": "Append Wave 03 under development_waves and preserve all prior base records unchanged in canonical JSON content; retain the baseline file verbatim.",
          "player_or_agent_decision": "Load base history plus new records.",
          "observable_consequence": "Existing IDs, source notes, seed records and old results do not disappear.",
          "origin_category": "RRR_native_support",
          "refines": [
            "W02.CONTRACT.04",
            "W02.ACCEPT.QUALITY"
          ],
          "status": "proposed_foundation"
        },
        {
          "id": "W03.REVISION.02",
          "statement": "Each refinement names the prior rule or record; a active-view projection may select current versions without editing stored history.",
          "player_or_agent_decision": "Revise a field or predicate intentionally.",
          "observable_consequence": "Catalogue changes cannot silently reroll stock.",
          "origin_category": "RRR_native_support",
          "refines": [
            "W02.CONTRACT.04",
            "W02.ACCEPT.QUALITY"
          ],
          "status": "proposed_foundation"
        },
        {
          "id": "W03.REVISION.03",
          "statement": "Test structural integrity, adversarial operations, controlled mechanisms and complete gameplay as distinct evidence categories.",
          "player_or_agent_decision": "Report exactly what was run.",
          "observable_consequence": "A model witness is not sold as a playable game.",
          "origin_category": "RRR_native_support",
          "refines": [
            "W02.CONTRACT.04",
            "W02.ACCEPT.QUALITY"
          ],
          "status": "proposed_foundation"
        },
        {
          "id": "W03.REVISION.04",
          "statement": "Unknown quality or novelty findings cannot be compensated by more passed tests, lower complexity or faster output.",
          "player_or_agent_decision": "Keep the appropriate acceptance gate open.",
          "observable_consequence": "No weighted average erases a hard guardrail failure.",
          "origin_category": "RRR_native_support",
          "refines": [
            "W02.CONTRACT.04",
            "W02.ACCEPT.QUALITY"
          ],
          "status": "proposed_foundation"
        },
        {
          "id": "W03.REVISION.05",
          "statement": "The next primary task connects these same traits to an assembled racer on modular circuits with real outcomes, not an unrelated scoring layer.",
          "player_or_agent_decision": "Continue the development graph.",
          "observable_consequence": "The supply game remains accountable to exciting racing.",
          "origin_category": "RRR_native_support",
          "refines": [
            "W02.CONTRACT.04",
            "W02.ACCEPT.QUALITY"
          ],
          "status": "proposed_foundation"
        }
      ]
    }
  ],
  "entity_extensions": [
    {
      "id": "W03.ENTITY.PROJECT",
      "fields": [
        "id",
        "version",
        "use",
        "product_id",
        "target_trait_predicates",
        "current_evidence",
        "missing_complement",
        "protected_specimen_ids",
        "capacity_budget",
        "spending_budget",
        "status"
      ],
      "invariants": [
        "No global best-insect score replaces purpose.",
        "Default advice is evidence-bound."
      ]
    },
    {
      "id": "W03.ENTITY.OBSERVATION",
      "fields": [
        "id",
        "subject_id",
        "trait_id",
        "protocol_version",
        "load",
        "surface",
        "stage",
        "condition",
        "world_time",
        "method",
        "lower",
        "upper",
        "uncertainty_kind",
        "owner_knowledge_scope"
      ],
      "invariants": [
        "Unknown remains unknown.",
        "Protocol-incompatible results cannot certify a selected order."
      ]
    },
    {
      "id": "W03.ENTITY.BROOD_PLAN",
      "fields": [
        "id",
        "profile_version",
        "parent_ids",
        "initiation_bound",
        "conditional_outcome_model",
        "stage_windows",
        "resources",
        "future_reservations",
        "supplies",
        "replacement_policy",
        "linked_orders",
        "delay_policy",
        "execution_state"
      ],
      "invariants": [
        "Future occupancy is not expected sales.",
        "Already-live offspring remain obligations."
      ]
    },
    {
      "id": "W03.ENTITY.ANATOMY_ALLOCATION",
      "fields": [
        "specimen_id",
        "region_token",
        "current_holder",
        "allocation_event",
        "product_id",
        "vital_consequence",
        "condition",
        "version"
      ],
      "invariants": [
        "One physical region has one current location.",
        "Complete assemblies and subparts do not create duplicate matter."
      ]
    },
    {
      "id": "W03.ENTITY.FUNDED_ORDER",
      "fields": [
        "id",
        "buyer",
        "seller_or_open_offer",
        "budget_source",
        "escrow",
        "product",
        "quantity",
        "acceptance_protocol",
        "requirements",
        "arrival_deadline",
        "partial_delivery_policy",
        "substitution_policy",
        "cancellation_policy",
        "reserved_assets",
        "delivered_assets",
        "payment_state"
      ],
      "invariants": [
        "Only accepted delivered units earn receipts.",
        "Escrow plus accounts is conserved in the closed witness."
      ]
    },
    {
      "id": "W03.ENTITY.BENCH_RESULT",
      "fields": [
        "id",
        "protocol_version",
        "input_build_version",
        "changed_variable",
        "unit_system",
        "fixed_conditions",
        "measurements",
        "energy_used",
        "limitations",
        "result_kind"
      ],
      "invariants": [
        "result_kind=component_bench is not race_result.",
        "A fixture is not physical calibration."
      ]
    }
  ],
  "assay_profiles": [
    {
      "id": "W03.ASSAY.HOP.1",
      "donor_id": "W02.DONOR.HOPPER",
      "product_id": "W02.PROD.HOPPER.1",
      "trait_ids": [
        "W02.TRAIT.HOPPER.1",
        "W02.TRAIT.HOPPER.2",
        "W02.TRAIT.HOPPER.3"
      ],
      "status": "uncalibrated_fixture",
      "units": "normalized M,L,T; energy=M L^2/T^2; fixture g=1 L/T^2",
      "phenotype": {
        "spring_return": "0.55 + 0.075 * R_allele_dosage",
        "phase_error": "0.12 - 0.05 * S_allele_dosage",
        "settle_time": "0.18 - 0.06 * D_allele_dosage"
      },
      "bench": {
        "useful_energy": "preload * spring_return * max(0, 1-phase_error-alignment_error)",
        "launch_speed": "sqrt(2*useful_energy/mass)",
        "air_time": "2*launch_speed*sin(angle)/g",
        "range": "launch_speed*cos(angle)*air_time"
      },
      "assumptions": [
        "Three independent diploid loci; no mutation, dominance or linkage in this witness.",
        "Development is adequate and condition controlled.",
        "Ballistic launch ignores appendage aerodynamics, obstacles and other racers.",
        "Preload is bounded by actual spring/drive in the full runtime; the witness accepts a declared prepaid value."
      ]
    },
    {
      "id": "W03.ASSAY.DRIVE.1",
      "donor_id": "W02.DONOR.CICADA",
      "product_id": "W02.PROD.CICADA.1",
      "trait_ids": [
        "W02.TRAIT.CICADA.1",
        "W02.TRAIT.CICADA.2"
      ],
      "status": "uncalibrated_fixture",
      "units": "normalized M,L,T; force=M L/T^2; power=M L^2/T^3",
      "phenotype": {
        "cadence": "provided measured loaded-drive profile input",
        "stall_force": "provided measured profile input; not falsely derived from a particular named cicada allele"
      },
      "bench": {
        "free_speed": "cadence*stride/leverage",
        "drive_force": "min(Fstall*leverage*max(0,1-speed/free_speed), power_limited_force, traction_ceiling)",
        "acceleration": "(drive_force-resistance)/mass"
      },
      "assumptions": [
        "One-dimensional fixed-resistance comparison.",
        "No full gait, combat, lane, steering, heat or fatigue simulation.",
        "No finite reservoir depletion in this test; consumed work is reported.",
        "Higher speed can require more energy without imposing an invented item penalty."
      ]
    }
  ],
  "interface_contracts": [
    {
      "id": "W03.UI.INTAKE",
      "primary": [
        "specimen identity and visible appearance",
        "Keep/Review/Sale candidate",
        "one reason",
        "selected batch count and actual quote"
      ],
      "expert": [
        "protocol bounds",
        "project missing complement",
        "pedigree evidence",
        "anatomy and stage"
      ],
      "actions": [
        "protect",
        "review",
        "assign project",
        "preview batch sale"
      ],
      "not_claimed": "Rendered interface or usability validation"
    },
    {
      "id": "W03.UI.BROOD",
      "primary": [
        "current stage",
        "next transition",
        "remaining care commitment",
        "capacity blocker",
        "replacement retention"
      ],
      "expert": [
        "future capacity timeline",
        "conditional genotype support",
        "linked orders and alternate handling"
      ],
      "actions": [
        "start feasible plan",
        "pause new starts",
        "replan future cohort",
        "acquire overflow"
      ],
      "not_claimed": "Implemented climate/colony simulation or production UI"
    },
    {
      "id": "W03.UI.CASH",
      "primary": [
        "received",
        "spent",
        "pending",
        "retained stock",
        "available after care reserve"
      ],
      "expert": [
        "buyer funding",
        "cost allocation",
        "capital versus operating spend",
        "unsold inventory"
      ],
      "actions": [
        "deliver",
        "reserve care funds",
        "buy upgrade",
        "inspect contract"
      ],
      "not_claimed": "Sustainable prices or finished economy balance"
    },
    {
      "id": "W03.UI.KIT",
      "primary": [
        "named host",
        "actual component positions",
        "completed assembly stages",
        "visible donor signatures"
      ],
      "expert": [
        "role coverage",
        "source anatomy",
        "measurement protocol",
        "support and motion conflicts"
      ],
      "actions": [
        "place",
        "fit",
        "test",
        "finish",
        "save versioned build"
      ],
      "not_claimed": "Rendered art or physical assembly runtime"
    }
  ],
  "implementation_boundaries": [
    "Only a three-locus independent hopper reproduction fixture; actual fertility, survival and life timing are not simulated.",
    "Capacity uses normalized stage-specific slots; live-cohort overflow relocation, staff and climate are not implemented.",
    "Closed finite-money order witnesses, not a self-renewing market or price calibration.",
    "Prepared-sect pack and simple installation custody, not geometric integration or removal/storage runtime.",
    "Intake routing uses public evidence only; no general breeding optimizer or complete probabilistic observer.",
    "Two controlled normalized benches, not multiplayer/AI races, collision, weapons, track layouts or player controls.",
    "Interaction specifications only; no rendered UI, animation, visual-grade claim or player retention evidence."
  ],
  "validation_artifacts": {
    "code": "w03_model.py",
    "tests": "test_wave03.py",
    "runner": "validate_wave03.py",
    "report": "evidence/validation_report.json",
    "fixtures": "evidence/fixture_outputs.json"
  },
  "operational_projects": [
    {
      "id": "W03.PROJECT.HOPPER",
      "extends": "W02.PROJECT.HOP",
      "use": "breed a selected jumping assembly",
      "donor_id": "W02.DONOR.HOPPER",
      "product_id": "W02.PROD.HOPPER.1",
      "field_run_id": "W02.RUN.VERGE",
      "protocol": "W03.ASSAY.HOP.1",
      "target": {
        "spring_return": {
          "direction": "at_least",
          "value": 0.68
        },
        "phase_error": {
          "direction": "at_most",
          "value": 0.03
        },
        "settle_time": {
          "direction": "at_most",
          "value": 0.08
        }
      },
      "resident_evidence": "High return demonstrated; synchrony is the missing complement.",
      "intake_predicate_basis": "missing_complement_not_final_product",
      "intake_requirements": {
        "phase_error": {
          "direction": "at_most",
          "value": 0.03
        }
      },
      "field_objective": "Find unrelated hopper stock with repeatable paired release; observe short hops and preserve both hind limbs.",
      "keep_logic": "A lower-return animal with demonstrated synchrony may be more useful than another high-return animal with the same deficiency.",
      "sell_or_use_logic": "Intermediate offspring can supply ordinary hopper assemblies; protect future parents and selected personal builds first.",
      "facility_ids": [
        "W02.FAC.RACK",
        "W02.FAC.DRY",
        "W02.FAC.ASSAY"
      ],
      "knowledge_boundary": "Target values are fixture protocol thresholds; exact hidden alleles are not shown by default.",
      "witness": "Genotype support and public routing are checked separately; no omniscient automatic mating optimizer is claimed."
    },
    {
      "id": "W03.PROJECT.WHOLESALE",
      "extends": "W02.PROJECT.STEADY",
      "use": "supply four ordinary hopper assemblies while preserving the line",
      "donor_id": "W02.DONOR.HOPPER",
      "product_id": "W02.PROD.HOPPER.1",
      "field_run_id": "W02.RUN.VERGE",
      "protocol": "W03.ASSAY.HOP.1",
      "target": {
        "spring_return": {
          "direction": "at_least",
          "value": 0.6
        },
        "phase_error": {
          "direction": "at_most",
          "value": 0.08
        }
      },
      "intake_predicate_basis": "complete_product",
      "intake_requirements": {
        "spring_return": {
          "direction": "at_least",
          "value": 0.6
        },
        "phase_error": {
          "direction": "at_most",
          "value": 0.08
        }
      },
      "order_fixture": {
        "quantity": 4,
        "unit_price": 20,
        "arrival_deadline_tick": 8,
        "initial_escrow": 80
      },
      "allocation_fixture": {
        "viable_young": 8,
        "replacement_breeders": 2,
        "commercial_prepared_donors": 4,
        "personal_prepared_donor": 1,
        "unsold_intact_young": 1
      },
      "facility_ids": [
        "W02.FAC.RACK",
        "W02.FAC.DRY",
        "W02.FAC.ASSAY",
        "W02.FAC.BUFFER"
      ],
      "keep_logic": "Protect replacements and the deliberate personal upgrade before allocating deliverable donor anatomy.",
      "witness": "Predetermined eight-survivor cohort; does not estimate probability of fulfilling the order."
    },
    {
      "id": "W03.PROJECT.DRIVE",
      "use": "purchase or produce a genuinely faster drive",
      "donor_id": "W02.DONOR.CICADA",
      "product_id": "W02.PROD.CICADA.1",
      "field_run_id": "W02.RUN.KILN",
      "protocol": "W03.ASSAY.DRIVE.1",
      "target": {
        "matched_straight_time": {
          "direction": "at_most",
          "value": 6.0
        }
      },
      "acquisition": [
        "buy a measured prepared drive",
        "catch a candidate Furnace cicada",
        "breed and rear using a complete life-stage facility"
      ],
      "intake_predicate_basis": "complete_product",
      "intake_requirements": {
        "matched_straight_time": {
          "direction": "at_most",
          "value": 6.0
        }
      },
      "selection_reason": "Loaded cadence and useful force, not loudness or body size; drive and hip leverage remain distinct.",
      "facility_ids": [
        "W02.FAC.FLIGHT",
        "W02.FAC.ASSAY"
      ],
      "fixture_profiles": {
        "ordinary": {
          "cadence": 10,
          "stall_force": 2
        },
        "improved": {
          "cadence": 12,
          "stall_force": 2.5
        }
      },
      "witness": "Part-to-bench comparison checked; cicada genetics, lifecycle and real racing remain outside this witness."
    }
  ],
  "polish_backlog": [
    {
      "id": "W03.POLISH.COPY",
      "status": "addressed_in_new_spec",
      "issue": "Prior generated build descriptions contain duplicate terminal punctuation and repeated generic capacity prose.",
      "resolution": "New text uses concise field-specific decisions and actual interval fixtures; the immutable prior document is not silently edited."
    },
    {
      "id": "W03.POLISH.UNITS",
      "status": "addressed_in_new_spec",
      "issue": "Directional traits could be mistaken for globally calibrated measurements.",
      "resolution": "Name assay protocol, normalized units and fixture bounds; preserve unknown real scale."
    },
    {
      "id": "W03.POLISH.STATE",
      "status": "specified_not_rendered",
      "issue": "Expected income, real cash and retained stock can appear as one reward total.",
      "resolution": "Separate cash-card fields and show pending amounts distinctly."
    },
    {
      "id": "W03.POLISH.IDENTITY",
      "status": "specified_not_rendered",
      "issue": "Batch management can erase collectible and build identity.",
      "resolution": "Retain individual names, donor marks, ancestry evidence and component placement in expandable views."
    }
  ]
}
