"""Authoritative W12 exchange data and readable handoff. Source bodies stay separate."""
from pathlib import Path
import copy, hashlib, json, subprocess
ROOT=Path(__file__).resolve().parents[1]
sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
js="const K=require('./src/maker.js'); console.log(JSON.stringify({briefs:K.BRIEFS,metrics:K.METRICS,mechanisms:K.MECHANISMS}));"
profiles=json.loads(subprocess.check_output(['node','-e',js],cwd=ROOT,text=True))
sources=[
 {'id':'W12.S01','title':'Tamiya — FM-A Balanced Starter Pack, 18710','url':'https://www.tamiya.com/english/products/18710/index.html','checked_on':'2026-09-11','function':'A complete assembly kit and selected upgrade parts supply a coordinated build project.','limit':'No RRR genetics, pricing, manufacturing or product-acceptance coefficient is supplied by this reference.'},
 {'id':'W12.S02','title':'Tamiya — Mini 4WD Setup Guide','url':'https://www.tamiya.com/english/mini4wd/setupguide/setupguide.htm','checked_on':'2026-09-11','function':'Drive output, gearing, contact material, assembly and handling remain distinct decisions.','limit':'Physical Mini 4WD is a separate reference layer from Gaiden. Walking-animal properties and all RRR values are fictional; no fixed-wheel formula is copied.'},
 {'id':'W12.S03','title':'SEGA — Gaiden Adventure / Pocket Circuit','url':'https://ryu-ga-gotoku.com/gaiden/asia_en/adventure/','checked_on':'2026-09-11','function':'A recurring Pocket Circuit venue combines parts acquisition, Time Attack and rivals.','limit':'Player kit manufacturing and biological breeding commissions are RRR extensions, not features inferred from the Coliseum content elsewhere on this page.'}
]
tasks=[
 ('W12.T01.REFERENCE','Recover the executable handoff and retain the real W11 application','P0',[],'supporting','reviewed','Runtime extends recovered W11. Missing W10 maker source is reconstructed from its written requirements, not falsely recovered.'),
 ('W12.T01.RECIPE','Translate an actual fitted construction into measured commercial requirements','P0',['W12.T01.REFERENCE'],'novel_integration','implemented_and_model_tested','Native host and every actual preparation have explicit promises. Mechanism-based alternatives and fitting are distinct from a source instance sheet.'),
 ('W12.T01.PACK','Construct full kits from alternate real stock without consuming the reference','P0',['W12.T01.RECIPE'],'novel_integration','implemented_and_browser_tested','A real bred component and another living host become one paid-for, packable, openable kit. Native anatomy remains explicit.'),
 ('W12.T01.BREEDERS','Deliver living selected stock using bounded observed line evidence','P0',['W12.T01.REFERENCE'],'novel_integration','implemented_and_browser_tested','Two measured broods and an eligible actual A/B pair are distinct checks. Unknown siblings and reproductive failure remain visible.'),
 ('W12.T03.DEMAND','Connect a permitted winning build to a specific funded product request','P1',['W12.T01.RECIPE','W12.T01.PACK'],'novel_integration','implemented_and_browser_tested','An actual completed championship and owner publication can prompt one bounded product inquiry; no cash is earned before physical delivery.'),
 ('W12.T01.COUNTER','Integrate maker output into Two Nets and the recipient workbench','P0',['W12.T01.PACK','W12.T01.BREEDERS','W12.T03.DEMAND'],'visual_and_interaction_execution','rendered_and_browser_tested','Product, host, contents, measurements and evidence remain recognizable. The bought-back kit opens into the original workbench as a draft, not an instant racer.'),
 ('W12.REPAIR','Correct encountered semantic, custody and pricing shortcuts','P0',['W12.T01.RECIPE','W12.T01.COUNTER'],'supporting_and_design_repair','implemented_and_tested','Geometry is not universally higher-better; historical receipts do not own animals forever; same-counter retail avoids a posted instant buyback profit.'),
 ('W12.CLOSE','Validate the delivered source, interactions, migration and archive','P0',['W12.T01.REFERENCE','W12.T01.RECIPE','W12.T01.PACK','W12.T01.BREEDERS','W12.T03.DEMAND','W12.T01.COUNTER','W12.REPAIR'],'supporting','verification_recorded_separately','Report exact tests, input provenance, negative operating examples and unverified game-wide criteria.')
]
next_tasks=[
 {'id':'W13.T01','priority':'P0','title':'Improve visible active-limb racing through the existing component mechanisms','acceptance':'Hopper loading, target clearance, air passage and landing recovery produce legible useful actions across representative own/rival constructions. Compare altered genes and fitted geometry separately. Preserve fees, maker provenance and finish-first competition; do not award an action or win bonus to conceal bad timing.'},
 {'id':'W13.T02','priority':'P0','title':'Calibrate production routes and repeat customer demand over several cohorts','acceptance':'Matched starting resources and action budgets compare retail assembly, caught donors and retained breeding lines. Include failed attempts, care, spare inventory, actual buyer funding and positive or negative margins. No forced breeder profession or invented guaranteed profit.'},
 {'id':'W13.T03','priority':'P1','title':'Broaden custom kit adaptation and customer specificity','acceptance':'Safe re-preparation and explicit recipe revision/adaptation for different host plans; real ordinary and premium customer uses for additional part combinations. Existing signed-looking local records are not secure authority. Retain old requirements and do not silently weaken accepted commissions.'},
 {'id':'W13.T04','priority':'P1','title':'Continue real storage, transport, Factional and Flyer prerequisites','acceptance':'Implement the required living condition, transport and locomotion mechanisms before declaring shipped products, aerial events or later championship stages complete. Earlier death/regrowth decisions remain explicit.'}
]
groups=[]
def group(name,origin,ref,rows):
    rules=[]
    key=name.split(' / ')[0]
    for i,(statement,decision,observable) in enumerate(rows,1):rules.append({'id':f'W12.{key}.{i:02d}','statement':statement,'decision':decision,'observable':observable})
    groups.append({'name':name,'origin':origin,'refines':ref,'rules':rules})
group('REFERENCE / function and continuity','source_hobby_translation',['W11.REFERENCE.01','W11.REFERENCE.06'],[
 ('Commercial kit manufacturing extends the source hobby’s complete-kit and interchangeable-part functions.','Build a product another hobbyist can assemble.','No 1:1 claim is made for biological breeding or escrow in a PCR menu.'),
 ('Reconstruct maker behavior against the recovered W11 state; do not claim to recover missing W10 source.','Continue the actual executable.','Club meets, prior specimens, Trackworks and the workbench remain.'),
 ('Keep user premises above generated implementation branches.','Choose speed, winning, collecting, breeding or commerce without a required profession.','No race-rank gene lock, universal point cap, new body species ban or mandatory sidegrade appears.'),
 ('A requirement describes a useful mechanism rather than just a shared menu label.','Distinguish a sensor from a physical brace even when both stabilize.','The automatic substitution group cannot replace one with the other indiscriminately.'),
 ('Source references do not establish normalized RRR equations or final prices.','Use a declared protocol and scope.','Authored quantitative promises remain revisable game data.')])
group('RECIPE / promises and independent stock','source_hobby_translation_and_rrr_production',['W05.RECIPE.02','W07.SHOP.05'],[
 ('Publish either the current committed build or an owned recorded club-round construction.','Choose a real reference.','Uncommitted draft and fabricated winner metadata cannot serve as an implicit build.'),
 ('Publication preserves the source host, components, positions and results.','Create a reusable design without sacrificing the original.','The champion can continue racing with H-6 while a different kit is made.'),
 ('A recipe specifies the source body plan and observed native mass, stride and support requirements.','Choose another suitable living foundation.','Matching the name Lowline alone is insufficient when native measurements fail.'),
 ('Each physical preparation becomes one recipe slot with actual measurements and preparation choices.','Promise the useful properties of an assembly.','A Hopper serving three functional roles is not three inventory items.'),
 ('Known legacy observations are normalized from the exact existing compiler defaults.','Describe historical parts that omit explicit fields.','Published efficiency or release is the declared old profile, not an invented new assay.'),
 ('Default margins create visible operating ranges or one-sided bounds; they are not statistical confidence.','Choose an appropriate manufacturing allowance.','The interface shows actual thresholds rather than an unexplained quality percentage.'),
 ('Individual measurement promises may be authored explicitly at publication.','Set quick release and adequate dusty purchase independently.','Only known axes and valid finite bounds are accepted; the reference must satisfy every promise.'),
 ('Geometry and operating ranges are not globally higher-better.','Specify useful leverage, brake engagement material or reach.','A larger ratio can fail the specified range without being universally lower quality.'),
 ('Mechanism-compatible substitutions must meet actual measurement and mass requirements.','Use different donors or permitted preparations.','Rarity and product names cannot hide a failed criterion.'),
 ('Signature mode restricts preparation choices, not individual identities.','Sell a recognizable construction with repeatable source forms.','Another properly measured individual can supply its parts.'),
 ('Recipe rows retain intended positions and setup while the actual substitute arrangement is checked again.','Adjust placement where needed.','Individually qualifying components can still fail whole-body fitting.'),
 ('Each publication is immutable and receives a new identity; current recipe version is one.','Publish a changed promise as a new product.','No in-place revision editor or completed revision-series system is claimed.'),
 ('Recipe export is knowledge, not world ownership.','Share the product specification.','The local exported product has no authority to mint host, anatomy, money or prizes.')])
group('KIT / actual assembly and custody','rrr_native_inventory_integration',['W08.KIT.01','W08.STABLE.03'],[
 ('Packing requires another owned mature intact measured host that is not the active bench animal.','Leave the source racer intact and select a real foundation.','The historical HOST cradle is nontransferable only in this fixture, not a universal species restriction.'),
 ('A parked registered host must have a native-only fitted state and an empty prepared-part draft before packing.','Unfit deliberately or use unused stock.','Packing does not silently dismantle a separate racer.'),
 ('Working, reproducing, packed or meet-entered hosts are unavailable.','Schedule production with the real animal.','One host cannot serve two simultaneous incompatible commitments.'),
 ('Every selected component must be owned, loose, usable and absent from every fitted build and draft reservation.','Release genuine stock before using it.','A draft-only removal does not free installed tissue.'),
 ('Alternative preparations cannot spend the same anatomical region twice; disjoint sources remain useful.','Allocate fatbody to reservoir or damper, and reserve separate donor material for both.','One valid complete kit has real physical sources for every listed item.'),
 ('Packing checks recipe promises, protected-host consent and complete geometry before changing the world.','Commit a reviewed full kit.','Any rejection leaves ownership, funds and custody unchanged.'),
 ('Successful packing costs four credits and one world turn plus care in this profile.','Budget performed work and supplies.','Host and components lock before time advances, preventing an automatic sale race.'),
 ('A packed host continues to need care and holding until ownership changes.','Deliver, retain or open the kit.','A tin does not stop biological obligations.'),
 ('Opening releases the same host and components and does not equip them.','Assemble personally after unpacking.','The guide creates a draft; fitting still commits the real construction.'),
 ('Maker retail transfers all existing kit contents without cloning them.','Buy the same delivered product from Two Nets.','The original donor identities reach the recipient bench and race.'),
 ('Opened supplier receipts remain history rather than perpetual ownership constraints.','Reuse or sell a previously opened native host appropriately.','An old receipt neither blocks legitimate packing nor reopens to restore missing assets.')])
group('BREEDER / purposeful evidence and living delivery','rrr_native_progression',['W08.LINE.05','W03.BREED.07'],[
 ('A breeder request names a donor form, measured contribution and actual living delivery.','Supply synchronization or release for another breeding project.','The request does not accept prepared tissue instead of reproductive stock.'),
 ('Customer evidence evaluates its own target rather than blindly trusting the line’s selected label.','Use relevant recorded observations.','A renamed line does not rewrite or satisfy unrelated customer requirements.'),
 ('Count distinct tested descendants, matching descendants and distinct measured broods separately.','Develop enough useful observed evidence.','Repeated tests of one individual or many siblings do not create several broods.'),
 ('Untested observed descendants remain unknown; unopened future outcomes do not enter the report.','Assay only when the information is useful.','The interface cannot reveal hidden survival or convert missing evidence into failure or success.'),
 ('Sold or prepared descendants can remain historical evidence with their actual custody.','Keep useful records after commercial use.','Evidence does not recreate owned stock.'),
 ('The delivered pair must itself be owned, intact, mature, measured, unreserved and composed of compatible A/B roles.','Choose eligible descendants from the line.','A strong evidence report cannot bypass unavailable or unsuitable living animals.'),
 ('Both delivered animals must satisfy the customer contribution.','Supply relevant future breeders, not arbitrary members of a famous line.','A compatible pair alone does not fulfill a synchronization promise.'),
 ('Protected delivery animals require scoped confirmation; original founders are not implicitly sold.','Select exactly which reproductive assets to transfer.','The two delivered identities change owner while the source line remains.'),
 ('A delivery freezes the narrow evidence claim that was accepted.','Retain receipt counts and sampled-brood identities.','Selected measured descendants are not reported as an unbiased future yield or a race-win guarantee.'),
 ('Failure and inconvenient reproductive-role distributions remain real outcomes.','Retry, source another contribution or decline a commitment.','The browser test preserves an all-A early brood and a failed attempt instead of spawning a convenient pair.')])
group('DEMAND / useful products and earned income','rrr_native_hobby_economy',['W11.REWARD.04','W03.CASH.01'],[
 ('Two complete-kit briefs and two breeder briefs coexist with ordinary immediate trade.','Supply a construction, a breeding contribution or surplus.','A casual racer need not become a certified breeder.'),
 ('Accepting an order reserves actual buyer funds but pays no seller.','Accept a feasible commitment.','Escrow, current cash and hoped-for income remain distinct.'),
 ('Accepted delivery transfers all promised assets and payment together.','Complete a whole-kit or pair handover.','Retries cannot duplicate funds, hosts or components.'),
 ('Local deadlines are inclusive; later expiry returns unearned funds.','Hand over actual stock at the counter within the displayed window.','No shipping system is implied by a local due date.'),
 ('Completed repeatable briefs can offer their next bounded edition when the buyer can fund it.','Produce another physical kit rather than repeat a receipt.','No infinite customer or immediate income is created by renewal.'),
 ('An owner may publish an actual champion’s recorded round and request one specific showroom inquiry per meet.','Translate public interest into a new product goal.','An alternate host and stock must satisfy the published promise before payment.'),
 ('Champion inquiries are finite authored counter opportunities, not simulated mass popularity.','Use the disclosed two-edition limit and funding.','The race trophy itself neither adds a genetic bonus nor pays product income.'),
 ('Delivered sealed maker kits appear as the same assets on the main Two Nets shelf.','Buy, supply or inspect actual commercial inventory.','A separate maker view cannot hide a second cloned shop instance.'),
 ('Retail quotes consider already posted same-counter kit buyback prices.','Pay for stock or add real production value.','An unchanged newly purchased kit cannot immediately profit against a currently posted request from the same counter.'),
 ('Operating costs, capital, retained stock, gross receipts and cash changes remain distinct.','Compare a completed project honestly.','The tested first manufacturing route may lose cash despite a successful sale.'),
 ('Claimed line reliability is supported by observations rather than a price aura.','Seek a useful customer and deliver accepted stock.','A new name or qualification label does not autonomously increase every buyer’s price.')])
group('PRESENT / useful decisions in one hobby','rrr_native_visual_and_interaction_execution',['W07.PRESENT.02','W11.PRESENT.04'],[
 ('The maker counter leads with the actual proposed animal and recognizable parts.','See the product before inspecting details.','The same anatomy renderer serves bench, maker and kit shelf.'),
 ('Reference construction, printed requirements, selected stock and physical tin are separate visible stages.','Identify the next meaningful action.','A published recipe is not styled as already-owned product inventory.'),
 ('Each rejected stock item states the relevant measurement, fit, ownership or reservation cause.','Repair the correct issue.','Unmeasured is not confused with genetically poor, and fitted elsewhere is not incompatible.'),
 ('Per-measurement and placement controls are optional depth with explicit keyboard-friendly inputs.','Choose coarse starting promises or detailed tuning.','Precision dragging and allele notation are not required to make a kit.'),
 ('Donor-route and contribution actions use the same existing project and field identities.','Find the anatomy the product lacks.','A range mismatch above the upper bound suggests less, not automatically more.'),
 ('Line evidence and live delivery selectors remain beside the actual customer.','Inspect the evidence gap and eligible animals together.','Count labels explicitly say measured broods and unmeasured descendants.')])
group('CONTINUITY / scoped quality and preserved history','supporting',['W11.VALIDATION.02','W08.HISTORY.01'],[
 ('Migration appends maker state without granting player cash or rerolling stock.','Continue existing saves.','W11 data is preserved except declared schema/profile changes; no W10 executable migration is invented.'),
 ('Restore synchronizes the selected world catalogue before maker validation.','Restore a legitimate alternate world.','Previously viewed fixtures cannot cause stale descriptor validation failures.'),
 ('World backup and product export have different authority.','Restore local world state explicitly or export only knowledge.','Consistency checking is not secure multiplayer authority.'),
 ('The existing race, bench, artwork, club and circuit source bodies stay unchanged.','Extend production without replacing existing racing.','No movement fidelity or new tournament stage is credited to this wave.'),
 ('Required quality and novel-development adherence remain noncompensable gates.','Assess the implemented contribution at its scope.','Test count, output length and speed do not establish novelty or enjoyment.'),
 ('Effectiveness, creativity and scaling potential retain separate evidence states.','Carry human, platform and economy gaps forward.','An actual browser route does not establish world-scale performance or guaranteed profit.')])

repairs=[
 {'id':'W12.REPAIR.01','before':'Mole mechanical advantage was labeled globally higher-better.','after':'The catalogue marks a target range; maker matching gives the appropriate missing direction only outside the operating band.','enables':'Gear selection stays about useful delivery rather than a false tier ladder.'},
 {'id':'W12.REPAIR.02','before':'One generic tolerance encouraged treating unrelated promises alike.','after':'Explicit min/max requirements per measured native or prepared property; known axes, domain and source coverage validated.','enables':'Quick release and sufficient loose-ground purchase can be specified independently.'},
 {'id':'W12.REPAIR.03','before':'Legacy component records omit fields that their compiler still uses.','after':'Published observations include the exact declared legacy defaults without altering race code or claiming a new assay.','enables':'Old earned components can be honest recipe references.'},
 {'id':'W12.REPAIR.04','before':'A previously opened supplier-kit record required its host to remain registered indefinitely.','after':'Opened receipts retain history but do not enforce old ownership or permit reopening.','enables':'A real host can participate in later legitimate manufacturing and resale.'},
 {'id':'W12.REPAIR.05','before':'A restore could validate maker parts against stale global descriptors from a different viewed world.','after':'Synchronize validated current-world component descriptors before maker checks.','enables':'Full local backup works across old and new production state.'},
 {'id':'W12.REPAIR.06','before':'A maker-specific sold product could be absent from the main Wrangloid shelf.','after':'The same identified packed host and contents appear once at Two Nets.','enables':'Production reconnects to the customer’s existing shop and workbench.'},
 {'id':'W12.REPAIR.07','before':'A fixed resale quote could fall below an already-posted same-counter purchase order.','after':'A public quote covers eligible current kit-order buyback plus the declared 24-credit margin.','enables':'Production value rather than unchanged circular trading supports the livelihood.'},
 {'id':'W12.REPAIR.08','before':'Line sample labels could blur all offspring with measured offspring.','after':'Measured descendants, target matches, distinct measured broods and unknown descendants are explicit.','enables':'A narrow evidence-backed breeder sale does not imply guaranteed future quality.'}
]
limits=[
 'Maker code is a new reconstruction on recovered Wave11, not the missing Wave10 executable. Its written handoff remains in history.',
 'No new donor form, mutation, linkage, inherited appearance or full reproductive simulation is added. Existing thirteen-form authored quantitative profiles supply products.',
 'Product recipes retain one reference body plan, explicit native promises and fixed reference setup. Alternate-host-plan adaptation, formal revision series and user-selectable arbitrary substitution groups remain open.',
 'Prototype margins are 0/10/15/25 percent starting conveniences; individual measured bounds override them. They are neither calibrated manufacturing tolerances nor statistical confidence.',
 'The historical HOST remains on its nontransferable starter cradle. Pack another owned mature host; a parked registered host must first be native-only and free of prepared drafts.',
 'No generic sale of a currently assembled active racer. This release sells packed build-it-yourself kits and specific living breeder pairs.',
 'Four finite named briefs share the actual Two Nets wallet; institutional names describe authored customer purposes rather than fully independent national accounts. Owner-approved champion inquiries are bounded authored opportunities, not autonomous information diffusion.',
 'All deliveries are local counter transfers. Prepared-stock decay, shipping, temperature-chain logistics, general injury, aging and regrowth remain unchanged or open.',
 'Packed care uses the current simplified holding/upkeep branch. A paid receipt is not proof of balanced prices, sustainable demand or affordable growth.',
 'The first complete browser manufacturing project loses cash after its win; retained breeders, samples and reference racer are assets, not sale revenue. Comparative multi-cohort careers require further calibration.',
 'The two-roach race operators and club structure are unchanged. Hopper timing, articulated motion, true multi-roach physics, Flyer routes, Factionals and World City remain open.',
 'Recipient construction is exercised by buying back the same kit through actual controls. Autonomous NPC assembly, racing with purchased maker stock and individual customer AI are not implemented.',
 'Local product export has no importer in this wave. Whole-world restore is consistency checked, user editable, and not competitive server authority.',
 'The shared global catalogue serves one active local world. No multi-world service or large-world benchmark is established.',
 'Browser verification used exact HTML set_content after native file navigation was blocked. Native Windows/macOS origin persistence, physical touch, human usability, engagement and retention remain unverified.'
]
threads=[
 {'id':'W12.THREAD.WINNER_TO_TIN','institution':'VENUE_FOUNDRY','path':['actual frozen club-round build','owner-approved recipe','separate host and real qualifying stock','personal packing','funded delivery','same kit on shop shelf'],'value':'Sporting achievement provides a recognizable reference and bounded product opportunity, not a duplicate winning roach.','runtime':'Implemented including actual competition-to-sale browser route.'},
 {'id':'W12.THREAD.TWO_NETS','institution':'SHOP_TWO_NETS','path':['published component promises','ordinary and selected brood output','actual host and preparations','funded kit handover','retail quote','open guide','recipient fitting and race'],'value':'The Wrangloid buys useful player work and sells a real kit that another hobbyist can build.','runtime':'Implemented local transactions and recipient controls; NPC retail uptake not simulated.'},
 {'id':'W12.THREAD.CINDER','institution':'ORG_CINDER','path':['missing synchronization contribution','existing hopper habitat or founder stock','several observed broods','specific measured descendant A/B pair','bounded evidence claim','funded living-stock sale'],'value':'Breeding expertise has a separate product from extracted racing anatomy.','runtime':'Implemented through Two Nets delegated buyer wallet.'},
 {'id':'W12.THREAD.CONTACT','institution':'SHOP_TWO_NETS','path':['quick-release foot requirement','Glazed Overgrowth','Glassfoot selection and compatible line','running pads or alternative brake preparation','kit or living founder commission'],'value':'The same inherited material can serve racing construction and a customer’s future breeding project.','runtime':'Existing source/preparation paths and new stock/claim matching; not a new insect or mutation system.'},
 {'id':'W12.THREAD.BENCHLINE','institution':'MEDIA_BENCHLINE','path':['permitted actual result','frozen public build','bounded product inquiry','observed delivered kit'],'value':'Public construction information has a useful commercial follow-through without claiming genetics caused a win.','runtime':'Owner publication and authored showroom request; no automatic regional news diffusion.'}
]
entities=[
 {'id':'W12.ENTITY.RECIPE','fields':['id','version','name','source','host.plans','host.requirements','guide','referenceProfile','slots','protocol','requirementOverrides','signature'],'boundary':'Knowledge object, immutable; no inventory ownership. Requirement keys include HOST and actual S-numbered slots.'},
 {'id':'W12.ENTITY.KIT','fields':['id','type','hostId','recipe','recipeRevision','owner','status','items','guide','entry','profile','preparedFor','created'],'boundary':'Physical packed host and anatomy, later opened historical receipt. Proposed entry is not an actual race result.'},
 {'id':'W12.ENTITY.ORDER','fields':['id','type','buyer','purpose','price','window','state','escrow','edition','limit','deadline','deliveries','requiredKinds_or_target'],'boundary':'Buyer terms stay fixed. Receipt is earned only on accepted actual stock.'},
 {'id':'W12.ENTITY.CLAIM','fields':['lineId','target','tested','matching','broods','unmeasured','rows','limit'],'boundary':'Frozen selected-sample evidence; not statistical future guarantee or new specimen ownership.'},
 {'id':'W12.ENTITY.PUBLICATION','fields':['id','recipeId','meet','round','hostId','champion','build'],'boundary':'Owner-selected actual history; one specific inquiry per meet. No invented earlier or future race.'},
 {'id':'W12.ENTITY.RECEIPT','fields':['id','orderId','edition','tick','assets','paid','claim'],'boundary':'One delivery edition, one payment and exact transferred assets; no replay renewal.'}
]

spec={'manifest':{'id':'W12','version':'0.12.0','date':'2026-09-11','title':'RRR — Makers & Bloodlines','status':'revisable_foundations_and_interactive_local_prototype','extends':'world_context_v0.11.json','base_sha256':sha(ROOT/'reference/world_context_v0.11.json'),'runtime_base':'Recovered Wave11 source','reconstruction':'New implementation of missing Wave10 maker requirements; not recovery of that missing source','serialization':'Strict JSON in .spec; RRR exchange format, not an asserted canonical private MIVIM grammar'},
 'Reference':{'sources':sources,'previous_task':'W12.T01','source_roles':profiles['metrics'],'mechanism_substitutions':profiles['mechanisms'],'preserved':['original host and anatomy','all prior race results','existing thirteen reproductive forms','source components and traits','club meets and prizes','owned circuits','native body plans','optional catching/breeding/buying','Open and other class identity']},
 'Plan':{'tasks':[dict(zip(['id','title','priority','depends_on','role','status','acceptance'],t)) for t in tasks],'next':next_tasks,'carried':'Prior W12.T02 movement fidelity and W12.T04 later competition are not closed by maker work; W12.T03 is implemented only as bounded owner-approved inquiries.'},
 'Workflow':['read actual W11 handoff','trace kit and parts purpose to primary reference','reconstruct maker model on shared state','implement explicit measured promises and alternate stock','integrate living breeder requests','render existing-roach product interface','exercise actual clubs and nursery via controls','repair encountered direction/custody/quote defects','regress and verify extracted artifact'],
 'Adherence':{'admission':'required_quality_at_declared_scope AND novel_development_adherence','innovation_profile':['effectiveness','creativity','scaling_potential'],'numerical_grade':None,'numerical_grade_reason':'No authorized numerical MIVIM scoring formula','authority':'User premises outrank generated proposal branches. Synthetic tests are not authored canon or player rewards.'},
 'rule_groups':groups,'customer_briefs':profiles['briefs'],'entities':entities,'world_threads':threads,'repairs':repairs,'limits':limits,
 'evidence':{'new_operators':'evidence/maker_report.json','migration':'evidence/migration_report.json','browser':'evidence/browser_maker_report.json','recipient_browser':'evidence/browser_retail_report.json','summary':'evidence/validation_report.json','scope':'Measured test results are regenerated independently of this source specification. Browser routes use ordinary funds and actual controls; nonbrowser fixtures disclose synthetic working capital.'}}
(ROOT/'RRR_Wave_12.spec').write_text(json.dumps(spec,indent=2,ensure_ascii=False)+'\n')
base=json.loads((ROOT/'reference/world_context_v0.11.json').read_text());c=copy.deepcopy(base);c['development_waves'].append(spec)
c['manifest'].update(version='0.12.0',latest_wave='W12',updated_on='2026-09-11',runtime_base='Recovered W11 plus reconstructed W12 maker integration',runtime_handoff_gap='Missing W10 source not recovered. Its written maker requirements have a new W12 implementation; original handoff remains in history.',relationship_to_handbook='Adds actual alternate-stock complete kits, measured component promises, bounded breeder evidence, local commissions and owner-approved sporting product inquiries.')
(ROOT/'world_context_v0.12.json').write_text(json.dumps(c,indent=2,ensure_ascii=False)+'\n')

md=['# RAD ROACH RACING — WAVE v0.12','## Makers & Bloodlines','', '**Status:** interactive local continuation and revisable foundations. '+str(sum(len(g['rules']) for g in groups))+' new statements; measured commercial recipes, actual-stock full kits, two kit briefs, two breeder briefs, bounded winning-build inquiries and the same shop-to-workbench loop.','',
 '## Reference and reconstruction','', 'The runtime extends recovered Wave11. Missing Wave10 maker source was not recovered. The written feature is reconstructed here against the existing stable, live inventory, breeding, Trackworks and competitive club circuits. This is not a source-preservation claim about an unavailable implementation.','',
 '| Reference | Source function | Boundary |','|---|---|---|']
for s in sources:md.append(f"| {s['id']} / {s['title']} | {s['function']} | {s['limit']} |")
md+=['','## Plan and actual scope','','| Task | Work | Evidence state |','|---|---|---|']
for t in spec['Plan']['tasks']:md.append(f"| {t['id']} | {t['title']} | {t['status']} |")
md+=['', '## Playable route','',
 '**09 · Maker counter:** publish a committed build, or explicitly choose a completed club round. Set the printed measurements, choose an actual alternate host and qualifying loose components, inspect whole-kit fit, then pack. A funded accepted order pays only on delivery. The same sealed product appears at Two Nets. Opening it makes a native host and real components available; loading its guide creates a draft, not a completed racer.','',
 'A separate breeder path selects an existing line, measures descendants across broods, and delivers an eligible actual A/B pair. Ordinary buying, catch-and-sell, component production, building and racing remain available without this career.','',
 '## The useful comparison to Pocket Circuit','',
 'The complete kit retains the source hobby’s foundation plus selected interchangeable parts and personally performed assembly. The maker chooses what a repeated kit promises; the breeding operation supplies suitable biological instances. A race-winning individual is neither consumed by publication nor cloned when its construction is reproduced. Gear ratio, foot release, drive efficiency, body support and native mass retain their separate purposes.','',
 'The maker does not promise equal race times for every substitute. The recipe states component measurements, native requirements and fit. Other individual properties, settings, course, traffic and actions can differ. A reference victory remains one historical result.','',
 '## Printed requirements and real supply','',
 '| Function | Requirements represented | Supply reason |','|---|---|---|',
 '| Host/body | Same stated plan; observed native mass ceiling, stride and support minimums | Select a foundation that can fulfill the construction rather than merely match its name. |',
 '| Drive | Cadence, useful force, conversion efficiency and mass | Select actual cicada or scarab musculature; gearing remains independent. |',
 '| Gearing | Mechanical-advantage operating range and mass | Select suitable hip delivery rather than chase the largest ratio. |',
 '| Contact | Clean and loose purchase, release delay and mass | A quick-release foot can complement an already high-purchase line. |',
 '| Hopper | Return, mismatch, settling and mass | Useful intermediate generations can supply ordinary kits while selected parents continue the premium project. |',
 '| Reserve / damper | Capacity and delivery versus separate rebound properties | Separate physical donors are required where both products consume one region. |',
 '| Brakes / guides | Operating friction/travel; low rail loss and adequate support | The intended surface interaction determines the requested material. |',
 '| Stabilizers | Actual sensing response or a specified support arrangement | A sensor is not silently substituted for a brace because both share a catalogue heading. |',
 '| Horn / claws / aero | Useful geometry with actual impact, timing, resistance and mass | Match the promised construction; no universal longer-is-better tier. |','',
 'Starting margins of 0, 10, 15 or 25 percent are disclosed conveniences. Explicit per-measurement bounds can replace them at publication, but must cover the chosen reference. Geometry has bounded ranges. Each published recipe is immutable and receives a new identity. Version-series editing and alternate-plan adaptation remain later work.','',
 '## Customer purposes','','| Brief | Payment | Window from acceptance | Actual need |','|---|---:|---:|---|']
for b in profiles['briefs']:md.append(f"| {b['name']} | {b['price']} cr | {b['window']} turns | {b['purpose']} |")
md+=['','Kit briefs support at most two editions; each breeder brief has one. These are finite authored requests handled through the actual Two Nets wallet. Declared institutions identify customer purposes; independent regional accounting is not simulated.','',
 'A completed real championship permits an owner-approved round publication and one specific showroom inquiry per meet. Its current offer is a bounded two-edition kit request, not automatic popularity or money from a trophy. The completed browser route produces a 112-credit inquiry.','',
 '## Exact foundation statements']
for g in groups:
 md+=['',f"### {g['name']}",f"Origin: `{g['origin']}`. Refines: "+', '.join('`'+v+'`' for v in g['refines'])+'.','']
 for r in g['rules']:md += [f"**{r['id']}** — {r['statement']}",f"Decision: {r['decision']} Observable: {r['observable']}",'']
md+=['## Connected world work','']
for t in threads:md += [f"### {t['id']} / `{t['institution']}`",' → '.join(t['path'])+'.',t['value'],f"Runtime: {t['runtime']}",'']
md+=['## Actual browser evidence','',
 '**Winning reference to physical kit:** the original host completes First Current through the actual controls. Its final-round construction is published; H-6 and its other installed anatomy remain on that racer. A descendant of the original Hopper founders supplies a different prepared assembly. A different owned Lowline, a purchased measured drive and newly prepared foot stock become the physical kit. Publication explicitly requires loose-surface purchase of at least 0.90 rather than silently rounding a marginal candidate into acceptance.','',
 '| Quantity | Actual browser value |','|---|---:|',
 '| Opening cash before competition | 142 cr |','| Cash after the tested competition path | 174 cr |','| Manufacturing cash payments after that point | 150 cr |','| Actual kit delivery receipt | 112 cr |','| Cash after first kit sale | 136 cr |','| Post-meet manufacturing cash change | -38 cr |','',
 'The project succeeds technically and loses operating cash in this particular retail-supplied first run. Starting parents/facilities, the original racer, retained offspring and acquired knowledge are not cash income. This does not establish profit, investment return or fair comparisons of maker careers. It identifies calibration work instead of hiding it behind gross revenue.','',
 '**Breeder commission:** three attempts include a completed first brood with only A-role survivors, a failed attempt, and a completed later brood. Five measured descendants match the synchronization threshold across two measured broods; five other observed descendants remain unmeasured. Two eligible living A/B descendants transfer for 76 credits. Original founders remain with the player. This is narrow selected-sample evidence, not a universal inheritance or future-yield claim.','',
 '**Recipient construction:** the actual sold-kit backup is restored through the file control. The tester earns needed money through funded club work, buys the same kit at Two Nets, opens it, loads the guide, personally fits its same components and enters a fresh race. No state-edit hook adds funds or animals. This is a tested recipient path, not autonomous NPC behavior.','',
 'Browser results, model results, declared synthetic fixtures and exact file hashes are reported separately under evidence/.','',
 '## Encountered repairs','']
for r in repairs:md += [f"**{r['id']}** — {r['before']} {r['after']} Purpose: {r['enables']}",'']
md+=['## Limits and carried work','']
for l in limits:md+=['**Boundary:** '+l,'']
md+=['## Next ordered work','']
for t in next_tasks:md += [f"**{t['priority']} / {t['id']} — {t['title']}**",t['acceptance'],'']
md+=['## Sources','', 'Sources support only the stated source-hobby functions. Fictional anatomy, normalized values and business behavior remain authored RRR proposals.','']
for s in sources:md += [f"**{s['id']} — {s['title']}**",f"Checked {s['checked_on']}. {s['function']} Limit: {s['limit']}",f"`{s['url']}`",'']
(ROOT/'RRR_Wave_12_Foundations.md').write_text('\n'.join(md))
todo=['# RRR — Wave v0.12 TODO','','Checkmarks mean the stated local implementation. They do not close complete game quality, autonomous NPC commerce or unrecovered source history.','']
for t in spec['Plan']['tasks']:todo += [f"## [x] {t['id']} — {t['title']}",f"Priority: {t['priority']}. Role: {t['role']}. Status: {t['status']}.",f"Dependencies: {', '.join(t['depends_on']) or 'none'}.",t['acceptance'],'']
todo+=['## Carried acceptance','',spec['Plan']['carried'],'','The measured first-kit project loses 38 credits after the meet. Do not describe gross receipts as profit or close production affordability from one successful handover.','']
for t in next_tasks:todo += [f"## [ ] {t['priority']} / {t['id']} — {t['title']}",t['acceptance'],'']
(ROOT/'RRR_Wave_12_TODO.md').write_text('\n'.join(todo))
review='''# MIVIM — Wave v0.12 contribution review

**Objective:** Turn a real personal construction into a repeatable living kit and useful breeding commissions while keeping component function, actual anatomy, evidence and the original racer intact.

**Comparator:** A recipe that clones the reference, family-name substitutions without useful measurements, cosmetic shop output, or a lineage name paid as a universal quality guarantee.

**Hard admission:** required quality at the declared scope AND novel-development adherence. No authorized numerical weights or grade bands are asserted.

| Criterion | Finding | Remaining evidence |
|---|---|---|
| Quality | Model checks and actual controls exercise publication, alternate-stock assembly, physical kit custody, funded sales, living breeder delivery and recipient fitting. Rendered desktop/narrow captures reviewed. | Human usability, native platforms and completed-game quality remain open. |
| Novel-development adherence | Concrete integration of source-hobby kit functions with specimen-level selection, measured promises and biological production. | No claim of global uniqueness; supporting test count cannot replace the creative result. |
| Effectiveness | Actual winner → recipe → bred component → separate kit → funded payment → shop shelf → recipient draft/fitting/race is exercised. | Financial sustainability is not established; the first tested kit project loses 38 credits after the meet. |
| Creativity | The original racer stays intact while the maker reproduces its construction using different useful biological stock and explicit promises. | Player-perceived distinctiveness and pleasure remain unmeasured. |
| Scaling potential | Declarative profiles, existing shared inventory and atomic operations support further products without bespoke worlds. | One active local catalogue and finite buyers are not national-economy or multi-server evidence. |

## Corrections credited at their scope

Per-axis promises replace vague blanket equivalence; geometry is a target range; real source defaults become truthful reference data; historic opened-kit receipts stop owning animals forever; restored catalogues are synchronized; the sold kit appears at the existing shop; circular same-counter buying cannot exploit an already-posted higher commission; observed-line denominators remain explicit.

The maker runtime is reconstructed, not recovered from Wave10. Existing race, anatomy, bench, circuit and club operators remain byte-identical to Wave11. Their preservation does not demonstrate improved limb mechanics.

## Unclosed questions

Production affordability across matched careers, repeat independent customer behavior, material viability in transport, staged body condition, user-directed recipe revision/adaptation, articulated racing, multi-racer physical simultaneity, full championship progression and human engagement remain open. Successful tests are evidence of the tested operations, not proof of being addictive.
'''
(ROOT/'RRR_MIVIM_Review_v0.12.md').write_text(review)
print('authored',sum(len(g['rules']) for g in groups),'rules',len(tasks),'tasks',len(profiles['briefs']),'fixed briefs')
report_path=ROOT/'evidence/validation_report.json'
if report_path.exists():
    report=json.loads(report_path.read_text())
    if report.get('html_sha256')==sha(ROOT/'RRR_Makers_Bloodlines_v0.12.html') and report.get('spec_sha256')==sha(ROOT/'RRR_Wave_12.spec'):
        block=['','## Verification recorded for this application','', '| Check | Passed | Failed |','|---|---:|---:|']
        for name,c in report['counts'].items():block.append(f"| {name} | {c['passed']} | {c['failed']} |")
        for b in report['browser']:block.append(f"| {b['file']} — exact delivered HTML | {b['passed']} | {b['failed']} |")
        block += ['', 'Schema, profile agreement, task ordering, identity uniqueness, prior context and five unchanged runtime modules passed. Browser source hashes match. Operator capital fixtures are disclosed separately from actual-control browser paths. Archive verification is performed after packaging; its external report is not circularly included in its own hash manifest.','']
        with (ROOT/'RRR_Wave_12_Foundations.md').open('a') as f:f.write('\n'.join(block))
