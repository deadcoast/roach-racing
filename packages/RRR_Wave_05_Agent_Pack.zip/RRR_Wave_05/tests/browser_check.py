"""Exercise the actual delivered HTML; no state mutation through test hooks."""
from pathlib import Path
import os
import json,sys,hashlib
from playwright.sync_api import sync_playwright
root=Path(__file__).resolve().parents[1]
errors=[]; requests=[];checks=[]
with sync_playwright() as p:
 browser=p.chromium.launch(executable_path=os.environ.get('RRR_CHROMIUM','/usr/bin/chromium'),headless=True,args=['--no-sandbox'])
 page=browser.new_page(viewport={'width':1440,'height':1100},device_scale_factor=1)
 page.on('pageerror',lambda e:errors.append(str(e)))
 page.on('request',lambda r:requests.append(r.url))
 file_error=None
 try:
  page.goto((root/'RRR_Living_Workbench_v0.5.html').as_uri())
  page.wait_for_function('window.RRR_WORKBENCH !== undefined')
  loaded='file URI'
 except Exception as exc:
  file_error=str(exc).splitlines()[0]
  page.close();page=browser.new_page(viewport={'width':1440,'height':1100},device_scale_factor=1)
  page.on('pageerror',lambda e:errors.append(str(e)))
  page.on('request',lambda r:requests.append(r.url))
  page.set_content((root/'RRR_Living_Workbench_v0.5.html').read_text(),wait_until='load')
  page.wait_for_function('window.RRR_WORKBENCH !== undefined')
  loaded='exact HTML via set_content (file URI blocked)'
 assert not errors, errors
 checks.append('Exact delivered HTML initializes')
 page.screenshot(path=str(root/'evidence/bench_desktop_initial.png'),full_page=True)
 # One actual baseline run.
 page.click('#go-race');page.click('#run')
 page.wait_for_function('RRR_WORKBENCH.runs().length===1',timeout=30000)
 base=page.evaluate('RRR_WORKBENCH.runs()[0]')
 checks.append('Baseline race computed from committed build')
 page.click('#end');page.click('#pin');page.click('#tab-bench')
 # Fit prepared owned parts rather than changing model state with a harness.
 page.click('[data-stock="UPGRADE-DRIVE"]');page.click('#fit-part')
 assert page.evaluate('RRR_WORKBENCH.state().fitted.placements.some(x=>x.id==="UPGRADE-DRIVE")') is False
 checks.append('Draft placement does not install stock')
 page.click('[data-stock="W05.CROP"]');page.click('#fit-part')
 page.click('[data-stock="W05.HORN"]');page.click('#fit-part')
 page.click('[data-stock="W05.VANES"]');page.click('#fit-part')
 assert page.locator('#commit').is_enabled()
 checks.append('Central horn and split vanes physically coexist')
 # Keyboard test with actual focused SVG assembly.
 page.locator('[data-part="W05.HORN"]').focus();x0=page.evaluate('RRR_WORKBENCH.state().draft.placements.find(x=>x.id==="W05.HORN").x')
 page.keyboard.press('ArrowRight');x1=page.evaluate('RRR_WORKBENCH.state().draft.placements.find(x=>x.id==="W05.HORN").x')
 assert abs(x1-x0-.01)<1e-8
 checks.append('Focused anatomical root supports keyboard nudging')
 page.click('#align')
 page.click('#tune summary')
 page.locator('#leverage').fill('0.85');page.locator('#leverage').dispatch_event('input')
 page.select_option('#approach','hopper')
 page.click('#finish summary');page.fill('#name','TIN SAINT');page.locator('#name').press('Tab')
 page.click('[data-livery="ochre"]')
 page.click('#cutaway') # crop selection enabled cutaway; display exterior
 page.click('#commit')
 state=page.evaluate('RRR_WORKBENCH.state()');assert any(p['id']=='UPGRADE-DRIVE' for p in state['fitted']['placements'])
 checks.append('Commit atomically fits identified owned parts')
 page.click('[data-stock="W05.HORN"]');page.wait_for_timeout(100)
 page.screenshot(path=str(root/'evidence/bench_desktop_fitted.png'),full_page=True)
 page.click('#go-race');page.select_option('#equipment','speedsters')
 assert page.locator('#run').is_disabled()
 checks.append('Weapons reject Speedsters even when set to jump')
 page.select_option('#equipment','open');page.click('#run');page.wait_for_function('RRR_WORKBENCH.runs().length===2',timeout=30000)
 updated=page.evaluate('RRR_WORKBENCH.runs()[0]')
 player=next(v for v in updated['results'] if v['host_id']=='HOST')
 assert player['build']['drive_source']=='UPGRADE-DRIVE'
 assert player['build']['hopper_source']=='H-6'
 assert player['build']['hopper']==[.625,.07,.06]
 assert player['build']['design_snapshot']['livery']=='ochre'
 assert player['build']['leverage']==.85
 checks.append('New simulation consumes same donor traits, settings and visual design')
 page.click('#end');page.screenshot(path=str(root/'evidence/circuit_desktop.png'),full_page=True)
 page.click('#replay-start');page.click('#play');page.wait_for_timeout(180)
 assert page.evaluate('RRR_WORKBENCH.playback().t')>0
 page.click('#play');stopped=page.evaluate('RRR_WORKBENCH.playback().t');page.wait_for_timeout(120)
 assert page.evaluate('RRR_WORKBENCH.playback().t')==stopped
 page.locator('#scrub').fill('500');page.locator('#scrub').dispatch_event('input')
 assert page.evaluate('RRR_WORKBENCH.playback().t')>1
 checks.append('Replay start, play, pause and scrub work')
 before=json.dumps(page.evaluate('RRR_WORKBENCH.runs()[0].metadata.design'),sort_keys=True)
 page.click('#tab-bench');page.click('#finish summary') if not page.locator('#finish').evaluate('el=>el.open') else None
 page.fill('#name','ANOTHER NAME');page.locator('#name').press('Tab');page.click('#commit')
 after=json.dumps(page.evaluate('RRR_WORKBENCH.runs()[0].metadata.design'),sort_keys=True)
 assert before==after
 checks.append('Later bench changes do not alter historical race snapshot')
 page.click('#tab-sheets');page.click('#save-card');assert page.locator('.sheet-card').count()==1
 page.click('[data-load-card="0"]');assert page.evaluate('RRR_WORKBENCH.tab()')=='bench'
 checks.append('Save and reload a recipe without copying assets')
 # Export actual download and import it via the browser file picker.
 with page.expect_download() as di:page.click('#export')
 download=di.value;target=root/'evidence/browser_export.rrr-build.json';download.save_as(target)
 page.set_input_files('#file-input',str(target));page.wait_for_timeout(100)
 assert page.evaluate('RRR_WORKBENCH.state().draft.name')=='ANOTHER NAME'
 checks.append('Actual export and file-input import round-trip')
 malicious=root/'evidence/bad_import.json';bad=json.loads(target.read_text());bad['design']['placements'][0]['id']='not-owned';malicious.write_text(json.dumps(bad))
 prior=page.evaluate('JSON.stringify(RRR_WORKBENCH.state())');page.set_input_files('#file-input',str(malicious));page.wait_for_timeout(100)
 assert page.evaluate('JSON.stringify(RRR_WORKBENCH.state())')==prior
 checks.append('Unknown-stock import rejected without mutation')
 page.set_viewport_size({'width':390,'height':844});page.wait_for_timeout(3500)
 assert page.evaluate('document.documentElement.scrollWidth<=innerWidth'), 'mobile overflow'
 page.screenshot(path=str(root/'evidence/bench_mobile.png'),full_page=True)
 page.click('#tab-race');page.click('#end');page.wait_for_timeout(100)
 assert page.evaluate('document.documentElement.scrollWidth<=innerWidth')
 page.screenshot(path=str(root/'evidence/circuit_mobile.png'),full_page=True)
 checks.append('390px bench and circuit have no horizontal overflow')
 # Relaunch via same file URL checks storage where allowed.
 if loaded=='file URI':
  page.reload();page.wait_for_function('window.RRR_WORKBENCH !== undefined')
  assert page.evaluate('RRR_WORKBENCH.state().fitted.name')=='ANOTHER NAME'
  checks.append('Local session survives actual file reload')
 assert not errors,errors
 browser.close()
report={'html_sha256':hashlib.sha256((root/'RRR_Living_Workbench_v0.5.html').read_bytes()).hexdigest(),'loaded_via':loaded,'file_error':file_error,'checks':checks,'page_errors':errors,'external_requests':[r for r in requests if r.startswith('http')], 'baseline_finish':next(r for r in base['results'] if r['host_id']=='HOST')['finish_time'],'updated_finish':player['finish_time'],'updated_events':[e['kind'] for e in updated['events']], 'limitations':['Linux Chromium only','No human playtest','W05 stock and physics are normalized fixtures','Screenshots require manual review']}
(root/'evidence/browser_report.json').write_text(json.dumps(report,indent=2))
print(json.dumps(report,indent=2))
