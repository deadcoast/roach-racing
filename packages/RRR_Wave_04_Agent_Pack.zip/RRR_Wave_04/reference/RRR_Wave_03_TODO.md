# RRR — TODO Wave v0.3

**Status vocabulary:** completed specification is not completed runtime. All rows retain their explicit evidence boundary.

## [x] W03.T01 — Review, reference trace and ordered wave plan

Priority: P0. Role: supporting. Dependencies: none.

Developed: Preserve prior records; record concrete gaps and scope-correct criteria.

Evidence: reviewed.

## [x] W03.T02 — Project-led intake and complementary-stock decisions

Priority: P0. Role: novel_integration. Dependencies: W03.T01.

Developed: Same public evidence gives same advice; poor present output can still matter to a named project.

Evidence: public-evidence routing checked; visual UI not rendered.

## [x] W03.T03 — Hopper inheritance-to-product specification

Priority: P0. Role: novel_integration. Dependencies: W03.T02.

Developed: Exact independent-locus outcomes and measured component consequences; no automatic max-parent inheritance.

Evidence: three-locus hopper fixture checked; general genetics and fertility not implemented.

## [x] W03.T04 — Future-cohort capacity and commitment-preserving replanning

Priority: P0. Role: novel_integration. Dependencies: W03.T03.

Developed: Reserve parents and future stages atomically; delay pauses only unstarted conflicts.

Evidence: interval capacity and delay witnesses checked; live-overflow relocation remains open.

## [x] W03.T05 — Funded brood orders and honest operating cash

Priority: P0. Role: novel_integration. Dependencies: W03.T04.

Developed: Care costs advance; delivered accepted assets earn money; escrow/unsold inventory do not.

Evidence: finite-money operators and eight-tick integration checked; repeated economy calibration open.

## [x] W03.T06 — Anatomy-safe prepared packs and assembly custody

Priority: P1. Role: novel_integration. Dependencies: W03.T02.

Developed: No overlapping harvest or duplicate component; native functions and actual kit assembly remain.

Evidence: harvest, pack and simple installation checked; geometric bench/kit unpack runtime open.

## [x] W03.T07 — Controlled performance witnesses and same-trait race binding

Priority: P1. Role: experimental. Dependencies: W03.T03, W03.T06.

Developed: A declared donor/drive improvement changes a measured result through a stated mechanism.

Evidence: normalized one-dimensional drive and launch benches checked; actual race binding queued.

## [x] W03.T08 — Intake, brood and earnings interaction polish

Priority: P1. Role: design. Dependencies: W03.T02, W03.T04, W03.T05.

Developed: Few actionable views preserve expert detail, identities and uncertainty without compulsory busywork.

Evidence: interaction and presentation contracts authored; no rendered UI/usability test.

## [x] W03.T09 — Regression, MIVIM review and next-wave handoff

Priority: P0. Role: supporting. Dependencies: W03.T01, W03.T02, W03.T03, W03.T04, W03.T05, W03.T06, W03.T07, W03.T08.

Developed: Base preservation and exact evidence scope; no test-count credit for innovation.

Evidence: automated report and qualitative review supplied.

## Remaining implementation and calibration work

### [ ] W04.T01 — Bind component traits to a real assembled racer and modular-course race slice

Priority: P0. Dependencies: W03.T07, W03.T06.

Acceptance: Same stock and build identities feed the race model. Compare actual finish times and overtakes; no result awarded from a bench score. Kit assembly, horn/claw/hopper choices and course connectivity remain visible. Inspect fun, legibility, identity and finish presentation separately from solver tests.

### [ ] W04.T02 — Calibrate repeated production, uncertainty and livelihood affordability

Priority: P0. Dependencies: W03.T04, W03.T05.

Acceptance: Multiple cohorts and buyer budgets; care and household/workshop costs included. Matched scenarios compare casual buying, collecting and breeding without forced profession choice. Common-catch recovery routes and delayed/failed contracts are stress-tested.

### [ ] W04.T03 — Extend life-stage, removal and storage branches

Priority: P1. Dependencies: W03.T03, W03.T06.

Acceptance: One staged non-hopper profile including colony or aquatic lifecycle. Actual removal/viability behavior and overflow support rather than silent assumptions. No surprise host permadeath rule.

### [ ] W04.T04 — Render and evaluate intake, brood and kit interactions

Priority: P1. Dependencies: W03.T08.

Acceptance: Bespoke coherent biological hobby presentation, not generic admin panels. Casual and expert paths tested on the same underlying state. No hidden-truth leak or compulsory repetitive care clicks.

No generated proposal is promoted to author canon by its checkbox. No open runtime item is marked complete because its specification exists.
