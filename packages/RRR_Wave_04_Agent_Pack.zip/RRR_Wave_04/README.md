# RAD ROACH RACING — Wave v0.4

Start with `RRR_Wave_04_Foundations.md`. The `.spec` is strict JSON using the existing RRR exchange structure. `world_context_v0.4.json` preserves earlier records and appends this wave.

Open `Race_Observatory.html` directly in a browser. It is a self-contained recorded-experiment viewer, not an editable game. No external resources, account, local server or network request is required.

## Reproduce

Python 3.10+; model and tests use the standard library.

```sh
python validate_wave04.py
```

The validator reruns 39 Wave 04 checks, the 66 preserved Wave 03 checks, fixture output generation, and preservation/structural checks. Browser evidence is recorded separately; the validator does not pretend to rerun a browser if one is unavailable. The optional development browser check requires Playwright and Chromium.

## Boundaries

Normalized path-constrained racing, not full rigid-body biology. Four authored encounter setups, not balanced race recommendations. One funded meeting and one authored customer trial, not autonomous demand. No editable assembly, complete colony lifecycle, long-run economy, host mortality policy, production-clock integration, or retention claim.

Stored baseline files and original model are unchanged. New task statuses retain unfinished acceptance requirements.

## Viewer reproduction and scope

`python build_replay.py` rebuilds the self-contained viewer from the recorded model output. `browser_check.py` is optional and requires Playwright plus Chromium; set `CHROMIUM_EXECUTABLE` when necessary. The recorded browser check ran the exact HTML on a blank page because this host blocks file-URI navigation; native Windows/macOS direct-file opening is not certified.

The specification uses an authored date; execution reports use the runtime UTC clock. All numeric setups are versioned examples, not global world balance.
