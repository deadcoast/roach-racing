from pathlib import Path
root=Path(__file__).resolve().parents[1]
s=(root/'src/template.html').read_text()
for key,name in [('CSS','style.css'),('ENGINE','race.js'),('BENCH','bench.js'),('ART','anatomy.js'),('WORLD','world.js'),('APP','app.js')]:
 t=(root/'src'/name).read_text();assert '</script' not in t.lower();s=s.replace('__'+key+'__',t)
(root/'RRR_Living_World_v0.6.html').write_text(s)
print(len(s.encode()),'bytes')
