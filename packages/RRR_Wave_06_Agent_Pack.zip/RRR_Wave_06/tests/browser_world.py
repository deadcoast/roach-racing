"""Drive the actual HTML with ordinary controls; state hooks only observe results."""
from pathlib import Path
from playwright.sync_api import sync_playwright
import json, sys, threading, functools, hashlib
from http.server import ThreadingHTTPServer, SimpleHTTPRequestHandler
root=Path(__file__).resolve().parents[1]
checks=[]; errors=[]; modes=[]
def check(name,condition):
 assert condition,name
 checks.append(name)
class Handler(SimpleHTTPRequestHandler):
 def log_message(self,*args):pass
server=ThreadingHTTPServer(('127.0.0.1',0),functools.partial(Handler,directory=str(root)))
threading.Thread(target=server.serve_forever,daemon=True).start()
with sync_playwright() as p:
 browser=p.chromium.launch(executable_path='/usr/bin/chromium',headless=True,args=['--no-sandbox'])
 page=browser.new_page(viewport={'width':1440,'height':1100});page.on('pageerror',lambda e:errors.append(str(e)));page.on('dialog',lambda d:d.accept())
 try:
  page.goto((root/'RRR_Living_World_v0.6.html').as_uri(),timeout=7000);page.wait_for_function('window.RRR_WORKBENCH',timeout=4000);modes.append('file URI')
 except Exception as e:
  modes.append('File URI blocked: '+str(e).splitlines()[0]);page.close();page=browser.new_page(viewport={'width':1440,'height':1100});page.on('pageerror',lambda e:errors.append(str(e)));page.on('dialog',lambda d:d.accept());page.set_content((root/'RRR_Living_World_v0.6.html').read_text());page.wait_for_function('window.RRR_WORKBENCH');modes.append('exact HTML via set_content')
 check('Initial bench and shared world initialize',page.evaluate('RRR_WORKBENCH.world().tick===0&&RRR_WORKBENCH.state().fitted.placements[0].id==="H-6"'))
 page.screenshot(path=str(root/'evidence/bench_desktop.png'),full_page=True)
 page.click('#tab-stock');page.screenshot(path=str(root/'evidence/stock_desktop_initial.png'),full_page=True)
 check('Live stock tab opens through normal navigation',page.locator('#view-stock').is_visible())
 page.check('#auto-brood');page.click('#breed')
 check('Actual breed button starts a reserved six-egg batch',page.evaluate('RRR_WORKBENCH.world().broods.length===1&&RRR_WORKBENCH.world().tick===1'))
 page.click('[data-field-route="verge"]')
 check('Field action advances the SAME batch to nymphs',page.evaluate('RRR_WORKBENCH.world().tick===3&&RRR_WORKBENCH.world().broods[0].stage==="nymphs"'))
 captures=page.evaluate('RRR_WORKBENCH.world().specimens.filter(s=>s.id.startsWith("W06.CATCH")).map(s=>s.id)')
 check('Captured specimens appear as identified cards',len(captures)==2 and page.locator('[data-specimen="'+captures[0]+'"]').is_visible())
 card=page.locator('[data-specimen="'+captures[0]+'"]')
 check('New capture exposes no exact inherited values', 'Not assayed' in card.inner_text())
 card.locator('[data-world="assay"]').click()
 check('Assay reveals measurements and charges one world turn',page.evaluate('RRR_WORKBENCH.world().tick===4') and 'Not assayed' not in page.locator('[data-specimen="'+captures[0]+'"]').inner_text())
 page.click('#wait-one')
 check('Maturity sells opted-in surplus with actual funded payment',page.evaluate('RRR_WORKBENCH.world().tick===5&&RRR_WORKBENCH.world().broods[0].delivered.length>0'))
 page.screenshot(path=str(root/'evidence/stock_desktop_mature.png'),full_page=True)
 # Prepare a specific caught donor, then fit the corresponding new assembly.
 page.locator('[data-specimen="'+captures[0]+'"]').locator('[data-world="prepare"]').click()
 newpart='W06.PART.'+captures[0]
 check('Preparation routes its unique output into the existing tray',page.locator('#view-bench').is_visible() and page.locator('[data-stock="'+newpart+'"]').count()==1)
 page.click('[data-stock="H-6"]');page.click('#remove-part');page.click('[data-stock="'+newpart+'"]');page.click('#fit-part');page.click('#commit')
 check('Existing host installs the newly caught and prepared anatomy',page.evaluate('(id)=>RRR_WORKBENCH.state().fitted.placements.some(p=>p.id===id)',newpart))
 check('Same donor body remains in owned stock with changed anatomy',page.evaluate('(id)=>RRR_WORKBENCH.world().specimens.some(s=>s.id===id&&s.alive&&!s.anatomy&&s.owner==="player")',captures[0]))
 page.click('#tab-stock');page.click('[data-field-route="kiln"]')
 cid=page.evaluate('RRR_WORKBENCH.world().specimens.find(s=>s.kind==="cicada").id');page.locator('[data-specimen="'+cid+'"]').locator('[data-world="prepare"]').click()
 check('Drive preparation records vital extraction',page.evaluate('(id)=>!RRR_WORKBENCH.world().specimens.find(s=>s.id===id).alive',cid))
 page.click('#fit-part');page.click('#commit');page.screenshot(path=str(root/'evidence/bench_desktop_newstock.png'),full_page=True)
 before=page.evaluate('({t:RRR_WORKBENCH.world().tick,c:RRR_WORKBENCH.world().accounts.player})')
 page.click('#go-race');page.select_option('#course','short');page.click('#run');page.wait_for_function('RRR_WORKBENCH.runs().length===1',timeout=30000)
 check('Fresh race uses both field-derived component identities',page.evaluate('([h,d])=>{const b=RRR_WORKBENCH.runs()[0].results.find(r=>r.host_id==="HOST").build;return b.hopper_source===h&&b.drive_source===d}',[newpart,'W06.PART.'+cid]))
 check('Successful attendance charges two world turns and care',page.evaluate('(old)=>RRR_WORKBENCH.world().tick===old.t+2&&RRR_WORKBENCH.world().accounts.player<=old.c-3',before))
 after=page.evaluate('JSON.stringify(RRR_WORKBENCH.world())');page.click('#end');page.click('#replay-start');page.locator('#scrub').fill('800');page.screenshot(path=str(root/'evidence/race_desktop_newstock.png'),full_page=True)
 check('Rewind and scrubbing do not charge or regenerate the world',page.evaluate('JSON.stringify(RRR_WORKBENCH.world())')==after)
 page.click('#tab-stock')
 with page.expect_download() as info:page.click('#save-world')
 info.value.save_as(root/'evidence/browser_world.rrr-save.json')
 saved=page.evaluate('RRR_WORKBENCH.world().tick');page.click('#wait-one');page.set_input_files('#world-file',str(root/'evidence/browser_world.rrr-save.json'));page.wait_for_timeout(200)
 check('Actual file import restores full stock and time backup',page.evaluate('RRR_WORKBENCH.world().tick')==saved)
 page.set_viewport_size({'width':390,'height':844});page.screenshot(path=str(root/'evidence/stock_mobile.png'),full_page=True)
 check('Narrow stock view has no horizontal page overflow',page.evaluate('document.documentElement.scrollWidth<=window.innerWidth+1'))
 page.click('#tab-bench');page.screenshot(path=str(root/'evidence/bench_mobile.png'),full_page=True)
 check('Narrow existing bench remains usable',page.locator('#commit').is_visible() and page.evaluate('document.documentElement.scrollWidth<=window.innerWidth+1'))
 check('No uncaught browser errors',len(errors)==0)
 # Separate origin-backed persistence test: served exact local artifact, no external assets.
 local=browser.new_page();local.on('pageerror',lambda e:errors.append(str(e)));url=f'http://127.0.0.1:{server.server_port}/RRR_Living_World_v0.6.html'
 try:
  local.goto(url,timeout=5000);local.wait_for_function('window.RRR_WORKBENCH');local.click('#tab-stock');local.click('#wait-one');local.reload();local.wait_for_function('window.RRR_WORKBENCH');check('HTTP-origin localStorage reload retains whole world',local.evaluate('RRR_WORKBENCH.world().tick===1'));modes.append('Loopback HTTP persistence tested with exact delivered HTML')
 except Exception as error:
  modes.append('Loopback HTTP blocked; origin persistence UNVERIFIED: '+str(error).splitlines()[0])
 browser.close()
server.shutdown()
(root/'evidence/browser_report.json').write_text(json.dumps({'html_sha256':hashlib.sha256((root/'RRR_Living_World_v0.6.html').read_bytes()).hexdigest(),'checks':checks,'count':len(checks),'errors':errors,'modes':modes,'scope':'Linux Chromium; actual controls and file backup; local HTTP persistence blocked in this host; no native Windows/macOS test'},indent=2))
print(len(checks),'browser checks passed');print(modes)
