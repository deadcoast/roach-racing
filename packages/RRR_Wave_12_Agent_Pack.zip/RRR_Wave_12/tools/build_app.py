from pathlib import Path
ROOT=Path(__file__).resolve().parents[1]
s=(ROOT/'src/template.html').read_text()
for key,name in [('CSS','style.css'),('ENGINE','race.js'),('CIRCUITS','circuits.js'),('CATALOG','catalog.js'),('HOSTS','hosts.js'),('EVIDENCE','evidence.js'),('BENCH','bench.js'),('ART','anatomy.js'),('CLUB','club.js'),('MAKER','maker.js'),('WORLD','world.js'),('TRACKUI','track_ui.js'),('CLUBUI','club_ui.js'),('MAKERUI','maker_ui.js'),('APP','app.js')]:
    text=(ROOT/'src'/name).read_text()
    assert '</script' not in text.lower(),name
    assert '__'+key+'__' in s,key
    s=s.replace('__'+key+'__',text)
out=ROOT/'RRR_Makers_Bloodlines_v0.12.html';out.write_text(s)
print(out,len(s.encode()),'bytes')
