"""Rebuild and validate the delivered wave without optional hidden dependencies."""
from pathlib import Path
import subprocess,json,hashlib,sys,time,argparse,zipfile,tempfile,os
root=Path(__file__).resolve().parent
parser=argparse.ArgumentParser();parser.add_argument('--browser',action='store_true');parser.add_argument('--prior',action='store_true');args=parser.parse_args()
evidence=root/'evidence';evidence.mkdir(exist_ok=True);runs=[]
def run(command,label,cwd=root):
 start=time.perf_counter();r=subprocess.run(command,cwd=cwd,text=True,capture_output=True)
 (evidence/(label+'.txt')).write_text(r.stdout+'\n'+r.stderr)
 runs.append({'label':label,'command':command,'returncode':r.returncode,'elapsed_seconds':round(time.perf_counter()-start,3)})
 if r.returncode:raise RuntimeError(label+' failed: '+r.stderr[-1800:]+r.stdout[-600:])
run([sys.executable,'tools/build_app.py'],'build')
run(['node','tests/world_parts.cjs'],'new_model')
run(['node','tests/bench_regression.cjs'],'bench_regression')
run(['node','tests/parity.cjs'],'legacy_parity')
run(['node','tests/migration_and_cycles.cjs'],'migration_cycles')
run([sys.executable,'tools/write_spec.py'],'specification')
basebytes=(root/'reference/world_context_v0.6.json').read_bytes();base=json.loads(basebytes)
world=json.loads((root/'world_context_v0.7.json').read_text());spec=json.loads((root/'RRR_Wave_07.spec').read_text())
assert spec['manifest']['base_sha256']==hashlib.sha256(basebytes).hexdigest()
for k,v in base.items():
 if k=='manifest':continue
 if k=='development_waves':assert world[k][:-1]==v
 else:assert world[k]==v,k
assert world['development_waves'][-1]==spec
ids=[r['id']for r in spec['rules']];assert len(ids)==len(set(ids))
seen=set()
for t in spec['Plan']['tasks']:
 assert set(t['depends_on'])<=seen
 seen.add(t['id'])
c=spec['catalogue'];assert len(c['forms'])==10 and len(c['products'])==16
for f in c['forms'].values():
 assert f['facility']in c['facilities'];assert all(p in c['products']for p in f['products']);assert len(f['traits'])==3
for kit in c['kits']:assert all(p in c['products']for p in kit['products'])
try:
 import jsonschema
 jsonschema.validate(spec,json.loads((root/'wave07.schema.json').read_text()));schema='passed'
except ImportError:schema='not installed; explicit structural checks used'
if args.browser:run([sys.executable,'tests/browser_parts.py'],'browser')
if args.prior:
 with tempfile.TemporaryDirectory(prefix='rrr-w06-') as tmp:
  with zipfile.ZipFile(root/'reference/RRR_Wave_06_Agent_Pack.zip')as z:
   for n in z.namelist():
    dest=(Path(tmp)/n).resolve();assert dest.is_relative_to(Path(tmp).resolve())
   z.extractall(tmp)
  candidates=list(Path(tmp).rglob('tests/world_tests.cjs'));assert candidates
  p=candidates[0];(p.parents[1]/'evidence').mkdir(exist_ok=True)
  run(['node',str(p)],'original_wave06_world_regression',cwd=p.parents[1])
new=json.loads((evidence/'world_parts_report.json').read_text());bench=json.loads((evidence/'model_report.json').read_text());cy=json.loads((evidence/'migration_cycles.json').read_text())
report={'status':'pass','new_model':new['summary'],'continued_bench':bench['summary'],'legacy_parity_cases':6,'migration_checks':cy['count'],'operational_scenarios':cy['cycleCount'],'schema':schema,'baseline_content_preserved':True,'baseline_sha256':hashlib.sha256(basebytes).hexdigest(),'html_sha256':hashlib.sha256((root/'RRR_Living_Parts_v0.7.html').read_bytes()).hexdigest(),'runs':runs,'limits':'Test/profile behavior only; no human playtest, final balance, biological validation or native Windows/macOS runtime.'}
if (evidence/'browser_report.json').exists():
 b=json.loads((evidence/'browser_report.json').read_text());report['browser_recorded']={'checks':b['count'],'errors':b['errors'],'html_matches':b['html_sha256']==report['html_sha256'],'rerun_this_call':args.browser};assert report['browser_recorded']['html_matches'],'Browser evidence stale after HTML changed'
(evidence/'validation_report.json').write_text(json.dumps(report,indent=2)+'\n');print(json.dumps(report,indent=2))
