"""Consumer path from the actual browser-produced backup, without invented assets."""
from pathlib import Path
import hashlib, json, os
from playwright.sync_api import sync_playwright
ROOT=Path(__file__).resolve().parents[1]
checks=[];errors=[]
def ck(value,name):
    checks.append({'name':name,'passed':bool(value)})
    print(('PASS ' if value else 'FAIL ')+name,flush=True)
    if not value:raise AssertionError(name)
def world(page):return page.evaluate('RRR_WORKBENCH.world()')
with sync_playwright() as p:
    browser=p.chromium.launch(executable_path=os.environ.get('RRR_CHROMIUM','/usr/bin/chromium'),args=['--no-sandbox'])
    page=browser.new_page(viewport={'width':1440,'height':1000},reduced_motion='reduce')
    page.on('pageerror',lambda e:errors.append(str(e)));page.on('dialog',lambda d:d.accept())
    page.set_default_timeout(10000)
    page.set_content((ROOT/'RRR_Makers_Bloodlines_v0.12.html').read_text(),timeout=30000)
    page.wait_for_function('window.RRR_WORKBENCH !== undefined')
    page.locator('#tab-stock').click();page.locator('#world-file').set_input_files(str(ROOT/'evidence/browser_maker.rrr-save.json'))
    page.wait_for_function('RRR_WORKBENCH.world().maker.shipments.length>0')
    before=world(page);kit=next(k for k in before['kits'] if k.get('type')=='maker_host');kid=kit['id'];hid=kit['hostId'];items=kit['items']
    original=before['bench']['fitted'];originalhost=before['bench']['host']['id'] if isinstance(before['bench'].get('host'),dict) else 'HOST'
    quote=page.evaluate('(id)=>RRRMaker.retailQuote(RRR_WORKBENCH.world(),RRR_WORKBENCH.world().kits.find(k=>k.id===id))',kid)
    for _ in range(12):
        if world(page)['accounts']['player']>=quote+40:break
        page.locator('#club-work').click()
    ck(world(page)['accounts']['player']>=quote+40,'Normal funded club work covers purchase, fitting and attendance')
    page.locator('#tab-shop').click();card=page.locator(f'[data-maker-retail="{kid}"]');ck(card.count()==1,'One physical maker kit has one retail listing')
    
    page.locator(f'[data-shop="buyKit"][data-id="{kid}"]').click()
    w=world(page);ck(next(k for k in w['kits'] if k['id']==kid)['owner']=='player','Retail purchase transfers the existing packed kit')
    ck(all(next(s for s in w['parts'] if s['id']==id)['owner']=='player' for id in items),'Retail purchase transfers the same components')
    ck(next(s for s in w['specimens'] if s['id']==hid)['owner']=='player','Retail purchase transfers the same living host')
    page.locator('#tab-maker').click()
    print('product actions',page.locator('[data-maker-open]').count(),flush=True)
    page.locator(f'[data-maker-open="{kid}"]').click()
    w=world(page);ck(next(k for k in w['kits'] if k['id']==kid)['status']=='unpacked','The buyer opens the existing tin')
    ck(len(w['specimens'])==len(before['specimens']),'Opening does not clone the living foundation or donors')
    page.locator(f'[data-maker-guide="{kid}"]').click()
    w=world(page);ck(w['bench']['fitted']['placements']==[],'Purchased kit guide remains a draft, not an assembled racer')
    page.locator('#tab-bench').click();page.locator('#commit').click()
    w=world(page);ck({x['id'] for x in w['bench']['fitted']['placements']}==set(items),'Recipient personally commits the actual supplied anatomy')
    ck(w['stabled']['HOST']['fitted']==original,'Reference winner remains assembled on its separate host')
    page.locator('#go-race').click();page.locator('#run').click()
    page.wait_for_function('RRR_WORKBENCH.runs().length>0 && !RRR_WORKBENCH.world().pendingRace',timeout=45000)
    run=page.evaluate('RRR_WORKBENCH.runs()[0]'); player=next(r for r in run['results'] if r.get('host_id')==hid)
    ck(player['host_id']==hid,'Fresh race uses the repurchased host identity')
    ck(set(x['id'] for x in player['build']['design_snapshot']['placements'])==set(items),'Frozen race keeps the same delivered components')
    ck(not errors,'No uncaught browser errors')
    page.wait_for_timeout(1000);page.screenshot(path=str(ROOT/'evidence/recipient_kit_race.png'),full_page=True)
    end=world(page)
    (ROOT/'evidence/browser_retail_report.json').write_text(json.dumps({'checks':checks,'passed':sum(x['passed'] for x in checks),'failed':sum(not x['passed'] for x in checks),'errors':errors,'navigation':'set_content','scope':'Restores actual earlier browser world via file control; earns money via funded work; buys, opens, fits and races the same kit. Not autonomous NPC behavior.','html_sha256':hashlib.sha256((ROOT/'RRR_Makers_Bloodlines_v0.12.html').read_bytes()).hexdigest(),'kit_id':kid,'host_id':hid,'component_ids':items,'race_result':{'host_id':player['host_id'],'finish_time':player.get('finish_time'),'gates':player.get('gates')},'closing_cash':end['accounts']['player'],'turn':end['tick']},indent=2))
    browser.close()
