"""Behavioral counterexamples for the Wave 03 specification witnesses."""
import unittest
import json
from pathlib import Path
from copy import deepcopy
from fractions import Fraction
from itertools import product
from w03_model import *

HET = ((0, 1), (0, 1), (0, 1))
TOP = ((1, 1), (1, 1), (1, 1))
LOW = ((0, 0), (0, 0), (0, 0))


def stock_public(genotype=TOP):
    return {"id": "H", "name": "Candidate", "donor": HOPPER, "stage": "adult",
            "genotype": genotype, "internal_breeding_value": 999,
            "observations": {"phase_error": {"low": 0.015, "high": 0.025, "protocol": PROTOCOL}},
            "protections": []}


def workshop():
    w = Workshop({"seller": 100, "buyer": 100, "supplier": 0})
    w.stocks["D"] = Stock("D", HOPPER, "seller", "adult", TOP,
                          {"hind_pair", "body", "other"}, measured(TOP))
    w.stocks["host"] = Stock("host", "W02.DONOR.HOST", "seller", "adult", LOW,
                             {"native_body"})
    return w


def prepared(w, sid="P"):
    w.prepare("prepare-"+sid, "seller", "D", [{"id": sid, "product": HOPPER_PRODUCT, "tissues": ["hind_pair"]}])


def order(w, qty=1, deadline=10):
    w.fund("fund", Order("O", "buyer", HOPPER_PRODUCT, qty, 20, deadline, PROTOCOL, REQUIREMENTS))


class GeneticsTests(unittest.TestCase):
    def test_gametes_normalized(self):
        self.assertEqual(sum(gametes(HET).values()), 1)
        self.assertEqual(len(gametes(HET)), 8)

    def test_cross_normalized_all_three_locus_genotypes(self):
        genomes = list(product(((0, 0), (0, 1), (1, 1)), repeat=3))
        for a in genomes:
            for b in genomes:
                self.assertEqual(sum(cross(a, b).values()), 1)

    def test_no_unparented_alleles(self):
        self.assertEqual(cross(LOW, LOW), {LOW: Fraction(1)})

    def test_fixed_target_is_inherited(self):
        self.assertEqual(cross(TOP, TOP), {TOP: Fraction(1)})

    def test_complementary_founders_do_not_immediately_maximize(self):
        a = ((1, 1), (0, 0), (1, 1))
        b = ((0, 0), (1, 1), (1, 1))
        child = ((0, 1), (0, 1), (1, 1))
        self.assertEqual(cross(a, b), {child: Fraction(1)})

    def test_original_two_locus_target(self):
        self.assertEqual(target_probability(HET[:2], HET[:2], TOP[:2]), Fraction(1, 16))

    def test_three_locus_target(self):
        self.assertEqual(target_probability(HET, HET, TOP), Fraction(1, 64))

    def test_event_seed_replay(self):
        self.assertEqual(brood("seed", "B1", HET, HET, 24), brood("seed", "B1", HET, HET, 24))

    def test_unrelated_batch_does_not_reroll(self):
        before = brood("seed", "B1", HET, HET, 24)
        brood("seed", "OTHER", HET, TOP, 100)
        self.assertEqual(before, brood("seed", "B1", HET, HET, 24))

    def test_unknown_or_mismatched_genomes_fail(self):
        for a, b in [((), TOP), (((2, 2),), ((0, 1),)), (HET[:2], TOP)]:
            with self.assertRaises(RuleViolation):
                cross(a, b)


class EvidenceTests(unittest.TestCase):
    def setUp(self):
        self.project = [{"id": "complement-S", "donor": HOPPER, "protocol": PROTOCOL,
                         "requirements": {"phase_error": {"direction": "at_most", "value": 0.03}}}]

    def test_public_projection_has_no_truth_fields(self):
        self.assertNotIn("genotype", public_view(stock_public()))
        self.assertNotIn("internal_breeding_value", public_view(stock_public()))

    def test_equal_evidence_same_advice_despite_genetics(self):
        self.assertEqual(disposition(stock_public(TOP), self.project),
                         disposition(stock_public(LOW), self.project))

    def test_founder_protection(self):
        s = stock_public()
        s["protections"] = ["founder"]
        self.assertEqual(disposition(s, self.project)["action"], "keep")

    def test_missing_evidence_is_not_zero(self):
        self.assertEqual(evidence_match({}, REQUIREMENTS, PROTOCOL), "possible")

    def test_different_protocol_is_not_equivalent(self):
        m = measured(TOP)
        for obs in m.values(): obs["protocol"] = "uncontrolled-field"
        self.assertEqual(evidence_match(m, REQUIREMENTS, PROTOCOL), "possible")

    def test_straddling_bounds_request_review(self):
        s = stock_public()
        s["observations"]["phase_error"]["high"] = 0.08
        self.assertEqual(disposition(s, self.project)["matches"][0]["evidence"], "possible")

    def test_demonstrated_complement_not_autosold(self):
        r = disposition(stock_public(), self.project)
        self.assertEqual(r["action"], "review")
        self.assertEqual(r["matches"][0]["evidence"], "pass")

    def test_excluded_target_can_be_sale_candidate(self):
        s = stock_public()
        s["observations"]["phase_error"] = {"low": 0.1, "high": 0.12, "protocol": PROTOCOL}
        self.assertEqual(disposition(s, self.project)["action"], "sale_candidate")

    def test_spec_candidate_filter_does_not_require_finished_product(self):
        spec = json.loads((Path(__file__).parent / "RRR_Wave_03.spec").read_text())
        project = next(p for p in spec["operational_projects"] if p["id"] == "W03.PROJECT.HOPPER")
        s = stock_public()
        s["observations"] = measured(((0,0),(1,1),(1,1)))
        self.assertEqual(evidence_match(s["observations"], project["target"], PROTOCOL), "fail")
        r = disposition(s, [intake_project(project)])
        self.assertEqual(r["action"], "review")
        self.assertEqual(r["matches"][0]["evidence"], "pass")

    def test_invalid_observation_rejected(self):
        s = stock_public()
        s["observations"]["phase_error"]["low"] = 0.5
        with self.assertRaises(RuleViolation): disposition(s, self.project)


class CapacityTests(unittest.TestCase):
    def test_half_open_boundaries(self):
        c = Calendar({"grow": 8})
        c.reserve([Reservation("A", "grow", 0, 4, 8)])
        c.reserve([Reservation("B", "grow", 4, 8, 8)])
        self.assertEqual(c.occupancy("grow", 4), 8)
        self.assertEqual(c.occupancy("grow", 8), 0)

    def test_future_overcommit_rejected_atomically(self):
        c = Calendar({"pair": 2, "grow": 8})
        c.reserve([Reservation("A", "grow", 3, 7, 8)])
        before = deepcopy(c)
        with self.assertRaises(RuleViolation):
            c.reserve([Reservation("B", "pair", 0, 1, 1), Reservation("B", "grow", 5, 9, 8)])
        self.assertEqual(c, before)

    def test_whole_future_count_not_average(self):
        c = Calendar({"grow": 10})
        with self.assertRaises(RuleViolation): c.reserve([Reservation("A", "grow", 3, 7, 12)])

    def test_parent_is_a_capacity_resource(self):
        c = Calendar({"parent:P": 1})
        c.reserve([Reservation("A", "parent:P", 0, 2, 1)])
        with self.assertRaises(RuleViolation): c.reserve([Reservation("B", "parent:P", 1, 3, 1)])

    def test_delay_pauses_whole_unstarted_batch(self):
        c = Calendar({"grow": 8, "pair": 1})
        c.reserve([Reservation("A", "grow", 3, 7, 8)])
        c.reserve([Reservation("B", "grow", 7, 11, 8), Reservation("B", "pair", 6, 7, 1)])
        c.running.add("A")
        self.assertEqual(c.delay("A", "grow", 9, 5), ["B"])
        self.assertEqual(c.occupancy("grow", 8), 8)
        self.assertFalse(any(r.job == "B" for r in c.reservations))

    def test_delay_cannot_erase_existing_running_cohort(self):
        c = Calendar({"grow": 8})
        c.reserve([Reservation("A", "grow", 3, 7, 8)])
        c.reserve([Reservation("B", "grow", 7, 11, 8)])
        c.running.update({"A", "B"})
        before = deepcopy(c)
        with self.assertRaises(RuleViolation): c.delay("A", "grow", 9, 5)
        self.assertEqual(c, before)

    def test_duplicate_or_invalid_bundle(self):
        c = Calendar({"grow": 8})
        for bundle in [[], [Reservation("A", "grow", 2, 2, 1)], [Reservation("A", "unknown", 0, 1, 1)]]:
            with self.assertRaises(RuleViolation): c.reserve(bundle)


class InventoryTests(unittest.TestCase):
    def test_prepare_moves_tissue(self):
        w = workshop(); prepared(w)
        self.assertNotIn("hind_pair", w.stocks["D"].anatomy)
        self.assertEqual(w.sects["P"].tissues, {"hind_pair"})

    def test_cannot_harvest_same_anatomy_twice(self):
        w = workshop(); prepared(w)
        with self.assertRaises(RuleViolation): prepared(w, "P2")

    def test_overlapping_products_rejected_without_mutation(self):
        w = workshop(); before = deepcopy(w)
        with self.assertRaises(RuleViolation):
            w.prepare("bad", "seller", "D", [
                {"id": "P1", "product": "whole-hopper", "tissues": ["hind_pair"]},
                {"id": "P2", "product": "spring", "tissues": ["hind_pair"]}])
        self.assertEqual(w, before)

    def test_disjoint_products_allowed(self):
        w = workshop()
        w.prepare("good", "seller", "D", [
            {"id": "P1", "product": "whole-hopper", "tissues": ["hind_pair"]},
            {"id": "P2", "product": "other", "tissues": ["other"]}])
        self.assertEqual(len(w.sects), 2)

    def test_founder_protection_rejects_preparation(self):
        w = workshop(); w.stocks["D"].protections.add("founder")
        with self.assertRaises(RuleViolation): prepared(w)

    def test_vital_extraction_changes_living_state(self):
        w = workshop()
        w.prepare("vital", "seller", "D", [{"id": "P", "product": "body-part", "tissues": ["body"]}], {"body"})
        self.assertFalse(w.stocks["D"].alive)

    def test_multirole_kit_counts_one_component(self):
        w = workshop(); prepared(w)
        k = w.pack("pack", "K", "seller", {"jump": "P", "hindlimbs": "P", "landing": "P"}, ["drive"])
        self.assertEqual(k["components"], ["P"])

    def test_packaged_component_cannot_be_sold_separately(self):
        w = workshop(); prepared(w); order(w)
        w.pack("pack", "K", "seller", {"jump": "P"}, ["drive"])
        with self.assertRaises(RuleViolation): w.deliver("sale", "O", "seller", ["P"], 5)

    def test_installation_preserves_host_genome(self):
        w = workshop(); prepared(w); before = w.stocks["host"].genotype
        w.install("fit", "P", "seller", "host")
        self.assertEqual(w.stocks["host"].genotype, before)

    def test_installed_component_not_saleable(self):
        w = workshop(); prepared(w); order(w)
        w.install("fit", "P", "seller", "host")
        with self.assertRaises(RuleViolation): w.deliver("sale", "O", "seller", ["P"], 5)

    def test_idempotent_prepare(self):
        w = workshop(); prepared(w); before = deepcopy(w)
        prepared(w)
        self.assertEqual(w, before)


class CommerceTests(unittest.TestCase):
    def test_escrow_is_not_income(self):
        w = workshop(); order(w)
        self.assertEqual(w.cash["seller"], 100)
        self.assertEqual(w.cash["buyer"], 80)
        self.assertEqual(w.orders["O"].escrow, 20)
        self.assertEqual(w.total_money(), 200)

    def test_unfunded_order_rejected(self):
        w = workshop()
        with self.assertRaises(RuleViolation): order(w, qty=6)
        self.assertEqual(w.total_money(), 200)

    def test_delivered_assets_and_cash_change_together(self):
        w = workshop(); prepared(w); order(w)
        receipt = w.deliver("sale", "O", "seller", ["P"], 5)
        self.assertEqual(receipt["payment"], 20)
        self.assertEqual(w.sects["P"].owner, "buyer")
        self.assertEqual(w.cash["seller"], 120)
        self.assertEqual(w.total_money(), 200)

    def test_payment_is_idempotent(self):
        w = workshop(); prepared(w); order(w)
        w.deliver("sale", "O", "seller", ["P"], 5)
        w.deliver("sale", "O", "seller", ["P"], 5)
        self.assertEqual(w.cash["seller"], 120)

    def test_key_reuse_with_different_payload_rejected(self):
        w = workshop(); prepared(w); order(w)
        w.deliver("sale", "O", "seller", ["P"], 5)
        with self.assertRaises(RuleViolation): w.deliver("sale", "O", "seller", ["P"], 6)

    def test_duplicate_delivery_rejected(self):
        w = workshop(); prepared(w); order(w, qty=2)
        with self.assertRaises(RuleViolation): w.deliver("sale", "O", "seller", ["P", "P"], 5)

    def test_late_delivery_rejected(self):
        w = workshop(); prepared(w); order(w, deadline=4)
        with self.assertRaises(RuleViolation): w.deliver("sale", "O", "seller", ["P"], 5)

    def test_delivery_at_deadline_is_legal(self):
        w = workshop(); prepared(w); order(w, deadline=4)
        self.assertEqual(w.deliver("sale", "O", "seller", ["P"], 4)["payment"], 20)

    def test_unknown_measurement_does_not_pass_selected_order(self):
        w = workshop(); prepared(w); order(w)
        w.sects["P"].measurements = {}
        with self.assertRaises(RuleViolation): w.deliver("sale", "O", "seller", ["P"], 5)

    def test_batch_delivery_is_all_or_nothing(self):
        w = workshop(); prepared(w); order(w, qty=2)
        before = deepcopy(w)
        with self.assertRaises(RuleViolation): w.deliver("sale", "O", "seller", ["P", "absent"], 5)
        self.assertEqual(w, before)

    def test_refund_is_not_extra_cash(self):
        w = workshop(); order(w)
        w.close_order("cancel", "O"); w.close_order("cancel", "O")
        self.assertEqual(w.cash["buyer"], 100)
        self.assertEqual(w.total_money(), 200)

    def test_insufficient_operating_cash_no_mutation(self):
        w = workshop(); before = deepcopy(w)
        with self.assertRaises(RuleViolation): w.transfer("cost", "seller", "supplier", 101, "care")
        self.assertEqual(w, before)

    def test_unsold_inventory_has_no_cash_receipt(self):
        w = workshop(); prepared(w)
        self.assertEqual(w.cash["seller"], 100)


class BenchTests(unittest.TestCase):
    def test_shared_delivery_capacity(self):
        r = allocate_delivery({"drive": 4, "weapon": 6}, 5)
        self.assertEqual(r, {"drive": 2, "weapon": 3})

    def test_unused_capacity_does_not_create_demand(self):
        self.assertEqual(allocate_delivery({"drive": 2}, 10), {"drive": 2})

    def test_no_free_energy(self):
        for g in (LOW, HET, TOP):
            b = hopper_bench(g)
            self.assertLessEqual(b["useful_launch_energy"], b["spent_energy"])

    def test_real_upgrade_without_mandatory_drawback(self):
        a, b = hopper_bench(LOW), hopper_bench(TOP)
        self.assertEqual(a["spent_energy"], b["spent_energy"])
        self.assertGreater(b["range"], a["range"])
        self.assertLess(b["settle_time"], a["settle_time"])

    def test_bad_mount_does_not_rewrite_genotype(self):
        before = deepcopy(TOP)
        self.assertLess(hopper_bench(TOP, alignment_error=0.2)["range"], hopper_bench(TOP)["range"])
        self.assertEqual(before, TOP)

    def test_better_motor_faster_in_matched_straight(self):
        a, b = straight_bench(10, 2), straight_bench(12, 2.5)
        self.assertEqual(b["status"], "completed")
        self.assertLess(b["time"], a["time"])

    def test_zero_delivery_stalls(self):
        self.assertEqual(straight_bench(10, 2, delivery=0, max_time=1)["status"], "stalled")

    def test_integration_convergence(self):
        a = straight_bench(10, 2, dt=0.002)
        b = straight_bench(10, 2, dt=0.001)
        self.assertLess(abs(a["time"] - b["time"]), 0.01)

    def test_invalid_values_rejected(self):
        for fn in (lambda: hopper_bench(TOP, mass=0), lambda: allocate_delivery({"drive": -1}, 2),
                   lambda: straight_bench(10, 2, efficiency=1.1), lambda: straight_bench(float("nan"), 2)):
            with self.assertRaises(RuleViolation): fn()


class IntegrationTests(unittest.TestCase):
    def test_integrated_accounts(self):
        r = integrated_fixture()
        self.assertEqual(r["closing_player_cash"], 142)
        self.assertEqual(r["operating_margin"], 46)
        self.assertEqual(r["all_accounts_and_escrow"], 220)

    def test_integrated_stock_disposition(self):
        r = integrated_fixture()
        self.assertEqual(len(r["retained_replacements"]), 2)
        self.assertEqual(len(r["delivered_sects"]), 4)
        self.assertEqual(r["unsold_intact_offspring"], "B1-7")

    def test_chunked_world_time_same_result(self):
        a = integrated_fixture((8,))
        b = integrated_fixture((0, 1, 2, 4, 7, 8))
        del a["operating_clock_points"]; del b["operating_clock_points"]
        self.assertEqual(a, b)

    def test_repeated_clock_boundary_not_paid_twice(self):
        a = integrated_fixture((8,))
        b = integrated_fixture((0, 0, 2, 2, 7, 8, 8))
        del a["operating_clock_points"]; del b["operating_clock_points"]
        self.assertEqual(a, b)

    def test_purchased_upgrade_has_actual_custody(self):
        r = integrated_fixture()
        self.assertEqual(r["acquired_upgrade_owner"], "player")
        self.assertEqual(r["acquired_upgrade_custody"], "inventory")

    def test_clock_cannot_run_backwards(self):
        with self.assertRaises(RuleViolation): integrated_fixture((4, 2, 8))


if __name__ == "__main__":
    unittest.main(verbosity=2)
