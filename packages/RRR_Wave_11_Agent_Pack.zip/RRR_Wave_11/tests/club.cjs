'use strict';
const assert=require('node:assert/strict'),fs=require('fs'),path=require('path');
const W=require('../src/world.js'),B=require('../src/bench.js'),R=require('../src/race.js'),M=require('../src/club.js'),C=require('../src/catalog.js');
const tests=[];function test(name,fn){try{fn();tests.push({name,passed:true});}catch(e){tests.push({name,passed:false,error:e.stack});process.exitCode=1;console.error(name,e.message);}}
const eq=assert.deepEqual,bad=fn=>assert.throws(fn),copy=B.copy,apply=(w,c)=>W.apply(w,c).world;
function upgraded(){let w=W.initial();w.bench=B.place(B.place(w.bench,'UPGRADE-DRIVE'),'W05.PADS');return apply(w,{type:'fit'});}
function start(w,event='first'){return apply(w,{type:'clubEnter',event});}
function round(w){const out=W.apply(w,{type:'clubStart'}),runs=out.result.requests.map(q=>new R.Race(q.course,q.entrants,q.equipment,q.dt).run());return{world:apply(out.world,{type:'clubFinish',id:out.result.id,runs}),runs,request:out.result};}
function complete(w,event='first'){w=start(w,event);const report=[];for(let i=0;i<3;i++){const out=round(w);w=out.world;report.push(out.runs.map(r=>({results:r.results.map(x=>({host:x.host_id,time:x.finish_time,energy:x.remaining_energy})),events:r.events.reduce((a,e)=>(a[e.kind]=(a[e.kind]||0)+1,a),{})})));}return{world:w,report};}
let reference;
test('Initial historical host and Hopper preserved',()=>{const w=W.initial();eq(w.bench.fitted.placements[0].id,'H-6');eq(B.byId['H-6'].donor,'B1-6');});
test('No new player grant',()=>eq(W.initial().accounts.player,142));
test('Finite sponsor endowment is offset in external account',()=>{const w=W.initial();eq(w.accounts.club,1440);eq(w.accounts.external,-1440);eq(Object.values(w.accounts).reduce((a,b)=>a+b,0),362);});
test('Six component-built rivals have distinct physical identities',()=>{const w=W.initial();eq(w.club.roster.length,6);const ids=w.club.roster.flatMap(r=>[r.host.id,...r.parts.map(p=>p.id),...r.donors.map(s=>s.id)]);eq(new Set(ids).size,ids.length);});
for(const id of M.DEFINITIONS.map(d=>d.id))test(id+' public build uses same compiler and actual anatomy',()=>{const w=W.initial(),r=M.rosterBy(w,id);eq(B.compile(r.bench.fitted,r.bench.revision,r.bench.host_profile),r.build);for(const p of r.parts)eq(p.snapshot,C.descriptor(r.donors.find(s=>s.id===p.donor),p,B.BASE));});
test('NPC stock cannot be fitted by player',()=>{const w=W.initial();const id=w.club.roster[0].parts[0].id;assert(!W.availablePart(w,id));w.bench=B.place(w.bench,id);bad(()=>apply(w,{type:'fit'}));});
test('Changing hidden player genes does not rebuild rivals',()=>{const w=W.initial(),before=copy(w.club.roster);w.specimens.find(s=>s.id==='P-R').genes=[[1,1],[1,1],[1,1]];W.sync(w);eq(w.club.roster,before);});
test('All advertised club courses are valid connected routes',()=>{const w=W.initial();for(const e of M.EVENTS.filter(e=>e.id!=='home'))new R.Course(M.courseFor(w,e).course);});
test('All advertised opponents are legal in their event',()=>{const w=W.initial();for(const e of M.EVENTS)for(const id of e.roster)assert(R.legal(M.rosterBy(w,id).build,e.equipment));});
test('Each rival project uses the actual donor trait domain',()=>{const w=W.initial();for(const d of M.DEFINITIONS)W.apply(w,{type:'selectionProject',...d.target});});
test('Registration reserves full purse but no prize',()=>{const w=W.initial(),v=start(w);eq(v.accounts.player,w.accounts.player-6);eq(v.accounts.escrow,96);eq(v.accounts.club,1344);eq(v.tick,w.tick);});
test('Uncommitted draft rejected without payment',()=>{const w=W.initial();w.bench=B.place(w.bench,'UPGRADE-DRIVE');const before=copy(w);bad(()=>start(w));eq(w,before);});
test('Regional qualifier cannot be bought with ordinary funds',()=>bad(()=>start(W.initial(),'regional')));
test('Home invitational needs actually laid sections',()=>bad(()=>start(W.initial(),'home')));
test('Weapon capability rejects Speedsters even with peaceful policy',()=>{let w=W.initial();w.bench=B.place(w.bench,'W05.HORN');w=apply(w,{type:'fit'});bad(()=>start(w,'glass'));});
test('No offense rejects Fireworks',()=>bad(()=>start(W.initial(),'sparks')));
test('Horn and light profile enters Fireworks',()=>{let w=W.initial();w.bench=B.place(w.bench,'W05.HORN');w=apply(w,{type:'fit'});assert(start(w,'sparks').club.active);});
test('Only one active meet',()=>bad(()=>start(start(W.initial()),'glass')));
test('Pending round freezes four requests and class',()=>{const v=W.apply(start(W.initial()),{type:'clubStart'});eq(v.result.requests.length,4);for(const q of v.result.requests)eq(q.equipment,'open');});
test('Starting sides are mirrored for each same competitor',()=>{const r=W.apply(start(W.initial()),{type:'clubStart'}).result.requests;for(const e of r[0].entrants){const e2=r[1].entrants.find(x=>x.build.host_id===e.build.host_id);eq(e.d,-e2.d);} });
test('Mirrored heat reverses solver evaluation order too',()=>{const r=W.apply(start(W.initial()),{type:'clubStart'}).result.requests;eq(r[1].entrants.map(e=>e.build.host_id),r[0].entrants.map(e=>e.build.host_id).reverse());});
test('Schedule meets each other entrant twice',()=>{const counts=new Map();for(const pairs of M.PAIRINGS)for(const pair of pairs){const k=[...pair].sort().join();counts.set(k,(counts.get(k)||0)+2);}eq(counts.size,6);assert([...counts.values()].every(v=>v===2));});
test('Pending computation blocks biological and financial actions',()=>{const w=W.apply(start(W.initial()),{type:'clubStart'}).world;for(const cmd of [{type:'wait',turns:1},{type:'fit'},{type:'work'},{type:'clubWithdraw'}])bad(()=>apply(w,cmd));});
test('Cancel calculation incurs no round costs or time',()=>{const entered=start(W.initial()),w=W.apply(entered,{type:'clubStart'}).world,v=apply(w,{type:'clubCancel'});eq(v.accounts,entered.accounts);eq(v.tick,entered.tick);eq(v.club.active.round,0);});
test('Repeat computation after cancel has identical input',()=>{const a=W.apply(start(W.initial()),{type:'clubStart'}),b=W.apply(apply(a.world,{type:'clubCancel'}),{type:'clubStart'});eq(a.result,b.result);});
test('False result batch fails atomically',()=>{const w=W.apply(start(W.initial()),{type:'clubStart'}).world,before=copy(w);bad(()=>apply(w,{type:'clubFinish',id:w.club.active.pending.id,runs:[]}));eq(w,before);});
test('Two DNF rows yield no win or tie points',()=>eq(M.scoreRows([{host_id:'a',finish_time:null},{host_id:'b',finish_time:null}]),{a:0,b:0}));
test('One legitimate finisher wins over DNF',()=>eq(M.scoreRows([{host_id:'a',finish_time:10},{host_id:'b',finish_time:null}]),{a:3,b:0}));
test('Equal completed times share points',()=>eq(M.scoreRows([{host_id:'a',finish_time:10},{host_id:'b',finish_time:10}]),{a:1,b:1}));
test('Client-supplied place never overrides actual completion ordering',()=>eq(M.scoreRows([{host_id:'a',finish_time:12,place:1},{host_id:'b',finish_time:10,place:2}]),{a:0,b:3}));
test('Withdrawal returns all unawarded purse not registration',()=>{const w=start(W.initial()),v=apply(w,{type:'clubWithdraw'});eq(v.accounts.club,1440);eq(v.accounts.player,136);eq(v.accounts.escrow,0);eq(v.club.history[0].state,'withdrawn');eq(v.club.badges,[]);});
test('Withdrawal consumes sponsored edition and cannot reset by reopening',()=>{let w=W.initial();for(let i=0;i<3;i++)w=apply(start(w),{type:'clubWithdraw'});bad(()=>start(w));eq(w.club.editions.first,3);});
test('Fixed local format completes using actual simulations',()=>{reference=complete(upgraded());const w=reference.world,m=w.club.history[0];eq(m.rounds.length,3);eq(m.rounds.flatMap(r=>r.heats).length,12);eq(m.table.find(r=>r.account==='player').heats,6);assert(m.champion);W.validate(w);});
test('Measured player title is backed by wins and gates',()=>{const m=reference.world.club.history[0];eq(m.table[0].name,'SECOND HELPING');eq(m.table[0].wins,5);eq(m.table[0].points,15);for(const h of m.rounds.flatMap(r=>r.heats))for(const r of h.results)if(r.finish_time!==null)eq(r.gates,r.required_gates);});
test('Prize, costs and finite money reconcile',()=>{const w=reference.world;eq(w.accounts.player,174);eq(w.accounts.club,1344);eq(w.accounts.npc_ram,24);eq(w.accounts.npc_seam,12);eq(w.accounts.escrow,0);eq(Object.values(w.accounts).reduce((a,b)=>a+b,0),362);});
test('Round attendance advanced common care clock six turns',()=>eq(reference.world.tick,7));
test('Prize receipt retry does not repeat the payment',()=>{const w=reference.world,before=copy(w);bad(()=>apply(w,{type:'clubFinish',id:w.club.history[0].rounds[2].id,runs:[]}));eq(w,before);});
test('Actual Local win admits Regional, no Factional title yet',()=>{const w=reference.world;eq(w.club.badges.map(b=>b.code),['local_open']);assert(start(w,'regional').club.active);});
test('Save/restore preserves histories and all identities',()=>eq(W.restore(W.save(reference.world)),reference.world));
test('Invented qualification rejected on restore',()=>{const w=W.initial();w.club.badges.push({code:'local_open',meetId:'fake'});bad(()=>W.restore(JSON.stringify({schema:'RRR.W11.SAVE.1',world:w})));});
test('Changed result score rejected',()=>{const w=copy(reference.world);w.club.history[0].table[0].points+=1;bad(()=>W.validate(w));});
test('Changed rival genes rejected',()=>{const w=W.initial();w.club.roster[0].donors[0].genes=[[1,1],[1,1],[1,1]];bad(()=>W.validate(w));});
test('Wrong-course historical heat rejected',()=>{const w=copy(reference.world);w.club.history[0].rounds[0].heats[0].request.course.id='other';bad(()=>W.validate(w));});
test('Actual awarded pair changes owner without gene reroll',()=>{const w=reference.world,ids=['A','B'].map(x=>'W11.AWARD.stick.'+x),before=ids.map(id=>w.specimens.find(s=>s.id===id).genes);const v=apply(w,{type:'clubClaim',id:w.club.tickets[0].id,kind:'stick'});eq(ids.map(id=>v.specimens.find(s=>s.id===id).genes),before);assert(ids.every(id=>v.specimens.find(s=>s.id===id).owner==='player'));eq(v.accounts,w.accounts);});
test('Already claimed award cannot duplicate even alternate choice',()=>{const w=apply(reference.world,{type:'clubClaim',id:reference.world.club.tickets[0].id,kind:'stick'});bad(()=>apply(w,{type:'clubClaim',id:w.club.tickets[0].id,kind:'hopper'}));});
test('Gift honors actual holding capacity',()=>{const w=copy(reference.world);w.capacity.holding=W.occupied(w);bad(()=>apply(w,{type:'clubClaim',id:w.club.tickets[0].id,kind:'stick'}));});
test('A race trophy is not a gene unlock',()=>{const a=W.initial();assert(C.FORMS.stick&&C.FORMS.hopper);eq(a.club.tickets,[]);assert(W.apply(a,{type:'selectionProject',kind:'stick',trait:'release',op:'max',threshold:.045}));});
test('Editing after meet cannot change frozen record',()=>{let w=copy(reference.world);const frozen=copy(w.club.history);w.bench=B.remove(w.bench,'UPGRADE-DRIVE');w=apply(w,{type:'fit'});eq(w.club.history,frozen);});
test('Refitting between rounds changes next snapshot only',()=>{let w=start(upgraded());const first=round(w);w=first.world;const old=copy(w.club.active.rounds);w.bench=B.remove(w.bench,'UPGRADE-DRIVE');w=apply(w,{type:'fit'});const p=W.apply(w,{type:'clubStart'});assert(!p.result.requests[0].entrants[0].build.component_ids.includes('UPGRADE-DRIVE'));eq(p.world.club.active.rounds,old);});
test('Custom exhibition freezes actual physical course',()=>{let w=W.initial();w=apply(w,{type:'trackPublish'});w=start(w,'home');eq(w.club.active.course.version,w.trackworks.active);const old=copy(w);bad(()=>apply(w,{type:'trackPublish'}));eq(w,old);});
test('Custom exhibition declares no qualification reward',()=>eq(M.EVENTS.find(e=>e.id==='home').grant,null));
test('Second simultaneous breeding use of entered host rejected',()=>{const w=start(W.initial());bad(()=>apply(w,{type:'breed',parents:['HOST','P-R'],auto:false}));});
// Explicit synthetic no-finisher witnesses test settlement semantics without claiming races occurred.
test('All-retired synthetic meet awards no crown, qualifier, stock or purse',()=>{let w=start(W.initial());for(let i=0;i<3;i++){const p=W.apply(w,{type:'clubStart'});const runs=p.result.requests.map(q=>({course:new R.Course(q.course).data(),equipment:q.equipment,events:[],results:q.entrants.map(e=>({host_id:e.build.host_id,build:e.build,finish_time:null,gates:0,required_gates:new R.Course(q.course).gates.length}))}));w=apply(p.world,{type:'clubFinish',id:p.result.id,runs});}eq(w.club.history[0].champion,false);eq(w.club.badges,[]);eq(w.club.trophies,[]);eq(w.accounts.club,1440);});
test('Synthetic fully tied valid meet shares purse but no minimum-win qualifier',()=>{let w=start(W.initial());for(let i=0;i<3;i++){const p=W.apply(w,{type:'clubStart'});const runs=p.result.requests.map(q=>({course:new R.Course(q.course).data(),equipment:q.equipment,events:[],results:q.entrants.map(e=>({host_id:e.build.host_id,build:e.build,finish_time:50,gates:new R.Course(q.course).gates.length,required_gates:new R.Course(q.course).gates.length}))}));w=apply(p.world,{type:'clubFinish',id:p.result.id,runs});}eq(w.club.history[0].payments.map(x=>x.amount),[24,24,24,24]);eq(w.club.badges,[]);});
const report={tests,passed:tests.filter(t=>t.passed).length,failed:tests.filter(t=>!t.passed).length,scope:'Local authored model. Synthetic tie/retirement rows verify settlement, not physical simulations.',real_meet:reference?{table:reference.world.club.history[0].table,accounts:reference.world.accounts,turn:reference.world.tick,rounds:reference.report}:null};
fs.writeFileSync(path.join(__dirname,'../evidence/club_report.json'),JSON.stringify(report,null,2));
console.log('CLUB',report.passed,'/',tests.length);
