"""Reproduce bounded RRR checks. Standard-library only; no network or game launch.

Browser execution is a separate optional check. Existing browser evidence is
reported as recorded evidence, never silently relabeled as rerun.
"""
from __future__ import annotations
import copy
import hashlib
import json
import os
from pathlib import Path
import re
import subprocess
import sys
from datetime import datetime, timezone

ROOT = Path(__file__).resolve().parent
EVIDENCE = ROOT / 'evidence'
EVIDENCE.mkdir(exist_ok=True)
sys.path.insert(0, str(ROOT / 'model'))
from fixtures import write_outputs  # noqa: E402


def load(path: Path):
    return json.loads(path.read_text(encoding='utf-8'))


def ids(value):
    result = set()
    if isinstance(value, dict):
        if isinstance(value.get('id'), str):
            result.add(value['id'])
        for child in value.values():
            result.update(ids(child))
    elif isinstance(value, list):
        for child in value:
            result.update(ids(child))
    return result


def main() -> int:
    checks = []
    failures = []

    def check(name, condition, details=''):
        entry = {'name': name, 'pass': bool(condition), 'details': details}
        checks.append(entry)
        if not condition:
            failures.append(name)

    spec = load(ROOT / 'RRR_Wave_04.spec')
    base = load(ROOT / 'reference/world_context_v0.3.json')
    world = load(ROOT / 'world_context_v0.4.json')
    check('baseline_bytes', hashlib.sha256((ROOT / 'reference/world_context_v0.3.json').read_bytes()).hexdigest() == spec['manifest']['base_sha256'])
    check('new_wave_embedded_exactly', world['development_waves'][-1] == spec)
    projected = copy.deepcopy(world)
    projected['development_waves'].pop()
    allowed_manifest_changes = ('version', 'latest_wave', 'relationship_to_handbook', 'validation_scope')
    for key in allowed_manifest_changes:
        if key in base['manifest']:
            projected['manifest'][key] = base['manifest'][key]
        else:
            projected['manifest'].pop(key, None)
    check('prior_world_records_and_waves_unchanged', projected == base,
          'Only four explicitly declared top-level manifest fields and the appended wave change.')
    check('latest_manifest_matches', world['manifest']['latest_wave'] == 'W04')
    for path, digest in load(ROOT / 'reference/baseline_code_hashes.json').items():
        check('preserved_code_' + path, hashlib.sha256((ROOT / path).read_bytes()).hexdigest() == digest)
    check('required_exchange_sections', all(k in spec for k in ('Reference', 'Plan', 'Workflow', 'Adherence', 'MIVIM', 'systems')))
    check('no_invented_mivim_number', spec['MIVIM']['numeric_score'] is None)

    declared = spec['Reference']['sources'] + spec['Reference']['findings'] + spec['Plan']['tasks'] + spec['systems'] + spec['operational_threads'] + spec['service_contracts'] + spec['entity_extensions']
    declared += [r for g in spec['systems'] for r in g['rules']]
    names = [v['id'] for v in declared]
    check('unique_declared_ids', len(names) == len(set(names)))
    known = ids(base) | set(names)
    refs = []
    for g in spec['systems']:
        refs += g['refines']
        for r in g['rules']:
            check(r['id'] + '_shape', all(isinstance(r.get(k), str) and bool(r[k].strip()) for k in ('statement', 'decision', 'observable', 'maturity')))
    for t in spec['operational_threads']:
        refs += [t['donor_id'], t['facility_id']]
        check(t['id'] + '_purpose_chain', all(t.get(k) for k in ('trigger', 'next_evidence', 'where', 'selection', 'breeding_objective', 'output', 'customer', 'world_consequence', 'limit')))
    refs += [t['provider_ref'] for t in spec['service_contracts']]
    refs += [ref for task in spec['Plan']['tasks'] for ref in task['depends_on']]
    missing = sorted(set(refs) - known)
    check('all_declared_references_resolve', not missing, ', '.join(missing))
    seen = ids(base)
    for task in spec['Plan']['tasks']:
        check(task['id'] + '_ordered_dependencies', set(task['depends_on']) <= seen)
        seen.add(task['id'])
        check(task['id'] + '_artifacts_present', all((ROOT / p).is_file() for p in task['artifacts']))
    check('open_runtime_work_retained', any(t['acceptance_state'] == 'open' for t in spec['Plan']['tasks']))

    env = dict(os.environ)
    env['PYTHONPATH'] = str(ROOT / 'model')
    env['PYTHONDONTWRITEBYTECODE'] = '1'
    suites = []
    for name, directory, pattern in [('wave04', 'tests', 'test_wave04.py'), ('wave03_regression', 'reference', 'test_wave03.py')]:
        command = [sys.executable, '-B', '-m', 'unittest', 'discover', '-s', str(ROOT / directory), '-p', pattern, '-v']
        run = subprocess.run(command, cwd=ROOT, env=env, text=True, capture_output=True, timeout=90)
        output = run.stdout + run.stderr
        (EVIDENCE / (name + '_test_log.txt')).write_text(output, encoding='utf-8')
        match = re.search(r'Ran (\d+) tests? in ([\d.]+)s', output)
        record = {'suite': name, 'count': int(match[1]) if match else None,
                  'elapsed_reported_s': float(match[2]) if match else None, 'exit_code': run.returncode}
        suites.append(record)
        check(name + '_behavioral_suite', run.returncode == 0 and match is not None, str(record))

    fixture = json.loads(json.dumps(write_outputs(EVIDENCE), allow_nan=False))
    expected_summary = {'before_time': fixture['comparisons']['before']['finish_time'],
                        'after_time': fixture['comparisons']['after']['finish_time'],
                        'encounters': fixture['encounters'], 'meeting': fixture['meeting']}
    check('spec_fixture_reproduces', spec['fixture_summary'] == expected_summary)
    html = (ROOT / 'Race_Observatory.html').read_text(encoding='utf-8')
    embedded = re.search(r'<script id="data" type="application/json">(.*?)</script>', html, re.S)
    check('replay_data_present', embedded is not None)
    if embedded:
        viewer = json.loads(embedded[1])
        check('replay_summary_is_actual_model_output', viewer['summary'] == fixture)
        for mode in ('pass', 'horn', 'claw', 'hop'):
            check('replay_' + mode + '_is_actual_model_output', viewer['races'][mode] == load(EVIDENCE / ('race_' + mode + '.json')))
    check('replay_no_external_dependencies', not re.search(r'(?:src|href)=[\"\']https?://|\bfetch\(', html))
    report = {'status': 'pass' if not failures else 'fail',
              'run_at_utc': datetime.now(timezone.utc).isoformat(),
              'python': sys.version.split()[0], 'suites': suites,
              'structural_and_reproduction_checks': checks, 'failures': failures,
              'browser': {'execution': 'not rerun by this validator',
                          'recorded_report_available': (EVIDENCE / 'browser_report.json').is_file()},
              'limits': ['Not a player study or innovation grade', 'Not full game physics',
                         'Not a calibrated or autonomous economy', 'No fully coupled production/race clock',
                         'No complete reproductive ecology', 'Model examples use normalized units and disclosed in-kind inputs']}
    (EVIDENCE / 'validation_report.json').write_text(json.dumps(report, indent=2), encoding='utf-8')
    print(json.dumps({'status': report['status'], 'suites': suites, 'check_count': len(checks), 'failures': failures}, indent=2))
    return 1 if failures else 0


if __name__ == '__main__':
    raise SystemExit(main())
