'use strict';
const fs=require('fs'),path=require('path'),assert=require('node:assert/strict'),W=require('../src/world.js'),B=require('../src/bench.js'),C=require('../src/catalog.js'),E=require('../src/evidence.js');const tests=[];function test(n,f){try{f();tests.push({name:n,passed:true});}catch(e){tests.push({name:n,passed:false,error:e.stack});process.exitCode=1;console.error(n,e.message);}}
const eq=assert.deepEqual,old=JSON.parse(fs.readFileSync(path.join(__dirname,'../reference/w08_world_backup.json'))).world,w=W.migrate08(old),apply=(s,c)=>W.apply(s,c).world;
for(const k of ['accounts','bench','stabled','hosts','lines','selection','ledger','results','broods'])test('W08 migration preserves '+k,()=>eq(w[k],old[k]));
test('Every prior specimen retained unchanged',()=>{for(const s of old.specimens)eq(w.specimens.find(a=>a.id===s.id),s);});
test('Every prior component retained unchanged',()=>{for(const p of old.parts)eq(w.parts.find(a=>a.id===p.id),p);});
test('Existing complete kits retain exact custody',()=>{for(const k of old.kits)eq(w.kits.find(a=>a.id===k.id),k);});
test('Migrated world roundtrip preserves new and old state',()=>eq(W.restore(W.save(w)),w));
test('No repeat endowment on repeated forward save load',()=>{const v=W.restore(W.save(w));eq(v.parts.length,w.parts.length);eq(v.specimens.length,w.specimens.length);eq(v.trackworks.inventory.length,68);});
test('Unknown guide genetics do not leak through selection guidance',()=>{const a=W.initial();a.selection={kind:'darkling',trait:'friction',op:'max',threshold:.15,focus:'complement'};const s={...a.specimens.find(x=>x.kind==='darkling'),measured:false},t={...s,genes:[[1,1],[1,1],[1,1]]};eq(E.guidance(a,s),E.guidance(a,t));});
// Synthetic but disclosed capital for model lifecycle probes. Browser tests use real opening cash.
const probes=[];
for(const kind of ['feltmoth','darkling'])for(let seed=0;seed<8;seed++){
 test(`${kind} seed ${seed}: observed offspring can supply an actual product`,()=>{
  let s=W.initial();s.seed=`W09-STAGES-${kind}-${seed}`;s.accounts.player+=160;s.accounts.external-=160;
  for(const role of ['A','B'])s=apply(s,{type:'buyLive',id:`W07.SHOP.LIVE.${kind}.${role}`});
  s=apply(s,{type:'facility',id:C.FORMS[kind].facility});s=apply(s,{type:'breed',parents:[`W07.SHOP.LIVE.${kind}.A`,`W07.SHOP.LIVE.${kind}.B`],auto:false});const brood=s.broods.at(-1);for(let i=0;i<8;i++)s=apply(s,{type:'wait',turns:1});
  const kids=s.specimens.filter(a=>a.brood===brood.id);for(const kid of kids){assert(kid.parents.length===2);assert(kid.kind===kind);if(kid.alive)assert(kid.stage==='adult');}
  let prepared=null;const a=kids.find(x=>x.alive&&x.anatomy&&!x.protected);if(a){const before=C.traits(a),out=W.apply(s,{type:'prepare',id:a.id,product:C.FORMS[kind].products[0]});s=out.world;prepared=out.result;const part=s.parts.find(p=>p.id===prepared);eq(part.donor,a.id);const current=s.specimens.find(x=>x.id===a.id);eq(C.traits(current),before);assert(part.snapshot.stats[kind==='darkling'?'rail_friction':'brake_mu']===before.friction);}
  eq(W.restore(W.save(s)),s);probes.push({kind,seed,stage:brood.stage,observed:kids.length,prepared,remainingCash:s.accounts.player,scope:'synthetic funded lifecycle probe, not calibrated livelihood yield'});
 });
}
fs.writeFileSync(path.join(__dirname,'../evidence/continuity_report.json'),JSON.stringify({tests,passed:tests.filter(x=>x.passed).length,failed:tests.filter(x=>!x.passed).length,probes},null,2));console.log('CONTINUITY:',tests.filter(x=>x.passed).length,'/',tests.length);
