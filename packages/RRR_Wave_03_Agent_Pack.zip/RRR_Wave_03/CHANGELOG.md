# Changelog — Wave v0.3

Added Reference/Plan/Workflow/Adherence/MIVIM exchange spec; 82 atomic refinement rules; 9 developed spec tasks; 3 populated operational projects; 6 entity extensions; 2 controlled bench profiles; 4 UI interaction contracts; 4 ordered next tasks; 66 behavioral checks and scoped evidence reports.

Connected intake criteria, complementary founders, future stage occupancy, anatomy custody, finite funded orders and actual acquired stock. Added exact independent-locus and controlled performance witnesses. Preserved all prior context collections and the complete Wave 02 unchanged.

Corrected within this wave: candidate-selection criteria separated from final-product requirements; an upgrade payment now transfers an actual asset; delayed live cohorts retain occupancy. These are new implementation repairs, not silent edits to older source files.

Not implemented: full race/track/gait/combat runtime; general fertility or colony inheritance; realistic lifecycle and habitat simulation; self-renewing economy; rendered interfaces; player testing. No historical record, author canon or prior null parameter was silently rewritten.
