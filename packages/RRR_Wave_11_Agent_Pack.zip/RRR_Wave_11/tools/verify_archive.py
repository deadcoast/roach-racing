"""Verify exactly the delivered inventory, then optionally rebuild/test extracted bytes."""
import argparse,hashlib,json,subprocess,sys,tempfile,zipfile
from pathlib import Path,PurePosixPath
p=argparse.ArgumentParser();p.add_argument('archive',type=Path);p.add_argument('--run',action='store_true');p.add_argument('--report',type=Path);args=p.parse_args()
with tempfile.TemporaryDirectory(prefix='rrr-w11-verified-') as tmp:
 root=Path(tmp)
 with zipfile.ZipFile(args.archive) as z:
  for info in z.infolist():
   n=PurePosixPath(info.filename)
   if n.is_absolute() or '..' in n.parts:raise ValueError('Unsafe archive member')
  z.extractall(root)
 folder=root/'RRR_Wave_11';manifest=json.loads((folder/'package-manifest.json').read_text())
 inventory={str(f.relative_to(folder)) for f in folder.rglob('*') if f.is_file()}
 assert inventory==set(manifest['files'])|{'package-manifest.json'},'Archive inventory mismatch'
 for name,digest in manifest['files'].items():assert hashlib.sha256((folder/name).read_bytes()).hexdigest()==digest,name
 sources={n:h for n,h in manifest['files'].items() if n.startswith('src/') or n.endswith('.html')}
 result={'archive_sha256':hashlib.sha256(args.archive.read_bytes()).hexdigest(),'file_hashes_checked':len(manifest['files']),'inventory_exact':True,'unsafe_paths':False,'rebuild_and_tests':'not requested'}
 if args.run:
  run=subprocess.run([sys.executable,'validate_wave11.py'],cwd=folder,text=True,capture_output=True,timeout=600)
  result['validation_exit']=run.returncode
  if run.returncode:print(run.stdout,run.stderr);raise SystemExit(run.returncode)
  for name,digest in sources.items():assert hashlib.sha256((folder/name).read_bytes()).hexdigest()==digest,name+' changed after rebuild'
  result['rebuild_and_tests']='passed';result['source_and_application_bytes_after_rebuild']='unchanged';result['validation']=json.loads((folder/'evidence/validation_report.json').read_text())
 if args.report:args.report.write_text(json.dumps(result,indent=2))
 print(json.dumps(result,indent=2))
