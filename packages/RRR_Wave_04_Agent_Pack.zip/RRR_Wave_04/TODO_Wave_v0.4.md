# RRR — Wave v0.4 TODO

Completed specification does not close an unimplemented gameplay task.

## W04.T01 — Assembled component identities on a modular-course race
Priority: P0. Dependencies: W03.T07, W03.T06.
Specification: developed.
Execution: bounded_path_race_model_executed.
Acceptance: partial: no editable assembly or finished game physics.

## W04.T02 — Repeated production and livelihood affordability
Priority: P0. Dependencies: W03.T04, W03.T05.
Specification: extended through race demand and funded meetings.
Execution: one event and trial-order settlement; not repeated economy.
Acceptance: open.

## W04.T03 — Life-stage, removal and storage expansion
Priority: P1. Dependencies: W03.T03, W03.T06.
Specification: stage-specific market dependencies specified.
Execution: not implemented in this wave.
Acceptance: open.

## W04.T04 — Render intake, brood and kit interactions
Priority: P1. Dependencies: W03.T08.
Specification: race/replay presentation developed alongside earlier requirements.
Execution: replay viewer only; intake/brood/editable bench remain open.
Acceptance: partial.

## W04.T05 — Intertwine club, result, supply, field and breeder systems
Priority: P0. Dependencies: W04.T01.
Specification: developed with eight operational demand threads and six services.
Execution: bounded result-to-funded-trial witness; autonomous NPCs unimplemented.
Acceptance: specification delivered; broad runtime open.

## W04.T06 — Adversarial checks, baseline preservation and MIVIM closeout
Priority: P0. Dependencies: W04.T01, W04.T05.
Specification: developed.
Execution: tests and replay surface checks.
Acceptance: scoped review only.

# Next ordered work

## [ ] W04.T01.RUNTIME — Editable kit-bench slice feeding these same race snapshots
Physically fitted owned stock; visible donor signatures; novice and expert control; same inherited measurements; playtest finish/readability separately.

## [ ] W04.T02 — Repeated customer/production seasons and common-stock livelihood affordability
At least several uncertain cohorts, upkeep, household/workshop cost, real replenishment and competing customers; compare buying/catching/breeding routes.

## [ ] W04.T03 — One complete Clockleaf or pond lifecycle plus viable removal/storage
Target stage, replacement parents, transport, growth and decay; no surprise global host permadeath.

## [ ] W04.T04 — Complete rendered intake and brood interactions on shared state
Useful batch decisions, no hidden-truth leak, inspectable protections and care commitments, polished creature-centered presentation.