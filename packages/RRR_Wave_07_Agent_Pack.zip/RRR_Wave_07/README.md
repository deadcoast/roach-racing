# RRR / The Living Parts Catalogue / Wave 07

Open **RRR_Living_Parts_v0.7.html** in a browser. No installation, network assets or account is required. The file contains the whole local application.

## Start with a meaningful project

**Buy a kit:** visit Two Nets → buy a conversion tin → open it → use the existing tray and fitting controls → commit → race. These tins use your existing host; they are not complete extra roaches.

**Find a source:** Live stock → choose a habitat → read its target traits and useful stage → capture → inspect → prepare the selected anatomy. Return a competing component in the draft before fitting the replacement. Raw parts retain donor identity.

**Breed a useful line:** buy or retain reproductive adults of one form, build the required stage-support facility, select both parents and start a brood. All current forms use an explicitly simplified three-locus model, not natural insect genetics. Waxmoth larvae can supply a reservoir OR a damper; retain other individuals to adulthood.

**Earn from selected output:** read one of Two Nets' three funded orders, reserve it, produce measured loose components that meet its conditions and hand them over. Ordinary surplus sales remain in Live stock. Repeated practice pays no prize; its attendance advances world time once. Replay is free.

## Files

- `RRR_Wave_07.spec` — strict JSON, the wave's primary machine-readable exchange document.
- `RRR_Wave_07_Foundations.md` — source audit, donor catalogue, 70 atomic rules and scoped findings.
- `world_context_v0.7.json` — cumulative context; baseline content and prior waves preserved.
- `RRR_Wave_07_TODO.md` — developed scope and next ordered work.
- `RRR_MIVIM_Review_v0.7.md` — contribution assessment; no fabricated weighted grades.
- `src/` — continuation of the existing application, with a declarative donor/product catalogue.
- `tests/` and `evidence/` — behavioral, migration, race parity, browser and repeated-operation checks.
- `reference/` — byte-preserved Wave 6 archive/context and explicitly synthetic migration input.

## Rebuild / verify

Python 3.10+ and Node.js are sufficient for core checks. `jsonschema` is optional for the extra structural schema pass. Browser checks need Playwright and Chromium; the checked environment used `/usr/bin/chromium`.

```sh
python validate_wave07.py
python validate_wave07.py --browser --prior
```

The source compiler emits the self-contained HTML. `tools/write_spec.py` emits the foundation, `.spec`, cumulative context, review and TODO from one source. Reports state what ran. Tests do not establish biological plausibility, game balance, enjoyment, native file persistence or multiplayer authority.

## Persistence

Whole-world backup is under Live stock. Header Export sheet / Import handles a **recipe**, not ownership. World v0.6 backups migrate with original identities, cash and genes preserved. New supplier stock is a disclosed setup addition. New forward mechanics are versioned; old recorded results are not recomputed. Browser localStorage is best-effort; portable export is the tested path in the restricted host.

## Explicit limits

One owned host; two-racer ground paths; current prepared-interface geometry; no general body roster, multi-drive anatomy, flyer runtime or freely navigable wilderness. Source-game coefficients and a complete PCR item catalogue have not been reverse-engineered. Current part behavior is normalized authored game logic. No wall-clock progression while closed. The economic model has a disclosed external funding boundary, not autonomous national commerce. Prepared stock has no general decay/cold-chain system; only the specified larval and unprepared-remains windows are implemented.

The original game premise and MIVIM quality/innovation gates continue to govern. This is a revised and expanded foundation, not a declaration that the full world is finished.
