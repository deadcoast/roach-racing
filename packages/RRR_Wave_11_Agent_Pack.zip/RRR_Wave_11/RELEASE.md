# Wave 11 — executable release boundary

Runtime base: recovered Wave09. The prior Wave10 maker source and verified artifact were not recovered; its written requirements remain explicit pending work. No maker panel is silently claimed present.

New: six component-built rivals, five race cards, mirrored all-pairs club rounds, between-round refitting, actual NPC prizes, Local/Regional records, one choice of real breeder stock, public rival-to-project links, owned-course exhibitions, portable meet history.

Current evidence: 59 new behavioral checks; 22 migration checks; 63 continuing bench checks; 70 current Trackworks checks; six raw historical numerical comparisons; 31 original-release continuity checks. Four further event probes exercise actual complete meetings. Browser: 24 UI checks, exact HTML through set_content, no uncaught errors. No human playtest or native-platform persistence claim.

Synthetic all-tied and all-retired result batches test settlement only. Actual modeled meetings are separately reported. The full-stage ladder and simultaneous four-roach racing are not implemented.
