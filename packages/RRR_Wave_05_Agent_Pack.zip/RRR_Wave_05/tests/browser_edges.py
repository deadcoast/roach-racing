"""Actual HTML via set_content; extra input and blocked-worker checks. Native file storage is unverified."""
from pathlib import Path
import os
import json,hashlib
from playwright.sync_api import sync_playwright
root=Path(__file__).resolve().parents[1];html=(root/'RRR_Living_Workbench_v0.5.html').read_text();checks=[];errors=[]
with sync_playwright() as p:
 b=p.chromium.launch(executable_path=os.environ.get('RRR_CHROMIUM','/usr/bin/chromium'),headless=True,args=['--no-sandbox'])
 context=b.new_context(viewport={'width':1360,'height':1080})
 
 page=context.new_page();page.set_default_timeout(5000);page.on('pageerror',lambda e:errors.append(str(e)));page.set_content(html,wait_until='load');page.wait_for_function('!!window.RRR_WORKBENCH')
 assert not errors,errors
 # Actual pointer drag on a root. Track point derives only SVG coordinate transform.
 page.click('[data-stock="H-6"]')
 def point(x,y):return page.locator('#bench').evaluate('(el,p)=>{const q=el.createSVGPoint();q.x=p[0];q.y=p[1];const r=q.matrixTransform(el.getScreenCTM());return {x:r.x,y:r.y}}',[x,y])
 origin=point(320,310+.3*180);end=point(320+25,310+.3*180)
 page.mouse.move(origin['x'],origin['y']);page.mouse.down();page.mouse.move(end['x'],end['y'],steps=10);page.mouse.up()
 x=page.evaluate('RRR_WORKBENCH.state().draft.placements[0].x');assert x>.1
 assert page.evaluate('RRR_WORKBENCH.state().fitted.placements[0].x')==0
 checks.append('Actual pointer dragging changes draft root only')
 # Beyond support; fit blocked; undo restores prior native supported placement.
 far=point(320+130,310+.3*180)
 page.mouse.move(end['x'],end['y']);page.mouse.down();page.mouse.move(far['x'],far['y'],steps=10);page.mouse.up()
 assert page.locator('#commit').is_disabled();assert page.locator('#fit-errors').is_visible()
 page.click('#undo');page.click('#align');assert page.locator('#fit-errors').is_hidden()
 checks.append('Off-support pointer preview blocks fit and can be undone')
 # Actual card drag with native DataTransfer, not a model injection.
 page.locator('[data-stock="W05.CROP"]').drag_to(page.locator('#bench'),target_position={'x':330,'y':360})
 assert page.evaluate('RRR_WORKBENCH.state().draft.placements.some(p=>p.id==="W05.CROP")')
 checks.append('Native donor-card drag fits a preview on supported rail')
 page.click('#commit')
 # Create a fresh page with storage blocked by the host and Worker unavailable.
 page.close();page=context.new_page();page.set_default_timeout(5000);page.on('pageerror',lambda e:errors.append(str(e)))
 page.set_content(html,wait_until='load');page.wait_for_function('!!window.RRR_WORKBENCH')
 page.evaluate('() => { window.Worker = function(){ throw new Error("blocked for fallback test"); }; return true; }')
 page.click('#tab-race');page.click('#run');page.wait_for_function('RRR_WORKBENCH.runs().length===1',timeout=30000)
 row=page.evaluate('RRR_WORKBENCH.runs()[0].results.find(r=>r.host_id==="HOST")')
 assert abs(row['finish_time']-70.04552728926302)<1e-6
 checks.append('Worker-unavailable cooperative fallback matches the initial fixture')
 page.emulate_media(reduced_motion='reduce');page.click('#run');page.wait_for_function('RRR_WORKBENCH.runs().length===2',timeout=30000)
 assert not page.evaluate('RRR_WORKBENCH.playback().playing')
 checks.append('Reduced-motion preference does not auto-play new result')
 assert not errors,errors
 b.close()
report={'html_sha256':hashlib.sha256((root/'RRR_Living_Workbench_v0.5.html').read_bytes()).hexdigest(),'checks':checks,'page_errors':errors,'scope':'Linux Chromium; exact HTML via set_content. Host blocks file and test-origin navigation; native storage persistence not verified.','external_server':False}
(root/'evidence/browser_edge_report.json').write_text(json.dumps(report,indent=2));print(json.dumps(report,indent=2))
