{
  "manifest": {
    "id": "W07",
    "version": "0.7.0",
    "date": "2026-09-10",
    "title": "RRR — The Living Parts Catalogue",
    "status": "revisable_foundations_and_interactive_slice",
    "base_sha256": "401f47d372f5bceb97a8e81c7866268ac8838595344325d855bdfd29c02241a9",
    "extends": "RRR_World_Context_v0.6.json",
    "serialization": "strict JSON in .spec; RRR exchange format, not a claimed canonical private MIVIM grammar"
  },
  "Reference": {
    "sources": [
      {
        "id": "W07.S01",
        "title": "SEGA — official Gaiden customization image",
        "url": "https://ryu-ga-gotoku.com/gaiden/asia_en/adventure/img/adv03_03.jpg",
        "scope": "Eight performance-part menu families plus appearance options and a body entry; seven aggregate build readings.",
        "limits": "The screenshot does not disclose isolated part coefficients, a complete item catalogue, or every PCR installment. Build readings are not per-item effects.",
        "checked_on": "2026-09-10"
      },
      {
        "id": "W07.S02",
        "title": "Tamiya — Mini 4WD Setup Guide",
        "url": "https://www.tamiya.com/english/mini4wd/setupguide/setupguide.htm",
        "scope": "Distinct motor, gearing, contact, structure, fitting and handling decisions.",
        "limits": "Physical Mini 4WD is a separate reference layer; fixed-wheel cornering is not insect walking.",
        "checked_on": "2026-09-10"
      },
      {
        "id": "W07.S03",
        "title": "Tamiya — low-friction tires 15534",
        "url": "https://www.tamiya.com/english/products/15534/index.html",
        "scope": "Contact compound and placement can affect cornering and jumping.",
        "limits": "RRR foot purchase, peel release and surface response are authored mechanisms.",
        "checked_on": "2026-09-10"
      },
      {
        "id": "W07.S04",
        "title": "Tamiya — high-mount stabilizer 15528",
        "url": "https://www.tamiya.com/english/products/15528/index.html",
        "scope": "A distinct stabilizing attachment in the physical hobby.",
        "limits": "RRR sensors and support limbs are functional analogues, not literal biological wall rollers.",
        "checked_on": "2026-09-10"
      },
      {
        "id": "W07.S05",
        "title": "Tamiya — mass damper 15392",
        "url": "https://www.tamiya.com/english/products/15392/index.html",
        "scope": "A separately configured mass-damper component affects rebound.",
        "limits": "A prepared living damper is fictional; damping coefficients here are uncalibrated.",
        "checked_on": "2026-09-10"
      },
      {
        "id": "W07.S06",
        "title": "Tamiya — coordinated upgrade pack 15476",
        "url": "https://www.tamiya.com/english/products/15476/index.html",
        "scope": "Complementary physical components can be supplied together.",
        "limits": "Coordinated stock does not imply an invisible set bonus or identical genomes.",
        "checked_on": "2026-09-10"
      },
      {
        "id": "W07.S07",
        "title": "SEGA — Gaiden adventure / Pocket Circuit",
        "url": "https://ryu-ga-gotoku.com/gaiden/asia_en/adventure/",
        "scope": "A recurring venue, parts acquisition, fastest-time and rival competition surround customization.",
        "limits": "Does not define RRR breeding, institutions or customer funding.",
        "checked_on": "2026-09-10"
      }
    ],
    "reference_categories": [
      [
        "Body",
        "Host / native bodyform",
        "HOST identity preserved",
        "Single host runtime; bodyform roster and host breeding remain open"
      ],
      [
        "Tires",
        "Foot-contact sets",
        "sticktoe, cleats",
        "purchase / release / surface response"
      ],
      [
        "Frame",
        "Thoracic brace",
        "boxbrace",
        "supported lateral load / carried mass"
      ],
      [
        "Motor",
        "Drive musculature",
        "redline, torque",
        "cadence / force / conversion efficiency"
      ],
      [
        "Gears",
        "Hip-lever assembly",
        "lowstep",
        "ratio × fine adjustment"
      ],
      [
        "Battery",
        "Metabolic reservoir",
        "fatbody + existing Nectar Crop",
        "capacity / delivery / fill mass"
      ],
      [
        "Side Stabilizer",
        "Sensors or support limbs",
        "gyropods, counterbraces",
        "correction rate or support footprint"
      ],
      [
        "Suspension",
        "Landing couplers",
        "springknees or whole hoppers",
        "settling / impact transfer"
      ],
      [
        "Front Wing",
        "Shell vanes",
        "splitvanes, browfoil",
        "hold-down / aerodynamic drag"
      ],
      [
        "Mass dampers (physical hobby extension)",
        "Rebound organ",
        "keel",
        "rebound damping; not a duplicate reservoir"
      ],
      [
        "Weapons / active jump (RRR extension)",
        "Horn / claws / hoppers",
        "bullhorn, catchclaws, hoppers",
        "race interaction; not PCR slot claims"
      ]
    ],
    "stat_translation": [
      {
        "source_stat": "Speed",
        "rrr_reading": "Achievable running pace",
        "causes": "drive cadence + foot release + stride / leverage, limited by load and available supply",
        "limits": "Free stride is a ceiling; a lap result is measured separately."
      },
      {
        "source_stat": "Acceleration",
        "rrr_reading": "Rate of gaining speed",
        "causes": "drive force × leverage, traction, supply and carried mass",
        "limits": "No additional inherited acceleration gene duplicates those causes."
      },
      {
        "source_stat": "Grip",
        "rrr_reading": "Available surface contact",
        "causes": "clean purchase, loose purchase and contact load",
        "limits": "Release is separately represented; high grip is not identical to fast stepping."
      },
      {
        "source_stat": "Cornering",
        "rrr_reading": "Permitted speed and motion through a bend",
        "causes": "surface contact, lateral structural allowance, radius and body geometry",
        "limits": "Derived from the built system, not a flat cornering item bonus."
      },
      {
        "source_stat": "Balance",
        "rrr_reading": "Corrective response and usable support",
        "causes": "sensor latency, correction response, brace footprint, settling",
        "limits": "Current path model is a bounded proxy, not full roll/inertia simulation."
      },
      {
        "source_stat": "Downforce",
        "rrr_reading": "Speed-dependent hold-down",
        "causes": "front surface coefficient and orientation; associated drag",
        "limits": "Aero does not provide powered flight or low-speed magic grip."
      },
      {
        "source_stat": "Weight",
        "rrr_reading": "Actual entry mass",
        "causes": "native host, replacement accounting, physical parts counted once and reserve fill",
        "limits": "Mass is normalized, not calibrated grams; consumed fuel does not yet update in-race mass."
      }
    ],
    "source_evidence_boundary": "The screenshot does not disclose isolated part coefficients, a complete item catalogue, or every PCR installment. Build readings are not per-item effects.",
    "reviewed_repairs": [
      "W06 stored cicada efficiency without using it. W07 compiles it into the same force/energy equations.",
      "Frames, gears, stabilizers and independent suspension were not interchangeable current products. They now have donor/preparation/fit/race paths.",
      "Native feet initially inherited a zero-release default, making ordinary tissue unrealistically unbeatable on that input. Native and legacy prepared foot baselines are explicit in W07, and selected stock is tested as a genuine full-circuit upgrade.",
      "A donor-derived horn replacement initially bypassed the earlier yaw projection. The projection now applies to the measured reach.",
      "Alternative preparations could otherwise duplicate a whole hind pair, mantis arms or larval fatbody. Region allocations enforce a physical choice; disjoint scarab and mole products remain allowed.",
      "Live-stage expansion initially reused adult silhouettes in larval cards. The rendered cards and nursery now use stage-specific larval and pupal forms.",
      "Long donor ids dominated product titles. The inspector separates recognizable product names from stable provenance metadata.",
      "Two-column narrow shop cards compressed measurements. Narrow screens now use wider specimen and prepared-product cards.",
      "The same shop could have funded an immediate unchanged retail-to-order buyback profit. Retail acquisition now exceeds that same-counter selected resale; preparation or real market differences remain legitimate value sources.",
      "The inherited cumulative manifest described Wave 5 despite containing Wave 6. The new manifest explicitly records its current version and evidence; prior manifest remains in the byte-preserved baseline."
    ]
  },
  "Plan": {
    "tasks": [
      {
        "id": "W07.T01",
        "title": "Audit actual PCR families and correct the runtime coverage gap",
        "priority": "P0",
        "depends_on": [],
        "acceptance": "Source matrix and limitations explicit; no source coefficient invention.",
        "status": "developed"
      },
      {
        "id": "W07.T02",
        "title": "Connect eight interchangeable families to causal race variables",
        "priority": "P0",
        "depends_on": [
          "W07.T01"
        ],
        "acceptance": "Frames, ratios, contact release, efficiency, stabilization, landing and aero are compiled from installed stock.",
        "status": "implemented_and_model_tested"
      },
      {
        "id": "W07.T03",
        "title": "Expand purposeful capture and component-producing donor selection",
        "priority": "P0",
        "depends_on": [
          "W07.T02"
        ],
        "acceptance": "Ten forms, named routes, three relevant traits each, valid stages and practical products.",
        "status": "implemented_and_model_tested"
      },
      {
        "id": "W07.T04",
        "title": "Implement alternative and disjoint preparation with custody",
        "priority": "P0",
        "depends_on": [
          "W07.T03"
        ],
        "acceptance": "No tissue duplication; useful nonvital bodies and bounded vital remains; old bench preserved.",
        "status": "implemented_and_model_tested"
      },
      {
        "id": "W07.T05",
        "title": "Develop form-specific production and a useful-stage branch",
        "priority": "P0",
        "depends_on": [
          "W07.T04"
        ],
        "acceptance": "Distinct schedules and facilities; actual waxmoth larva to component or adult; retained founders.",
        "status": "implemented_profile_not_biological_validation"
      },
      {
        "id": "W07.T06",
        "title": "Build specimen-aware Two Nets, conversion tins and selected orders",
        "priority": "P0",
        "depends_on": [
          "W07.T05"
        ],
        "acceptance": "Funded purchases, packed custody, explicit measured demand, partial delivery and refund.",
        "status": "implemented_and_browser_tested"
      },
      {
        "id": "W07.T07",
        "title": "Polish source-to-bench presentation and stage recognition",
        "priority": "P1",
        "depends_on": [
          "W07.T06"
        ],
        "acceptance": "Whole stock, prepared art, causal metrics and larval/pupal icons; narrow layout inspected.",
        "status": "rendered_review_no_human_test"
      },
      {
        "id": "W07.T08",
        "title": "Validate continuation, migration, experiments and package",
        "priority": "P0",
        "depends_on": [
          "W07.T07"
        ],
        "acceptance": "Repeatable tests, six legacy parity cases, migration, multi-seed probes and extracted-archive checks.",
        "status": "tested_at_reported_scope"
      }
    ],
    "next": [
      {
        "id": "W08.T01",
        "priority": "P0",
        "title": "Complete the body/host layer and calibrated multi-family component catalogue",
        "acceptance": "At least several selectable host bodyforms with distinct geometry and native anatomy, purchasable full kits, source-traceable component grades and comparable test protocols. No arbitrary host-stat aura. Do not reset existing stock."
      },
      {
        "id": "W08.T02",
        "priority": "P0",
        "title": "Expand breeding evidence and earned market progression",
        "acceptance": "Longitudinal brood records, project-specific contribution guidance for every form, measured product qualification, repeat customer demand driven by delivered stock and public racing. Use enough seeds and actual play sessions to calibrate livelihood pacing."
      },
      {
        "id": "W08.T03",
        "priority": "P1",
        "title": "Complete missing track and physical-hobby functions",
        "acceptance": "Editable modular layouts, explicit braking and rail-guide families, richer airborne and contact interaction. Current bump seams are not a complete suspension model; flyers need real aerial paths, not a ground reskin."
      },
      {
        "id": "W08.T04",
        "priority": "P1",
        "title": "Viable storage, movement and commercial breadth",
        "acceptance": "Prepared-stock condition and actual shipping windows; more anatomical motion and ownership-preserving kit substitution. Species appearance inheritance and named lineage branding need real records; no hidden survival oracle."
      }
    ]
  },
  "Workflow": [
    "source/function audit",
    "data-driven donor and product model",
    "existing state and bench continuation",
    "new world/shop interaction",
    "adversarial and matched component tests",
    "rendered desktop/narrow review",
    "migration and repeated operational probes",
    "extracted delivery verification"
  ],
  "Adherence": {
    "authority": "User premises outrank generated proposals",
    "preserve": [
      "race speed and winning",
      "kit assembly",
      "anyone may catch and breed",
      "whole-insect Wrangloid trade",
      "genuine improvements and valuable collections",
      "Open freedom / Flyer segregation / Speedster weapon exclusion / Fireworks light protection",
      "Locals→Regionals→Factionals→New World City"
    ],
    "gates": "quality_at_declared_scope AND novel_development_adherence",
    "evaluation": [
      "effectiveness",
      "creativity",
      "scaling_potential"
    ],
    "no_invented_weights": true
  },
  "rules": [
    {
      "id": "W07.REFERENCE.01",
      "origin": "source_hobby_translation",
      "refines": [
        "W06.REVIEW.03",
        "W05.TUNE.01"
      ],
      "statement": "Audit distinct source part families before expanding supporting menus.",
      "player_decision": "Develop a missing race function and its supply chain together.",
      "observable": "The matrix shows runtime coverage and remaining gaps.",
      "status": "revisable_working_branch"
    },
    {
      "id": "W07.REFERENCE.02",
      "origin": "source_hobby_translation",
      "refines": [
        "W06.REVIEW.03",
        "W05.TUNE.01"
      ],
      "statement": "Gaiden menu evidence, physical Mini 4WD mechanisms and RRR extensions remain separate.",
      "player_decision": "Use the appropriate source for the function.",
      "observable": "Breeding tanks and insect weapons are never falsely attributed to a PCR menu.",
      "status": "revisable_working_branch"
    },
    {
      "id": "W07.REFERENCE.03",
      "origin": "source_hobby_translation",
      "refines": [
        "W06.REVIEW.03",
        "W05.TUNE.01"
      ],
      "statement": "Aggregate source-game stats do not establish isolated item coefficients.",
      "player_decision": "Author and label a normalized model where source coefficients are unknown.",
      "observable": "No invented numerical PCR item bonuses are reported.",
      "status": "revisable_working_branch"
    },
    {
      "id": "W07.REFERENCE.04",
      "origin": "source_hobby_translation",
      "refines": [
        "W06.REVIEW.03",
        "W05.TUNE.01"
      ],
      "statement": "Quality tiers describe measured performance within a family; appearance, rarity, acquisition price and reproductive value remain independent.",
      "player_decision": "Buy or retain a genuinely useful improvement.",
      "observable": "A rare shell cannot silently multiply drive power.",
      "status": "revisable_working_branch"
    },
    {
      "id": "W07.REFERENCE.05",
      "origin": "source_hobby_translation",
      "refines": [
        "W06.REVIEW.03",
        "W05.TUNE.01"
      ],
      "statement": "A same-family upgrade may genuinely improve several useful properties.",
      "player_decision": "Keep exceptional stock without an obligatory invented penalty.",
      "observable": "Selected feet can grip more and release faster than ordinary native feet.",
      "status": "revisable_working_branch"
    },
    {
      "id": "W07.REFERENCE.06",
      "origin": "source_hobby_translation",
      "refines": [
        "W06.REVIEW.03",
        "W05.TUNE.01"
      ],
      "statement": "One fixed host in this runtime is an incomplete body-selection translation, not a world-wide prohibition.",
      "player_decision": "Preserve the host while scheduling host-roster work explicitly.",
      "observable": "The eight interchangeable menu families are not mislabeled as a complete recreation of all PCR content.",
      "status": "revisable_working_branch"
    },
    {
      "id": "W07.PART.01",
      "origin": "source_hobby_translation",
      "refines": [
        "W05.TUNE.01",
        "W06.ANATOMY.05"
      ],
      "statement": "Drive cadence, useful force and conversion efficiency are separately inherited inputs.",
      "player_decision": "Select speed, loaded output or economy; then fit that exact drive.",
      "observable": "Cicada efficiency now reaches the energy model rather than remaining inert metadata.",
      "status": "revisable_working_branch"
    },
    {
      "id": "W07.PART.02",
      "origin": "source_hobby_translation",
      "refines": [
        "W05.TUNE.01",
        "W06.ANATOMY.05"
      ],
      "statement": "Prepared hip leverage multiplies fine setup while force and free stride speed respond separately.",
      "player_decision": "Use a Lowstep assembly for the desired delivery range.",
      "observable": "The gear does not create another source of energy.",
      "status": "revisable_working_branch"
    },
    {
      "id": "W07.PART.03",
      "origin": "source_hobby_translation",
      "refines": [
        "W05.TUNE.01",
        "W06.ANATOMY.05"
      ],
      "statement": "Foot purchase and release delay are independent properties.",
      "player_decision": "Seek a foot that holds and also disengages quickly.",
      "observable": "Effective cadence includes contact-release time.",
      "status": "revisable_working_branch"
    },
    {
      "id": "W07.PART.04",
      "origin": "source_hobby_translation",
      "refines": [
        "W05.TUNE.01",
        "W06.ANATOMY.05"
      ],
      "statement": "Contact uses a declared surface response rather than one universal grip bonus.",
      "player_decision": "Use cleats on loose ash or select useful pad material.",
      "observable": "Smooth and loose courses resolve through different measured contact inputs.",
      "status": "revisable_working_branch"
    },
    {
      "id": "W07.PART.05",
      "origin": "source_hobby_translation",
      "refines": [
        "W05.TUNE.01",
        "W06.ANATOMY.05"
      ],
      "statement": "The native contact profile has finite release time; undocumented zero-delay feet are not an invisible maximum-tier item.",
      "player_decision": "Compare selected stock against an ordinary native baseline.",
      "observable": "A real selected-foot replacement can improve the full circuit, including its component mass.",
      "status": "revisable_working_branch"
    },
    {
      "id": "W07.PART.06",
      "origin": "source_hobby_translation",
      "refines": [
        "W05.TUNE.01",
        "W06.ANATOMY.05"
      ],
      "statement": "Frame support and its mass constrain lateral loading independently of armor.",
      "player_decision": "Select light support for a driven body.",
      "observable": "Corner allowance changes through support divided by carried mass; protective carapace remains separate.",
      "status": "revisable_working_branch"
    },
    {
      "id": "W07.PART.07",
      "origin": "source_hobby_translation",
      "refines": [
        "W05.TUNE.01",
        "W06.ANATOMY.05"
      ],
      "statement": "A sensory stabilizer improves the response of existing correction limbs; a brace also changes the physical footprint.",
      "player_decision": "Choose fast sensing or extended support.",
      "observable": "Correction rate and width/support terms differ; no passive armor is invented.",
      "status": "revisable_working_branch"
    },
    {
      "id": "W07.PART.08",
      "origin": "source_hobby_translation",
      "refines": [
        "W05.TUNE.01",
        "W06.ANATOMY.05"
      ],
      "statement": "Suspension controls incoming impact and settling; a damper changes rebound after that impact.",
      "player_decision": "Choose landing couplers and a separately sourced rebound organ.",
      "observable": "Rail seams and jump landings use both inputs once.",
      "status": "revisable_working_branch"
    },
    {
      "id": "W07.PART.09",
      "origin": "source_hobby_translation",
      "refines": [
        "W05.TUNE.01",
        "W06.ANATOMY.05"
      ],
      "statement": "A reservoir supplies capacity and delivery; filling changes current reserve and mass.",
      "player_decision": "Choose a compact sprint supply or a larger reserve, then select fill.",
      "observable": "A large capacity cannot independently satisfy unlimited simultaneous power demands.",
      "status": "revisable_working_branch"
    },
    {
      "id": "W07.PART.10",
      "origin": "source_hobby_translation",
      "refines": [
        "W05.TUNE.01",
        "W06.ANATOMY.05"
      ],
      "statement": "Aero supplies hold-down and drag, not powered flight.",
      "player_decision": "Select a shaped plate or vane and fit its actual orientation.",
      "observable": "The surface can affect contact and energy demand without changing the locomotion division.",
      "status": "revisable_working_branch"
    },
    {
      "id": "W07.PART.11",
      "origin": "source_hobby_translation",
      "refines": [
        "W05.TUNE.01",
        "W06.ANATOMY.05"
      ],
      "statement": "Horn and claw input measurements continue to affect the installed action geometry.",
      "player_decision": "Select useful reach, closure and transmitted impact, then align the assembly.",
      "observable": "Yaw still projects horn reach after donor-specific values are applied.",
      "status": "revisable_working_branch"
    },
    {
      "id": "W07.PART.12",
      "origin": "source_hobby_translation",
      "refines": [
        "W05.TUNE.01",
        "W06.ANATOMY.05"
      ],
      "statement": "Every race freezes component identity and measured inputs.",
      "player_decision": "Enter a committed build.",
      "observable": "Future breeding, purchase or fitting cannot alter a recorded configuration.",
      "status": "revisable_working_branch"
    },
    {
      "id": "W07.ANATOMY.01",
      "origin": "rrr_native_biological_integration",
      "refines": [
        "W06.ANATOMY.01",
        "W06.ANATOMY.02"
      ],
      "statement": "A donor owns named physical regions; preparation transfers the required regions once.",
      "player_decision": "Choose a specific product from a living specimen.",
      "observable": "Neither a second menu role nor a second product label duplicates tissue.",
      "status": "revisable_working_branch"
    },
    {
      "id": "W07.ANATOMY.02",
      "origin": "rrr_native_biological_integration",
      "refines": [
        "W06.ANATOMY.01",
        "W06.ANATOMY.02"
      ],
      "statement": "Complete Hoppers and standalone Springknees use the same hind-joint source.",
      "player_decision": "Choose the complete paired assembly or its joint preparation.",
      "observable": "The source cannot supply both products; standalone joints fit native hind limbs in this starter profile.",
      "status": "revisable_working_branch"
    },
    {
      "id": "W07.ANATOMY.03",
      "origin": "rrr_native_biological_integration",
      "refines": [
        "W06.ANATOMY.01",
        "W06.ANATOMY.02"
      ],
      "statement": "Mantis arms can be attacking Catchclaws or non-attacking Counterbraces.",
      "player_decision": "Prepare the same donor for a different sporting purpose.",
      "observable": "The brace product has disabled attack capability and is evaluated accordingly.",
      "status": "revisable_working_branch"
    },
    {
      "id": "W07.ANATOMY.04",
      "origin": "rrr_native_biological_integration",
      "refines": [
        "W06.ANATOMY.01",
        "W06.ANATOMY.02"
      ],
      "statement": "Scarab drive tissue and support plates, and mole-cricket hip levers and toes, are distinct regions.",
      "player_decision": "Produce multiple honest products when their physical sources differ.",
      "observable": "The second product retains the same donor provenance without repeating the first region.",
      "status": "revisable_working_branch"
    },
    {
      "id": "W07.ANATOMY.05",
      "origin": "rrr_native_biological_integration",
      "refines": [
        "W06.ANATOMY.01",
        "W06.ANATOMY.02"
      ],
      "statement": "Vital extraction ends the donor living state; its unprepared remains have a short explicit processing window.",
      "player_decision": "Schedule any subsequent disjoint preparation before the window closes.",
      "observable": "A dead donor cannot breed or remain a permanent source of fresh tissue.",
      "status": "revisable_working_branch"
    },
    {
      "id": "W07.ANATOMY.06",
      "origin": "rrr_native_biological_integration",
      "refines": [
        "W06.ANATOMY.01",
        "W06.ANATOMY.02"
      ],
      "statement": "Nonvital extraction changes anatomy and retains supported-body care.",
      "player_decision": "Keep a reproductively capable body or use a declared custody service.",
      "observable": "An altered body cannot be sold as intact ordinary stock.",
      "status": "revisable_working_branch"
    },
    {
      "id": "W07.ANATOMY.07",
      "origin": "rrr_native_biological_integration",
      "refines": [
        "W06.ANATOMY.01",
        "W06.ANATOMY.02"
      ],
      "statement": "Existing protected founders require deliberate release before irreversible preparation.",
      "player_decision": "Choose immediate component use versus future reproduction.",
      "observable": "Routine actions cannot consume protected stock.",
      "status": "revisable_working_branch"
    },
    {
      "id": "W07.ANATOMY.08",
      "origin": "rrr_native_biological_integration",
      "refines": [
        "W06.ANATOMY.01",
        "W06.ANATOMY.02"
      ],
      "statement": "Prepared product observations are frozen from their actual donor and preparation.",
      "player_decision": "Fit, store or sell that component.",
      "observable": "The snapshot does not change merely because the remaining donor advances a stage.",
      "status": "revisable_working_branch"
    },
    {
      "id": "W07.ANATOMY.09",
      "origin": "rrr_native_biological_integration",
      "refines": [
        "W06.ANATOMY.01",
        "W06.ANATOMY.02"
      ],
      "statement": "Reusable workshop collars and retained native units remain restricted prepared interfaces.",
      "player_decision": "Exchange supported components on the existing bench.",
      "observable": "No universal painless removal, regrowth or unlimited preservation rule is added.",
      "status": "revisable_working_branch"
    },
    {
      "id": "W07.FIELD.01",
      "origin": "rrr_native_acquisition",
      "refines": [
        "W06.FIELD.01",
        "W06.FIELD.06"
      ],
      "statement": "Each route supplies a named form, useful stage, field signs and downstream products.",
      "player_decision": "Choose the source of the desired component.",
      "observable": "Ten routes are purposeful alternatives, not reskinned generic loot rolls.",
      "status": "revisable_working_branch"
    },
    {
      "id": "W07.FIELD.02",
      "origin": "rrr_native_acquisition",
      "refines": [
        "W06.FIELD.01",
        "W06.FIELD.06"
      ],
      "statement": "Protected and bulk capture have different capacity and anatomical preservation outcomes.",
      "player_decision": "Protect valuable feet, limbs, sensors or wings, or pursue ordinary volume.",
      "observable": "Damage affects the relevant physical region rather than improving or rerolling genes.",
      "status": "revisable_working_branch"
    },
    {
      "id": "W07.FIELD.03",
      "origin": "rrr_native_acquisition",
      "refines": [
        "W06.FIELD.01",
        "W06.FIELD.06"
      ],
      "statement": "Population identity belongs to a bounded world-time cohort.",
      "player_decision": "Return after development or choose another habitat.",
      "observable": "Reopening a view does not regenerate desirable stock.",
      "status": "revisable_working_branch"
    },
    {
      "id": "W07.FIELD.04",
      "origin": "rrr_native_acquisition",
      "refines": [
        "W06.FIELD.01",
        "W06.FIELD.06"
      ],
      "statement": "Capture evidence is not a complete genotype inspection.",
      "player_decision": "Pay for an assay, breed from supported knowledge or sell ordinary stock.",
      "observable": "Unmeasured cards disclose no exact trait values.",
      "status": "revisable_working_branch"
    },
    {
      "id": "W07.FIELD.05",
      "origin": "rrr_native_acquisition",
      "refines": [
        "W06.FIELD.01",
        "W06.FIELD.06"
      ],
      "statement": "Assay and preparation consume time while protecting the working individual from conflicting operations.",
      "player_decision": "Schedule the useful stage and care reserve.",
      "observable": "A process that would cross an unsupported molt window is rejected without partial mutation.",
      "status": "revisable_working_branch"
    },
    {
      "id": "W07.FIELD.06",
      "origin": "rrr_native_acquisition",
      "refines": [
        "W06.FIELD.01",
        "W06.FIELD.06"
      ],
      "statement": "Sold intact stock may become actual shop inventory.",
      "player_decision": "Supply the Wrangloid or buy that same available specimen later.",
      "observable": "The previous seller and a later buyer refer to one individual, not clones.",
      "status": "revisable_working_branch"
    },
    {
      "id": "W07.BREED.01",
      "origin": "rrr_native_progression",
      "refines": [
        "W06.BREED.01",
        "W06.BREED.04"
      ],
      "statement": "Ten authored donor forms use distinct stage schedules, clutch bounds and appropriate facilities in this experimental branch.",
      "player_decision": "Support the donor life history rather than apply a Hopper tank to everything.",
      "observable": "Root juveniles, burrowing stages, pupae, larvae and adults are separately recorded.",
      "status": "revisable_working_branch"
    },
    {
      "id": "W07.BREED.02",
      "origin": "rrr_native_progression",
      "refines": [
        "W06.BREED.01",
        "W06.BREED.04"
      ],
      "statement": "All current profiles use three independent diploid quantitative loci with versioned coefficients.",
      "player_decision": "Combine relevant inherited traits.",
      "observable": "This is a simplified fictional model, not a complete natural-history or Mewgenics algorithm.",
      "status": "revisable_working_branch"
    },
    {
      "id": "W07.BREED.03",
      "origin": "rrr_native_progression",
      "refines": [
        "W06.BREED.01",
        "W06.BREED.04"
      ],
      "statement": "Parents must be owned compatible adults of the same reproductive form and complementary A/B roles in this profile.",
      "player_decision": "Acquire suitable founders from a route or shop.",
      "observable": "Graft compatibility does not grant universal reproductive compatibility.",
      "status": "revisable_working_branch"
    },
    {
      "id": "W07.BREED.04",
      "origin": "rrr_native_progression",
      "refines": [
        "W06.BREED.01",
        "W06.BREED.04"
      ],
      "statement": "The missing breeding contribution can differ from the required finished component.",
      "player_decision": "Keep synchronization for a high-return project, or useful release in a high-purchase line.",
      "observable": "An individually weaker racer can be a valuable parent.",
      "status": "revisable_working_branch"
    },
    {
      "id": "W07.BREED.05",
      "origin": "rrr_native_progression",
      "refines": [
        "W06.BREED.01",
        "W06.BREED.04"
      ],
      "statement": "Waxmoth larval tissue is useful for a reservoir or damper; reproductive adults fulfill a different role.",
      "player_decision": "Harvest selected larvae while retaining replacements.",
      "observable": "One brood can produce components now and adults for future output.",
      "status": "revisable_working_branch"
    },
    {
      "id": "W07.BREED.06",
      "origin": "rrr_native_progression",
      "refines": [
        "W06.BREED.01",
        "W06.BREED.04"
      ],
      "statement": "A high-capacity larva and an efficiently reproducing adult lineage are different commercial assessments.",
      "player_decision": "Track harvested measurements and offspring results separately.",
      "observable": "Adult evidence can cite retained larval records without pretending the adult is a larval component.",
      "status": "revisable_working_branch"
    },
    {
      "id": "W07.BREED.07",
      "origin": "rrr_native_progression",
      "refines": [
        "W06.BREED.01",
        "W06.BREED.04"
      ],
      "statement": "Brood initiation reserves maximum committed places in its actual facility and global holding.",
      "player_decision": "Build the needed nursery or change the schedule.",
      "observable": "Expected mortality cannot manufacture physical room.",
      "status": "revisable_working_branch"
    },
    {
      "id": "W07.BREED.08",
      "origin": "rrr_native_progression",
      "refines": [
        "W06.BREED.01",
        "W06.BREED.04"
      ],
      "statement": "Ordinary-surplus policies remain optional and are not hidden genetic optimizers.",
      "player_decision": "Choose detailed selection or routine ordinary output.",
      "observable": "Protected replacements remain identified; unfunded surplus remains owned and cared for.",
      "status": "revisable_working_branch"
    },
    {
      "id": "W07.BREED.09",
      "origin": "rrr_native_progression",
      "refines": [
        "W06.BREED.01",
        "W06.BREED.04"
      ],
      "statement": "Failed pairing, survival, development and market acceptance remain distinct events.",
      "player_decision": "Improve the relevant bottleneck and preserve recovery options.",
      "observable": "A gene probability is not displayed as guaranteed income.",
      "status": "revisable_working_branch"
    },
    {
      "id": "W07.BREED.10",
      "origin": "rrr_native_progression",
      "refines": [
        "W06.BREED.01",
        "W06.BREED.04"
      ],
      "statement": "Larval, pupal and adult presentation follows the recorded stage.",
      "player_decision": "Recognize what is available before reading detailed values.",
      "observable": "The nursery no longer depicts every larva as an adult donor.",
      "status": "revisable_working_branch"
    },
    {
      "id": "W07.SHOP.01",
      "origin": "rrr_native_commerce",
      "refines": [
        "W06.CASH.01",
        "W05.RECIPE.01"
      ],
      "statement": "Two Nets sells whole live stock, loose prepared sects and coordinated conversion kits from distinct actual inventory.",
      "player_decision": "Buy a parent, a usable component or a build project.",
      "observable": "Each purchase transfers existing ownership once.",
      "status": "revisable_working_branch"
    },
    {
      "id": "W07.SHOP.02",
      "origin": "rrr_native_commerce",
      "refines": [
        "W06.CASH.01",
        "W05.RECIPE.01"
      ],
      "statement": "Shop measurements describe particular individuals or prepared components.",
      "player_decision": "Compare evidence rather than assume a species-wide guarantee.",
      "observable": "A stocked pair has distinct inherited profiles and provenance.",
      "status": "revisable_working_branch"
    },
    {
      "id": "W07.SHOP.03",
      "origin": "rrr_native_commerce",
      "refines": [
        "W06.CASH.01",
        "W05.RECIPE.01"
      ],
      "statement": "Conversion kits in this wave are for the already-owned host, not newly created full racers.",
      "player_decision": "Buy a coordinated set then build it yourself.",
      "observable": "The kit description discloses that the host is not included.",
      "status": "revisable_working_branch"
    },
    {
      "id": "W07.SHOP.04",
      "origin": "rrr_native_commerce",
      "refines": [
        "W06.CASH.01",
        "W05.RECIPE.01"
      ],
      "statement": "Packed kit custody blocks loose use until unpacking.",
      "player_decision": "Open the tin, choose placements and commit the build.",
      "observable": "A package cannot be sold complete while its components are fitted elsewhere.",
      "status": "revisable_working_branch"
    },
    {
      "id": "W07.SHOP.05",
      "origin": "rrr_native_commerce",
      "refines": [
        "W06.CASH.01",
        "W05.RECIPE.01"
      ],
      "statement": "Set value comes from complementary roles, actual selection and convenience.",
      "player_decision": "Choose a coordinated contact, loaded or hopper project.",
      "observable": "No invisible set aura, duplicated battery or bonus genome is granted.",
      "status": "revisable_working_branch"
    },
    {
      "id": "W07.SHOP.06",
      "origin": "rrr_native_commerce",
      "refines": [
        "W06.CASH.01",
        "W05.RECIPE.01"
      ],
      "statement": "The hopper conversion kit uses separate donors for the reservoir and damper.",
      "player_decision": "Allocate real stock to both functions.",
      "observable": "The same larval fatbody is not spent twice.",
      "status": "revisable_working_branch"
    },
    {
      "id": "W07.SHOP.07",
      "origin": "rrr_native_commerce",
      "refines": [
        "W06.CASH.01",
        "W05.RECIPE.01"
      ],
      "statement": "Live purchases enter protected custody.",
      "player_decision": "Deliberately release a breeder before selling or preparing it.",
      "observable": "A bought founder is not accidentally consumed by ordinary dispatch.",
      "status": "revisable_working_branch"
    },
    {
      "id": "W07.SHOP.08",
      "origin": "rrr_native_commerce",
      "refines": [
        "W06.CASH.01",
        "W05.RECIPE.01"
      ],
      "statement": "Ordinary sale quotes, retail prices and selected-order payments are different transactions.",
      "player_decision": "Choose immediate sale, preparation, trading or contracted production.",
      "observable": "Buying and reselling unchanged shop stock does not automatically make a profit.",
      "status": "revisable_working_branch"
    },
    {
      "id": "W07.SHOP.09",
      "origin": "rrr_native_commerce",
      "refines": [
        "W06.CASH.01",
        "W05.RECIPE.01"
      ],
      "statement": "Retail stock refresh does not recreate purchased individuals.",
      "player_decision": "Seek another source or develop production.",
      "observable": "Funds may renew under the explicit external-sector model while finite identities stay finite.",
      "status": "revisable_working_branch"
    },
    {
      "id": "W07.ORDER.01",
      "origin": "rrr_native_livelihood",
      "refines": [
        "W03.CASH.01",
        "W06.CASH.02"
      ],
      "statement": "A selected order names a product, measured acceptance, quantity, unit payment, deadline and buyer.",
      "player_decision": "Accept only a useful feasible commitment.",
      "observable": "A gene, rarity or reputation label cannot substitute for the requested physical output.",
      "status": "revisable_working_branch"
    },
    {
      "id": "W07.ORDER.02",
      "origin": "rrr_native_livelihood",
      "refines": [
        "W03.CASH.01",
        "W06.CASH.02"
      ],
      "statement": "Acceptance reserves actual buyer funds without recognizing seller income.",
      "player_decision": "Plan against funded demand.",
      "observable": "Escrow and available player cash remain separate.",
      "status": "revisable_working_branch"
    },
    {
      "id": "W07.ORDER.03",
      "origin": "rrr_native_livelihood",
      "refines": [
        "W03.CASH.01",
        "W06.CASH.02"
      ],
      "statement": "Only loose owned components not reserved in the draft or fitted host can be delivered.",
      "player_decision": "Choose commercial output rather than accidentally sell the racer.",
      "observable": "Delivery transfers custody and payment together.",
      "status": "revisable_working_branch"
    },
    {
      "id": "W07.ORDER.04",
      "origin": "rrr_native_livelihood",
      "refines": [
        "W03.CASH.01",
        "W06.CASH.02"
      ],
      "statement": "Partial accepted delivery earns only its completed share.",
      "player_decision": "Deliver useful current output while continuing the remainder.",
      "observable": "Cancellation or expiry returns unearned funds to the buyer.",
      "status": "revisable_working_branch"
    },
    {
      "id": "W07.ORDER.05",
      "origin": "rrr_native_livelihood",
      "refines": [
        "W03.CASH.01",
        "W06.CASH.02"
      ],
      "statement": "Deadline completion uses current counter arrival; shipping transit is not modeled in this local order slice.",
      "player_decision": "Complete a direct handover in the allowed window.",
      "observable": "A non-existent transport system is not credited as implemented.",
      "status": "revisable_working_branch"
    },
    {
      "id": "W07.ORDER.06",
      "origin": "rrr_native_livelihood",
      "refines": [
        "W03.CASH.01",
        "W06.CASH.02"
      ],
      "statement": "Intermediate and ordinary production retains easier outlets beside demanding selected orders.",
      "player_decision": "Sell useful surplus without meeting a premium project target.",
      "observable": "Every nonperfect animal is not categorically worthless.",
      "status": "revisable_working_branch"
    },
    {
      "id": "W07.ORDER.07",
      "origin": "rrr_native_livelihood",
      "refines": [
        "W03.CASH.01",
        "W06.CASH.02"
      ],
      "statement": "Race attendance, brood development, care and order expiry share the world clock; replay changes none of them.",
      "player_decision": "Attend, work, collect or advance time with visible commitments.",
      "observable": "The same delivery cannot pay twice through retry or playback.",
      "status": "revisable_working_branch"
    },
    {
      "id": "W07.ORDER.08",
      "origin": "rrr_native_livelihood",
      "refines": [
        "W03.CASH.01",
        "W06.CASH.02"
      ],
      "statement": "Repeated income probes report cash, retained stock, arrears and external funding separately.",
      "player_decision": "Compare commitments rather than advertised revenue alone.",
      "observable": "A 48-turn seed test is not certification of a sustainable national economy.",
      "status": "revisable_working_branch"
    },
    {
      "id": "W07.PRESENT.01",
      "origin": "rrr_native_execution",
      "refines": [
        "W06.UI.01",
        "W05.POLISH.03"
      ],
      "statement": "Component names lead the inspector while specimen identifiers remain accessible metadata.",
      "player_decision": "Recognize the part and then inspect its exact origin.",
      "observable": "Long generated identifiers do not dominate the main assembly title.",
      "status": "revisable_working_branch"
    },
    {
      "id": "W07.PRESENT.02",
      "origin": "rrr_native_execution",
      "refines": [
        "W06.UI.01",
        "W05.POLISH.03"
      ],
      "statement": "Source form, preparation alternatives, breeding purpose and mechanical contribution are displayed together.",
      "player_decision": "Move from desired behavior to a useful buying or collecting choice.",
      "observable": "The shop is not a disconnected generic price list.",
      "status": "revisable_working_branch"
    },
    {
      "id": "W07.PRESENT.03",
      "origin": "rrr_native_execution",
      "refines": [
        "W06.UI.01",
        "W05.POLISH.03"
      ],
      "statement": "Primary controls support explicit click and keyboard paths in addition to spatial placement.",
      "player_decision": "Build at casual depth or expose measurements.",
      "observable": "A user need not master direct dragging to use the new sect families.",
      "status": "revisable_working_branch"
    },
    {
      "id": "W07.PRESENT.04",
      "origin": "rrr_native_execution",
      "refines": [
        "W06.UI.01",
        "W05.POLISH.03"
      ],
      "statement": "The same part observation feeds the inspector, build compiler and frozen race entry.",
      "player_decision": "Compare and test the actual asset.",
      "observable": "No separate untraceable race-power layer awards the result.",
      "status": "revisable_working_branch"
    },
    {
      "id": "W07.PRESENT.05",
      "origin": "rrr_native_execution",
      "refines": [
        "W06.UI.01",
        "W05.POLISH.03"
      ],
      "statement": "A shape-specific representation is retained through shop, loose tray and host assembly.",
      "player_decision": "Recognize what was earned and fitted.",
      "observable": "Body art and component identity remain visible beside measurements.",
      "status": "revisable_working_branch"
    },
    {
      "id": "W07.EVIDENCE.01",
      "origin": "supporting",
      "refines": [
        "W06.SAVE.01",
        "W06.REVIEW.02"
      ],
      "statement": "World v0.6 migrates without granting new player money or changing prior genetic state.",
      "player_decision": "Restore an existing local world.",
      "observable": "New supplier inventory is disclosed; old identities, cash and fitted placements remain.",
      "status": "revisable_working_branch"
    },
    {
      "id": "W07.EVIDENCE.02",
      "origin": "supporting",
      "refines": [
        "W06.SAVE.01",
        "W06.REVIEW.02"
      ],
      "statement": "Forward W07 mechanics are versioned; stored historical race records are not recomputed.",
      "player_decision": "Evaluate a revised model without rewriting history.",
      "observable": "Legacy raw input parity and new current-build behavior have separate tests.",
      "status": "revisable_working_branch"
    },
    {
      "id": "W07.EVIDENCE.03",
      "origin": "supporting",
      "refines": [
        "W06.SAVE.01",
        "W06.REVIEW.02"
      ],
      "statement": "Quality and novel-development adherence remain non-compensable gates.",
      "player_decision": "Judge the actual integrated feature at its tested scope.",
      "observable": "Test counts do not prove fun, originality or retention.",
      "status": "revisable_working_branch"
    },
    {
      "id": "W07.EVIDENCE.04",
      "origin": "supporting",
      "refines": [
        "W06.SAVE.01",
        "W06.REVIEW.02"
      ],
      "statement": "Specification, executable prototype, numerical tests, rendered review and human playtests are distinct evidence states.",
      "player_decision": "Keep unverified work in the next queue.",
      "observable": "No prepared anatomy or stage window is called realistic insect biology.",
      "status": "revisable_working_branch"
    },
    {
      "id": "W07.EVIDENCE.05",
      "origin": "supporting",
      "refines": [
        "W06.SAVE.01",
        "W06.REVIEW.02"
      ],
      "statement": "Append this wave to cumulative context while preserving prior records and source bytes.",
      "player_decision": "Continue the same work instead of recreating another demo.",
      "observable": "Baseline hashes and unchanged content comparisons are supplied.",
      "status": "revisable_working_branch"
    }
  ],
  "catalogue": {
    "forms": {
      "hopper": {
        "name": "Switchyard hopper",
        "form": "HOPPER",
        "family": "Suspension / active mobility",
        "habitat": "Switchyard Verge",
        "sign": "Paired release and clean recovery after a short hop.",
        "seek": "Keep synchronized legs to complement a high-return line; distance alone is misleading.",
        "colour": "#c3944e",
        "products": [
          "hoppers",
          "springknees"
        ],
        "livePrice": 8,
        "breedPrice": 20,
        "facility": "dry",
        "stage": "adult",
        "region": "hind_pair",
        "profile": {
          "count": 6,
          "hatch": 2,
          "stages": [
            [
              2,
              "nymph"
            ],
            [
              5,
              "adult"
            ]
          ],
          "success": 0.88,
          "survival": 0.85,
          "cost": 6
        },
        "traits": [
          [
            "return",
            "Elastic return",
            "ratio",
            0.55,
            0.075,
            "higher"
          ],
          [
            "phase",
            "Release mismatch",
            "T",
            0.12,
            -0.05,
            "lower"
          ],
          [
            "settle",
            "Settling time",
            "T",
            0.18,
            -0.06,
            "lower"
          ]
        ]
      },
      "cicada": {
        "name": "Furnace cicada",
        "form": "CICADA",
        "family": "Motor",
        "habitat": "Cooling-kiln Galleries",
        "sign": "Rhythmic loaded movement; intact thorax, not loudness.",
        "seek": "Select cadence, force and useful work per reserve unit independently. Efficiency now reaches the race.",
        "colour": "#b85d48",
        "products": [
          "redline"
        ],
        "livePrice": 10,
        "breedPrice": 24,
        "facility": "root",
        "stage": "adult",
        "region": "drive",
        "profile": {
          "count": 4,
          "hatch": 2,
          "stages": [
            [
              2,
              "root_nymph"
            ],
            [
              7,
              "adult"
            ]
          ],
          "success": 0.82,
          "survival": 0.85,
          "cost": 7
        },
        "traits": [
          [
            "cadence",
            "Loaded cadence",
            "cycles/T",
            9,
            1.5,
            "higher"
          ],
          [
            "force",
            "Drive force",
            "F",
            1.9,
            0.35,
            "higher"
          ],
          [
            "efficiency",
            "Drive efficiency",
            "ratio",
            0.7,
            0.035,
            "higher"
          ]
        ]
      },
      "scarab": {
        "name": "Kilnback scarab",
        "form": "SCARAB",
        "family": "Motor / frame",
        "habitat": "Furnace Compost Beds",
        "sign": "Short loaded pushes; interlocking inner plates; do not grade by shell size.",
        "seek": "Strong support at ordinary mass creates frame stock; thick working muscles supply a different product.",
        "colour": "#b5a28a",
        "products": [
          "torque",
          "boxbrace"
        ],
        "livePrice": 10,
        "breedPrice": 24,
        "facility": "soil",
        "stage": "adult",
        "region": "drive",
        "profile": {
          "count": 4,
          "hatch": 2,
          "stages": [
            [
              2,
              "grub"
            ],
            [
              5,
              "pupa"
            ],
            [
              7,
              "adult"
            ]
          ],
          "success": 0.86,
          "survival": 0.88,
          "cost": 7
        },
        "traits": [
          [
            "force",
            "Drive force",
            "F",
            3.5,
            0.45,
            "higher"
          ],
          [
            "support",
            "Lateral support",
            "F",
            0.6,
            0.25,
            "higher"
          ],
          [
            "density",
            "Structural mass",
            "M",
            0.28,
            -0.04,
            "lower"
          ]
        ]
      },
      "mole": {
        "name": "Ballast mole cricket",
        "form": "MOLE",
        "family": "Gears / tires",
        "habitat": "Ballast Banks",
        "sign": "Intact short hip levers, toothed toes, grit-free joints.",
        "seek": "Lowstep leverage serves loaded starts; purchase on ash supplies a separate contact product.",
        "colour": "#b69365",
        "products": [
          "lowstep",
          "cleats"
        ],
        "livePrice": 9,
        "breedPrice": 22,
        "facility": "soil",
        "stage": "adult",
        "region": "hip_levers",
        "profile": {
          "count": 5,
          "hatch": 2,
          "stages": [
            [
              2,
              "burrow_nymph"
            ],
            [
              6,
              "adult"
            ]
          ],
          "success": 0.85,
          "survival": 0.88,
          "cost": 6
        },
        "traits": [
          [
            "ratio",
            "Mechanical advantage",
            "ratio",
            1.18,
            0.12,
            "higher"
          ],
          [
            "roughGrip",
            "Loose-surface purchase",
            "ratio",
            1.25,
            0.15,
            "higher"
          ],
          [
            "release",
            "Foot release delay",
            "T",
            0.05,
            -0.012,
            "lower"
          ]
        ]
      },
      "stick": {
        "name": "Glassfoot stick insect",
        "form": "STICK",
        "family": "Tires / contact material",
        "habitat": "Glazed Overgrowth",
        "sign": "Pad attachment followed by release; inspect clean surfaces under comparable conditions.",
        "seek": "Grip and release are distinct. A sticky but slow foot can bottleneck a high-cadence build.",
        "colour": "#acb49b",
        "products": [
          "sticktoe"
        ],
        "livePrice": 9,
        "breedPrice": 22,
        "facility": "reed",
        "stage": "adult",
        "region": "contact_pads",
        "profile": {
          "count": 5,
          "hatch": 3,
          "stages": [
            [
              3,
              "nymph"
            ],
            [
              7,
              "adult"
            ]
          ],
          "success": 0.9,
          "survival": 0.88,
          "cost": 6
        },
        "traits": [
          [
            "grip",
            "Clean purchase",
            "ratio",
            1.15,
            0.15,
            "higher"
          ],
          [
            "release",
            "Foot release delay",
            "T",
            0.07,
            -0.025,
            "lower"
          ],
          [
            "dust",
            "Dust retention",
            "ratio",
            0.68,
            0.12,
            "higher"
          ]
        ]
      },
      "wax": {
        "name": "Reservoir waxmoth",
        "form": "WAX",
        "family": "Battery / rebound damper",
        "habitat": "Insulation Cavities",
        "sign": "Supported feeding larvae, not swollen recent gut contents; retain some to adulthood.",
        "seek": "Harvest larval fatbody for energy OR a prepared damper. Adult breeders are not the same usable tissue stage.",
        "colour": "#d2b37d",
        "products": [
          "fatbody",
          "keel"
        ],
        "livePrice": 9,
        "breedPrice": 24,
        "facility": "drawer",
        "stage": "larva",
        "region": "fatbody",
        "profile": {
          "count": 6,
          "hatch": 1,
          "stages": [
            [
              1,
              "larva"
            ],
            [
              4,
              "pupa"
            ],
            [
              6,
              "adult"
            ]
          ],
          "success": 0.9,
          "survival": 0.9,
          "cost": 5
        },
        "traits": [
          [
            "capacity",
            "Usable reserve",
            "E",
            155,
            25,
            "higher"
          ],
          [
            "delivery",
            "Delivery ceiling",
            "E/T",
            4,
            1.5,
            "higher"
          ],
          [
            "damping",
            "Rebound dissipation",
            "ratio",
            0.18,
            0.16,
            "higher"
          ]
        ]
      },
      "fly": {
        "name": "Sumpfly",
        "form": "FLY",
        "family": "Side stabilizer / sensing",
        "habitat": "Damp Service Voids",
        "sign": "Paired club-ended organs; controlled turns, not merely frantic flight.",
        "seek": "Low signal delay permits an earlier correction through existing limbs. Sensors supply no free force.",
        "colour": "#8eb2aa",
        "products": [
          "gyropods"
        ],
        "livePrice": 8,
        "breedPrice": 20,
        "facility": "drawer",
        "stage": "adult",
        "region": "sensors",
        "profile": {
          "count": 5,
          "hatch": 1,
          "stages": [
            [
              1,
              "larva"
            ],
            [
              3,
              "pupa"
            ],
            [
              5,
              "adult"
            ]
          ],
          "success": 0.88,
          "survival": 0.86,
          "cost": 5
        },
        "traits": [
          [
            "latency",
            "Signal delay",
            "T",
            0.2,
            -0.06,
            "lower"
          ],
          [
            "correction",
            "Usable correction",
            "ratio",
            0.7,
            0.1,
            "higher"
          ],
          [
            "mass",
            "Paired organ mass",
            "M",
            0.07,
            -0.012,
            "lower"
          ]
        ]
      },
      "mantis": {
        "name": "Saltglass mantis",
        "form": "MANTIS",
        "family": "Grasp offense / support braces",
        "habitat": "Saltglass Perches",
        "sign": "Long useful reach with quick closure; isolate predatory stock in transit.",
        "seek": "Select fast closing arms for interception OR prepare the same limbs as disabled-attack counterbraces.",
        "colour": "#bcb38a",
        "products": [
          "catchclaws",
          "counterbraces"
        ],
        "livePrice": 12,
        "breedPrice": 28,
        "facility": "predator",
        "stage": "adult",
        "region": "forelimbs",
        "profile": {
          "count": 4,
          "hatch": 2,
          "stages": [
            [
              2,
              "nymph"
            ],
            [
              7,
              "adult"
            ]
          ],
          "success": 0.78,
          "survival": 0.85,
          "cost": 8
        },
        "traits": [
          [
            "reach",
            "Working reach",
            "L",
            1.2,
            0.15,
            "higher"
          ],
          [
            "closure",
            "Closure delay",
            "T",
            0.17,
            -0.045,
            "lower"
          ],
          [
            "support",
            "Brace extension",
            "L",
            0.1,
            0.025,
            "higher"
          ]
        ]
      },
      "horn": {
        "name": "Bullhorn beetle",
        "form": "HORN",
        "family": "Ram / front aero",
        "habitat": "Compost Undercrofts",
        "sign": "Intact root and useful curve; long tips can conceal weak bases.",
        "seek": "Preserve the horn-root assembly for attacks; separate head plates can become a browfoil.",
        "colour": "#dfc69b",
        "products": [
          "bullhorn",
          "browfoil"
        ],
        "livePrice": 12,
        "breedPrice": 28,
        "facility": "soil",
        "stage": "adult",
        "region": "horn",
        "profile": {
          "count": 4,
          "hatch": 2,
          "stages": [
            [
              2,
              "grub"
            ],
            [
              5,
              "pupa"
            ],
            [
              8,
              "adult"
            ]
          ],
          "success": 0.85,
          "survival": 0.88,
          "cost": 7
        },
        "traits": [
          [
            "reach",
            "Contact reach",
            "L",
            1.2,
            0.12,
            "higher"
          ],
          [
            "impact",
            "Transferred impact",
            "ratio",
            0.85,
            0.15,
            "higher"
          ],
          [
            "vane",
            "Shaped-plate hold-down",
            "coefficient",
            0.025,
            0.0125,
            "higher"
          ]
        ]
      },
      "moth": {
        "name": "Ashveil moth",
        "form": "MOTH",
        "family": "Front wing / aero",
        "habitat": "Textile Ruins",
        "sign": "Intact margins and stiff light veins; resting inspection preserves surfaces.",
        "seek": "Select high hold-down at modest drag, while retaining distinctive natural patterns for collectors.",
        "colour": "#948b75",
        "products": [
          "splitvanes"
        ],
        "livePrice": 9,
        "breedPrice": 22,
        "facility": "drawer",
        "stage": "adult",
        "region": "wings",
        "profile": {
          "count": 5,
          "hatch": 1,
          "stages": [
            [
              1,
              "larva"
            ],
            [
              3,
              "pupa"
            ],
            [
              6,
              "adult"
            ]
          ],
          "success": 0.88,
          "survival": 0.87,
          "cost": 6
        },
        "traits": [
          [
            "downforce",
            "Hold-down",
            "coefficient",
            0.025,
            0.015,
            "higher"
          ],
          [
            "drag",
            "Air resistance",
            "coefficient",
            0.009,
            -0.003,
            "lower"
          ],
          [
            "mass",
            "Surface mass",
            "M",
            0.05,
            -0.01,
            "lower"
          ]
        ]
      }
    },
    "products": {
      "hoppers": {
        "name": "Grasshopper Hoppers",
        "kind": "hopper",
        "template": "H-6",
        "regions": [
          "hind_pair"
        ],
        "vital": false,
        "stages": [
          "adult"
        ],
        "price": 22,
        "pcr": "Suspension + RRR jump",
        "purpose": "One paired assembly carries launch and landing anatomy."
      },
      "springknees": {
        "name": "Locust Springknees",
        "kind": "suspension",
        "regions": [
          "hind_pair"
        ],
        "vital": false,
        "stages": [
          "adult"
        ],
        "price": 18,
        "pcr": "Suspension",
        "purpose": "Fit landing couplers to native hind legs. A complete Hopper already contains this tissue; the two are alternative builds."
      },
      "redline": {
        "name": "Cicada Redline",
        "kind": "drive",
        "template": "UPGRADE-DRIVE",
        "regions": [
          "drive"
        ],
        "vital": true,
        "stages": [
          "adult"
        ],
        "price": 30,
        "pcr": "Motor",
        "purpose": "Cadence, force and conversion efficiency feed motion and energy consumption separately."
      },
      "torque": {
        "name": "Scarab Torque Bundle",
        "kind": "drive",
        "template": "W05.TORQUE",
        "regions": [
          "drive"
        ],
        "vital": true,
        "stages": [
          "adult"
        ],
        "price": 28,
        "pcr": "Motor",
        "purpose": "High force at lower cadence; ratio is still a separate component choice."
      },
      "boxbrace": {
        "name": "Scarab Boxbrace",
        "kind": "frame",
        "regions": [
          "support_plates"
        ],
        "vital": true,
        "stages": [
          "adult"
        ],
        "price": 24,
        "pcr": "Frame",
        "purpose": "Lateral structural support changes the corner load limit at an actual carried mass. Not an armor score."
      },
      "lowstep": {
        "name": "Mole-Cricket Lowstep",
        "kind": "gear",
        "regions": [
          "hip_levers"
        ],
        "vital": false,
        "stages": [
          "adult"
        ],
        "price": 20,
        "pcr": "Gears",
        "purpose": "A prepared leverage ratio multiplies the fine-tuning setting; force and free stride speed move in opposite directions."
      },
      "cleats": {
        "name": "Mole-Cricket Cleats",
        "kind": "pads",
        "template": "W05.PADS",
        "regions": [
          "toe_tips"
        ],
        "vital": false,
        "stages": [
          "adult"
        ],
        "price": 18,
        "pcr": "Tires",
        "purpose": "Mechanical purchase on loose ash differs from performance on smooth enamel."
      },
      "sticktoe": {
        "name": "Sticktoe Contact Set",
        "kind": "pads",
        "template": "W05.PADS",
        "regions": [
          "contact_pads"
        ],
        "vital": false,
        "stages": [
          "adult"
        ],
        "price": 20,
        "pcr": "Tires",
        "purpose": "Purchase limits slip; peel delay changes usable cadence. The same feet do not gain extra traction from a rarity label."
      },
      "fatbody": {
        "name": "Waxmoth Fatbody",
        "kind": "reserve",
        "template": "W05.CROP",
        "regions": [
          "fatbody"
        ],
        "vital": true,
        "stages": [
          "larva"
        ],
        "price": 24,
        "pcr": "Battery",
        "purpose": "Capacity, delivery and loaded mass govern range and supplied power. Larva is the usable donor stage."
      },
      "keel": {
        "name": "Larval Keel",
        "kind": "damper",
        "regions": [
          "fatbody"
        ],
        "vital": true,
        "stages": [
          "larva"
        ],
        "price": 20,
        "pcr": "Physical Mini 4WD mass damper",
        "purpose": "The same larval tissue is allocated to a constrained damping assembly, not simultaneously to a second reservoir."
      },
      "gyropods": {
        "name": "Fly Gyropods",
        "kind": "stabilizer",
        "regions": [
          "sensors"
        ],
        "vital": false,
        "stages": [
          "adult"
        ],
        "price": 22,
        "pcr": "Side stabilizer — sensing alternative",
        "purpose": "Signal delay changes the correction rate supplied through available legs; no added force or armor."
      },
      "catchclaws": {
        "name": "Mantis Catchclaws",
        "kind": "claws",
        "template": "W05.CLAWS",
        "regions": [
          "forelimbs"
        ],
        "vital": false,
        "stages": [
          "adult"
        ],
        "price": 28,
        "pcr": "RRR derby extension",
        "purpose": "Reach and closure timing feed actual grasp attempts."
      },
      "counterbraces": {
        "name": "Mantis Counterbraces",
        "kind": "stabilizer",
        "regions": [
          "forelimbs"
        ],
        "vital": false,
        "stages": [
          "adult"
        ],
        "price": 22,
        "pcr": "Side stabilizer — physical support",
        "purpose": "Forelimbs are prepared as support-only lateral braces with grasp disabled. Added support competes with passing width."
      },
      "bullhorn": {
        "name": "Bullhorn Ram",
        "kind": "horn",
        "template": "W05.HORN",
        "regions": [
          "horn"
        ],
        "vital": false,
        "stages": [
          "adult"
        ],
        "price": 28,
        "pcr": "RRR derby extension",
        "purpose": "Root-supported contact, reach and impact alter an aligned charge."
      },
      "browfoil": {
        "name": "Beetle Browfoil",
        "kind": "vanes",
        "template": "W05.VANES",
        "regions": [
          "head_plates"
        ],
        "vital": false,
        "stages": [
          "adult"
        ],
        "price": 18,
        "pcr": "Front wing",
        "purpose": "Prepared head-shell vanes add hold-down and real modeled drag; they do not grant flight."
      },
      "splitvanes": {
        "name": "Ashveil Split-Vanes",
        "kind": "vanes",
        "template": "W05.VANES",
        "regions": [
          "wings"
        ],
        "vital": false,
        "stages": [
          "adult"
        ],
        "price": 20,
        "pcr": "Front wing",
        "purpose": "Light veined surfaces with selectable hold-down, drag and mass."
      }
    },
    "facilities": {
      "dry": {
        "name": "Dry-bank nursery",
        "cost": 0,
        "note": "Paired running stock; six committed places."
      },
      "root": {
        "name": "Root-and-emergence cabinet",
        "cost": 34,
        "note": "Root-fed juveniles then adult drive donors; seven-turn profile."
      },
      "soil": {
        "name": "Deep-soil nursery",
        "cost": 32,
        "note": "Burrowing young, pupation where required, protected emergence."
      },
      "reed": {
        "name": "Vertical molt case",
        "cost": 30,
        "note": "Climbing nymphs and room for intact pads to develop."
      },
      "drawer": {
        "name": "Larval / pupation drawer",
        "cost": 28,
        "note": "Stage selection: retain replacements instead of harvesting every larva."
      },
      "predator": {
        "name": "Partitioned predator case",
        "cost": 38,
        "note": "Controlled pairing and separated growing arms."
      }
    },
    "kits": [
      {
        "id": "CONTACT",
        "name": "Glassline / contact pair",
        "tag": "Tires + stabilizer",
        "products": [
          "sticktoe",
          "gyropods"
        ],
        "price": 59,
        "purpose": "Clean purchase, quick release and sensory correction. Build it on your existing roach."
      },
      {
        "id": "LOAD",
        "name": "Lowstep / load kit",
        "tag": "Motor + gears + frame",
        "products": [
          "torque",
          "lowstep",
          "boxbrace"
        ],
        "price": 96,
        "purpose": "Loaded force, mechanical advantage and supporting structure. Three distinct choices, not a set bonus."
      },
      {
        "id": "HOP",
        "name": "Last Laugh / hop set",
        "tag": "Hoppers + reserve + damper",
        "products": [
          "hoppers",
          "fatbody",
          "keel"
        ],
        "price": 84,
        "purpose": "A paired launch assembly, a separate energy donor and a separate damper donor. No duplicated fatbody."
      }
    ],
    "mapping": [
      [
        "Body",
        "Host / native bodyform",
        "HOST identity preserved",
        "Single host runtime; bodyform roster and host breeding remain open"
      ],
      [
        "Tires",
        "Foot-contact sets",
        "sticktoe, cleats",
        "purchase / release / surface response"
      ],
      [
        "Frame",
        "Thoracic brace",
        "boxbrace",
        "supported lateral load / carried mass"
      ],
      [
        "Motor",
        "Drive musculature",
        "redline, torque",
        "cadence / force / conversion efficiency"
      ],
      [
        "Gears",
        "Hip-lever assembly",
        "lowstep",
        "ratio × fine adjustment"
      ],
      [
        "Battery",
        "Metabolic reservoir",
        "fatbody + existing Nectar Crop",
        "capacity / delivery / fill mass"
      ],
      [
        "Side Stabilizer",
        "Sensors or support limbs",
        "gyropods, counterbraces",
        "correction rate or support footprint"
      ],
      [
        "Suspension",
        "Landing couplers",
        "springknees or whole hoppers",
        "settling / impact transfer"
      ],
      [
        "Front Wing",
        "Shell vanes",
        "splitvanes, browfoil",
        "hold-down / aerodynamic drag"
      ],
      [
        "Mass dampers (physical hobby extension)",
        "Rebound organ",
        "keel",
        "rebound damping; not a duplicate reservoir"
      ],
      [
        "Weapons / active jump (RRR extension)",
        "Horn / claws / hoppers",
        "bullhorn, catchclaws, hoppers",
        "race interaction; not PCR slot claims"
      ]
    ],
    "geometry": {
      "frame": {
        "mass": 0.2,
        "replaces": 0.15,
        "default": {
          "x": 0,
          "y": 0.02,
          "angle": 0
        },
        "bounds": [
          -0.07,
          0.07,
          -0.08,
          0.12
        ],
        "layer": "structural",
        "roots": [
          [
            -0.16,
            0,
            0.1,
            0.5
          ],
          [
            0.16,
            0,
            0.1,
            0.5
          ]
        ],
        "roles": [
          "frame"
        ]
      },
      "gear": {
        "mass": 0.08,
        "replaces": 0.05,
        "default": {
          "x": 0,
          "y": 0.13,
          "angle": 0
        },
        "bounds": [
          -0.06,
          0.06,
          0.07,
          0.2
        ],
        "layer": "transmission",
        "roots": [
          [
            0,
            0,
            0.27,
            0.14
          ]
        ],
        "roles": [
          "leverage"
        ]
      },
      "suspension": {
        "mass": 0.12,
        "replaces": 0.08,
        "default": {
          "x": 0,
          "y": 0.31,
          "angle": 0
        },
        "bounds": [
          -0.08,
          0.08,
          0.22,
          0.42
        ],
        "layer": "shell",
        "roots": [
          [
            -0.27,
            0,
            0.13,
            0.18
          ],
          [
            0.27,
            0,
            0.13,
            0.18
          ]
        ],
        "roles": [
          "landing"
        ]
      },
      "damper": {
        "mass": 0.13,
        "replaces": 0,
        "default": {
          "x": 0,
          "y": 0.22,
          "angle": 0
        },
        "bounds": [
          -0.09,
          0.09,
          0.1,
          0.38
        ],
        "layer": "ventral",
        "roots": [
          [
            0,
            0,
            0.16,
            0.2
          ]
        ],
        "roles": [
          "rebound"
        ]
      },
      "stabilizer": {
        "mass": 0.07,
        "replaces": 0,
        "default": {
          "x": 0,
          "y": 0,
          "angle": 0
        },
        "bounds": [
          -0.08,
          0.08,
          -0.1,
          0.1
        ],
        "layer": "support",
        "roots": [
          [
            -0.34,
            0,
            0.1,
            0.13
          ],
          [
            0.34,
            0,
            0.1,
            0.13
          ]
        ],
        "roles": [
          "balance"
        ]
      }
    }
  },
  "formula_contracts": {
    "free_stride": "stride / (ratio * (1/cadence + release_delay))",
    "native_release_delay": 0.045,
    "legacy_contact_set_release_delay": 0.035,
    "lateral_support": "1.2 + brace_support / entry_mass + support_extension / body_height",
    "correction": "min(.75, .35 + .5*usable_correction/(1+signal_delay)); only existing actuation is used",
    "landing": "settling_time * (1 - damping)",
    "power": "one shared delivery ceiling; drive work consumes reserve / inherited efficiency",
    "gear": "prepared_ratio × adjustable_leverage; force and unloaded stride change separately",
    "aero": "hold_down*v^2 adds contact load; drag*v^2 opposes running",
    "scope": "normalized authored profiles, not measured animal physics"
  },
  "world_threads": [
    {
      "id": "W07.THREAD.PADS",
      "institution": "SHOP_TWO_NETS",
      "chain": [
        "grip/release requirement",
        "Glassfoot field population or live founders",
        "vertical nursery",
        "selected contact anatomy",
        "foot set or retained breeder",
        "measured counter order or personally fitted racer"
      ]
    },
    {
      "id": "W07.THREAD.WAX",
      "institution": "SHOP_TWO_NETS",
      "chain": [
        "reservoir or rebound need",
        "living waxmoth parents",
        "larval drawer",
        "useful larval window",
        "fatbody OR keel from each larva",
        "retained adults support later brood",
        "different donors supply both components in a kit"
      ]
    },
    {
      "id": "W07.THREAD.LOAD",
      "institution": "VENUE_FOUNDRY",
      "chain": [
        "loaded-racing project",
        "scarb drive / support tissue and mole hip geometry",
        "honest disjoint preparations",
        "coordinated conversion kit",
        "personal workbench assembly",
        "race entry and public fit evidence"
      ]
    },
    {
      "id": "W07.THREAD.BROOD",
      "institution": "ORG_CINDER",
      "chain": [
        "specific customer requirements",
        "selected parental contribution",
        "stage capacity and care",
        "ordinary intermediate output plus retained stock",
        "accepted funded payment",
        "additional useful production capacity"
      ]
    }
  ],
  "evidence": {
    "component_comparisons": {
      "order": {
        "scope": "Synthetic selected founder genes; actual catch, preparation and settlement commands",
        "ids": [
          "W07.PART.W07.CATCH.stick.0.0.sticktoe",
          "W07.PART.W07.CATCH.stick.0.1.sticktoe"
        ],
        "paid": 62,
        "before": 1118,
        "after": 1180
      },
      "selectedContact": {
        "scope": "Selected synthetic donor genes, actual preparation/installation; same host and setup, component mass included",
        "native": 90.29244869340997,
        "selected": 75.7670736298187
      },
      "race": {
        "source": "W07.CATCH.stick.0.0",
        "part": "W07.PART.W07.CATCH.stick.0.0.sticktoe",
        "finish": 93.4263305854188,
        "events": [
          "seam_landing",
          "recovered",
          "seam_landing",
          "recovered",
          "seam_landing",
          "recovered",
          "seam_landing",
          "recovered",
          "seam_landing",
          "recovered",
          "seam_landing",
          "recovered",
          "seam_landing",
          "recovered",
          "seam_landing",
          "recovered",
          "seam_landing",
          "recovered",
          "seam_landing",
          "recovered",
          "seam_landing",
          "recovered",
          "seam_landing",
          "recovered",
          "seam_landing",
          "recovered",
          "seam_landing",
          "recovered",
          "seam_landing",
          "recovered",
          "seam_landing",
          "recovered",
          "seam_landing",
          "recovered",
          "seam_landing",
          "recovered",
          "seam_landing",
          "recovered",
          "seam_landing",
          "recovered",
          "finish",
          "seam_landing",
          "recovered",
          "seam_landing",
          "recovered",
          "seam_landing",
          "recovered",
          "seam_landing",
          "recovered",
          "finish"
        ]
      },
      "efficiency": {
        "scope": "Same built mass, output, reserve and delivery; efficiency only",
        "before": {
          "time": 70.6706258461434,
          "used": 35.361512274698725,
          "seams": 0,
          "settles": []
        },
        "after": {
          "time": 70.6706258461434,
          "used": 30.94132324043437,
          "seams": 0,
          "settles": []
        }
      },
      "release": {
        "before": {
          "time": 85.37233657722528,
          "used": 31.500823906286428,
          "seams": 0,
          "settles": []
        },
        "after": {
          "time": 60.40571545119216,
          "used": 72.93834075544419,
          "seams": 0,
          "settles": []
        }
      },
      "frame": {
        "before": {
          "time": 80.99139288481898,
          "used": 92.67880731232225,
          "seams": 0,
          "settles": []
        },
        "after": {
          "time": 70.6706258461434,
          "used": 33.004078123026034,
          "seams": 0,
          "settles": []
        }
      },
      "damper": {
        "before": {
          "time": 71.60251307707384,
          "used": 38.54823977062961,
          "seams": 12,
          "settles": [
            0.18,
            0.18,
            0.18,
            0.18,
            0.18,
            0.18,
            0.18,
            0.18,
            0.18,
            0.18,
            0.18,
            0.18
          ]
        },
        "after": {
          "time": 71.23592962115401,
          "used": 36.65809431450475,
          "seams": 12,
          "settles": [
            0.09,
            0.09,
            0.09,
            0.09,
            0.09,
            0.09,
            0.09,
            0.09,
            0.09,
            0.09,
            0.09,
            0.09
          ]
        }
      },
      "suspension": {
        "before": {
          "time": 71.63460647349187,
          "used": 38.751816747837154,
          "seams": 12,
          "settles": [
            0.18,
            0.18,
            0.18,
            0.18,
            0.18,
            0.18,
            0.18,
            0.18,
            0.18,
            0.18,
            0.18,
            0.18
          ]
        },
        "after": {
          "time": 71.06053786167396,
          "used": 35.59841160533949,
          "seams": 12,
          "settles": [
            0.06,
            0.06,
            0.06,
            0.06,
            0.06,
            0.06,
            0.06,
            0.06,
            0.06,
            0.06,
            0.06,
            0.06
          ]
        }
      },
      "rough_contact": {
        "before": {
          "time": 83.14072964301208,
          "used": 99.856682845423,
          "seams": 0,
          "settles": []
        },
        "after": {
          "time": 70.66478279501564,
          "used": 33.00238218989813,
          "seams": 0,
          "settles": []
        }
      },
      "gear": {
        "before": {
          "time": 70.6706258461434,
          "used": 33.004078123026034,
          "seams": 0,
          "settles": []
        },
        "after": {
          "time": 97.7915237708717,
          "used": 30.726078232519512,
          "seams": 0,
          "settles": []
        }
      },
      "aero": {
        "before": {
          "time": 70.67055909008344,
          "used": 33.00410535786051,
          "seams": 0,
          "settles": []
        },
        "after": {
          "time": 73.05950396555434,
          "used": 50.785777459140604,
          "seams": 0,
          "settles": []
        }
      }
    },
    "model_report": "evidence/world_parts_report.json",
    "browser_report": "evidence/browser_report.json",
    "migration_cycles": "evidence/migration_cycles.json",
    "review": {
      "quality": "Reviewed and tested at declared interactive/profile scope; whole-game and human usability gates open",
      "novel_development_adherence": "Concrete project-specific integration of useful anatomy, life-stage selection, alternate preparations, actual kits and causal racing; not a worldwide novelty claim",
      "effectiveness": "Demonstrated for bounded component, supply, interface and transaction paths",
      "creativity": "Authored biological execution and integrated commercial use developed; experiential distinctiveness unmeasured",
      "scaling_potential": "Declarative profiles reuse stock, rearing, preparation and bench operations; current small world and global active catalogue are not multi-world or world-scale proof"
    },
    "limits": [
      "One named player host; alternative bodyforms, host breeding and purchasable whole-host kits are not yet implemented.",
      "Ten fictional pair-bred donor profiles use three independent binary loci each. No colony genetics, mutation, linkage, continuous natural genotype or heritable appearance system.",
      "The source screenshot establishes categories and aggregate build readings, not exact per-part formulas or complete game catalogues. Normalized RRR coefficients are authored.",
      "Path-space two-racer ground simulation; root rectangles rather than swept limbs; no free 3D flight, full damage, steering physics or complete tire-like gait.",
      "Structural support, sensory correction, release delay and rail-seam response are simplified mechanisms. Rail seams do not establish realistic suspension travel or mass-damper mechanics.",
      "Prepared native replacement cradles remain a specific workshop profile. General graft rejection, storage decay, regrowth, aging and permanent loss are not decided by this implementation.",
      "Waxmoth useful-stage and short vital-remains windows are implemented. Prepared components remain stable inventory; cold-chain storage and shipped-order transit remain open.",
      "Three finite conversion kits and three finite selected orders. No unlimited item respawn, automatic contract renewal, full NPC supply simulation or national economy.",
      "Market wallet renewal uses explicit off-screen customer funding. Repeated profiles are stress probes with supplied starting assets, not proof of profitability or fair comparisons of player careers.",
      "Ordinary current-stock quotes use form and condition; individual project guidance beyond Hopper currently exposes trait evidence but is not a full multiform breeding optimizer.",
      "User-editable local backups are consistency-checked, not secure multiplayer authority. Browser tests use exact HTML set_content because native navigation is blocked.",
      "No Windows/macOS native file persistence, physical touch or human playtest; no measured enjoyment or retention; no final numerical MIVIM grade."
    ]
  }
}
