"""RRR Wave 04: deterministic, path-constrained 2.5D experimental race model.

Normalized L/M/T units; not calibrated biology, free-body physics or a full game.
Race outcomes integrate motion and ordered gates; no aggregate power-to-win score.
Standard library only. Python 3.10+.
"""
from __future__ import annotations
from dataclasses import dataclass, field, asdict
from copy import deepcopy
from itertools import combinations
import math
from typing import Any
from w03_model import (require, finite, canonical, sha256, Workshop, Stock, Order,
    brood, hopper_phenotype, measured, HOPPER, HOPPER_PRODUCT, PROTOCOL, REQUIREMENTS)

G = 1.0
EPS = 1e-8

def angle_distance(a: float, b: float) -> float:
    return abs((a-b+math.pi)%(2*math.pi)-math.pi)

@dataclass(frozen=True)
class Piece:
    id: str
    name: str
    length: float
    curvature: float
    x: float
    y: float
    heading: float
    width: float = 2.4
    grip: float = 1.6
    resistance: float = 0.15
    jumpable: bool = True
    ceiling: float = 5.0

    def pose(self, distance: float, lateral: float = 0) -> tuple[float,float,float]:
        s = max(0., min(self.length, distance))
        h = self.heading + self.curvature*s
        if abs(self.curvature)<EPS:
            x, y = self.x+s*math.cos(h), self.y+s*math.sin(h)
        else:
            x=self.x+(math.sin(h)-math.sin(self.heading))/self.curvature
            y=self.y-(math.cos(h)-math.cos(self.heading))/self.curvature
        return x-lateral*math.sin(h), y+lateral*math.cos(h), h

@dataclass
class Course:
    id: str
    pieces: list[Piece]
    laps: int = 2
    def __post_init__(self):
        require(bool(self.pieces), 'empty course')
        require(type(self.laps) is int and self.laps>0,'invalid laps')
        require(len({p.id for p in self.pieces})==len(self.pieces),'duplicate physical track section')
        for p in self.pieces:
            for n in ('length','width','grip','resistance','ceiling'): finite(getattr(p,n),n)
            for n in ('curvature','x','y','heading'): require(math.isfinite(getattr(p,n)),f'invalid {n}')
            require(p.length>0 and p.width>0,'zero track geometry')
            require(abs(p.curvature)*p.width/2<0.95,'offset path singularity')
        for a,b in zip(self.pieces,self.pieces[1:]+self.pieces[:1]):
            x,y,h=a.pose(a.length)
            require(math.hypot(x-b.x,y-b.y)<1e-6 and angle_distance(h,b.heading)<1e-6,
                    f'disconnected ports: {a.id}->{b.id}')
        self.length=sum(p.length for p in self.pieces)
        self.ends=[]; s=0.
        for p in self.pieces: s+=p.length; self.ends.append(s)
        self.total=self.length*self.laps
        self.gates=[lap*self.length+end for lap in range(self.laps) for end in self.ends]
    def locate(self,s:float)->tuple[Piece,float]:
        q=s%self.length; start=0.
        for p,end in zip(self.pieces,self.ends):
            if q<end-EPS:return p,q-start
            start=end
        return self.pieces[-1], self.pieces[-1].length
    def pose(self,s:float,d:float=0):
        p,q=self.locate(s);return p.pose(q,d)
    def clearance(self,s:float,distance:float,height:float)->bool:
        # Conservative sampled tube test for this piecewise-flat witness.
        for i in range(max(2,int(distance/0.05)+1)):
            p,_=self.locate(s+distance*i/max(1,int(distance/0.05)))
            if not p.jumpable or abs(p.curvature)>EPS or p.ceiling<height:return False
        return True
    def to_dict(self):return {'id':self.id,'laps':self.laps,'length':self.length,'pieces':[asdict(p) for p in self.pieces]}

def foundry_course(grip:float=1.6,laps:int=2,straight:float=12.)->Course:
    """Ten declared in-kind section instances; arcs have endpoint/heading continuity."""
    recipe=[('Pack Run',straight/2,0),('Gutter Run',straight/2,0),('Drum Bend',1.5*math.pi,1/3),
            ('Service Run',6,0),('Drum Bend',1.5*math.pi,1/3),('Pack Run',straight/2,0),
            ('Gutter Run',straight/2,0),('Drum Bend',1.5*math.pi,1/3),('Service Run',6,0),
            ('Drum Bend',1.5*math.pi,1/3)]
    pieces=[];x=y=h=0.
    for i,(name,length,k) in enumerate(recipe):
        p=Piece(f'W04.SECTION.{i:02}',name,length,k,x,y,h,grip=grip,jumpable=not bool(k))
        pieces.append(p);x,y,h=p.pose(length)
    layout_key = sha256(canonical({'pieces':[asdict(p) for p in pieces]}).encode()).hexdigest()[:12]
    return Course(f'W04.COURSE.FOUNDRY_LOOP.{layout_key}.v1',pieces,laps)

@dataclass(frozen=True)
class Build:
    id: str
    host_id: str
    name: str
    component_ids: tuple[str,...]
    drive_source: str
    hopper_source: str|None
    mass: float = 1.0
    cadence: float = 10.0
    force: float = 2.0
    stride: float = 0.25
    leverage: float = 1.0
    grip: float = 1.0
    delivery: float = 3.0
    efficiency: float = .75
    reserve: float = 120.0
    width: float = .38
    length: float = .62
    height: float = .26
    hopper: tuple[float,float,float]|None = None # return,phase error,settle
    preload: float = .7
    alignment_error: float = 0.
    horn: bool = False
    claws: bool = False
    armor: str = 'light'
    provenance: tuple[str,...] = ()

    def __post_init__(self):
        for k in ('mass','cadence','force','stride','leverage','grip','delivery','efficiency','reserve','width','length','height','preload','alignment_error'):
            finite(getattr(self,k),k)
        require(all(getattr(self,k)>0 for k in ('mass','cadence','force','stride','leverage','width','length')),'nonpositive body/drive')
        require(0<self.efficiency<=1,'efficiency out of bounds')
        require(len(self.component_ids)==len(set(self.component_ids)),'duplicate fitted component')
        if self.hopper:
            require(0<=self.hopper[0]<=1 and 0<=self.hopper[1]<=1 and self.hopper[2]>=0,'invalid hopper')
        require(self.armor in {'light','medium','heavy'},'unknown armor')
    @property
    def free_speed(self):return self.cadence*self.stride/self.leverage

@dataclass(frozen=True)
class Policy:
    passing: bool=True
    jumping: bool=False
    attacking: bool=False
    counter: bool=False
    preferred_line: float=0.

@dataclass
class Runner:
    build: Build
    policy: Policy=field(default_factory=Policy)
    s: float=0.
    d: float=0.
    v: float=0.
    energy: float|None=None
    state: str='run'
    timer: float=0.
    z: float=0.
    vz: float=0.
    cooldown: float=0.
    attack: str|None=None
    attack_target: str|None=None
    attack_due: float=0.
    action_charge: float=0.
    pass_target: str|None=None
    pass_line: float|None=None
    finish: float|None=None
    next_gate: int=0
    passed: list[dict]=field(default_factory=list)
    distance: float=0.
    def __post_init__(self):
        if self.energy is None:self.energy=self.build.reserve
        require(0<=self.energy<=self.build.reserve,'invalid initial reserve')
        require(self.s==0,'fixture requires all entrants on start plane')
        require(self.v==0,'fixture requires standing start')
    @property
    def id(self):return self.build.id

def legal(build:Build, equipment:str)->bool:
    require(equipment in {'open','speedsters','fireworks'},'unsupported event')
    if equipment=='speedsters':return not(build.horn or build.claws)
    if equipment=='fireworks':return (build.horn or build.claws) and build.armor=='light'
    return True

class Race:
    """Path-space envelopes; zero restitution contacts; continuous gate interpolation.

    Airborne runners follow the declared course tube, not unconstrained trajectories.
    Horn/claw effects are fictional dissipative contact operators, not resolved limbs.
    Decisions use a beginning-of-step snapshot. IDs never decide who receives a win.
    """
    def __init__(self,course:Course,runners:list[Runner],equipment:str='open',dt:float=.01):
        require(.001<=dt<=.025,'dt outside tested domain')
        require(len({r.id for r in runners})==len(runners) and len({r.build.host_id for r in runners})==len(runners),'duplicate entrant/host')
        require(bool(runners),'empty race')
        for r in runners:
            require(legal(r.build,equipment),'illegal build capability')
            require(abs(r.d)+r.build.width/2<course.pieces[0].width/2,'outside start')
            require(all(r.build.width<p.width for p in course.pieces),'body cannot fit track')
            max_speed=math.sqrt(r.build.free_speed**2+2*r.build.preload/r.build.mass)
            require(max_speed*dt < r.build.length/4,'timestep too coarse for body/speed envelope')
        for a,b in combinations(runners,2):
            require(abs(a.d-b.d)>=(a.build.width+b.build.width)/2,'overlapping start boxes')
        self.course=course;self.runners=deepcopy(sorted(runners,key=lambda r:r.id));self.dt=dt
        self.equipment=equipment;self.time=0.;self.events=[];self.frames=[];self._frame=0
        self._ahead={};self._last_pair_event={}
        self.capture()
    def emit(self,kind:str,runner:Runner,**payload):
        self.events.append({'t':round(self.time,6),'kind':kind,'runner':runner.id,**payload})
    def near_delta(self,a:Runner,b:Runner):
        return (b.s-a.s+self.course.length/2)%self.course.length-self.course.length/2
    def capture(self):
        self.frames.append({'t':round(self.time,6),'runners':[{ 'id':r.id,'s':r.s,'d':r.d,'z':r.z,'v':r.v,'energy':r.energy,'state':r.state,'finish':r.finish,'gates':r.next_gate} for r in self.runners]})
    def step(self):
        dt=self.dt; old=deepcopy(self.runners); byid={r.id:r for r in self.runners}; oldid={r.id:r for r in old}
        # Reaction intent is computed from one shared snapshot, not iteration mutations.
        for r in self.runners:
            if r.finish is not None:continue
            o=oldid[r.id];r.cooldown=max(0.,r.cooldown-dt)
            p,q=self.course.locate(o.s)
            ahead=sorted([(self.near_delta(o,b),b) for b in old if b.id!=o.id and b.finish is None and self.near_delta(o,b)>0],key=lambda x:x[0])
            target=next((b for gap,b in ahead if gap<2 and abs(b.d-o.d)<(b.build.width+o.build.width)/2+.1),None)
            if o.state=='run' and o.cooldown<=0 and o.attack is None:
                if r.policy.counter and r.build.claws:
                    threats=[b for b in old if b.attack=='ram' and b.attack_target==o.id and abs(self.near_delta(o,b))<1.35 and abs(b.d-o.d)<.4 and b.z<o.build.height]
                    if threats: r.attack='claw';r.attack_target=threats[0].id;r.attack_due=self.time+.10;self.emit('claw_windup',r,target=r.attack_target)
                if r.attack is None and target and r.policy.jumping and r.build.hopper and o.v>target.v+.15 and .58<self.near_delta(o,target)<1.8:
                    ret,phase,settle=r.build.hopper;useful=r.build.preload*ret*max(0.,1-phase-r.build.alignment_error)
                    vz=math.sqrt(useful/r.build.mass);air=2*vz/G
                    flight_v=math.sqrt(o.v*o.v+useful/r.build.mass)
                    corridor=max(.2,flight_v)*air+o.build.length
                    if (r.energy>=r.build.preload and useful>0 and self.course.clearance(o.s,corridor,vz*vz/(2*G)+r.build.height)):
                        r.attack='jump';r.attack_due=self.time+.12;self.emit('jump_load',r,source=r.build.hopper_source)
                if r.attack is None and target and r.policy.attacking and r.build.horn and self.near_delta(o,target)<1.2:
                    r.attack='ram';r.attack_target=target.id;r.attack_due=self.time+.18;self.emit('ram_windup',r,target=target.id)
            if o.state=='run':
                goal=r.policy.preferred_line
                if r.pass_target:
                    passed=oldid.get(r.pass_target)
                    if passed is None or o.s-passed.s>(o.build.length+passed.build.length)/2+.35 or passed.finish is not None:
                        r.pass_target=None;r.pass_line=None
                    else:
                        clearance=(o.build.width+passed.build.width)/2+.10
                        side=1 if r.pass_line>=passed.d else -1
                        goal=passed.d+side*clearance;r.pass_line=goal
                if target and r.policy.passing and r.attack is None and r.pass_target is None:
                    clearance=(r.build.width+target.build.width)/2+.10
                    candidates=[target.d+clearance,target.d-clearance]
                    valid=[d for d in candidates if abs(d)+r.build.width/2<p.width/2-.03 and all(b.id in {r.id,target.id} or abs(self.near_delta(o,b))>1 or abs(d-b.d)>(r.build.width+b.build.width)/2+.03 for b in old)]
                    if valid:
                        goal=min(valid,key=lambda d:abs(d-o.d));r.pass_target=target.id;r.pass_line=goal
                limit=max(0,p.width/2-r.build.width/2-.025);goal=max(-limit,min(limit,goal))
                max_shift=min(.75,o.v*.55)*dt
                r.d=o.d+max(-max_shift,min(max_shift,goal-o.d))
        # Charge actions from the same delivery and energy budget as locomotion.
        action_draw={r.id:0. for r in self.runners}
        for r in self.runners:
            if r.finish is not None or r.attack is None:continue
            needed=r.build.preload if r.attack=='jump' else (.10 if r.attack=='ram' else .08)
            charge=min(max(0.,needed-r.action_charge),.65*r.build.delivery*dt,r.energy)
            r.action_charge+=charge;r.energy-=charge;action_draw[r.id]=charge/dt
        # Resolve due actions from the shared snapshot, accumulate losses/reactions.
        losses={r.id:0. for r in self.runners};held=set();cancelled=set()
        due=[r for r in self.runners if r.finish is None and r.attack and self.time+EPS>=r.attack_due and r.action_charge+EPS >= (r.build.preload if r.attack=='jump' else (.10 if r.attack=='ram' else .08))]
        for r in due:
            if r.attack!='claw':continue
            target=byid.get(r.attack_target);o=oldid[r.id]
            hit=bool(target and target.finish is None and abs(self.near_delta(o,oldid[target.id]))<1.4 and abs(o.d-oldid[target.id].d)<.45 and oldid[target.id].z<r.build.height and r.action_charge+EPS>=.08)
            r.action_charge=0.
            if hit:held.update([r.id,target.id]);cancelled.add(target.id);self.emit('claw_contact',r,target=target.id,cancelled_action=target.attack)
            else:self.emit('claw_miss',r)
            r.attack=None;r.cooldown=2.5
        for r in due:
            if r.id in cancelled:r.attack=None;r.action_charge=0.;r.cooldown=2.;continue
            o=oldid[r.id]
            if r.attack=='jump':
                if r.action_charge+EPS>=r.build.preload and r.build.hopper:
                    ret,phase,settle=r.build.hopper;useful=r.build.preload*ret*max(0,1-phase-r.build.alignment_error)
                    vz=math.sqrt(useful/r.build.mass)
                    flight_v=math.sqrt(r.v*r.v+useful/r.build.mass)
                    if useful>0 and self.course.clearance(r.s,max(.2,flight_v)*2*vz/G+r.build.length,vz*vz/(2*G)+r.build.height):
                        r.v=flight_v;r.vz=vz;r.z=EPS;r.state='air';self.emit('takeoff',r,source=r.build.hopper_source,useful_energy=useful)
                r.attack=None;r.action_charge=0.;r.cooldown=3.
            elif r.attack=='ram':
                target=oldid.get(r.attack_target)
                hit=bool(target and target.finish is None and 0<self.near_delta(o,target)<1.35 and abs(o.d-target.d)<.43 and o.z<.1 and target.z<o.build.height and r.action_charge+EPS>=.10)
                r.action_charge=0.
                if hit:
                    # Contact disruption dissipates kinetic energy; not magic remote damage.
                    closing=max(0,o.v-target.v);loss=min(target.v,.20+.55*closing)
                    losses[target.id]+=loss;losses[r.id]+=.1;self.emit('ram_contact',r,target=target.id,speed_loss=loss)
                else:self.emit('ram_miss',r)
                r.attack=None;r.cooldown=2.
        for r in self.runners:
            if r.finish is not None:continue
            o=oldid[r.id];p,q=self.course.locate(o.s)
            r.v=max(0,r.v-losses[r.id])
            if r.id in held:r.state='held';r.timer=.30;r.attack=None;r.action_charge=0.
            if r.state=='air':
                r.z+=r.vz*dt-.5*G*dt*dt;r.vz-=G*dt
                # No drive in air; following the curve is deliberately disallowed at takeoff.
                v1=max(0,r.v-.025*dt)
                if r.z<=0:
                    r.z=0;r.vz=0;r.state='settling';r.timer=r.build.hopper[2] if r.build.hopper else .18
                    self.emit('landing',r,settle_duration=r.timer)
            elif r.state in {'held','settling'}:
                v1=max(0,r.v-.50*dt);r.timer-=dt
                if r.timer<=0:r.state='run';self.emit('recovered',r)
            else:
                free=r.build.free_speed
                desired=r.build.force*r.build.leverage*max(0,1-r.v/free)
                available=min(max(0,r.build.delivery-action_draw[r.id]),r.energy/dt)
                cap=(math.sqrt(r.v*r.v+2*dt*r.build.efficiency*available/r.build.mass)-r.v)*r.build.mass/dt
                drive=min(desired,cap,p.grip*r.build.grip*r.build.mass*G)
                v1=max(0,r.v+(drive-p.resistance)*dt/r.build.mass)
                # Current curvature plus braking preview for the next port; traction-limited corner pace.
                nextp=self.course.pieces[(self.course.pieces.index(p)+1)%len(self.course.pieces)]
                brake=.85*p.grip*r.build.grip*G
                for piece,distance in ((p,0.),(nextp,max(0,p.length-q))):
                    if piece.curvature:
                        radius=1/abs(piece.curvature)-math.copysign(r.d,piece.curvature)
                        turn=math.sqrt(piece.grip*r.build.grip*G*radius)
                        target_v=math.sqrt(turn*turn+2*brake*distance)
                        if v1>target_v:v1=max(target_v,r.v-brake*dt)
                distance=(r.v+v1)*dt*.5
                spend=drive*distance/r.build.efficiency
                require(spend<=r.energy+1e-7 and spend<=r.build.delivery*dt+1e-7,'power budget exceeded')
                r.energy=max(0,r.energy-spend)
            lateral=r.d-o.d
            motion=(r.v+v1)*dt*.5
            forward=math.sqrt(max(0,motion*motion-lateral*lateral))
            metric=1-p.curvature*(o.d+r.d)/2
            require(metric>0,'invalid course metric')
            r.s=o.s+forward/metric;r.distance+=motion;r.v=v1
        # Local envelope collision in (course progress, lateral, height).
        # Correct only the following racer; energy is never restored by collision correction.
        for a,b in combinations(self.runners,2):
            if a.finish is not None or b.finish is not None:continue
            delta=self.near_delta(a,b)
            leader,follower=(b,a) if delta>=0 else (a,b)
            sep=abs(delta);contact_len=(a.build.length+b.build.length)/2
            if sep<contact_len and abs(a.d-b.d)<(a.build.width+b.build.width)/2 and abs(a.z-b.z)<max(a.build.height,b.build.height):
                follower.s=max(oldid[follower.id].s,follower.s-(contact_len-sep))
                follower.v=min(follower.v,leader.v)
                key=tuple(sorted((a.id,b.id)))
                if self.time-self._last_pair_event.get(key,-999)>.5:
                    self.emit('body_contact',follower,target=leader.id);self._last_pair_event[key]=self.time
        for r in self.runners:
            if r.finish is not None:continue
            o=oldid[r.id]
            while r.next_gate<len(self.course.gates) and self.course.gates[r.next_gate]<=r.s+EPS:
                gate=self.course.gates[r.next_gate];f=(gate-o.s)/(r.s-o.s) if r.s>o.s else 0.
                crossing=self.time+max(0.,min(1.,f))*dt
                r.passed.append({'gate':r.next_gate,'t':crossing});r.next_gate+=1
                if r.next_gate==len(self.course.gates):
                    r.finish=crossing;r.s=self.course.total;r.state='finished';self.emit('finish',r,finish_time=crossing)
            require(r.energy>=-EPS and math.isfinite(r.s),'invalid race state')
        for a,b in combinations(self.runners,2):
            if a.finish is not None or b.finish is not None:continue
            diff=a.s-b.s;key=(a.id,b.id)
            if abs(diff)>.12:
                sign=1 if diff>0 else -1
                if key in self._ahead and self._ahead[key]!=sign:
                    passer,passed=(a,b) if sign>0 else (b,a)
                    self.emit('overtake',passer,target=passed.id,airborne=passer.z>passed.build.height)
                self._ahead[key]=sign
        self.time+=dt
        if self.time+EPS>=self._frame*.08:self.capture();self._frame+=1
    def run(self,max_time:float=180.):
        while self.time<max_time and any(r.finish is None for r in self.runners):self.step()
        self.capture()
        ranked=sorted(self.runners,key=lambda r:(r.finish is None,r.finish if r.finish is not None else -r.s))
        rows=[];previous=None;place=0
        for i,r in enumerate(ranked,1):
            if r.finish is None:place=None
            elif previous is None or abs(r.finish-previous)>1e-7:place=i
            rows.append({'place':place,'id':r.id,'host_id':r.build.host_id,'name':r.build.name,'finish_time':r.finish,
                         'gates':r.next_gate,'required_gates':len(self.course.gates),'remaining_energy':r.energy,'build':asdict(r.build)})
            previous=r.finish
        return {'model':'W04.RACE.PATH2P5.v1','scope':'Normalized path-constrained race experiment, not validated game physics',
                'course':self.course.to_dict(),'equipment':self.equipment,'dt':self.dt,'results':rows,'events':self.events,'frames':self.frames}


def resume_workshop()->Workshop:
    """Replay W03's documented transactions using its unchanged operators.

    Not an invented save export: W03 exported a summary, so this is a reconstruction
    cross-checked against that deterministic fixture. IDs stay in that fixture's scope.
    """
    a=((1,1),(0,0),(1,1));b=((0,0),(1,1),(1,1))
    w=Workshop({'player':120,'buyer':100,'suppliers':0})
    w.stocks['P-R']=Stock('P-R',HOPPER,'player','adult',a,{'hind_pair','body'},protections={'founder'})
    w.stocks['P-S']=Stock('P-S',HOPPER,'player','adult',b,{'hind_pair','body'},protections={'founder'})
    w.stocks['HOST']=Stock('HOST','W02.DONOR.HOST','player','adult',a,{'native_body'},protections={'named_racer'})
    w.stocks['DRIVE-DONOR']=Stock('DRIVE-DONOR','W02.DONOR.CICADA','suppliers','adult',None,{'thoracic_drive'})
    w.prepare('opening-prepared-drive','suppliers','DRIVE-DONOR',[{'id':'UPGRADE-DRIVE','product':'W02.PROD.CICADA.1','tissues':['thoracic_drive']}],{'thoracic_drive'})
    w.fund('order-fund',Order('O-HOP','buyer',HOPPER_PRODUCT,4,20,8,PROTOCOL,REQUIREMENTS))
    for eid in ('start','care-2','care-4','care-6'):w.transfer(eid,'player','suppliers',6,'brood operations')
    for i,g in enumerate(brood('W03-seed-1','B1',a,b,8)):
        sid=f'B1-{i}';w.stocks[sid]=Stock(sid,HOPPER,'player','adult',g,{'hind_pair','body'},measured(g),{'replacement'} if i<2 else set())
    for i in range(2,7):
        w.transfer(f'prep-cost-{i}','player','suppliers',2,'preparation')
        w.prepare(f'prep-{i}','player',f'B1-{i}',[{'id':f'H-{i}','product':HOPPER_PRODUCT,'tissues':['hind_pair']}])
    w.deliver('deliver','O-HOP','player',[f'H-{i}' for i in range(2,6)],8)
    w.install('fit-personal','H-6','player','HOST')
    w.fund('upgrade-fund',Order('O-DRIVE','player','W02.PROD.CICADA.1',1,24,8,'ordinary-offer',{}))
    w.deliver('upgrade-purchase','O-DRIVE','suppliers',['UPGRADE-DRIVE'],8)
    return w

def compile_workshop(w:Workshop,build_id:str='W04.BUILD.WORKSHOP')->Build:
    """Runtime consumes inherited hopper truth; UI receives observations separately."""
    require(w.stocks['HOST'].alive,'host unavailable')
    fitted=[p for p in w.sects.values() if p.custody=='installed' and p.holder=='HOST']
    hopper=next((p for p in fitted if p.product==HOPPER_PRODUCT),None)
    drive=next((p for p in fitted if p.product=='W02.PROD.CICADA.1'),None)
    hp=hopper_phenotype(w.stocks[hopper.donor_id].genotype) if hopper else None
    return Build(build_id,'HOST','Workshop racer',tuple(p.id for p in fitted),drive.id if drive else 'HOST.native_drive',hopper.id if hopper else None,
        cadence=12 if drive else 10,force=2.5 if drive else 2,
        hopper=tuple(hp[k] for k in ('spring_return','phase_error','settle_time')) if hp else None,
        provenance=tuple([p.donor_id for p in fitted]+['W03.fixture.replayed']))
