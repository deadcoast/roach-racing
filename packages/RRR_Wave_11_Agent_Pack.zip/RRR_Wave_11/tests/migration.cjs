const fs=require('fs'),path=require('path'),assert=require('node:assert/strict'),cp=require('child_process'),W=require('../src/world.js'),B=require('../src/bench.js');
const tests=[];function test(n,f){try{f();tests.push({name:n,passed:true});}catch(e){tests.push({name:n,passed:false,error:e.stack});process.exitCode=1;}}
const raw=cp.execFileSync(process.execPath,['-e',`const W=require(${JSON.stringify(path.join(__dirname,'../reference/w09_release/src/world.js'))});console.log(W.save(W.initial()));`],{encoding:'utf8'});const baseline=JSON.parse(raw).world,v=W.restore(raw);
for(const field of ['bench','hosts','stabled','broods','lines','selection','parts','kits','trackworks','results','tick','capacity','careArrears'])test('W09 migration preserves '+field,()=>assert.deepEqual(v[field],baseline[field]));
for(const key of ['player','shop','services','sponsor','escrow'])test('Existing account preserved: '+key,()=>assert.equal(v.accounts[key],baseline.accounts[key]));
test('Existing animals unchanged',()=>{for(const s of baseline.specimens)assert.deepEqual(v.specimens.find(t=>t.id===s.id),s);});
test('Grant precisely reconciled',()=>assert.equal(v.accounts.external,baseline.accounts.external-1440));
test('Forward round trip does not replenish sponsor or add animals',()=>assert.deepEqual(W.restore(W.save(v)),v));
test('No Wave10 implementation claimed by migration',()=>assert.equal(v.maker,undefined));
const out={tests,passed:tests.filter(t=>t.passed).length,failed:tests.filter(t=>!t.passed).length};fs.writeFileSync(path.join(__dirname,'../evidence/migration_report.json'),JSON.stringify(out,null,2));console.log(out.passed,'/',tests.length);
