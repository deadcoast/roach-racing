#!/usr/bin/env python3
"""Reproducible checks for the delivered W05 slice, never a full-game certificate."""
from __future__ import annotations
import argparse
import hashlib
import json
import os
from pathlib import Path
import re
import subprocess
import sys
from datetime import datetime, timezone

ROOT = Path(__file__).resolve().parent
EVIDENCE = ROOT / 'evidence'

def digest(path: Path) -> str:
    return hashlib.sha256(path.read_bytes()).hexdigest()

def load(path: str):
    return json.loads((ROOT / path).read_text(encoding='utf-8'))

def identifiers(value):
    if isinstance(value, dict):
        if isinstance(value.get('id'), str):
            yield value['id']
        for v in value.values():
            yield from identifiers(v)
    elif isinstance(value, list):
        for v in value:
            yield from identifiers(v)

def run(command, log_name, env=None):
    result = subprocess.run(command, cwd=ROOT, env=env, capture_output=True, text=True, timeout=120)
    (EVIDENCE / log_name).write_text(result.stdout + '\n' + result.stderr, encoding='utf-8')
    if result.returncode:
        raise RuntimeError(f'{command!r} failed: {result.returncode}; inspect evidence/{log_name}')
    return result

def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--browser', action='store_true', help='also rerun Playwright interaction tests')
    args = parser.parse_args()
    checks = []
    def check(name, condition):
        if not condition:
            raise AssertionError(name)
        checks.append({'name': name, 'passed': True})
    EVIDENCE.mkdir(exist_ok=True)
    spec = load('RRR_Wave_05.spec')
    base = load('reference/world_context_v0.4.json')
    cumulative = load('world_context_v0.5.json')
    import jsonschema
    jsonschema.Draft202012Validator(load('wave05.schema.json')).validate(spec)
    check('Wave specification schema', True)
    check('Baseline SHA matches manifest', digest(ROOT/'reference/world_context_v0.4.json') == spec['manifest']['base_sha256'])
    for name, value in base.items():
        if name not in ('manifest','development_waves'):
            check('Preserved base field: '+name, cumulative[name] == value)
    check('Prior waves preserved without changes', cumulative['development_waves'][:-1] == base['development_waves'])
    check('Exactly W05 appended', cumulative['development_waves'][-1] == spec)
    oldids = set(identifiers(base))
    rules = [r for g in spec['systems'] for r in g['rules']]
    newids = [r['id'] for r in rules]
    check('Unique current rule IDs', len(set(newids)) == len(newids))
    check('No prior rule overwritten', not (set(newids) & oldids))
    for group in spec['systems']:
        for ref in group['refines']:
            check('Known refined rule: '+ref, ref in oldids)
    known = set(oldids)
    for task in spec['Plan']['tasks']:
        check('Task dependency order: '+task['id'], set(task['depends_on']) <= known)
        known.add(task['id'])
    for task in spec['Plan']['next_tasks']:
        check('Carried task references: '+task['id'], set(task['continuation']) <= oldids)
    for thread in spec['operational_threads']:
        check('Existing service actor: '+thread['actor_ref'], thread['actor_ref'] in oldids)
    source_manifest = load('reference/baseline_source_hashes.json')
    for item in source_manifest['files']:
        check('Preserved source bytes: '+item['path'], digest(ROOT/item['path']) == item['sha256'])
    # Compile text in memory to verify the delivered artifact matches its editable sources.
    html=(ROOT/'src/template.html').read_text(encoding='utf-8')
    for key,file in [('CSS','style.css'),('ENGINE','race.js'),('BENCH','bench.js'),('ART','anatomy.js'),('APP','app.js')]:
        html=html.replace('__'+key+'__',(ROOT/'src'/file).read_text(encoding='utf-8'))
    check('Standalone HTML exact source build', html.encode() == (ROOT/'RRR_Living_Workbench_v0.5.html').read_bytes())
    check('No unexpanded HTML build slots', not any('__'+k+'__' in html for k in ['CSS','ENGINE','BENCH','ART','APP']))
    run([sys.executable,'tools/export_reference.py'],'reference_export_console.txt')
    run(['node','tests/model_tests.cjs'],'model_console.txt')
    run(['node','tests/parity.cjs'],'parity_console.txt')
    model=load('evidence/model_report.json');parity=load('evidence/parity_report.json')
    check('New behavioral tests passed', model['summary']['failed']==0 and model['summary']['passed']==len(model['tests']))
    check('All six numerical port comparisons passed',len(parity['cases'])==6 and all(x['passed'] for x in parity['cases']))
    regression={}
    env=dict(os.environ);env['PYTHONPATH']=str(ROOT/'reference/wave04_model') + os.pathsep + env.get('PYTHONPATH','')
    for wave in ['04','03']:
        r=run([sys.executable,'-B','-m','unittest','discover','-s','reference','-p',f'test_wave{wave}.py','-v'],f'wave{wave}_regression.txt',env)
        match=re.search(r'Ran (\d+) tests',r.stderr)
        check('Prior W'+wave+' regression ran', bool(match))
        regression['W'+wave]={'passed':int(match.group(1)), 'return_code':r.returncode}
    if args.browser:
        run([sys.executable,'tests/browser_check.py'],'browser_console.txt')
        run([sys.executable,'tests/browser_edges.py'],'browser_edge_console.txt')
    browser={}
    for name in ['browser_report','browser_edge_report']:
        path=EVIDENCE/(name+'.json')
        if path.exists():
            b=load('evidence/'+name+'.json')
            check(name+' artifact hash fresh',b['html_sha256']==digest(ROOT/'RRR_Living_Workbench_v0.5.html'))
            check(name+' no page errors',b['page_errors']==[])
            browser[name]={'checks':len(b['checks']), 'rerun_this_validation':args.browser, 'html_sha256':b['html_sha256']}
        else:
            browser[name]={'checks':None,'rerun_this_validation':False, 'status':'not_run'}
    check('Drive comparison matches generated spec',spec['fixture_summary']['drive_only_comparison']==load('evidence/drive_comparison.json'))
    tracked=[ROOT/'RRR_Wave_05.spec',ROOT/'RRR_Living_Workbench_v0.5.html',ROOT/'validate_wave05.py',ROOT/'wave05.schema.json']
    for directory in ['src','tests','tools']:
        tracked.extend(p for p in (ROOT/directory).iterdir() if p.is_file())
    report={'timestamp_utc':datetime.now(timezone.utc).isoformat(),'status':'passed','scope':'Specification and bounded editable browser slice; not human playtest, calibrated economy, native platform assurance or complete game.',
            'structural_checks':checks,'new_behavioral':model['summary'],'port_cases':len(parity['cases']),'prior_regressions':regression,'browser':browser,
            'visual_review':'evidence/visual_review.md; separate manual inspection, not automated image quality certification',
            'input_hashes':{str(p.relative_to(ROOT)):digest(p) for p in sorted(tracked)},
            'limitations':['No autonomous economy or joined stock/world-clock runtime','No physical Windows/macOS/touch device run','File URI navigation blocked in test host; exact bytes executed via set_content','Native file autosave behavior unverified','No human usability, enjoyment or retention measurement']}
    (EVIDENCE/'validation_report.json').write_text(json.dumps(report,indent=2)+'\n',encoding='utf-8')
    print(json.dumps({k:report[k] for k in ['status','new_behavioral','port_cases','prior_regressions','browser']},indent=2))

if __name__=='__main__':
    try:
        main()
    except Exception as exc:
        EVIDENCE.mkdir(exist_ok=True)
        (EVIDENCE/'validation_failure.txt').write_text(f'{type(exc).__name__}: {exc}\n',encoding='utf-8')
        raise
