"""Reproduce local model evidence. Browser checks are separate and never inferred."""
from pathlib import Path
import hashlib,json,subprocess,sys
ROOT=Path(__file__).resolve().parent
E=ROOT/'evidence';E.mkdir(exist_ok=True)
commands=[['node','tests/club.cjs'],['node','tests/migration.cjs'],['node','tests/bench_regression.cjs'],['node','tests/parity.cjs'],['node','tests/trackworks.cjs'],['node','tests/event_probe.cjs'],['node','reference/w09_release/tests/continuity.cjs']]
reports=[]
for cmd in commands:
 p=subprocess.run(cmd,cwd=ROOT,text=True,capture_output=True,timeout=180)
 name=Path(cmd[-1]).stem+('_original' if 'reference/' in cmd[-1] else '')
 (E/(name+'_transcript.txt')).write_text(p.stdout+'\n'+p.stderr)
 reports.append({'command':cmd,'exit':p.returncode,'log':f'evidence/{name}_transcript.txt'})
 if p.returncode:print(p.stdout,p.stderr);raise SystemExit(p.returncode)
subprocess.run([sys.executable,'tools/build_app.py'],cwd=ROOT,check=True)
spec=json.loads((ROOT/'RRR_Wave_11.spec').read_text());world=json.loads((ROOT/'world_context_v0.11.json').read_text());base=json.loads((ROOT/'reference/world_context_v0.9.json').read_text())
assert spec['manifest']['id']=='W11' and spec['manifest']['runtime_base']=='Wave09'
assert len(set(x['id']for x in spec['rules']))==len(spec['rules'])
assert all(set(['id','origin','statement','purpose'])<=r.keys() for r in spec['rules'])
seen=set()
for t in spec['Plan']['tasks']:
 assert all(x in seen for x in t['depends_on']);seen.add(t['id'])
for k,v in base.items():
 if k not in ('manifest','development_waves'):assert world[k]==v,k
assert world['development_waves'][:len(base['development_waves'])]==base['development_waves']
assert hashlib.sha256((ROOT/'reference/world_context_v0.9.json').read_bytes()).hexdigest()==spec['manifest']['base_sha256']
for name in ['race.js','anatomy.js','catalog.js','hosts.js','circuits.js','evidence.js']:
 assert (ROOT/'src'/name).read_bytes()==(ROOT/'reference/w09_release/src'/name).read_bytes(),name
club=json.loads((E/'club_report.json').read_text());migration=json.loads((E/'migration_report.json').read_text());parity=json.loads((E/'parity_report.json').read_text())
result={'status':'passed','commands':reports,'new_behavior_tests':club['passed'],'migration_tests':migration['passed'],'legacy_bench_tests':63,'current_track_tests':70,'old_release_continuity_tests':31,'historical_numerical_comparisons':len(parity['cases']),'further_event_probes':4,'rule_count':len(spec['rules']),'prior_world_records':'preserved exactly','unchanged_source_modules':['race','anatomy','catalog','hosts','circuits','evidence'],'html_sha256':hashlib.sha256((ROOT/'RRR_Club_Circuit_v0.11.html').read_bytes()).hexdigest(),'scope':'Local authored scenarios, logic and preservation. Not human gameplay, economic calibration or native-platform certification.'}
(E/'validation_report.json').write_text(json.dumps(result,indent=2));print(json.dumps(result,indent=2))
