"""Bounded hobby-event writeback using the Wave 03 finite-money operators.
Not a market equilibrium model or a simulation of NPC willingness to buy.
"""
from __future__ import annotations
from copy import deepcopy
from typing import Any
from w03_model import Workshop, Order, require, canonical, sha256, PROTOCOL, REQUIREMENTS, HOPPER_PRODUCT


def register_result(result:dict[str,Any],event_id:str)->dict[str,Any]:
    """Register model output, not a benchmark score. No security/authenticity claim."""
    finishers=[r for r in result['results'] if r['finish_time'] is not None]
    require(finishers,'no finisher')
    for row in finishers:
        require(row['gates']==row['required_gates'],'unfinished course')
    payload={'event_id':event_id,'course_id':result['course']['id'],'model':result['model'],
             'classification':[{k:r[k] for k in ('place','id','host_id','finish_time','gates','required_gates')} for r in result['results']],
             'build_snapshots':{r['id']:deepcopy(r['build']) for r in result['results']}}
    payload['hash']=sha256(canonical(payload).encode()).hexdigest()
    return payload


def verify_registration(record:dict[str,Any])->None:
    unsigned={k:v for k,v in record.items() if k!='hash'}
    require(record['hash']==sha256(canonical(unsigned).encode()).hexdigest(),'result changed after registration')


def settle_meeting(w:Workshop,event_id:str,record:dict[str,Any],owners:dict[str,str],
                   sponsor:str,club:str,prizes:tuple[int,...]=(30,12),operations:int=18)->dict[str,Any]:
    """One atomic funded event. Ties pool affected prizes; integer residue stays sponsor-owned."""
    verify_registration(record)
    require(record['event_id']==event_id,'wrong event registration')
    require(all(type(p)is int and p>=0 for p in (*prizes,operations)),'invalid prize')
    def op():
        require(sponsor in w.cash and club in w.cash,'missing event accounts')
        payouts={};used=0
        for row in record['classification']:
            place=row['place']
            if place is None or place>len(prizes):continue
            tied=[r for r in record['classification'] if r['place']==place]
            pooled=sum(prizes[place-1:place-1+len(tied)])
            amount=pooled//len(tied)
            require(row['id'] in owners and owners[row['id']] in w.cash,'missing entrant payee')
            owner=owners[row['id']];payouts[owner]=payouts.get(owner,0)+amount;used+=amount
        require(w.cash[sponsor]>=used+operations,'event has insufficient funding')
        w.cash[sponsor]-=used+operations;w.cash[club]+=operations
        for owner,amount in payouts.items():w.cash[owner]+=amount
        receipt={'event':event_id,'record_hash':record['hash'],'prizes':payouts,'operations_payment':operations,
                 'unspent_nominal_prizes':sum(prizes)-used,'claim_kind':'observed_result_not_genetic_certification'}
        w.ledger.append(deepcopy(receipt));return receipt
    return w.transact('settle:'+event_id,{'record':record,'owners':owners,'sponsor':sponsor,'club':club,'prizes':prizes,'operations':operations},op)


def public_build_card(row:dict[str,Any],publish_components:bool)->dict[str,Any]:
    """Projection explicitly excludes genotype and hidden measurements."""
    b=row['build']
    card={'name':b['name'],'build_id':b['id'],'host_id':b['host_id'],'finish_time':row['finish_time'],'place':row['place']}
    if publish_components:card['component_ids']=list(b['component_ids'])
    return card


def funded_trial(w:Workshop,event_id:str,buyer:str,quantity:int=2)->dict[str,Any]:
    """A named funded customer chooses a disclosed assembly trial, not magic automatic demand."""
    order=Order('trial:'+event_id,buyer,HOPPER_PRODUCT,quantity,20,30,PROTOCOL,REQUIREMENTS)
    w.fund('fund:'+order.id,order)
    return {'id':order.id,'escrow':w.orders[order.id].escrow,'quantity':quantity,'seller_revenue':0,
            'acceptance':'ordinary measured assembly, no champion-gene guarantee'}
