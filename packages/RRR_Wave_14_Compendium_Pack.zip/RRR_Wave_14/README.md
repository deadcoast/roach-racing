# RAD ROACH RACING — Wave 14 Reference Pack

## Read first

- `RRR_Wave_14_Foundations.md` — the current living-racer and hobby compendium volume.
- `RRR_Compendium_Map_v0.14.md` — reading routes, source-role index and incomplete book areas.
- `RRR_Wave_14.spec` — the same reference as structured data in the existing strict-JSON .spec format.
- `RRR_World_Context_v0.14.json` — previous context preserved with W14 appended.
- `RRR_Wave_14_TODO.md` — authoring work, separate from historical runtime tasks.
- `RRR_MIVIM_Review_v0.14.md` — evidence-scoped editorial assessment.

## Authority

Explicit user premises govern. Newly authored definitions are working proposals. W14 amendments refine current reading without changing historical experiment inputs, ownership, genomes or results. A value appearing in a prototype is not automatically a law of the fictional world.

## This pack is reference material

No new application, runtime patch, gameplay source, generated art sheet, model experiment or browser evidence is included. The previous executable remains unchanged. The pack advances world definition for later implementation.

## Preserved material

`reference/RRR_World_Context_v0.13.json` is byte-preserved. The previous foundation document is provided as historical context. `editorial/reference_review.json` documents reference-integrity checks only. `manifest.json` hashes the packaged files except itself.
