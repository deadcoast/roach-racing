'use strict';
const assert=require('assert/strict'),fs=require('fs'),path=require('path'),W=require('../src/world.js'),B=require('../src/bench.js');
const old=JSON.parse(fs.readFileSync(path.join(__dirname,'../reference/w06_save_fixture.json'))),neww=W.restore(JSON.stringify(old)),checks=[];
function check(name,fn){fn();checks.push(name);}
check('Migrate preserves old identities and genes',()=>{for(const s of old.world.specimens){const n=neww.specimens.find(n=>n.id===s.id);assert(n);assert.deepEqual(n.genes,s.genes);assert.equal(n.owner,s.owner);assert.equal(n.alive,s.alive);}});
check('Migration preserves cash and already incurred costs',()=>{for(const [k,v]of Object.entries(old.world.accounts))assert.equal(neww.accounts[k],v);assert.deepEqual(neww.ledger,old.world.ledger);});
check('Migration keeps the installed dynamic component and native exchange',()=>{assert.deepEqual(neww.bench.fitted,old.world.bench.fitted);assert(neww.bench.fitted.placements.some(p=>p.id.startsWith('W06.PART')));});
check('Migration discloses supplier stock without granting player money',()=>{assert(neww.migration.includes('no player cash'));assert(neww.parts.filter(p=>p.owner==='shop').length>0);});
check('Migrated part can still enter the new forward model',()=>{W.sync(neww);const c=B.compile(neww.bench.fitted);assert(c.hopper_source.startsWith('W06.PART'));});
check('Matured world can continue after old profile migration',()=>{const a=W.apply(neww,{type:'wait',turns:3});assert(a.world.tick===neww.tick+3);assert(W.validate(a.world));});

// Same 142-credit starting fixture across seeds; deliberately different operational
// schedules are not a balanced competition of playstyles or a retention test.
const trials=[];
for(let seed=0;seed<12;seed++)for(const scenario of ['manual_selection','ordinary_production','field_supplier']){
 let w=W.initial();w.seed='W07.CYCLE.'+seed;let actions=0,blocked=0;
 function act(c){const o=W.apply(w,c);w=o.world;actions++;return o.result;}
 if(scenario!=='field_supplier')act({type:'breed',parents:['P-R','P-S'],auto:scenario==='ordinary_production',repeat:true});
 while(w.tick<48){
  if(scenario==='field_supplier'&&w.tick+2<=48){
   try{const ids=act({type:'field',route:w.tick%4===0?'verge':'kiln'});for(const id of ids){try{act({type:'sellLive',id});}catch{blocked++;}}}
   catch{blocked++;act({type:'wait',turns:1});}
  }else act({type:'wait',turns:Math.min(4,48-w.tick)});
 }
 const start=142,receipts=w.ledger.filter(l=>l.to==='player').reduce((n,l)=>n+l.amount,0),expenses=w.ledger.filter(l=>l.from==='player').reduce((n,l)=>n+l.amount,0);
 assert.equal(w.accounts.player,start+receipts-expenses);assert(W.validate(w));
 trials.push({scenario,seed,tick:w.tick,cash:w.accounts.player,careArrears:w.careArrears,receipts,expenses,ownedLive:W.live(w).length,broods:w.broods.length,failed:w.broods.filter(b=>b.stage==='failed').length,unsold:w.specimens.filter(s=>s.owner==='player'&&s.autoOrdinary).length,actions,blocked});
}
const summaries=Object.fromEntries([...new Set(trials.map(x=>x.scenario))].map(s=>{const a=trials.filter(x=>x.scenario===s);return[s,{cashMin:Math.min(...a.map(x=>x.cash)),cashMax:Math.max(...a.map(x=>x.cash)),careArrearsMax:Math.max(...a.map(x=>x.careArrears)),liveMin:Math.min(...a.map(x=>x.ownedLive)),liveMax:Math.max(...a.map(x=>x.ownedLive)),broodsMin:Math.min(...a.map(x=>x.broods)),broodsMax:Math.max(...a.map(x=>x.broods))}];}));
fs.writeFileSync(path.join(__dirname,'../evidence/migration_cycles.json'),JSON.stringify({checks,count:checks.length,cycleCount:trials.length,scope:'12 seeds, three named operational policies, 48 world turns; starting assets supplied; off-screen demand funding explicit. Not economy balance, livelihood guarantee, or fair comparison of enjoyment. Manual selection deliberately retains stock and can require care arrears.',summaries,trials},null,2));
console.log(JSON.stringify({migrationChecks:checks.length,cycles:trials.length,summaries},null,2));
