# RRR agent context packet — 0.1

Companion to **RAD_ROACH_RACING_Handbook_v0.2.md**, not a replacement.

## Contents

- `REFERENCE_DOSSIER.md`: researched world-construction reference with concrete transformations and a connected sample community.
- `world_context.json`: all source metadata, canon constraints, provisional records, decisions, entity contracts, causal rules and scenario fixtures.
- `records.jsonl`: the same major record collections, one record per line, for retrieval or indexing.
- `sources.json`: primary-source register. External articles, figures and complete source pages are not bundled.
- `validate_pack.py`: standard-library structural checks for IDs, links, provenance references and JSON/JSONL consistency.

## Loading

Read the manifesto/authority metadata, author constraints and relevant unresolved decisions first. Then load the matching connected records for the task. The prior handbook remains the companion component catalogue.

Suggested retrieval:

- Shop scene: shop, local people, actual stock, offers, nearby habitat, event and current claims.
- Donor design: anatomy/function mapping, life-stage and assimilation decisions, environment, market uses and relevant biological evidence.
- Race: ruleset version, layout version, entrant build versions, injury/control decisions, results and witnesses.
- Commercial product: recipe, supplier line, available specimen identities, preparation, assembly and advertised claims.

`author_canon` describes premises supplied by the author. `working_proposal` records come from the prior handbook; `new_proposal` records are illustrative additions. Both are provisional. `reference_fact` describes an external source; it does not legislate the fictional world.

A fictional person's belief has a separate truth status. For example, a customer can exaggerate a brood's performance without making that statement world truth.

The three sample communities are a reference district, not a fixed start location, canonical map or scope cap. The sample victory is authored fiction, not a simulated result. Null prices, dimensions and timings deliberately remain unresolved.

## Structural verification

Run from this folder:

```sh
python validate_pack.py
```

The checker verifies record integrity only. It does not certify biology, fun, market balance, inheritance, physics or buildable track geometry.

## Superseded assumptions to avoid resurrecting

The v0.1 framing that displaced speed and winning with merely solving a track is not governing context. Neither are its unapproved universal Graft Point cap, mandatory slot exclusions, assumed nonlethal recovery, or invented vault-origin explanation. The source hobby's manufacturer restrictions and its meaning of Open are not RRR laws.

## Date and uncertainty

Reference snapshot: 9 September 2026. Current event rules and services can change. Public book descriptions are not evidence that the full book was read. Primary biological research supplies inspiration, not verification of the fictional graft premise.
