# Development record

## v0.6 — One Living Inventory

Continues W06.T01 from the Wave 05 handoff. Preserves the earlier cumulative context, source race engine and anatomical rendering. Extends the editable workbench instead of replacing it.

Delivered targeted two-form intake, observation-based selection, Hopper breeding stages, future-capacity checks, operating care, repeat plans and funded sales; produced components retain their real donor anatomy and enter the original tray. Joined race attendance to the same clock while leaving replay free. Added whole-world backup alongside recipe-only imports.

Review repairs: incoming stock reserves its destination during travel; working specimens cannot be sold or re-paired by automatic boundary operations; forecasts do not read hidden mortality; unsold automatic surplus waits for funded renewal; supported bodies retain their obligations; whole-world restore clears stale replay controls; selected new parts scroll into view and long names wrap. Invalid commands and repeated receipts cannot create partial ownership or duplicate payment.

Deferred: full two-way market, specimen-aware contracts and delivery, general reproduction, non-Hopper life cycles, viability/storage, full physical articulation, native platform persistence, human testing and multi-seed economic calibration.

Supporting checks: 76 world tests, 63 prior bench tests, six Python/JS reference comparisons, 39 W04 and 66 W03 regression tests, 19 real browser checks. These are bounded evidence, not an innovation or enjoyment score. See the hash-bound report and delivered-archive verification for the actual run.
