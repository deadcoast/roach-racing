# Wave 02 change record

Adds 126 proposed atomic rules, 16 donor profiles, 52 traits, 12 facility configurations, five targeted field-run profiles, eight effect records, four complete kit recipes, four sorting profiles, three breeding projects, eight market channels and two arithmetic fixtures.

Preserves all 41 prior seed records, all 12 prior decisions and all 15 prior sources byte-for-byte at the object level. New working directions point to existing decisions rather than replacing them. The combined context adds only the new user development directives to author canon; new biology, mechanics and numeric examples remain proposals.

The wave-only JSON is an extension, not a JSON Patch document. Load it under development_waves or use the supplied combined world context.

The Python fixtures passed 16 tests and the schema check in the authoring environment. They are not a complete game implementation or a balance result.
