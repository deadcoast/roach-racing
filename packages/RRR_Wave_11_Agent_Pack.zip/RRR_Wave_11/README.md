# RRR — Club Circuit / Wave 11

Open **RRR_Club_Circuit_v0.11.html** in a desktop browser. Everything is included; no network or installation is required by the application. Browser restrictions may prevent file-origin persistence; use the Live stock world-backup controls.

**Play:** fit owned parts in Workbench; enter First Current in Club meets; run three rounds; inspect and refit the same host between rounds; watch the actual heats; claim the protected living prize and proceed to Regional. Finite sponsor editions are disclosed.

**Runtime continuity:** this release extends recovered Wave09. Wave10's maker source was not recovered. Its written requirements are preserved as pending; do not mistake them for an included maker feature. Wave09 and earlier supported backups migrate to Wave11; unrecognized Wave10 schemas are not claimed compatible. No new player cash is granted on migration.

**Rebuild:** `python tools/build_app.py` (Python 3.11+).
**Validate:** `python validate_wave11.py` (Python 3.11+ and Node 18+).
**Browser checks:** install Playwright and a Chromium browser separately, then run `python tests/browser_club.py`. Set `RRR_CHROMIUM` to an executable path when necessary. This is development tooling, not required to play.

`src/race.js` and `src/anatomy.js` preserve the Wave09 mechanics and art bytes. `club.js` compiles NPC stock with the same model, owns meet operators and validates results. `club_ui.js` supplies the race programme, public anatomical inspection and living award controls. `world.js` integrates accounts, custody, time and backup.

Local editable data is not anti-cheat. Four-entry meetings are scheduled two-roach heats. Flyers, Factionals and World City are not yet playable. Parameter values are authored, uncalibrated game experiments. Human enjoyment and native-platform persistence have not been measured.
