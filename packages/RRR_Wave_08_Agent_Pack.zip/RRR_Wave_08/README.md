# RAD ROACH RACING — The Living Stable / v0.8

Open `RRR_Living_Stable_v0.8.html` in a browser. It contains its application code, CSS and procedural art; no installation, server, network or downloaded fonts are required by the app.

## Start a whole kit
Two Nets → buy a complete host kit → open → Stable & lines → lay out its guide → review on the workbench → Fit this build → Take the line → Race this build. Original HOST and H-6 remain on their own bench.

## Start a host line
Buy or catch two compatible adult roaches. In Stable & lines choose a native target and record the founder pair. Use Live stock to breed and manage the stages. Measure descendants; commission an adult as a racer. Naming a line does not create genetic improvements or immediate demand.

## Persistence
World backup in Live stock saves all owned hosts, builds, stock, cash and lines. Header sheet export/import is only a host-specific recipe. Local storage may be blocked; portable backup is the tested fallback. Backups are editable local data, not competitive server authority.

## Files
- `RRR_Wave_08.spec`: strict-JSON authored rules, profiles, trace, tasks and evidence boundary.
- `world_context_v0.8.json`: cumulative context with the unchanged previous waves.
- `RRR_Wave_08_Foundations.md`: agent-readable full expansion.
- `RRR_Wave_08_TODO.md`: delivered states and next ordered work.
- `RRR_MIVIM_Review_v0.8.md`: scoped assessment, not a numeric certification.
- `src/`: editable application sources, no external runtime dependencies.
- `tests/`: model, legacy parity and actual browser interaction paths.
- `reference/`: verbatim baseline context, previous release archive and earlier comparison fixtures.
- `evidence/`: outputs, screenshots and verification results.

## Development checks
Python 3.11+, Node 18+, and Python `jsonschema` are needed for validation. Browser checks additionally need `playwright` and Chromium. Set `CHROMIUM_EXECUTABLE` to the browser path when it is not `/usr/bin/chromium`.

```sh
python tools/build_app.py
python validate_wave08.py
python validate_wave08.py --browser --prior-release
```

`--prior-release` executes the old Wave07 tests on the preserved old release, not on the new model. Reports label that distinction. These dependencies are for development only; they are not required to open the HTML.

The host blocked native file navigation during automated review; exact HTML ran with Playwright `set_content`. Native Windows/macOS persistence, physical touch and human enjoyment remain unverified.
