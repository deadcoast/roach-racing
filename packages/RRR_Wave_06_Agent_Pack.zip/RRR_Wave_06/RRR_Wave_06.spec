{
  "manifest": {
    "id": "W06",
    "version": "0.6.0",
    "title": "RRR — One Living Inventory",
    "date": "2026-09-10",
    "status": "revisable_foundation_with_shared_world_browser_slice",
    "extends": "RRR_World_Context_v0.5.json",
    "base_sha256": "718105b9351a7fd4b6b23c52bd57a657698355ac5c9586812bf16167bb5b30eb",
    "serialization": "Strict JSON .spec continuing the RRR exchange format, not an asserted private MIVIM grammar."
  },
  "Reference": {
    "sources": [
      {
        "id": "W06.S01",
        "title": "Tamiya Mini 4WD Setup Guide",
        "url": "https://www.tamiya.com/english/mini4wd/setupguide/setupguide.htm",
        "checked_on": "2026-09-10",
        "supports": "Assembly and distinct motor, leverage, contact and handling choices.",
        "limits": "Walking anatomy and living production are RRR extensions, not Tamiya mechanisms."
      },
      {
        "id": "W06.S02",
        "title": "Tamiya Starter Pack FM-A Balanced Spec, 18710",
        "url": "https://www.tamiya.com/english/products/18710/index.html",
        "checked_on": "2026-09-10",
        "supports": "A coordinated kit and selected upgrade components give a manageable first build.",
        "limits": "Does not support breeding, numerical prices or biological performance."
      },
      {
        "id": "W06.S03",
        "title": "Mewgenics developer-authored Steam description",
        "url": "https://store.steampowered.com/app/686060/Mewgenics/",
        "checked_on": "2026-09-10",
        "supports": "Expeditions, inherited traits, breeding and facility advancement are connected progression activities.",
        "limits": "No undocumented exact inheritance, breeding rates or causal retention claim imported."
      },
      {
        "id": "W06.S04",
        "title": "MDN Window.localStorage",
        "url": "https://developer.mozilla.org/en-US/docs/Web/API/Window/localStorage",
        "checked_on": "2026-09-10",
        "supports": "Local persistence can be denied; file-URL behavior is not guaranteed.",
        "limits": "This host blocked file and loopback HTTP navigation. Origin persistence was not verified."
      }
    ],
    "reviewed_inputs": [
      "RRR_Wave_05_Foundations.md",
      "RRR_Wave_05.spec",
      "RRR_Wave_05_Agent_Pack.zip"
    ],
    "selected_next": "W06.T01",
    "source_boundary": "Source-hobby functions are preserved; fictional biology, timing and trading rules are authored proposals."
  },
  "Plan": {
    "tasks": [
      {
        "id": "W06.T01.01",
        "title": "Review the W05 handoff and preserve its sources",
        "continues": "W06.T01",
        "depends_on": [
          "W05.T08"
        ],
        "role": "supporting",
        "status": "implemented_and_checked_at_stated_scope",
        "acceptance_scope": "Baseline and next-task references checked."
      },
      {
        "id": "W06.T01.02",
        "title": "Implement one live stock and dynamic component service",
        "continues": "W06.T01",
        "depends_on": [
          "W06.T01.01"
        ],
        "role": "novel_integration",
        "status": "implemented_and_checked_at_stated_scope",
        "acceptance_scope": "Two field forms; new prepared parts enter the original bench."
      },
      {
        "id": "W06.T01.03",
        "title": "Implement complementary Hopper breeding and future capacity",
        "continues": "W06.T01",
        "depends_on": [
          "W06.T01.02"
        ],
        "role": "novel_integration",
        "status": "implemented_and_checked_at_stated_scope",
        "acceptance_scope": "One staged pair-bred profile; no colony or aquatic runtime claimed."
      },
      {
        "id": "W06.T01.04",
        "title": "Join world time, care, repeat plans and funded sales",
        "continues": "W06.T01",
        "depends_on": [
          "W06.T01.03"
        ],
        "role": "novel_integration",
        "status": "implemented_and_checked_at_stated_scope",
        "acceptance_scope": "Optional recurring production; finite buyer budget and explicit off-screen funding."
      },
      {
        "id": "W06.T01.05",
        "title": "Couple committed race attendance without charging replays",
        "continues": "W06.T01",
        "depends_on": [
          "W06.T01.04"
        ],
        "role": "novel_integration",
        "status": "implemented_and_checked_at_stated_scope",
        "acceptance_scope": "Same engine and component ids; two-turn attendance model."
      },
      {
        "id": "W06.T01.06",
        "title": "Render stock, nursery, money and backup interactions",
        "continues": "W06.T01",
        "depends_on": [
          "W06.T01.05"
        ],
        "role": "design_execution",
        "status": "implemented_and_checked_at_stated_scope",
        "acceptance_scope": "Desktop/narrow browser controls reviewed; no physical touch or human test."
      },
      {
        "id": "W06.T01.07",
        "title": "Test conflicts, safety, source continuity and package",
        "continues": "W06.T01",
        "depends_on": [
          "W06.T01.06"
        ],
        "role": "supporting",
        "status": "implemented_and_checked_at_stated_scope",
        "acceptance_scope": "Behavioral, browser, prior-model and delivered-archive checks."
      }
    ],
    "next_tasks": [
      {
        "id": "W07.T01",
        "priority": "P0",
        "title": "Expand Two Nets into a two-way, specimen-aware shop and contract system",
        "continuation": [
          "W06.T02"
        ],
        "acceptance": "Buy live breeders and prepared kits from actual stock; reserve funded contracts, condition/stage and arrival; preserve easy ordinary sales. Compare buy-only, catcher and breeder paths without forcing careers."
      },
      {
        "id": "W07.T02",
        "priority": "P0",
        "title": "Improve longitudinal selection, visual traits and repeated economic calibration",
        "continuation": [
          "W06.T02"
        ],
        "acceptance": "Useful history across broods, public-evidence selection, multiple seeds and demand scenarios, care/body handling costs, clear reserve and backlog decisions. No claim that rare labels guarantee value."
      },
      {
        "id": "W07.T03",
        "priority": "P1",
        "title": "Complete one non-Hopper stage/storage branch",
        "continuation": [
          "W06.T03"
        ],
        "acceptance": "Actual juvenile window, mature reproductive replacements, transport and storage viability for Clockleaf or pond stock; no Hopper lifecycle copied wholesale."
      },
      {
        "id": "W07.T04",
        "priority": "P1",
        "title": "Improve animated anatomical fit and race legibility",
        "continuation": [
          "W06.T04"
        ],
        "acceptance": "Loaded limbs, recovery and more useful envelope visualization; preserve simple controls. Human novice/recognition tests remain required."
      }
    ],
    "remaining_current_tasks": {
      "W06.T01": "implemented at declared two-form, one-breeding-profile scope",
      "W06.T02": "bounded repeated production probe developed; comprehensive calibration remains open",
      "W06.T03": "deferred non-Hopper stage/storage branch; historical cradle branch retained",
      "W06.T04": "stock interface added; articulated motion, physical touch and human review remain open"
    }
  },
  "Workflow": {
    "order": [
      "reference review",
      "dependency plan",
      "shared-domain implementation",
      "workbench integration",
      "public interface",
      "conflict tests",
      "browser and visual review",
      "prior regression",
      "specification and archive closure"
    ],
    "completion_semantics": "A running slice is not a complete life-cycle model or a proven enjoyable economy."
  },
  "Adherence": {
    "authority": "Original user premise governs; new rules remain revisable.",
    "preserve": [
      "winning races and speed",
      "personally building kits",
      "whole-insect Wrangloid trade",
      "catching and breeding open to all",
      "genuine upgrades",
      "collections and finishing",
      "optional expert depth",
      "Open equipment freedom",
      "Flyers against Flyers",
      "Local-Regional-Factional-New World City route"
    ],
    "avoid": [
      "story exposition replacing mechanics",
      "hidden genetic advice oracle",
      "tank-prints-money economy",
      "arbitrary world-rank genes",
      "prototype interface caps promoted to universal bans",
      "test counts used as innovation grades"
    ]
  },
  "MIVIM": {
    "admission": "quality_at_declared_scope AND novel_development_adherence",
    "quality": "Implemented and reviewed at local-slice scope; complete gameplay, native runtime and human quality remain open.",
    "novel_development_adherence": "Concrete project-specific linking of organism custody, complementary breeding, timed operating choices and the same editable racer.",
    "effectiveness": "Demonstrated for bounded tested interactions and operational conflicts.",
    "creativity": "Integrated execution beyond a fixed equipment catalogue; experiential distinctiveness not independently measured.",
    "scaling_potential": "One state and reusable commands provide an extension path; current global catalogue registry supports one active local world and is not a multi-world server architecture.",
    "no_numeric_grade": "No authorized weights or grade thresholds were supplied."
  },
  "systems": [
    {
      "id": "W06.SYSTEM.STOCK",
      "title": "One living inventory",
      "origin": "rrr_native_integration",
      "refines": [
        "W05.BENCH.03",
        "W05.LIVELIHOOD.07"
      ],
      "rules": [
        {
          "id": "W06.STOCK.01",
          "statement": "Specimens, prepared components, the host, its draft and its fitted build belong to one persistent world.",
          "decision": "Choose where a particular asset is used.",
          "observable": "A component entering the bench retains its actual donor identity.",
          "status": "implemented_in_declared_slice"
        },
        {
          "id": "W06.STOCK.02",
          "statement": "Inherited potential is attached to the individual at creation.",
          "decision": "Inspect, retain, breed, prepare or trade.",
          "observable": "Viewing, selling or renaming cannot reroll the genome.",
          "status": "implemented_in_declared_slice"
        },
        {
          "id": "W06.STOCK.03",
          "statement": "Live owner, source anatomy and current component owner are distinct fields.",
          "decision": "Sell an assembly or place its supported donor body with a service.",
          "observable": "The assembly transaction does not silently transfer or erase the remaining body.",
          "status": "implemented_in_declared_slice"
        },
        {
          "id": "W06.STOCK.04",
          "statement": "The eight historical sects, named host and earlier provenance are preserved as opening assets.",
          "decision": "Continue the existing bench instead of restarting its design.",
          "observable": "H-6 and UPGRADE-DRIVE keep their previous identities and functions.",
          "status": "implemented_in_declared_slice"
        },
        {
          "id": "W06.STOCK.05",
          "statement": "Two protected historical founder profiles, 142 credits and facilities are disclosed starting assets.",
          "decision": "Begin a field, building or production project.",
          "observable": "Starting capital is not reported as newly earned income; this is not an imported authoritative historical world save.",
          "status": "implemented_in_declared_slice"
        },
        {
          "id": "W06.STOCK.06",
          "statement": "Whole-specimen records remain after sale, preparation or supported-body placement.",
          "decision": "Inspect ancestry and custody.",
          "observable": "A database record is not mistaken for a still-intact, locally owned animal.",
          "status": "implemented_in_declared_slice"
        },
        {
          "id": "W06.STOCK.07",
          "statement": "The shared-world custody function is authoritative; legacy bench-only custody is not a market ownership service.",
          "decision": "Inspect a sold or installed part.",
          "observable": "A recipe and an old drawing cannot grant ownership.",
          "status": "implemented_in_declared_slice"
        },
        {
          "id": "W06.STOCK.08",
          "statement": "Opening specimens and commercial inventory do not inherit player-rank gates.",
          "decision": "Use any supported activity from the beginning.",
          "observable": "The prototype does not add a profession unlock to breeding or catching.",
          "status": "implemented_in_declared_slice"
        }
      ]
    },
    {
      "id": "W06.SYSTEM.FIELD",
      "title": "Targeted collection and public evidence",
      "origin": "rrr_native_extension",
      "refines": [
        "W03.INTAKE.02",
        "W03.INTAKE.03",
        "W03.INTAKE.10"
      ],
      "rules": [
        {
          "id": "W06.FIELD.01",
          "statement": "Two authored routes supply distinct current donor forms.",
          "decision": "Search the Switchyard Verge for Hopper stock or the Cooling-kiln Galleries for drive donors.",
          "observable": "The trip produces actual donors rather than generic parts rolled after combat.",
          "status": "implemented_in_declared_slice"
        },
        {
          "id": "W06.FIELD.02",
          "statement": "Each route names a location, desired anatomy, selection reason and ordinary outlet.",
          "decision": "Pursue the contribution the racer or customer needs.",
          "observable": "The capture has an intelligible use before rarity is known.",
          "status": "implemented_in_declared_slice"
        },
        {
          "id": "W06.FIELD.03",
          "statement": "Protected pods take up to two candidates; bulk containment takes up to three with disclosed anatomy-damage risk.",
          "decision": "Choose quantity or preservation for this trip.",
          "observable": "Damage changes use and condition, not the inherited alleles.",
          "status": "implemented_in_declared_slice"
        },
        {
          "id": "W06.FIELD.04",
          "statement": "A route contains a bounded cohort that refreshes on its six-turn world schedule.",
          "decision": "Return later or choose another source.",
          "observable": "Reopening the view does not generate a fresh population.",
          "status": "implemented_in_declared_slice"
        },
        {
          "id": "W06.FIELD.05",
          "statement": "Incoming captures reserve holding space during their travel.",
          "decision": "Plan travel alongside automatic production.",
          "observable": "A newly started brood cannot consume the capacity already committed to arriving animals.",
          "status": "implemented_in_declared_slice"
        },
        {
          "id": "W06.FIELD.06",
          "statement": "Unmeasured specimens expose identity, stage, origin and condition, not exact genetics.",
          "decision": "Assay a promising candidate or sell it honestly as ordinary stock.",
          "observable": "Two unseen genotypes with the same evidence receive the same advice.",
          "status": "implemented_in_declared_slice"
        },
        {
          "id": "W06.FIELD.07",
          "statement": "A project contribution is judged separately from finished-product performance.",
          "decision": "Keep good synchronization for an existing high-return line.",
          "observable": "A relatively weak individual can be a useful parent.",
          "status": "implemented_in_declared_slice"
        },
        {
          "id": "W06.FIELD.08",
          "statement": "Assay is a timed, paid observation; preparation includes a controlled component reading.",
          "decision": "Choose information before destructive allocation or measure the prepared product.",
          "observable": "Neither operation improves the inherited potential.",
          "status": "implemented_in_declared_slice"
        },
        {
          "id": "W06.FIELD.09",
          "statement": "Assay and preparation reserve the working donor against automatic sale and renewed mating.",
          "decision": "Finish the intended work on the same specimen.",
          "observable": "A boundary market renewal cannot sell the animal while its anatomy is being processed.",
          "status": "implemented_in_declared_slice"
        }
      ]
    },
    {
      "id": "W06.SYSTEM.BREED",
      "title": "Staged hopper production and selective continuation",
      "origin": "rrr_native_progression",
      "refines": [
        "W03.BREED.01",
        "W03.BREED.04",
        "W03.BREED.08"
      ],
      "rules": [
        {
          "id": "W06.BREED.01",
          "statement": "The live breeding implementation is restricted to the declared pair-bred Hopper profile.",
          "decision": "Choose mature compatible A/B reproductive roles.",
          "observable": "Captured cicadas are not quietly assigned the Hopper life cycle.",
          "status": "implemented_in_declared_slice"
        },
        {
          "id": "W06.BREED.02",
          "statement": "Each of three independent diploid loci contributes return, synchronization or settling.",
          "decision": "Combine complementary inherited stock.",
          "observable": "Offspring inherit one allele from each parent rather than all parental maxima.",
          "status": "implemented_in_declared_slice"
        },
        {
          "id": "W06.BREED.03",
          "statement": "Pairing success and survival are sampled once at commitment under a stable event seed.",
          "decision": "Commit a brood with disclosed uncertainty.",
          "observable": "Later inspection and split clock advances cannot reroll that brood.",
          "status": "implemented_in_declared_slice"
        },
        {
          "id": "W06.BREED.04",
          "statement": "Six initiated places are reserved before starting; hatch and adult transitions are separate.",
          "decision": "Observe eggs, nymphs and mature output.",
          "observable": "Expected survivors are not used as a substitute for sufficient capacity.",
          "status": "implemented_in_declared_slice"
        },
        {
          "id": "W06.BREED.05",
          "statement": "A failed reproductive opportunity spends its declared start and elapsed care costs.",
          "decision": "Retry with resources or choose another use for stock.",
          "observable": "Failure does not erase unrelated roaches or inventories.",
          "status": "implemented_in_declared_slice"
        },
        {
          "id": "W06.BREED.06",
          "statement": "Manual selection protects up to two replacement animals while retaining the other offspring for review.",
          "decision": "Inspect useful intermediates before deciding their use.",
          "observable": "Ordinary products and partial genetic progress remain useful.",
          "status": "implemented_in_declared_slice"
        },
        {
          "id": "W06.BREED.07",
          "statement": "The ordinary-production preset maintains two protected descendant replacements, choosing available reproductive roles before ordinal fallbacks.",
          "decision": "Prioritize repeatable ordinary stock rather than inspect every offspring.",
          "observable": "Retention is not a hidden genetic optimizer and does not guarantee a compatible replacement pair when a role is absent.",
          "status": "implemented_in_declared_slice"
        },
        {
          "id": "W06.BREED.08",
          "statement": "Opted-in ordinary surplus waits in a sale queue when the current quota or buyer budget is exhausted.",
          "decision": "Keep output for later funded demand or intervene.",
          "observable": "Unaccepted stock remains alive, owned, housed and charged for care.",
          "status": "implemented_in_declared_slice"
        },
        {
          "id": "W06.BREED.09",
          "statement": "An optional repeating plan attempts another brood only after capacity and care-reserve checks; stopping it does not stop current care.",
          "decision": "Run a modest production operation while pursuing other hobbies.",
          "observable": "The plan reports its blocker instead of deleting young or generating free capacity.",
          "status": "implemented_in_declared_slice"
        }
      ]
    },
    {
      "id": "W06.SYSTEM.CLOCK",
      "title": "One clock for obligations and opportunities",
      "origin": "rrr_native_integration",
      "refines": [
        "W03.CAPACITY.01",
        "W03.CAPACITY.08",
        "W03.CAPACITY.09",
        "W05.RACE.08"
      ],
      "rules": [
        {
          "id": "W06.CLOCK.01",
          "statement": "World time advances through declared actions, never elapsed browser inactivity.",
          "decision": "Race, collect, work, assay, fit or wait.",
          "observable": "Broods and care follow the same clock; offline default remains paused.",
          "status": "implemented_in_declared_slice"
        },
        {
          "id": "W06.CLOCK.02",
          "statement": "Race attendance is a two-turn activity with a three-credit service charge plus care.",
          "decision": "Attend a fresh ground practice with a committed build.",
          "observable": "The world advances once after successful computation, not once per playback.",
          "status": "implemented_in_declared_slice"
        },
        {
          "id": "W06.CLOCK.03",
          "statement": "Race model-time units and world turns are distinct.",
          "decision": "Interpret lap performance separately from attendance duration.",
          "observable": "A two-turn meeting includes abstract attendance and preparation rather than claiming a biological time scale.",
          "status": "implemented_in_declared_slice"
        },
        {
          "id": "W06.CLOCK.04",
          "statement": "A pending attendance locks conflicting world commands and freezes its entry.",
          "decision": "Finish or cancel a failed computation.",
          "observable": "The solver cannot use a changing draft or settle a different build.",
          "status": "implemented_in_declared_slice"
        },
        {
          "id": "W06.CLOCK.05",
          "statement": "Replay, scrubbing and result inspection do not advance the world or pay money.",
          "decision": "Watch freely.",
          "observable": "A finished meeting has only one attendance receipt.",
          "status": "implemented_in_declared_slice"
        },
        {
          "id": "W06.CLOCK.06",
          "statement": "Care bounds depend on committed occupancy, not hidden survival outcomes.",
          "decision": "Keep sufficient cash before starting another commitment.",
          "observable": "The forecast cannot leak unobserved mortality through an exact future bill.",
          "status": "implemented_in_declared_slice"
        },
        {
          "id": "W06.CLOCK.07",
          "statement": "When cash is exhausted, emergency contracted care records arrears and blocks new paid commitments.",
          "decision": "Sell stock or perform funded club work to recover.",
          "observable": "Animals are not silently deleted and their care is not silently free; this is a temporary credit branch, not the final injury model.",
          "status": "implemented_in_declared_slice"
        },
        {
          "id": "W06.CLOCK.08",
          "statement": "Automatic stages, queued sales and market funding execute in a declared order at turn boundaries.",
          "decision": "Repeat or split a waiting action.",
          "observable": "The same elapsed world interval produces the same biological and financial outcome apart from command bookkeeping.",
          "status": "implemented_in_declared_slice"
        }
      ]
    },
    {
      "id": "W06.SYSTEM.ANATOMY",
      "title": "Preparation, fitting and custody",
      "origin": "source_hobby_translation_and_rrr_extension",
      "refines": [
        "W05.BENCH.01",
        "W05.BENCH.03",
        "W05.BENCH.05",
        "W05.FIT.05"
      ],
      "rules": [
        {
          "id": "W06.ANATOMY.01",
          "statement": "Preparation requires owned, mature, usable anatomy and explicit release of protected founders.",
          "decision": "Trade reproductive or collecting value for immediate component use.",
          "observable": "The whole animal and extracted anatomy are not counted twice.",
          "status": "implemented_in_declared_slice"
        },
        {
          "id": "W06.ANATOMY.02",
          "statement": "A complete Hopper pair is a single physical unit serving running, launch and landing.",
          "decision": "Replace the existing paired assembly rather than stack duplicate role entries.",
          "observable": "Mass and replacement anatomy are counted once.",
          "status": "implemented_in_declared_slice"
        },
        {
          "id": "W06.ANATOMY.03",
          "statement": "Hopper preparation transfers the hind pair and leaves a supported body with ongoing obligations.",
          "decision": "Retain a reproductively capable body or place it in service custody.",
          "observable": "No automatic regrowth, intact-stock sale or second extraction is available.",
          "status": "implemented_in_declared_slice"
        },
        {
          "id": "W06.ANATOMY.04",
          "statement": "Cicada drive preparation is vital in the declared profile.",
          "decision": "Authorize the consequence before work begins.",
          "observable": "The donor living state changes; a deceased record cannot be bred.",
          "status": "implemented_in_declared_slice"
        },
        {
          "id": "W06.ANATOMY.05",
          "statement": "Generated components use measured properties derived from their actual donors.",
          "decision": "Fit a new captured or bred assembly.",
          "observable": "The same return/phase/settling or cadence/force values reach the unchanged race model.",
          "status": "implemented_in_declared_slice"
        },
        {
          "id": "W06.ANATOMY.06",
          "statement": "Dynamic descriptors extend the existing anatomical bench and artwork.",
          "decision": "Use the existing placement, undo and tuning tools.",
          "observable": "A new-stock panel does not replace the playable workbench.",
          "status": "implemented_in_declared_slice"
        },
        {
          "id": "W06.ANATOMY.07",
          "statement": "Draft and fitted components are excluded from automatic and manual component sale.",
          "decision": "Unfit and remove draft reservations before offering the part.",
          "observable": "The race cannot retain sold anatomy.",
          "status": "implemented_in_declared_slice"
        },
        {
          "id": "W06.ANATOMY.08",
          "statement": "Historical native exchange units remain in the restricted reusable-cradle preparation branch.",
          "decision": "Replace and return a prepared component.",
          "observable": "This wave does not expand bench reuse into universal painless removal or tissue regeneration.",
          "status": "implemented_in_declared_slice"
        }
      ]
    },
    {
      "id": "W06.SYSTEM.CASH",
      "title": "Funded demand and operating livelihoods",
      "origin": "rrr_native_commerce",
      "refines": [
        "W03.CASH.01",
        "W03.CASH.08",
        "W03.CASH.09"
      ],
      "rules": [
        {
          "id": "W06.CASH.01",
          "statement": "Ordinary live-stock prices use disclosed form/stage/condition, not hidden exact genes.",
          "decision": "Sell useful surplus to a relevant buyer.",
          "observable": "The quote cannot act as an unearned genetic oracle.",
          "status": "implemented_in_declared_slice"
        },
        {
          "id": "W06.CASH.02",
          "statement": "New prepared assemblies can be sold to funded, quantity-limited product orders.",
          "decision": "Add preparation value or retain the part for racing.",
          "observable": "Payment follows actual custody transfer.",
          "status": "implemented_in_declared_slice"
        },
        {
          "id": "W06.CASH.03",
          "statement": "The historical endowed collection is excluded from automatic component dispatch.",
          "decision": "Experiment with the previous workbench stock safely.",
          "observable": "Automated income cannot liquidate the starting racer unnoticed.",
          "status": "implemented_in_declared_slice"
        },
        {
          "id": "W06.CASH.04",
          "statement": "Ordinary-production consent explicitly permits unmeasured surplus sales; the research default instead requests review.",
          "decision": "Choose the desired balance of management and selection.",
          "observable": "Convenience does not secretly claim to know which offspring are worthless.",
          "status": "implemented_in_declared_slice"
        },
        {
          "id": "W06.CASH.05",
          "statement": "Buyer quota renewal occurs every twelve turns; up to 100 credits refill a wallet toward 180.",
          "decision": "Plan output relative to real current demand.",
          "observable": "Every modeled off-screen customer receipt is recorded against an external sector, not invented invisibly.",
          "status": "implemented_in_declared_slice"
        },
        {
          "id": "W06.CASH.06",
          "statement": "New production and care can continue while already produced goods wait for acceptance.",
          "decision": "Pause starts, sell other stock, expand useful capacity or work for customers.",
          "observable": "Stored output is not counted as cash and saturation can consume margin.",
          "status": "implemented_in_declared_slice"
        },
        {
          "id": "W06.CASH.07",
          "statement": "Funded two-turn club setup work earns sixteen credits while care continues.",
          "decision": "Use a low-capital recovery activity.",
          "observable": "Labor is paid from an actual buyer balance rather than a reset button.",
          "status": "implemented_in_declared_slice"
        },
        {
          "id": "W06.CASH.08",
          "statement": "A forty-credit rack expands holding by twelve places and nursery by six within prototype bounds.",
          "decision": "Buy capacity for a real bottleneck.",
          "observable": "The upgrade does not improve genes or raise unchanged stock prices.",
          "status": "implemented_in_declared_slice"
        },
        {
          "id": "W06.CASH.09",
          "statement": "Accounts, external receipts, care debt, unsold stock and retained breeders are reported separately.",
          "decision": "Choose reserves and reinvestment.",
          "observable": "A profitable displayed receipt is not a claim of lifetime return on all starting capital.",
          "status": "implemented_in_declared_slice"
        }
      ]
    },
    {
      "id": "W06.SYSTEM.UI",
      "title": "Creature-led optional-depth interaction",
      "origin": "rrr_native_execution",
      "refines": [
        "W05.POLISH.01",
        "W05.POLISH.03",
        "W05.POLISH.10"
      ],
      "rules": [
        {
          "id": "W06.UI.01",
          "statement": "The Live stock view connects field routes, actual intake, the nursery, demand and receipts.",
          "decision": "Choose an action without leaving the existing app.",
          "observable": "All panels display the same underlying world.",
          "status": "implemented_in_declared_slice"
        },
        {
          "id": "W06.UI.02",
          "statement": "Each specimen card shows source, stage, protection, condition and the reason it matters.",
          "decision": "Inspect, reserve, prepare or sell.",
          "observable": "The creature remains individually recognizable inside batch management.",
          "status": "implemented_in_declared_slice"
        },
        {
          "id": "W06.UI.03",
          "statement": "The tank displays observed nymph occupancy rather than unobserved future survival.",
          "decision": "Check the current cohort and upcoming stage.",
          "observable": "Its illustration responds to live state rather than being only decoration.",
          "status": "implemented_in_declared_slice"
        },
        {
          "id": "W06.UI.04",
          "statement": "Batch sale previews exact identities and fails as a whole on protected or unsuitable stock.",
          "decision": "Manage ordinary volume efficiently.",
          "observable": "A failed batch does not silently sell the first few items.",
          "status": "implemented_in_declared_slice"
        },
        {
          "id": "W06.UI.05",
          "statement": "The top bar distinguishes current cash, conservative upcoming care and unpaid obligations.",
          "decision": "Decide whether more production is affordable.",
          "observable": "Forecasts are not styled as already-earned income.",
          "status": "implemented_in_declared_slice"
        },
        {
          "id": "W06.UI.06",
          "statement": "Primary fit controls and the new stock actions retain keyboard/tap alternatives and textual state.",
          "decision": "Use casual defaults or inspect deeper detail.",
          "observable": "Precise dragging is not required to participate.",
          "status": "implemented_in_declared_slice"
        },
        {
          "id": "W06.UI.07",
          "statement": "Meaningful error messages persist in the stock view; model-level rejection leaves source state unchanged.",
          "decision": "Correct the actual problem and retry.",
          "observable": "Failure feedback does not require reading a fleeting console line.",
          "status": "implemented_in_declared_slice"
        }
      ]
    },
    {
      "id": "W06.SYSTEM.SAVE",
      "title": "Persistence and historical continuity",
      "origin": "supporting",
      "refines": [
        "W05.EVIDENCE.02",
        "W05.RECIPE.01",
        "W05.RACE.06"
      ],
      "rules": [
        {
          "id": "W06.SAVE.01",
          "statement": "A world backup contains the stock, genetic state, obligations, accounts, timers and build.",
          "decision": "Export or restore local work explicitly.",
          "observable": "Recipe import and world restore have different authority and controls.",
          "status": "implemented_in_declared_slice"
        },
        {
          "id": "W06.SAVE.02",
          "statement": "A recipe cannot create components or restore ownership of a sold part.",
          "decision": "Load a useful design only when its required stock is owned.",
          "observable": "Unowned historical items produce a missing-stock rejection, not duplicated tissue.",
          "status": "implemented_in_declared_slice"
        },
        {
          "id": "W06.SAVE.03",
          "statement": "World restore checks identities, allele domains, capacities, anatomy and monetary conservation.",
          "decision": "Recover a valid backup.",
          "observable": "Corrupt state is rejected before future actions use it; this is consistency validation, not anti-cheat.",
          "status": "implemented_in_declared_slice"
        },
        {
          "id": "W06.SAVE.04",
          "statement": "Available same-origin W05 local bench state can seed the new world with disclosed new facilities and capital.",
          "decision": "Keep an earlier arrangement where browser storage permits.",
          "observable": "This migration does not pretend to recover unsimulated historical finances or every historical donor body.",
          "status": "implemented_in_declared_slice"
        },
        {
          "id": "W06.SAVE.05",
          "statement": "Attendance summaries persist; full replay frames remain session data and can be exported separately.",
          "decision": "Inspect history after a backup restore.",
          "observable": "Restoring a summary does not recompute or repay attendance.",
          "status": "implemented_in_declared_slice"
        },
        {
          "id": "W06.SAVE.06",
          "statement": "Origin persistence remains best-effort; portable backup is the reliable tested data path in this host.",
          "decision": "Save work when browser storage is denied.",
          "observable": "File and loopback restrictions are reported as unverified runtime behavior, not passed tests.",
          "status": "implemented_in_declared_slice"
        }
      ]
    },
    {
      "id": "W06.SYSTEM.REVIEW",
      "title": "Quality and continued scope",
      "origin": "supporting",
      "refines": [
        "W05.EVIDENCE.05",
        "W05.EVIDENCE.06"
      ],
      "rules": [
        {
          "id": "W06.REVIEW.01",
          "statement": "MIVIM hard quality and novel-development guardrails remain non-compensable.",
          "decision": "Review the delivered interaction and integrated mechanism.",
          "observable": "A test count cannot compensate for an unfulfilled design objective.",
          "status": "implemented_in_declared_slice"
        },
        {
          "id": "W06.REVIEW.02",
          "statement": "Effectiveness, creativity and scaling potential receive separate evidence-scoped findings.",
          "decision": "Judge actual change against the previous fixed-stock bench.",
          "observable": "No invented weighted grade or worldwide-novelty certification is presented.",
          "status": "implemented_in_declared_slice"
        },
        {
          "id": "W06.REVIEW.03",
          "statement": "The finite fixture uses two field forms, one breeding profile, one market wallet and a single player host.",
          "decision": "Extend only the supported path.",
          "observable": "A seventy-three-turn probe does not establish a balanced world economy.",
          "status": "implemented_in_declared_slice"
        },
        {
          "id": "W06.REVIEW.04",
          "statement": "Completed specification, executable slice, browser checks and human enjoyment remain distinct statuses.",
          "decision": "Retain unproven acceptance tasks.",
          "observable": "No colony life cycle, free exploration, graphical production polish or retention result is falsely closed.",
          "status": "implemented_in_declared_slice"
        },
        {
          "id": "W06.REVIEW.05",
          "statement": "Preserve old context and source bytes while appending this wave.",
          "decision": "Continue future work from the live bench and inventory.",
          "observable": "Later development must not discard this functioning integration for another disconnected demo.",
          "status": "implemented_in_declared_slice"
        }
      ]
    }
  ],
  "operational_threads": [
    {
      "id": "W06.THREAD.CAPTURE_TO_RACE",
      "actor_ref": "VENUE_FOUNDRY",
      "chain": [
        "route",
        "live identity",
        "assay or preparation",
        "donor region transferred",
        "actual bench fitting",
        "frozen race entry",
        "care/time settlement"
      ],
      "purpose": "A personally sourced component becomes visible race behavior through its exact donor and construction."
    },
    {
      "id": "W06.THREAD.ORDINARY_KEEP",
      "actor_ref": "SHOP_TWO_NETS",
      "chain": [
        "complementary parents",
        "reserved cohort",
        "observed offspring",
        "retained replacements",
        "funded ordinary-stock sale",
        "operating care and reinvestment"
      ],
      "purpose": "Useful intermediate generations can support a livelihood without being perfect racers."
    },
    {
      "id": "W06.THREAD.SHOP_CAPACITY",
      "actor_ref": "ORG_CINDER",
      "chain": [
        "demand limit",
        "unsold living stock",
        "continued care",
        "paused new starts",
        "funded renewed quota",
        "actual sale"
      ],
      "purpose": "Strategic production meets real downstream limits; upgrades are useful only for a genuine bottleneck."
    },
    {
      "id": "W06.THREAD.AVAILABLE_TIME",
      "actor_ref": "VENUE_FOUNDRY",
      "chain": [
        "frozen entry",
        "modeled race",
        "two world turns",
        "nursery transitions",
        "care cost",
        "history without repeat payment"
      ],
      "purpose": "Race attendance and a productive hobby operation coexist on the same clock."
    }
  ],
  "model_contract": {
    "version": "W06.SUPPLY.1",
    "opening_cash": 142,
    "opening_other_accounts": {
      "shop": 160,
      "services": 0,
      "sponsor": 60,
      "external": 0
    },
    "historical_sects": 8,
    "founders": [
      "P-R",
      "P-S"
    ],
    "genes": [
      "return",
      "synchronization",
      "settling"
    ],
    "brood": {
      "initiated": 6,
      "failure_probability": 0.12,
      "individual_survival_probability": 0.85,
      "hatch_after": 2,
      "adult_after": 5,
      "note": "Coefficients are fictional and fixed in this prototype."
    },
    "capacity": {
      "holding": 24,
      "nursery": 6
    },
    "costs": {
      "brood_start": 6,
      "assay": 2,
      "preparation": 4,
      "fit": 2,
      "race_attendance": 3,
      "rack": 40
    },
    "ordinary_quotes": {
      "hopper": 8,
      "cicada": 10
    },
    "prepared_quotes": {
      "hopper": 22,
      "cicada": 30
    },
    "clock": "in-world turns; offline pause; care charged each turn; replay free",
    "care": "1 workshop turn + ceil(live owned specimens/6) + number of active broods",
    "renewal": "12-turn quotas; up to 100 off-screen receipts refill shop toward 180; external account records source",
    "debt": "Emergency contracted care is recorded, not silently forgiven; new paid commitments require available funds.",
    "source_of_runtime_truth": "src/world.js; arithmetic and acceptance fields above checked by behavioral probes, not a separate physics implementation."
  },
  "fixture_summary": {
    "new_world_tests": 76,
    "repeated_example": [
      {
        "tick": 13,
        "cash": 142,
        "careOwed": 0,
        "broods": 3,
        "living": 10,
        "capacity": 10,
        "blocker": null
      },
      {
        "tick": 25,
        "cash": 204,
        "careOwed": 0,
        "broods": 6,
        "living": 5,
        "capacity": 11,
        "blocker": null
      },
      {
        "tick": 37,
        "cash": 202,
        "careOwed": 0,
        "broods": 9,
        "living": 6,
        "capacity": 12,
        "blocker": null
      },
      {
        "tick": 49,
        "cash": 200,
        "careOwed": 0,
        "broods": 12,
        "living": 7,
        "capacity": 13,
        "blocker": null
      },
      {
        "tick": 61,
        "cash": 200,
        "careOwed": 0,
        "broods": 14,
        "living": 15,
        "capacity": 15,
        "blocker": null
      },
      {
        "tick": 73,
        "cash": 191,
        "careOwed": 0,
        "broods": 16,
        "living": 16,
        "capacity": 16,
        "blocker": null
      }
    ],
    "brood_to_track": {
      "donor": "W06.BROOD.1.3",
      "part": "W06.PART.W06.BROOD.1.3",
      "traits": [
        0.625,
        0.07,
        0.06
      ],
      "entryHopper": "W06.PART.W06.BROOD.1.3",
      "worldTurn": 9,
      "cash": 97
    }
  },
  "assets": {
    "interactive": "RRR_Living_World_v0.6.html",
    "preserved_base": "reference/world_context_v0.5.json",
    "prior_archive": "reference/RRR_Wave_05_Agent_Pack.zip"
  },
  "validation_artifacts": [
    "evidence/world_test_report.json",
    "evidence/model_report.json",
    "evidence/browser_report.json",
    "evidence/validation_report.json",
    "evidence/visual_review.md"
  ],
  "implementation_boundaries": [
    "This is a local browser slice, not a complete sandbox, authored story or finished game.",
    "Field collecting is a route-and-containment simulation, not a freely navigable wilderness.",
    "Hopper genetics use three independent diploid loci with fixed coefficients; no mutation, linkage, inherited morphology or general mating system.",
    "Cicadas can be caught, assayed and prepared; a complete root-to-adult cicada breeding profile is not implemented.",
    "The single nursery uses a conservative six-place commitment and fixed stage schedule, not the full general interval scheduler from W03.",
    "Rates, costs, survival and stage lengths are prototype parameters; observed first-seed performance is not a profit guarantee.",
    "Market renewal is explicit modeled off-screen customer funding; national NPC commerce, two-way retail, transport orders and contracts are not fully simulated.",
    "Care credit prevents silent stock loss at zero funds; interest, creditor enforcement, general injury and lifetime care are future branches.",
    "Native exchange is the W05 retained-cradle profile; broad tissue storage, regrowth and damage behavior remain open.",
    "The unchanged two-racer path model retains its earlier aerodynamic, ground-only and entry-mass simplifications.",
    "Cicada efficiency is stored as a selectable donor property but is NOT yet connected to the constant .75 race efficiency; current drive effect is cadence and force.",
    "World JSON is user-editable local data, not competitive authority or protection from intentional cheating.",
    "Archive bounds are 1200 specimen/component records, 200 broods, 15000 ledger entries and bounded world turns; world-scale performance is not established.",
    "File and loopback HTTP navigation were blocked by this host. Exact HTML was exercised via set_content; native origin persistence and Windows/macOS launch remain unverified.",
    "No human playtest or retention measurement. No final MIVIM numerical grade is claimed."
  ]
}
