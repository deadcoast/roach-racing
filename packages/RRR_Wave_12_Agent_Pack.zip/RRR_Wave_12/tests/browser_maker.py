"""W12 real controls. No injected inventory, genomes, cash or result batches."""
from pathlib import Path
import hashlib, json, os
from playwright.sync_api import sync_playwright
ROOT=Path(__file__).resolve().parents[1];checks=[];errors=[];navigation=[]
def check(ok,name):
 checks.append({'name':name,'passed':bool(ok)});print(('PASS ' if ok else 'FAIL ')+name,flush=True)
 if not ok: raise AssertionError(name)
def load(browser):
 page=browser.new_page(viewport={'width':1440,'height':1000},reduced_motion='reduce');page.on('pageerror',lambda e:errors.append(str(e)));page.on('dialog',lambda d:d.accept());page.set_default_timeout(8000)
 try:page.goto((ROOT/'RRR_Makers_Bloodlines_v0.12.html').as_uri(),timeout=10000);mode='file'
 except Exception:
  page.close();page=browser.new_page(viewport={'width':1440,'height':1000},reduced_motion='reduce');page.on('pageerror',lambda e:errors.append(str(e)));page.on('dialog',lambda d:d.accept());page.set_default_timeout(8000);page.set_content((ROOT/'RRR_Makers_Bloodlines_v0.12.html').read_text(),timeout=30000);mode='set_content'
 page.wait_for_function('window.RRR_WORKBENCH !== undefined');navigation.append(mode);return page
def w(page):return page.evaluate('RRR_WORKBENCH.world()')
def stock(page):page.locator('#tab-stock').click();page.locator('#stock-filter').select_option('all')
def money(page,minimum):
 stock(page)
 for _ in range(10):
  if w(page)['accounts']['player']-w(page)['careArrears']>=minimum:return
  page.locator('#club-work').click()
 raise AssertionError('Normal recovery work did not cover required operation')
def brood(page):
 stock(page);money(page,35);page.locator('#parent-a').select_option('P-R');page.locator('#parent-b').select_option('P-S');old=len(w(page)['broods']);page.locator('#breed').click();check(len(w(page)['broods'])==old+1,'Real brood committed through nursery controls');page.locator('#wait-four').click();page.locator('#wait-one').click()
def prep(page,id,product):
 stock(page);s=next(s for s in w(page)['specimens'] if s['id']==id)
 if s['protected']:page.locator(f'[data-world="protect"][data-id="{id}"]').click()
 before={p['id'] for p in w(page)['parts']};page.locator(f'[data-world="prepare"][data-id="{id}"][data-product="{product}"]').click()
 created=[p for p in w(page)['parts'] if p['id'] not in before]
 check(len(created)==1 and created[0]['donor']==id,'Preparation transfers the selected donor into one new component');return created[0]['id']
def shop(page,kind,action,id):
 page.locator('#tab-shop').click();page.locator('#shop-kind').select_option(kind);page.locator(f'[data-shop="{action}"][data-id="{id}"]').click()
def screenshot(page,name):
 page.wait_for_timeout(3500);page.screenshot(path=str(ROOT/'evidence'/name),full_page=True)

with sync_playwright() as pw:
 browser=pw.chromium.launch(executable_path=os.environ.get('RRR_CHROMIUM','/usr/bin/chromium'),args=['--no-sandbox'])
 page=load(browser)
 # Win with existing owned kit; no debug edits.
 page.locator('[data-stock="UPGRADE-DRIVE"]').click();page.locator('#fit-part').click();page.locator('[data-stock="W05.PADS"]').click();page.locator('#fit-part').click();page.locator('#commit').click()
 page.locator('#tab-meets').click();page.locator('#enter-first').click()
 for i in range(3):
  page.locator('#meet-run').click();page.wait_for_function("RRR_WORKBENCH.tab()==='race' && !RRR_WORKBENCH.world().club.active?.pending",timeout=45000);page.locator('#tab-meets').click()
 world=w(page);meet=world['club']['history'][0];check(meet['champion'],'The reference is an actual computed club winner');check(world['accounts']['player']==174,'Competition retains its previous actual payout and costs');original=world['bench']['fitted']
 page.locator('#tab-maker').click();page.locator('#maker-name').fill('Second Helping / club tin');page.locator('#maker-source').select_option(meet['id']);page.locator('#maker-tolerance').select_option('0.25')
 page.locator('#maker-promise-editor summary').click();el=page.locator('[data-maker-bound="S3"][data-metric="rough_grip"][data-op="min"]');el.fill('0.9');el.press('Tab');page.locator('#maker-publish').click()
 check(len(w(page)['maker']['recipes'])==1,'Actual winner published through owner action');check(w(page)['bench']['fitted']==original,'Publication leaves reference build installed');rid=w(page)['maker']['recipes'][0]['id']
 page.locator('#maker-inquiry').click();oid=w(page)['maker']['orders'][-1]['id'];check(w(page)['accounts']['escrow']==0,'Customer inquiry is not yet money');screenshot(page,'maker_published.png')
 # Need a different actual Hopper with useful inherited settling.
 for _ in range(5):
  brood(page);adults=[s for s in w(page)['specimens'] if s.get('brood') and s['alive'] and s['stage']=='adult' and s['owner']=='player' and s['regions'].get('hind_pair')=='intact']
  if adults:break
 check(bool(adults),'Usable real descendant produced without gene injection');s=next((s for s in adults if not s['protected']),adults[0]);hpid=prep(page,s['id'],'hoppers')
 money(page,115);shop(page,'roach','buyLive','W08.SHOP.HOST.lowline.A');shop(page,'cicada','buyPart','W07.PART.W07.SHOP.DONOR.3.redline');shop(page,'stick','buyLive','W07.SHOP.LIVE.stick.B');feet=prep(page,'W07.SHOP.LIVE.stick.B','sticktoe')
 money(page,20);page.locator('#tab-maker').click();page.locator('#maker-host').select_option('W08.SHOP.HOST.lowline.A');page.locator('#maker-slot-S1').select_option(hpid);page.locator('#maker-slot-S2').select_option('W07.PART.W07.SHOP.DONOR.3.redline');page.locator('#maker-slot-S3').select_option(feet)
 check(page.locator('#maker-pack').is_enabled(),'Different host and actual alternate anatomy satisfy whole-kit promise');screenshot(page,'maker_ready.png');page.locator('#maker-release').check();tick=w(page)['tick'];page.locator('#maker-pack').click()
 kits=[k for k in w(page)['kits'] if k.get('type')=='maker_host'];check(len(kits)==1,'One physical maker tin created');kit=kits[0];check(w(page)['tick']==tick+1,'Packing advances shared care clock once');check(w(page)['bench']['fitted']==original,'The original race-winning kit is not consumed');check(hpid in kit['items'] and 'H-6' not in kit['items'],'Actual offspring, not original H6, supplies reproduction kit')
 page.locator(f'[data-maker-accept="{oid}"]').click();price=next(o for o in w(page)['maker']['orders'] if o['id']==oid)['price'];cash=w(page)['accounts']['player'];check(w(page)['accounts']['escrow']==price,'Specific inquiry reserves real buyer funds')
 page.locator(f'[data-maker-deliver-kit="{oid}"]').click();after=w(page);check(after['accounts']['player']==cash+price,'Kit handover earns the actual price');check(next(s for s in after['specimens'] if s['id']==kit['hostId'])['owner']=='shop','Living foundation transfers with sold contents');check(all(next(p for p in after['parts'] if p['id']==id)['owner']=='shop' for id in kit['items']),'Every physical component changes ownership once');check(after['club']['history'][0]==meet,'Commerce does not rewrite the sporting record');screenshot(page,'maker_delivered.png')
 print('STEP restock',flush=True);page.locator('#tab-shop').click();check(page.locator(f'[data-maker-retail="{kit["id"]}"]').count()==1,'Actual delivered kit appears once on Two Nets independent-maker shelf');screenshot(page,'maker_shop_shelf.png');page.locator('#tab-maker').click();before=after['accounts']['player'];page.locator(f'[data-maker-restock="{oid}"]').click();check(w(page)['accounts']['player']==before,'Next finite batch offer is not immediate profit')
 # full world restore through actual controls
 print('STEP export',flush=True);stock(page)
 with page.expect_download(timeout=12000) as info:page.locator('#save-world').click()
 save=ROOT/'evidence/browser_maker.rrr-save.json';info.value.save_as(save);before=w(page);print('STEP wait/restore',flush=True);page.locator('#wait-one').click();page.locator('#world-file').set_input_files(str(save));page.wait_for_function(f'RRR_WORKBENCH.world().tick==={before["tick"]}');check(w(page)==before,'Portable backup restores maker, club, stable, stock and payments together')
 print('STEP mobile',flush=True);page.locator('#tab-maker').click();page.set_viewport_size({'width':390,'height':844});screenshot(page,'maker_mobile.png');check(page.evaluate('document.documentElement.scrollWidth<=innerWidth+1'),'Narrow maker view has no horizontal overflow');check(page.locator('#maker-publish').is_visible(),'Narrow publication control remains available')
 kit_world=w(page);page.close()
 # Separate real starting world: breeder commission with failures and partial evidence retained.
 page=load(browser);page.locator('#tab-stable').click();page.locator('#selection-kind').select_option('hopper');page.locator('#selection-trait').select_option('phase');page.locator('#selection-threshold').fill('0.07');page.locator('#apply-selection').click();page.locator('#line-name').fill('Two Nets / synchronized founders');page.locator('#line-parent-a').select_option('P-R');page.locator('#line-parent-b').select_option('P-S');page.locator('#create-line').click();line_id=w(page)['lines'][0]['id'];check(all(next(s for s in w(page)['specimens'] if s['id']==id)['protected'] for id in ['P-R','P-S']),'Named project retains protected original founders')
 report=None
 for attempt in range(6):
  brood(page);stock(page)
  adults=[s for s in w(page)['specimens'] if s.get('brood') and s['alive'] and s['stage']=='adult' and s['owner']=='player' and s['regions'].get('hind_pair')=='intact']
  # The first two needed roles plus at least one in each actual brood; inspect only observed anatomy, no genomes.
  chosen=[]
  for role in ['A','B']:
   q=next((s for s in adults if s['sex']==role),None)
   if q and q['id'] not in chosen:chosen.append(q['id'])
  for bid in dict.fromkeys(s['brood'] for s in adults):
   q=next(s for s in adults if s['brood']==bid)
   if q['id'] not in chosen:chosen.append(q['id'])
  for s in adults:
   if len(chosen)>=3:break
   if s['id'] not in chosen:chosen.append(s['id'])
  for id in chosen:
   current=next(s for s in w(page)['specimens'] if s['id']==id)
   if not current['measured']:
    money(page,12);stock(page);page.locator(f'[data-world="assay"][data-id="{id}"]').click()
  page.locator('#tab-maker').click();report=page.evaluate("RRRMaker.evidence(RRR_WORKBENCH.world(),RRR_WORKBENCH.world().lines[0].id,RRRMaker.BRIEFS[2])") # read-only public evidence projection
  if attempt==0:
   check(not report['ok'],'One measured brood does not meet two-brood evidence');screenshot(page,'breeder_partial.png')
  if report['ok'] and all(any(s['sex']==role for s in report['eligible']) for role in ['A','B']):break
 check(report['ok'],'Actual measured descendants eventually meet customer evidence');check(report['unmeasured']>0,'Untested siblings remain explicitly unknown');oid2='W12.ORDER.BREED.HOP';page.locator(f'[data-maker-accept="{oid2}"]').click()
 pair=[next(s['id'] for s in report['eligible'] if s['sex']==role) for role in ['A','B']]
 for i,id in enumerate(pair):page.locator(f'[data-maker-pair="{oid2}"][data-index="{i}"]').select_option(id)
 page.locator(f'[data-maker-pair-release="{oid2}"]').check();screenshot(page,'breeder_evidence.png');before=w(page)['accounts']['player'];page.locator(f'[data-maker-deliver-breeders="{oid2}"]').click();bw=w(page);check(bw['accounts']['player']==before+76,'Actual measured living pair earns its commissioned receipt');check(all(next(s for s in bw['specimens'] if s['id']==id)['owner']=='shop' for id in pair),'Only selected living descendants are transferred');check(all(next(s for s in bw['specimens'] if s['id']==id)['owner']=='player' for id in ['P-R','P-S']),'Founding parents are retained rather than sold implicitly');screenshot(page,'breeder_delivered.png')
 check(not errors,'All browser routes completed without uncaught page errors')
 output={'html_sha256':hashlib.sha256((ROOT/'RRR_Makers_Bloodlines_v0.12.html').read_bytes()).hexdigest(),'checks':checks,'passed':sum(c['passed'] for c in checks),'failed':sum(not c['passed'] for c in checks),'errors':errors,'navigation':navigation,'kit_path':{'tick':kit_world['tick'],'cash':kit_world['accounts']['player'],'recipe':kit_world['maker']['recipes'][0],'kit':kit,'receipts':kit_world['maker']['shipments'],'ledger':kit_world['ledger'],'reference_result':meet['table']},'breeder_path':{'brood_attempts':len(bw['broods']),'broods':[{'id':b['id'],'stage':b['stage']} for b in bw['broods']],'claim':bw['maker']['shipments'][-1],'cash':bw['accounts']['player'],'tick':bw['tick']}}
 (ROOT/'evidence/browser_maker_report.json').write_text(json.dumps(output,indent=2));browser.close();print(json.dumps({'checks':len(checks),'passed':output['passed'],'navigation':navigation,'cash':kit_world['accounts']['player'],'attempts':len(bw['broods'])}))
