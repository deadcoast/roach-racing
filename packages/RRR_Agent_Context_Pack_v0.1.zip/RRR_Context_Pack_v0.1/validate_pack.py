#!/usr/bin/env python3
"""Validate reference-pack structure only; this is not a game/balance validator."""
from __future__ import annotations
import json
import sys
from pathlib import Path

COLLECTIONS = (
    'author_canon', 'working_proposals', 'reference_facts', 'translation_rules',
    'decisions', 'seed_records', 'causal_rules', 'scenario_fixtures',
)


def validate(directory: Path) -> dict[str, int]:
    data = json.loads((directory / 'world_context.json').read_text(encoding='utf-8'))
    source_ids = [row['id'] for row in data['sources']]
    if len(source_ids) != len(set(source_ids)):
        raise ValueError('Duplicate source ID.')
    identifiers: list[str] = []
    for collection in COLLECTIONS:
        rows = data[collection]
        if not isinstance(rows, list):
            raise ValueError(f'{collection} must be an array.')
        for row in rows:
            if not isinstance(row.get('id'), str) or not row['id']:
                raise ValueError(f'Invalid ID in {collection}.')
            identifiers.append(row['id'])
    if len(identifiers) != len(set(identifiers)):
        raise ValueError('Record IDs must be unique across collections.')
    seed_ids = {row['id'] for row in data['seed_records']}
    for row in data['seed_records']:
        if row['status'] not in {'working_proposal', 'new_proposal'}:
            raise ValueError(f"Seed promoted to unapproved authority: {row['id']}")
        for target in row.get('related_ids', []):
            if target not in seed_ids:
                raise ValueError(f"Broken seed link: {row['id']} -> {target}")
    for fact in data['reference_facts']:
        if fact['status'] != 'reference_fact':
            raise ValueError('Incorrect reference status.')
        for source_id in fact['source_ids']:
            if source_id not in source_ids:
                raise ValueError(f'Unknown reference source: {source_id}')
    for decision in data['decisions']:
        if decision['status'] != 'unresolved':
            raise ValueError('Unapproved decision status.')
        for prerequisite in decision['depends_on']:
            if prerequisite not in {r['id'] for r in data['decisions']}:
                raise ValueError(f'Unknown decision dependency: {prerequisite}')
    line_rows = [json.loads(line) for line in (directory / 'records.jsonl').read_text(encoding='utf-8').splitlines() if line.strip()]
    if [row['id'] for row in line_rows] != identifiers:
        raise ValueError('JSONL records do not match the combined JSON.')
    for full, line_row in zip((r for c in COLLECTIONS for r in data[c]), line_rows):
        if full != {k: v for k, v in line_row.items() if k != 'collection'}:
            raise ValueError(f"JSONL content drift: {full['id']}")
    return {**{c: len(data[c]) for c in COLLECTIONS},
            'sources': len(source_ids), 'entity_contracts': len(data['entity_contracts'])}


if __name__ == '__main__':
    root = Path(sys.argv[1]).resolve() if len(sys.argv) > 1 else Path(__file__).resolve().parent
    try:
        counts = validate(root)
    except (OSError, ValueError, KeyError, TypeError) as exc:
        print(f'Validation failed: {exc}', file=sys.stderr)
        raise SystemExit(1)
    print(json.dumps({'structural_validation': 'passed', 'counts': counts,
                      'not_validated': ['gameplay', 'biology', 'economy', 'race physics', 'course geometry']}, indent=2))
