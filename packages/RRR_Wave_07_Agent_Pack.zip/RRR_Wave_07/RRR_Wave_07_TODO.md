# RRR — Wave 07 task ledger

Specifications and profile implementation are not complete-game acceptance.

## [x] W07.T01 — Audit actual PCR families and correct the runtime coverage gap
Priority P0. Status: developed.
Acceptance: Source matrix and limitations explicit; no source coefficient invention.

## [x] W07.T02 — Connect eight interchangeable families to causal race variables
Priority P0. Status: implemented_and_model_tested.
Acceptance: Frames, ratios, contact release, efficiency, stabilization, landing and aero are compiled from installed stock.

## [x] W07.T03 — Expand purposeful capture and component-producing donor selection
Priority P0. Status: implemented_and_model_tested.
Acceptance: Ten forms, named routes, three relevant traits each, valid stages and practical products.

## [x] W07.T04 — Implement alternative and disjoint preparation with custody
Priority P0. Status: implemented_and_model_tested.
Acceptance: No tissue duplication; useful nonvital bodies and bounded vital remains; old bench preserved.

## [x] W07.T05 — Develop form-specific production and a useful-stage branch
Priority P0. Status: implemented_profile_not_biological_validation.
Acceptance: Distinct schedules and facilities; actual waxmoth larva to component or adult; retained founders.

## [x] W07.T06 — Build specimen-aware Two Nets, conversion tins and selected orders
Priority P0. Status: implemented_and_browser_tested.
Acceptance: Funded purchases, packed custody, explicit measured demand, partial delivery and refund.

## [x] W07.T07 — Polish source-to-bench presentation and stage recognition
Priority P1. Status: rendered_review_no_human_test.
Acceptance: Whole stock, prepared art, causal metrics and larval/pupal icons; narrow layout inspected.

## [x] W07.T08 — Validate continuation, migration, experiments and package
Priority P0. Status: tested_at_reported_scope.
Acceptance: Repeatable tests, six legacy parity cases, migration, multi-seed probes and extracted-archive checks.

## Carry / next work

### [ ] W08.T01 — Complete the body/host layer and calibrated multi-family component catalogue
P0. At least several selectable host bodyforms with distinct geometry and native anatomy, purchasable full kits, source-traceable component grades and comparable test protocols. No arbitrary host-stat aura. Do not reset existing stock.

### [ ] W08.T02 — Expand breeding evidence and earned market progression
P0. Longitudinal brood records, project-specific contribution guidance for every form, measured product qualification, repeat customer demand driven by delivered stock and public racing. Use enough seeds and actual play sessions to calibrate livelihood pacing.

### [ ] W08.T03 — Complete missing track and physical-hobby functions
P1. Editable modular layouts, explicit braking and rail-guide families, richer airborne and contact interaction. Current bump seams are not a complete suspension model; flyers need real aerial paths, not a ground reskin.

### [ ] W08.T04 — Viable storage, movement and commercial breadth
P1. Prepared-stock condition and actual shipping windows; more anatomical motion and ownership-preserving kit substitution. Species appearance inheritance and named lineage branding need real records; no hidden survival oracle.
