'use strict';
const assert=require('node:assert/strict'),fs=require('fs'),path=require('path'),W=require('../src/world.js'),B=require('../src/bench.js'),R=require('../src/race.js'),C=require('../src/catalog.js'),X=require('../src/circuits.js');
const results=[],evidence={};const cp=B.copy,eq=assert.deepEqual,bad=fn=>assert.throws(fn);
function test(name,fn){try{fn();results.push({name,passed:true});}catch(e){results.push({name,passed:false,error:e.stack});console.error(name,e.message);process.exitCode=1;}}
const apply=(w,c)=>W.apply(w,c).world;
function ops(w,cmds){for(const c of cmds)w=apply(w,c);return w;}
const shape=['run','rise','half','rail','run','run','bend','run','run','half','bend','run','run','bend'];
const plan=(types=shape,name='Apron test')=>({format:'RRR.TRACK.PLAN.1',name,laps:2,sections:types.map(type=>({type,turn:1}))});
function laid(){let w=W.initial();for(const k of ['rise.1','half.1','half.2','rail.1'])w=apply(w,{type:'trackBuy',id:'W09.SECTION.SHOP.'+k});w=apply(w,{type:'trackImport',text:JSON.stringify(plan())});return apply(w,{type:'trackPublish'});}
function addKit(w){w=ops(w,[{type:'buyKit',id:'W07.KIT.APRON'},{type:'unpack',id:'W07.KIT.APRON'}]);return w;}
function fast(w,ids=[]){W.sync(w);let s=B.remove(w.bench,'H-6');for(const id of ['UPGRADE-DRIVE','W05.CROP','W05.PADS',...ids])s=B.place(s,id);s.draft.tuning.leverage=.7;s.draft.approach='clean';w.bench=s;return apply(w,{type:'fit'});}
const sum=w=>Object.values(w.accounts).reduce((a,b)=>a+b,0);
function solo(course,b,policy={passing:false},dt=.01){return new R.Race(course,[{build:cp(b),policy,d:0}],'open',dt).run();}
function shortBuild(){let w=laid();w=fast(w);const b=B.compile(w.bench.fitted,w.bench.revision,w.bench.host_profile);return {w,b,course:X.active(w.trackworks).course};}

test('Disclosed opening rack contains 12 identified player sections',()=>{const w=W.initial();eq(w.trackworks.inventory.filter(s=>s.owner==='player').length,12);eq(w.accounts.player,142);eq(sum(w),362);});
test('Starter construction closes and has connected gates',()=>{const t=X.initial(),r=X.compile(t);assert(r.valid);const c=new R.Course(r.course);eq(c.gates.length,24);assert(r.closure<1e-6);});
test('Segment distance recognizes crossings',()=>eq(X.segDist([0,0],[2,2],[0,2],[2,0]),0));
test('Open endpoint is explicit',()=>{const t=X.initial();t.draft.sequence.pop();assert(X.compile(t).errors.some(e=>e.code==='open'));});
test('Heading mismatch is not hidden by snap',()=>{const t=X.initial();t.draft.sequence[2].turn=-1;assert(!X.compile(t).valid);});
test('Unowned section cannot be placed',()=>bad(()=>apply(W.initial(),{type:'trackAppend',id:'W09.SECTION.SHOP.rise.1'})));
test('Same piece cannot occur twice',()=>{const t=X.initial();t.draft.sequence.push(cp(t.draft.sequence[0]));bad(()=>X.compile(t));});
test('Unknown types refused',()=>{const t=X.initial();t.inventory[0].type='magic';bad(()=>X.validate(t));});
test('Negative or noninteger laps refused',()=>{for(const laps of [0,-1,2.1,7])bad(()=>apply(W.initial(),{type:'trackName',name:'Test',laps}));});
test('Names do not permit control characters',()=>bad(()=>apply(W.initial(),{type:'trackName',name:'x\u0000',laps:2})));
test('Published geometry cannot overlap floor channels',()=>{const t=X.initial();const seq=t.draft.sequence.map(cp);for(const a of seq){const s=cp(t.inventory.find(x=>x.id===a.id));s.id+='extra';t.inventory.push(s);a.id=s.id;}t.draft.sequence.push(...seq);const r=X.compile(t);assert(r.errors.some(e=>e.code==='overlap'));});
test('Too few sections is a draft not a course',()=>{const t=X.initial();t.draft.sequence=[];assert(!X.compile(t).valid);bad(()=>X.publish(t,0));});
test('Workshop supports a reversible turn',()=>{const t=X.initial();for(const a of t.draft.sequence)a.turn=-1;assert(X.compile(t).valid);});
test('A rise immediately before a bend is rejected',()=>{let w=apply(W.initial(),{type:'trackBuy',id:'W09.SECTION.SHOP.rise.1'});w=apply(w,{type:'trackReplace',id:'W09.SECTION.SHOP.rise.1',index:1});assert(X.compile(w.trackworks).errors.some(e=>e.code==='landing'));});
test('Purchase conserves money and changes only one owner',()=>{const a=W.initial(),b=apply(a,{type:'trackBuy',id:'W09.SECTION.SHOP.rise.1'});eq(sum(a),sum(b));eq(b.accounts.player,a.accounts.player-12);eq(b.trackworks.inventory.find(s=>s.id==='W09.SECTION.SHOP.rise.1').owner,'player');});
test('Duplicate purchase cannot buy the same piece again',()=>{const w=apply(W.initial(),{type:'trackBuy',id:'W09.SECTION.SHOP.rise.1'});bad(()=>apply(w,{type:'trackBuy',id:'W09.SECTION.SHOP.rise.1'}));});
test('Insufficient funds leave transaction unchanged',()=>{const w=W.initial();w.accounts.services+=w.accounts.player;w.accounts.player=0;const before=cp(w);bad(()=>apply(w,{type:'trackBuy',id:'W09.SECTION.SHOP.rise.1'}));eq(w,before);});
test('Draft edits cost no turns or credits',()=>{const a=W.initial(),b=apply(a,{type:'trackRemove',index:0});eq(a.tick,b.tick);eq(a.accounts,b.accounts);});
test('Undo restores sequence',()=>{const a=W.initial(),b=ops(a,[{type:'trackRemove',index:0},{type:'trackUndo'}]);eq(a.trackworks.draft,b.trackworks.draft);});
test('Moving a section reorders real identities',()=>{const a=W.initial(),b=apply(a,{type:'trackMove',index:0,offset:1});eq(b.trackworks.draft.sequence[1],a.trackworks.draft.sequence[0]);});
test('Cannot reverse a straight',()=>bad(()=>apply(W.initial(),{type:'trackFlip',index:0})));
test('Missing-stock plan fails atomically',()=>{const a=W.initial(),before=cp(a);bad(()=>apply(a,{type:'trackImport',text:JSON.stringify(plan())}));eq(a,before);});
test('Plan rejects injected money fields',()=>bad(()=>apply(W.initial(),{type:'trackImport',text:JSON.stringify({...X.exportPlan(X.initial()),cash:999})})));
test('Plan rejects injected section identities',()=>{const p=X.exportPlan(X.initial());p.sections[0].id='FREE';bad(()=>X.importPlan(X.initial(),p));});
test('Plan roundtrip resolves to current owned pieces',()=>{const t=X.initial(),before=cp(t.inventory);X.importPlan(t,X.exportPlan(t));eq(t.inventory,before);assert(X.compile(t).valid);});
test('Laying a course advances work and care once',()=>{const a=W.initial(),b=apply(a,{type:'trackPublish'});eq(b.tick,a.tick+1);assert(b.accounts.player<=a.accounts.player-2);eq(b.trackworks.published.length,1);});
test('Unchanged publication is not a second work charge',()=>{const a=apply(W.initial(),{type:'trackPublish'}),b=apply(a,{type:'trackPublish'});eq(a.accounts,b.accounts);eq(a.tick,b.tick);eq(a.trackworks,b.trackworks);});
test('Geometry changes require a new archived identity',()=>{let a=laid();const id=a.trackworks.active;a=apply(a,{type:'trackName',name:'New name',laps:3});eq(a.trackworks.active,id);a=apply(a,{type:'trackPublish'});assert(a.trackworks.active!==id);eq(a.trackworks.published.length,2);});
test('Archived course remains frozen while draft changes',()=>{let a=laid();const c=cp(X.active(a.trackworks));a=apply(a,{type:'trackRemove',index:0});eq(X.active(a.trackworks),c);});
test('Changed archive geometry rejected on world restore',()=>{const w=laid();w.trackworks.published[0].course.pieces[0].length=999;bad(()=>W.restore(JSON.stringify({format:'RRR.W09.SAVE.1',world:w})));});
test('Changed archive name or fingerprint rejected',()=>{const w=laid();w.trackworks.published[0].fingerprint='forged';bad(()=>W.validate(w));});
test('World roundtrip includes stock, stable and track undo',()=>{const w=apply(laid(),{type:'trackRemove',index:0});eq(W.restore(W.save(w)),w);});
test('Old prototype courses still available',()=>{const w=W.initial();assert(W.apply(w,{type:'raceStart',settings:{course:'long'}}).result.course);});
test('Cannot enter unpublished custom geometry',()=>bad(()=>apply(W.initial(),{type:'raceStart',settings:{course:'built'}})));
test('Caller cannot bypass owned geometry with raw courseData',()=>bad(()=>apply(W.initial(),{type:'raceStart',settings:{course:'built',courseData:R.foundryCourse().data()}})));
test('Published race entry uses exact section ids and version',()=>{const w=laid(),q=W.apply(w,{type:'raceStart',settings:{course:'built'}}).result;eq(q.course.id,w.trackworks.active);eq(q.course.pieces.map(p=>p.id),X.active(w.trackworks).course.pieces.map(p=>p.id));});
test('Pending attendance prevents track mutation',()=>{const w=apply(laid(),{type:'raceStart',settings:{course:'built'}});bad(()=>apply(w,{type:'trackRemove',index:0}));});
test('Cancelled calculation charges no attendance',()=>{const a=laid(),b=ops(a,[{type:'raceStart',settings:{course:'built'}},{type:'raceCancel'}]);eq(a.tick,b.tick);eq(a.accounts,b.accounts);});
test('Sponsor-funded layout work pays once and retains inventory',()=>{const a=laid(),b=apply(a,{type:'trackCommission'});eq(b.accounts.sponsor,a.accounts.sponsor-24);eq(a.trackworks.inventory,b.trackworks.inventory);eq(b.tick,a.tick+2);eq(sum(a),sum(b));bad(()=>apply(b,{type:'trackCommission'}));});
test('Generic starter layout does not satisfy a specialist commission',()=>bad(()=>apply(apply(W.initial(),{type:'trackPublish'}),{type:'trackCommission'})));
test('An unfunded commission cannot pay',()=>{const a=laid();a.accounts.services+=a.accounts.sponsor;a.accounts.sponsor=0;bad(()=>apply(a,{type:'trackCommission'}));});
test('Two new donors bring distinct traits and schedules',()=>{eq(C.FORMS.darkling.traits.length,3);eq(C.FORMS.feltmoth.traits.length,3);assert(C.FORMS.darkling.facility!==C.FORMS.feltmoth.facility);});
test('Source contact pads have one alternative brake preparation',()=>{assert(C.FORMS.stick.products.includes('gripstrip'));eq(C.PRODUCTS.gripstrip.regions,C.PRODUCTS.sticktoe.regions);});
test('Conversion tin is not an assembled host',()=>{const a=addKit(W.initial());const kit=a.kits.find(k=>k.recipe==='APRON');eq(kit.items.length,2);eq(a.bench.fitted.placements.map(p=>p.id),['H-6']);});
test('Approach tin uses different physical donors',()=>{const w=W.initial(),kit=w.kits.find(k=>k.recipe==='APRON');const donors=kit.items.map(id=>w.parts.find(p=>p.id===id).donor);eq(new Set(donors).size,2);});
test('New product qualifiers use actual measurements, not grade labels',()=>{const w=W.initial();assert(w.contracts.find(o=>o.id==='W09.ORDER.RAIL').requirements.rail_support.min===1.8);assert(w.contracts.find(o=>o.id==='W09.ORDER.BRAKE').requirements.brake_mu.min===.72);});
test('Field route catches a real new donor',()=>{const a=W.apply(W.initial(),{type:'field',route:'darkling',method:'protect'});assert(a.result.length);const s=a.world.specimens.find(s=>s.id===a.result[0]);eq(s.kind,'darkling');assert(!s.measured);});
test('Prepare darkling side shell once',()=>{let {world:w,result:ids}=W.apply(W.initial(),{type:'field',route:'darkling',method:'protect'});const id=ids[0],out=W.apply(w,{type:'prepare',id,product:'railshoes'});assert(out.result);eq(out.world.specimens.find(s=>s.id===id).regions.side_shell,out.result);bad(()=>apply(out.world,{type:'prepare',id,product:'railshoes'}));});
test('Alternative stick pad preparation cannot duplicate contact tissue',()=>{let {world:w,result:ids}=W.apply(W.initial(),{type:'field',route:'stick',method:'protect'});w=apply(w,{type:'prepare',id:ids[0],product:'gripstrip'});bad(()=>apply(w,{type:'prepare',id:ids[0],product:'sticktoe'}));});
test('Protected founders cannot become brake material',()=>{let w=apply(W.initial(),{type:'buyLive',id:'W07.SHOP.LIVE.feltmoth.A'});bad(()=>apply(w,{type:'prepare',id:'W07.SHOP.LIVE.feltmoth.A',product:'feltbrake'}));});
test('No species-specific bonus from a shop bought guide',()=>{const w=addKit(W.initial()),id=w.kits.find(k=>k.recipe==='APRON').items.find(id=>w.parts.find(p=>p.id===id).product==='railshoes');W.sync(w);const desc=W.descriptor(w,w.parts.find(p=>p.id===id));eq(desc.stats.rail_friction,C.traits(w.specimens.find(s=>s.id===desc.donor)).friction);});
test('Actual guide expands the envelope and counts mass once',()=>{const w=addKit(W.initial());W.sync(w);const id=w.kits.find(k=>k.recipe==='APRON').items.find(id=>w.parts.find(p=>p.id===id).product==='railshoes'),a=B.compile(w.bench.draft,1,w.bench.host_profile),s=B.place(w.bench,id),b=B.compile(s.draft,1,s.host_profile);assert(b.width>a.width);assert(b.mass>a.mass);eq(b.component_ids.filter(v=>v===id).length,1);});
test('Brake clearance is separate from inherited friction',()=>{const w=addKit(W.initial());W.sync(w);const id=w.kits.find(k=>k.recipe==='APRON').items.find(id=>w.parts.find(p=>p.id===id).product==='feltbrake'),a=B.place(w.bench,id),b=B.place(a,id,{y:.69});const ca=B.compile(a.draft,1,a.host_profile),cb=B.compile(b.draft,1,b.host_profile);eq(ca.brake_mu,cb.brake_mu);assert(cb.brake_clearance>ca.brake_clearance);});
test('Nonfinite brake coefficient rejected',()=>{const b=B.compile(B.initial().fitted);b.brake_mu=NaN;bad(()=>R.build(b));});
test('Bad launch metadata rejected',()=>{const c=X.compile(X.initial()).course;c.pieces[0].launch_angle=Infinity;bad(()=>new R.Course(c));});
test('Active jump and passive ramp are distinct causes',()=>{const {b,course}=shortBuild();const r=solo(course,b);assert(r.events.some(e=>e.kind==='ramp_launch'));assert(!r.events.some(e=>e.kind==='jump_load'));});
const fixture=shortBuild();
const noBrake=solo(fixture.course,fixture.b),yesBrake=solo(fixture.course,{...fixture.b,brake_source:'SYNTHETIC.CONTROLLED.PAD',brake_mu:.72,brake_rough:.72,brake_travel:.08,brake_clearance:.08});
test('Fast native approach overruns short landing into a curve',()=>{eq(noBrake.results[0].finish_time,null);assert(noBrake.events.some(e=>e.kind==='course_out'));assert(noBrake.results[0].gates<noBrake.results[0].required_gates);});
test('Controlled braking can preserve a fast racer through the short landing',()=>{assert(yesBrake.results[0].finish_time!==null);assert(yesBrake.results[0].brake_work>0);});
test('Same mass and inputs isolate the pad contact comparison',()=>{eq(yesBrake.results[0].build.mass,noBrake.results[0].build.mass);eq(yesBrake.results[0].build.cadence,noBrake.results[0].build.cadence);});
test('A raised noncontacting pad has no magical slowing benefit',()=>{const raised=solo(fixture.course,{...yesBrake.results[0].build,brake_clearance:.24});eq(raised.results[0].finish_time,noBrake.results[0].finish_time);eq(raised.results[0].brake_work,0);});
test('Stronger braking is not always a faster time',()=>{const hard=solo(fixture.course,{...yesBrake.results[0].build,brake_mu:.9});assert(hard.results[0].finish_time>yesBrake.results[0].finish_time);});
test('Reserve never regenerates from braking',()=>{for(const f of yesBrake.frames)assert(f.runners[0].energy<=fixture.b.reserve+1e-9);for(let i=1;i<yesBrake.frames.length;i++)assert(yesBrake.frames[i].runners[0].energy<=yesBrake.frames[i-1].runners[0].energy+1e-8);});
test('Ramp velocity splitting preserves its entry kinetic magnitude',()=>{const e=yesBrake.events.find(e=>e.kind==='ramp_launch');assert(Math.abs((e.speed*Math.cos(e.angle))**2+(e.speed*Math.sin(e.angle))**2-e.speed**2)<1e-9);});
test('Retired racer cannot acquire a synthetic finish',()=>{const r=noBrake.results[0];eq(r.finish_time,null);eq(r.place,null);assert(!noBrake.events.some(e=>e.kind==='finish'));});
const railCourse=X.compile(X.initial()).course,railNative=solo(railCourse,fixture.b,{passing:false,rail_following:true}),railSelected=solo(railCourse,{...fixture.b,rail_source:'SYNTHETIC.CONTROLLED.GUIDE',rail_friction:.08,rail_support:2.3},{passing:false,rail_following:true});
test('Rail-following produces physical contact events',()=>assert(railNative.events.some(e=>e.kind==='rail_contact')));
test('Smoother supported guide reduces wall-contact dissipation',()=>assert(railSelected.results[0].rail_work<railNative.results[0].rail_work));
test('Guide component does not grant free output away from a wall',()=>{const a=solo(railCourse,fixture.b),b=solo(railCourse,{...fixture.b,rail_source:'SYNTHETIC.GUIDE',rail_friction:.08,rail_support:2.3});eq(a.results[0].rail_work,0);eq(b.results[0].rail_work,0);eq(a.results[0].finish_time,b.results[0].finish_time);});
test('W09 running uses deterministic event-local replay',()=>eq(solo(fixture.course,yesBrake.results[0].build),yesBrake));
test('Brake result remains bounded under a half timestep',()=>{const r=solo(fixture.course,yesBrake.results[0].build,{passing:false},.005);assert(r.results[0].finish_time!==null);assert(Math.abs(r.results[0].finish_time-yesBrake.results[0].finish_time)<.3);});
test('New specimens can be bred with their own required facility',()=>{let w=W.initial();w.accounts.player+=200;w.accounts.external-=200;for(const sex of ['A','B'])w=apply(w,{type:'buyLive',id:'W07.SHOP.LIVE.feltmoth.'+sex});w=apply(w,{type:'facility',id:'drawer'});const r=W.apply(w,{type:'breed',parents:['W07.SHOP.LIVE.feltmoth.A','W07.SHOP.LIVE.feltmoth.B'],auto:false,repeat:false});assert(r.world.broods.at(-1).kind==='feltmoth');});
// Synthetic funding above is explicit model-test setup, not used in the browser paths.
evidence.scope='Controlled synthetic model inputs unless marked actual inventory; normalized units. No human calibration.';evidence.brake={inputs:fixture.b,no_brake:{finish:noBrake.results[0].finish_time,launch:noBrake.events.filter(e=>e.kind==='ramp_launch')},contacting:{finish:yesBrake.results[0].finish_time,work:yesBrake.results[0].brake_work,launch:yesBrake.events.filter(e=>e.kind==='ramp_launch')}};evidence.rail={native:{finish:railNative.results[0].finish_time,work:railNative.results[0].rail_work},selected:{finish:railSelected.results[0].finish_time,work:railSelected.results[0].rail_work}};
fs.writeFileSync(path.join(__dirname,'../evidence/track_model_tests.json'),JSON.stringify({tests:results,passed:results.filter(r=>r.passed).length,failed:results.filter(r=>!r.passed).length},null,2));fs.writeFileSync(path.join(__dirname,'../evidence/controlled_comparisons.json'),JSON.stringify(evidence,null,2));console.log('TRACK TESTS:',results.filter(r=>r.passed).length,'/',results.length);
