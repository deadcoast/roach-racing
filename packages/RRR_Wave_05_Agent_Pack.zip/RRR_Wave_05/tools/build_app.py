from pathlib import Path
root=Path(__file__).resolve().parents[1]
text=(root/'src/template.html').read_text()
for key,file in [('CSS','style.css'),('ENGINE','race.js'),('BENCH','bench.js'),('ART','anatomy.js'),('APP','app.js')]:
 value=(root/'src'/file).read_text()
 if '</script' in value.lower():raise ValueError('Unsafe inline script terminator')
 text=text.replace('__'+key+'__',value)
(root/'RRR_Living_Workbench_v0.5.html').write_text(text,encoding='utf8')
print('Built',len(text.encode()),'bytes')
