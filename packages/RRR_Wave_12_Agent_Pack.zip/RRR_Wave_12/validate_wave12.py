"""Validate W12 at declared operator, preservation and optional browser scopes."""
from pathlib import Path
import argparse, hashlib, json, os, platform, subprocess, sys
import jsonschema
ROOT=Path(__file__).resolve().parent
E=ROOT/'evidence';E.mkdir(exist_ok=True)
sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
def command(args,label,timeout=180):
    print('RUN '+label,flush=True)
    env=dict(os.environ,PYTHONDONTWRITEBYTECODE='1')
    result=subprocess.run(args,cwd=ROOT,env=env,capture_output=True,text=True,timeout=timeout)
    (E/(label+'_stdout.txt')).write_text(result.stdout+'\n'+result.stderr)
    if result.returncode:
        print(result.stdout,result.stderr);raise RuntimeError(label+' failed with '+str(result.returncode))
    print('PASS '+label,flush=True)
    return result
p=argparse.ArgumentParser();p.add_argument('--browser',action='store_true',help='Run actual Chromium controls using declared stock and normal funds');args=p.parse_args()
command([sys.executable,'tools/build_app.py'],'build')
for f in sorted((ROOT/'src').glob('*.js')):command(['node','--check',str(f)],'syntax_'+f.stem)
spec=json.loads((ROOT/'RRR_Wave_12.spec').read_text());schema=json.loads((ROOT/'RRR_Wave_12.schema.json').read_text());jsonschema.Draft202012Validator(schema).validate(spec)
base=json.loads((ROOT/'reference/world_context_v0.11.json').read_text());current=json.loads((ROOT/'world_context_v0.12.json').read_text())
assert sha(ROOT/'reference/world_context_v0.11.json')==spec['manifest']['base_sha256'],'Baseline bytes changed'
for key in base:
    if key not in ('manifest','development_waves'):assert current[key]==base[key],key
assert current['development_waves'][:-1]==base['development_waves'],'Historical waves changed'
assert current['development_waves'][-1]==spec,'Cumulative wave differs'
assert current['manifest']['latest_wave']=='W12' and current['manifest']['version']=='0.12.0'
unchanged=['race.js','bench.js','anatomy.js','club.js','circuits.js']
for name in unchanged:assert (ROOT/'src'/name).read_bytes()==(ROOT/'reference/w11_release/src'/name).read_bytes(),name
ids=[]
for item in spec['Reference']['sources']+spec['Plan']['tasks']+spec['Plan']['next']+spec['repairs']+spec['entities']+spec['world_threads']:
    ids.append(item['id'])
for group in spec['rule_groups']:ids.extend(r['id'] for r in group['rules'])
assert len(ids)==len(set(ids)),'Duplicate spec identity'
prior=set()
for task in spec['Plan']['tasks']:
    assert set(task['depends_on'])<=prior,'Task order not dependency-complete';prior.add(task['id'])
js="const K=require('./src/maker.js');console.log(JSON.stringify({briefs:K.BRIEFS,metrics:K.METRICS,mechanisms:K.MECHANISMS}));"
profiles=json.loads(subprocess.check_output(['node','-e',js],cwd=ROOT,text=True))
assert profiles['briefs']==spec['customer_briefs'] and profiles['metrics']==spec['Reference']['source_roles'] and profiles['mechanisms']==spec['Reference']['mechanism_substitutions'],'Spec/code profile drift'
for name in ['maker','migration','club','trackworks','bench_regression','parity']:command(['node','tests/'+name+'.cjs'],name)
reports={}
for label,name in [('maker','maker_report.json'),('migration','migration_report.json'),('club','club_report.json'),('trackworks','track_model_tests.json'),('bench','model_report.json'),('parity','parity_report.json')]:
    r=json.loads((E/name).read_text())
    if label=='bench':counts=r['summary']
    elif label=='parity':counts={'passed':sum(x['passed'] for x in r['cases']),'failed':sum(not x['passed'] for x in r['cases'])}
    else:counts={'passed':r['passed'],'failed':r['failed']}
    assert counts['failed']==0,label;reports[label]={'file':name,**counts}
if args.browser:
    command([sys.executable,'tests/browser_maker.py'],'browser_maker',timeout=360)
    command([sys.executable,'tests/browser_retail.py'],'browser_retail',timeout=180)
html=ROOT/'RRR_Makers_Bloodlines_v0.12.html'
browser=[]
for name in ['browser_maker_report.json','browser_retail_report.json']:
    if (E/name).exists():
        r=json.loads((E/name).read_text());fresh=r.get('html_sha256')==sha(html)
        assert fresh,'Browser report is for different HTML: '+name
        assert r['failed']==0 and r['errors']==[],name
        browser.append({'file':name,'passed':r['passed'],'failed':r['failed'],'errors':len(r['errors']),'exact_html_hash_matches':fresh,'executed_in_this_invocation':args.browser,'navigation':r['navigation']})
report={'wave':'W12','version':'0.12.0','status':'passed_at_declared_scope','environment':{'python':sys.version.split()[0],'node':subprocess.check_output(['node','--version'],text=True).strip(),'platform':platform.system()},'html_sha256':sha(html),'spec_sha256':sha(ROOT/'RRR_Wave_12.spec'),'baseline_sha256':spec['manifest']['base_sha256'],'schema_valid':True,'task_dependencies_valid':True,'definition_ids_unique':True,'prior_context_preserved':True,'unchanged_W11_modules':unchanged,'counts':reports,'browser':browser,'limits':['Local authored model; no calibrated economy or biology.','Synthetic capital in some operator fixtures; browser paths use actual ordinary commands and starting resources.','Browser set_content follows blocked native file navigation; native Windows/macOS persistence, touch and human playtesting remain unverified.','Positive gross receipts and test counts do not prove profit, originality or retention.']}
(E/'validation_report.json').write_text(json.dumps(report,indent=2)+'\n');print(json.dumps(report,indent=2))
