# Replay surface review

Reviewed the captured 1440px desktop and 390px mobile layouts. Track, playback controls, running order, component identities and the separate transaction example remain visible. The mobile layout stacks panels without horizontal overflow. The two entrants have distinct marks and colors; hop height is indicated separately from ground position. The replay is an experiment-review surface, not finished production game art.

Playback, pause, event switching, scrub, reset and focus retention were exercised in Chromium on Linux. The runtime blocked file-URI navigation; the exact delivered HTML bytes were executed on a fresh blank page instead. This does not certify direct-file launch on Windows or macOS. The browser report records the tested HTML hash. No human playtesting was performed.
