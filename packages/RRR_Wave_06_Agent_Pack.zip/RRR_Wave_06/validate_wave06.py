#!/usr/bin/env python3
"""Check the shared-world slice at its declared scope; not a gameplay-quality certificate."""
from __future__ import annotations
import argparse, hashlib, json, os, re, subprocess, sys, tempfile, zipfile
from pathlib import Path
from datetime import datetime, timezone
ROOT=Path(__file__).resolve().parent
EV=ROOT/'evidence'
def sha(p): return hashlib.sha256(Path(p).read_bytes()).hexdigest()
def load(p):return json.loads((ROOT/p).read_text(encoding='utf-8'))
def ids(value):
    if isinstance(value,dict):
        if isinstance(value.get('id'),str):yield value['id']
        for v in value.values():yield from ids(v)
    elif isinstance(value,list):
        for v in value:yield from ids(v)
def run(cmd,log,cwd=ROOT,env=None):
    r=subprocess.run(cmd,cwd=cwd,env=env,capture_output=True,text=True,timeout=90)
    (EV/log).write_text(r.stdout+'\n'+r.stderr,encoding='utf-8')
    if r.returncode:raise RuntimeError(f'{cmd} failed; inspect evidence/{log}')
    return r

def main():
    parser=argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--browser',action='store_true')
    args=parser.parse_args(); EV.mkdir(exist_ok=True); checks=[]
    def check(name,ok):
        if not ok:raise AssertionError(name)
        checks.append({'name':name,'passed':True})
    spec=load('RRR_Wave_06.spec');base=load('reference/world_context_v0.5.json');world=load('world_context_v0.6.json')
    import jsonschema
    jsonschema.Draft202012Validator(load('wave06.schema.json')).validate(spec)
    check('Specification structure',True)
    check('Baseline exact bytes',sha(ROOT/'reference/world_context_v0.5.json')==spec['manifest']['base_sha256'])
    for k,v in base.items():
        if k not in ['manifest','development_waves']:check('Preserved base field '+k,world[k]==v)
    check('All previous development waves unchanged',world['development_waves'][:-1]==base['development_waves'])
    check('Exactly current spec appended',world['development_waves'][-1]==spec)
    oldids=set(ids(base));rules=[r for g in spec['systems'] for r in g['rules']];ruleids=[r['id'] for r in rules]
    check('Current rule IDs unique and nonoverwriting',len(ruleids)==len(set(ruleids)) and not(set(ruleids)&oldids))
    for g in spec['systems']:
        for ref in g['refines']:check('Known refinement '+ref,ref in oldids)
    seen=oldids.copy()
    for t in spec['Plan']['tasks']:
        check('Ordered dependency '+t['id'],set(t['depends_on'])<=seen and t['continues'] in oldids);seen.add(t['id'])
    for t in spec['Plan']['next_tasks']:check('Known continuation '+t['id'],set(t['continuation'])<=oldids)
    for t in spec['operational_threads']:check('Existing actor '+t['actor_ref'],t['actor_ref'] in oldids)
    html=(ROOT/'src/template.html').read_text()
    for key,fn in [('CSS','style.css'),('ENGINE','race.js'),('BENCH','bench.js'),('ART','anatomy.js'),('WORLD','world.js'),('APP','app.js')]:html=html.replace('__'+key+'__',(ROOT/'src'/fn).read_text())
    check('Exact standalone source build',html.encode()==(ROOT/'RRR_Living_World_v0.6.html').read_bytes())
    check('No unexpanded build markers',not re.search(r'__(CSS|ENGINE|BENCH|ART|WORLD|APP)__',html))
    check('No external script/style dependencies',not re.search(r'<script[^>]+src=|<link[^>]+rel=[\"\']stylesheet',html,re.I))
    for f in ['race.js','bench.js','world.js','app.js','anatomy.js']:run(['node','--check','src/'+f],'syntax_'+f+'.txt')
    run(['node','tests/world_tests.cjs'],'world_console.txt')
    run(['node','tests/bench_regression.cjs'],'bench_regression_console.txt')
    run(['node','tests/parity.cjs'],'parity_console.txt')
    w=load('evidence/world_test_report.json');b=load('evidence/model_report.json');p=load('evidence/parity_report.json')
    check('New shared-world tests',w['passed']==w['tests'] and all(c['status']=='passed' for c in w['checks']))
    check('Preserved bench regression',b['summary']['failed']==0 and b['summary']['passed']==len(b['tests']))
    check('Six earlier Python/browser model comparisons',len(p['cases'])==6 and all(c['passed'] for c in p['cases']))
    check('Spec examples match executed outcomes',spec['fixture_summary']['repeated_example']==w['examples']['repeated'] and all(w['examples']['broodToTrack'][k]==v for k,v in spec['fixture_summary']['brood_to_track'].items()))
    prior={}
    with tempfile.TemporaryDirectory(prefix='rrr-w06-prior-') as tmp:
        with zipfile.ZipFile(ROOT/'reference/RRR_Wave_05_Agent_Pack.zip') as z:
            for n in z.namelist():
                target=(Path(tmp)/n).resolve()
                if not target.is_relative_to(Path(tmp).resolve()):raise ValueError('Unsafe reference archive path')
            z.extractall(tmp)
        src=Path(tmp)/'RRR_Wave_05'
        for f in ['race.js','anatomy.js']:check('Byte-identical prior '+f,sha(ROOT/'src'/f)==sha(src/'src'/f))
        env=dict(os.environ);env['PYTHONPATH']=str(src/'reference/wave04_model')+os.pathsep+env.get('PYTHONPATH','')
        for wave in ['04','03']:
            result=run([sys.executable,'-B','-m','unittest','discover','-s','reference','-p',f'test_wave{wave}.py','-v'],f'wave{wave}_regression.txt',cwd=src,env=env)
            match=re.search(r'Ran (\d+) tests',result.stderr)
            check('Earlier W'+wave+' suite executed',bool(match));prior['W'+wave]={'passed':int(match.group(1)),'source':'preserved actual W05 archive'}
    if args.browser:run([sys.executable,'tests/browser_world.py'],'browser_console.txt')
    browser=load('evidence/browser_report.json')
    check('Browser evidence matches exact current HTML',browser['html_sha256']==sha(ROOT/'RRR_Living_World_v0.6.html'))
    check('Browser no uncaught errors',browser['errors']==[])
    tracked=[ROOT/'RRR_Wave_06.spec',ROOT/'RRR_Living_World_v0.6.html',ROOT/'world_context_v0.6.json',ROOT/'validate_wave06.py',ROOT/'wave06.schema.json']
    for d in ['src','tools','tests']:tracked.extend(p for p in (ROOT/d).iterdir() if p.is_file())
    report={'timestamp_utc':datetime.now(timezone.utc).isoformat(),'status':'passed','scope':'Two-form collection, one Hopper breeding profile, shared local inventory/clock, original editable bench and path-space races; no full-game or economy certification.','structural_checks':checks,'new_behavioral':{'passed':w['passed'],'failed':w['tests']-w['passed']},'bench_regression':b['summary'],'port_comparisons':len(p['cases']),'prior_regressions':prior,'browser':{'checks':browser['count'],'rerun_this_validation':args.browser,'html_sha256':browser['html_sha256'],'modes':browser['modes']},'input_hashes':{str(p.relative_to(ROOT)):sha(p) for p in sorted(tracked)},'limits':spec['implementation_boundaries']}
    (EV/'validation_report.json').write_text(json.dumps(report,indent=2)+'\n')
    (EV/'validation_failure.txt').unlink(missing_ok=True)
    print(json.dumps({k:report[k] for k in ['status','new_behavioral','bench_regression','port_comparisons','prior_regressions','browser']},indent=2))
if __name__=='__main__':
    try:main()
    except Exception as e:
        EV.mkdir(exist_ok=True);(EV/'validation_failure.txt').write_text(f'{type(e).__name__}: {e}\n');raise
