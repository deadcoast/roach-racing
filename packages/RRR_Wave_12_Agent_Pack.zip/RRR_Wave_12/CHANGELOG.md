# Changes — Wave v0.12

## Added
- Actual-stock complete kit production with explicit reference-native and per-preparation promises.
- Mechanism-compatible, measured substitutions and independent fitting checks.
- Packed host/component custody, same-tin opening and recipient draft/fit/race path.
- Two complete-kit briefs, two evidence-backed living breeder briefs and bounded owner-approved champion inquiries.
- Main Two Nets independent-maker shelf and actual funded counter handovers.
- Maker interface, narrow layout, actual biological artwork, per-axis authoring, targeted donor links and narrow line claims.

## Corrected along the implementation path
- Mechanical advantage is a target-range choice, not universally higher-better.
- Legacy compiler defaults are represented as their actual declared measurements.
- Per-axis promises avoid false blanket equivalence across unrelated properties.
- Opened supplier receipts no longer claim perpetual host ownership.
- Catalogue synchronization precedes restored maker validation.
- Same-counter buyback offers inform the current retail quote.
- Line evidence labels distinguish measured animals and measured broods from unmeasured descendants.

## Preserved
Existing race, bench, artwork, club and circuit engine bytes; prior identity, genetics, cash, historical results and cumulative records. W10 source was not recovered; its feature is a new W12 reconstruction.

## Not claimed
Automatic NPC buying/building, profitable or calibrated maker careers, broad transport viability, formal revision-series editing, user-defined cross-body adaptation, new donors or genetics, improved articulated racing, Factional/Flyer runtime, native-platform persistence, human usability, originality or retention certification.
