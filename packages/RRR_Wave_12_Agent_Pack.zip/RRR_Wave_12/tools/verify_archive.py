"""Inspect the delivered ZIP independently, then rebuild/test its extracted source."""
from pathlib import Path, PurePosixPath
import argparse, hashlib, json, os, stat, subprocess, sys, tempfile, zipfile

def sha(path):return hashlib.sha256(path.read_bytes()).hexdigest()
p=argparse.ArgumentParser();p.add_argument('archive',type=Path);p.add_argument('--run',action='store_true');p.add_argument('--browser',action='store_true');p.add_argument('--report',type=Path);args=p.parse_args()
archive=args.archive.resolve()
with tempfile.TemporaryDirectory(prefix='rrr-w12-archive-') as tmp:
    dest=Path(tmp)
    with zipfile.ZipFile(archive) as z:
        names=[i.filename for i in z.infolist()]
        if len(names)!=len(set(names)):raise ValueError('Duplicate archive entry')
        for info in z.infolist():
            path=PurePosixPath(info.filename)
            if path.is_absolute() or '..' in path.parts or '\\' in info.filename:raise ValueError('Unsafe archive path')
            if path.parts[0]!='RRR_Wave_12':raise ValueError('Unexpected archive root')
            if stat.S_ISLNK(info.external_attr>>16):raise ValueError('Archive symlink rejected')
        z.extractall(dest)
    root=dest/'RRR_Wave_12'
    manifest=json.loads((root/'package-manifest.json').read_text())
    actual={str(f.relative_to(root)) for f in root.rglob('*') if f.is_file()}
    assert actual==set(manifest['files'])|{'package-manifest.json'},'Archive inventory differs'
    for name,digest in manifest['files'].items():assert sha(root/name)==digest,name+' hash differs'
    immutable={name:digest for name,digest in manifest['files'].items() if name.startswith('src/') or name.endswith('.html') or name in ['RRR_Wave_12.spec','world_context_v0.12.json']}
    result={'archive_sha256':sha(archive),'file_hashes_checked':len(manifest['files']),'inventory_exact':True,'paths_checked':True,'rebuild_and_tests':'not requested'}
    if args.run:
        command=[sys.executable,'-u','validate_wave12.py']+(['--browser'] if args.browser else [])
        completed=subprocess.run(command,cwd=root,env=dict(os.environ,PYTHONDONTWRITEBYTECODE='1'),capture_output=True,text=True,timeout=900)
        result['validation_exit']=completed.returncode
        if completed.returncode:print(completed.stdout,completed.stderr);raise SystemExit(completed.returncode)
        for name,digest in immutable.items():assert sha(root/name)==digest,name+' changed while rebuilding'
        result.update(rebuild_and_tests='passed',source_application_spec_context_after_rebuild='unchanged',validation=json.loads((root/'evidence/validation_report.json').read_text()))
    if args.report:args.report.resolve().write_text(json.dumps(result,indent=2)+'\n')
    print(json.dumps(result,indent=2))
