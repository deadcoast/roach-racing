"""Behavioral checks for the declared model domain, not fun or realism claims."""
import unittest
from copy import deepcopy
from dataclasses import replace
from functools import lru_cache
from pathlib import Path
import sys
sys.path.insert(0,str(Path(__file__).resolve().parents[1]/'model'))
from race import *
from fixtures import comparative_runs, encounter, integrated_meeting
from hobby import *
from w03_model import RuleViolation, integrated_fixture

@lru_cache(None)
def scene(mode):return encounter(mode)[1]

class CourseChecks(unittest.TestCase):
    def test_different_layouts_get_distinct_identity(self):
        self.assertNotEqual(foundry_course(straight=12).id,foundry_course(straight=20).id)
        self.assertNotEqual(foundry_course(grip=1.6).id,foundry_course(grip=1.2).id)
    def test_layout_identity_is_stable_across_race_laps(self):
        self.assertEqual(foundry_course(laps=1).id,foundry_course(laps=3).id)
    def test_closed_geometry(self):
        c=foundry_course();x,y,h=c.pieces[-1].pose(c.pieces[-1].length)
        self.assertAlmostEqual(x,0);self.assertAlmostEqual(y,0);self.assertAlmostEqual(h,2*math.pi)
    def test_disconnected_port_rejected(self):
        c=foundry_course();bad=list(c.pieces);bad[1]=replace(bad[1],x=99)
        with self.assertRaises(RuleViolation):Course('bad',bad)
    def test_duplicate_physical_piece_rejected(self):
        c=foundry_course();bad=list(c.pieces);bad[1]=replace(bad[1],id=bad[0].id)
        with self.assertRaises(RuleViolation):Course('bad',bad)
    def test_length_not_footprint(self):
        self.assertAlmostEqual(foundry_course().length,36+6*math.pi)
    def test_curved_tube_blocks_unsteered_jump(self):
        self.assertFalse(foundry_course().clearance(11,4,.3))
    def test_ceiling_blocks_launch(self):
        c=foundry_course();c.pieces[0]=replace(c.pieces[0],ceiling=.2)
        self.assertFalse(c.clearance(0,1,.5))
    def test_start_overlap_rejected(self):
        a=Build('a','a','a',(),'native',None);b=replace(a,id='b',host_id='b')
        with self.assertRaises(RuleViolation):Race(foundry_course(),[Runner(a),Runner(b)])
    def test_coarse_step_rejected(self):
        a=Build('a','a','a',(),'native',None,cadence=1000)
        with self.assertRaises(RuleViolation):Race(foundry_course(),[Runner(a)])

class LineageChecks(unittest.TestCase):
    def test_w03_cash_and_asset_bridge(self):
        w=resume_workshop();old=integrated_fixture()
        self.assertEqual(w.cash['player'],old['closing_player_cash'])
        self.assertEqual(w.total_money(),old['all_accounts_and_escrow'])
        self.assertEqual(w.ledger,old['ledger'])
        self.assertEqual(w.sects['UPGRADE-DRIVE'].custody,'inventory')
    def test_purchase_not_installation(self):
        self.assertEqual(compile_workshop(resume_workshop()).drive_source,'HOST.native_drive')
    def test_installed_source_survives_compilation(self):
        w=resume_workshop();w.install('fit','UPGRADE-DRIVE','player','HOST');b=compile_workshop(w)
        self.assertEqual(b.drive_source,'UPGRADE-DRIVE');self.assertEqual(b.hopper_source,'H-6')
        self.assertIn('B1-6',b.provenance)
    def test_inherited_trait_binding(self):
        w=resume_workshop();b=compile_workshop(w)
        p=hopper_phenotype(w.stocks[w.sects['H-6'].donor_id].genotype)
        self.assertEqual(b.hopper,tuple(p[k] for k in ('spring_return','phase_error','settle_time')))
    def test_same_asset_not_multiple_roles(self):
        b=compile_workshop(resume_workshop());self.assertEqual(b.component_ids,('H-6',))
    def test_genuine_drive_improvement_in_course(self):
        _,r=comparative_runs();self.assertLess(r['after']['results'][0]['finish_time'],r['before']['results'][0]['finish_time'])
    def test_snapshot_not_mutated_after_race(self):
        w=resume_workshop();b=compile_workshop(w);r=Race(foundry_course(laps=1),[Runner(b)])
        w.stocks['B1-6'].genotype=((1,1),(1,1),(1,1))
        self.assertEqual(r.runners[0].build.hopper,b.hopper)
    def test_duplicate_component_rejected(self):
        with self.assertRaises(RuleViolation):Build('a','a','a',('same','same'),'same',None)

class RaceChecks(unittest.TestCase):
    def test_finish_requires_all_gates(self):
        for row in scene('pass')['results']:
            self.assertEqual(row['gates'],row['required_gates']);self.assertIsNotNone(row['finish_time'])
    def test_overtake_is_position_change(self):
        self.assertTrue(any(e['kind']=='overtake' for e in scene('pass')['events']))
    def test_horn_requires_contact(self):
        events=scene('horn')['events'];self.assertTrue(any(e['kind']=='ram_contact' for e in events))
        self.assertFalse(any(e['kind']=='ram_contact' for e in scene('pass')['events']))
    def test_claw_response_and_recovery(self):
        kinds=[e['kind'] for e in scene('claw')['events']]
        self.assertIn('claw_contact',kinds);self.assertIn('recovered',kinds)
    def test_airborne_overtake(self):
        self.assertTrue(any(e['kind']=='overtake' and e['airborne'] for e in scene('hop')['events']))
    def test_jump_lands_and_settles(self):
        kinds=[e['kind'] for e in scene('hop')['events']]
        for k in ('jump_load','takeoff','landing','recovered'):self.assertIn(k,kinds)
    def test_energy_never_rises_or_negative(self):
        r=scene('hop');last={row['id']:row['build']['reserve'] for row in r['results']}
        for frame in r['frames']:
            for row in frame['runners']:
                self.assertGreaterEqual(row['energy'],0);self.assertLessEqual(row['energy'],last[row['id']]+EPS);last[row['id']]=row['energy']
    def test_speedster_actual_capability(self):
        b=Build('a','a','Disguised stabilizer',(),'native',None,horn=True)
        self.assertFalse(legal(b,'speedsters'));self.assertTrue(legal(b,'open'))
    def test_fireworks_light_armor(self):
        b=Build('a','a','a',(),'native',None,horn=True,armor='heavy')
        self.assertFalse(legal(b,'fireworks'));self.assertTrue(legal(replace(b,armor='light'),'fireworks'))
    def test_entry_order_independence(self):
        a=Build('a','a','a',(),'native',None);b=replace(a,id='b',host_id='b',cadence=12)
        entrants=[Runner(a,d=-.3),Runner(b,d=.3)]
        x=Race(foundry_course(laps=1),entrants).run();y=Race(foundry_course(laps=1),list(reversed(entrants))).run()
        self.assertEqual(x,y)
    def test_timestep_halving_solo(self):
        _,a=comparative_runs(.01);_,b=comparative_runs(.005)
        for k in a:self.assertLess(abs(a[k]['results'][0]['finish_time']-b[k]['results'][0]['finish_time']),.15)
    def test_unfinished_racer_no_place(self):
        b=Build('a','a','a',(),'native',None,reserve=0)
        r=Race(foundry_course(),[Runner(b)]).run(max_time=.1)
        self.assertIsNone(r['results'][0]['place']);self.assertIsNone(r['results'][0]['finish_time'])

class HobbyChecks(unittest.TestCase):
    def setUp(self):
        self.result=deepcopy(scene('hop'));self.record=register_result(self.result,'event')
        self.w=resume_workshop();self.w.cash.update({'sponsor':90,'club':0,'npc':0,'trial':70})
        self.owners={'W04.ENTRY.WORKSHOP':'player','W04.ENTRY.CLUB':'npc'}
    def test_funded_prizes_conserve_cash(self):
        total=self.w.total_money();settle_meeting(self.w,'event',self.record,self.owners,'sponsor','club')
        self.assertEqual(total,self.w.total_money());self.assertEqual(self.w.cash['player'],172)
    def test_result_replay_no_second_prize(self):
        a=settle_meeting(self.w,'event',self.record,self.owners,'sponsor','club');snapshot=deepcopy(self.w.cash)
        b=settle_meeting(self.w,'event',self.record,self.owners,'sponsor','club');self.assertEqual(a,b);self.assertEqual(snapshot,self.w.cash)
    def test_unfunded_event_atomic_failure(self):
        self.w.cash['sponsor']=0;before=deepcopy(self.w.__dict__)
        with self.assertRaises(RuleViolation):settle_meeting(self.w,'event',self.record,self.owners,'sponsor','club')
        self.assertEqual(before,self.w.__dict__)
    def test_changed_result_rejected(self):
        self.record['classification'][0]['finish_time']=0
        with self.assertRaises(RuleViolation):settle_meeting(self.w,'event',self.record,self.owners,'sponsor','club')
    def test_trial_is_not_income(self):
        before=self.w.cash['player'];r=funded_trial(self.w,'event','trial')
        self.assertEqual(self.w.cash['player'],before);self.assertEqual(r['escrow'],40);self.assertEqual(r['seller_revenue'],0)
    def test_public_card_no_hidden_traits(self):
        card=public_build_card(self.result['results'][0],True)
        self.assertNotIn('hopper',card);self.assertNotIn('genotype',card);self.assertNotIn('provenance',card)
    def test_public_card_opt_out(self):
        self.assertNotIn('component_ids',public_build_card(self.result['results'][0],False))
    def test_tied_prizes_pooled(self):
        result=deepcopy(self.result)
        for r in result['results']:r['finish_time']=10.;r['place']=1
        record=register_result(result,'tie')
        receipt=settle_meeting(self.w,'tie',record,self.owners,'sponsor','club')
        self.assertEqual(receipt['prizes'],{'player':21,'npc':21})
    def test_history_keeps_build_before_later_change(self):
        original=deepcopy(self.record);self.result['results'][0]['build']['name']='changed'
        self.assertEqual(self.record,original)

if __name__=='__main__':unittest.main(verbosity=2)
