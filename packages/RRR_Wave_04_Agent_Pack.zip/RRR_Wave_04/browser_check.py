"""Optional local-browser QA; requires Playwright and a Chromium executable."""
from pathlib import Path
import json
import hashlib
import os
import shutil
from playwright.sync_api import sync_playwright
root=Path(__file__).resolve().parent
with sync_playwright() as p:
 browser=p.chromium.launch(executable_path=os.environ.get('CHROMIUM_EXECUTABLE') or shutil.which('chromium') or shutil.which('google-chrome'),headless=True,args=['--no-sandbox'])
 page=browser.new_page(viewport={'width':1440,'height':1200},device_scale_factor=1)
 errors=[];page.on('pageerror',lambda e:errors.append(str(e)))
 file_uri_error=None
 try:
  page.goto((root/'Race_Observatory.html').as_uri())
  loaded_via='file URI'
 except Exception as exc:
  file_uri_error=str(exc).splitlines()[0]
  page.close()
  page=browser.new_page(viewport={'width':1440,'height':1200},device_scale_factor=1)
  page.on('pageerror',lambda e:errors.append(str(e)))
  page.set_content((root/'Race_Observatory.html').read_text(),wait_until='load')
  loaded_via='exact delivered HTML via set_content; file URI blocked by host policy'
 page.wait_for_timeout(200)
 page.evaluate('RRR_REPLAY.seek(5.9)');page.screenshot(path=str(root/'evidence/replay_desktop.png'),full_page=True)
 assert not errors, errors
 page.locator('[data-mode="horn"]').click();assert page.evaluate('RRR_REPLAY.state().mode')=='horn'
 page.locator('#play').click();page.locator('.racer').first.focus();page.wait_for_timeout(200);assert page.evaluate('document.activeElement.classList.contains("racer")');assert page.evaluate('RRR_REPLAY.state().t')>0
 page.locator('#play').click();assert not page.evaluate('RRR_REPLAY.state().playing')
 page.locator('#scrub').evaluate('(el)=>{el.value=1000;el.dispatchEvent(new Event("input",{bubbles:true}));}');assert abs(page.evaluate('RRR_REPLAY.state().t-RRR_REPLAY.state().end'))<.001
 page.locator('#reset').click();assert page.evaluate('RRR_REPLAY.state().t')==0
 page.locator('[data-mode="hop"]').click();page.evaluate('RRR_REPLAY.seek(5.9)')
 page.set_viewport_size({'width':390,'height':844});page.wait_for_timeout(100)
 assert page.evaluate('document.documentElement.scrollWidth<=window.innerWidth'), 'mobile overflow'
 page.screenshot(path=str(root/'evidence/replay_mobile.png'),full_page=True)
 assert not errors,errors
 browser.close()
(root/'evidence/browser_report.json').write_text(json.dumps({'html_sha256':hashlib.sha256((root/'Race_Observatory.html').read_bytes()).hexdigest(),'browser':'Chromium via Playwright, Linux','loaded_via':loaded_via,'file_uri_error':file_uri_error,'console_errors':errors,
 'checks':['exact delivered HTML executes','experiment switching','play advances time','pause stops playback','racer focus preserved during playback','scrub to finish','reset','390px no horizontal overflow'],
 'limits':['Not user playtesting','Not Windows/macOS execution','Not an editable game','Screenshots require separate visual inspection']},indent=2))
